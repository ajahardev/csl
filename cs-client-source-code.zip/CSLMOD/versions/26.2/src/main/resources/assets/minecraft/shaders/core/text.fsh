#version 330

// CS Client 26.2 compatibility source for Minecraft's text pipeline.
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
#ifdef IS_GRAYSCALE
    vec4 sampled = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 sampled = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 result = sampled * vertexColor;
#else
    vec4 result = sampled * vertexColor * ColorModulator;
#endif

    if (result.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = result * ColorModulator;
#elif defined(IS_GUI)
    fragColor = result;
#else
    fragColor = apply_fog(result, sphericalVertexDistance, cylindricalVertexDistance,
            FogEnvironmentalStart, FogEnvironmentalEnd,
            FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
