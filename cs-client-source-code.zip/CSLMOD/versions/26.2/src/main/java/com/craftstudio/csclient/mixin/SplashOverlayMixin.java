package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.impl.ui.RenderScopeImpl;
import com.craftstudio.csclient.ui.LoadingVisuals;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.server.packs.resources.ReloadInstance;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

/**
 * CS visual replacement for the 26.2 reload overlay.
 *
 * In 26.2 vanilla moved reload completion/onFinish into LoadingOverlay#tick.
 * The visual injection deliberately draws only; vanilla tick still owns completion,
 * error propagation and screen reinitialisation exactly once.
 */
@Mixin(value = LoadingOverlay.class, priority = 900)
public abstract class SplashOverlayMixin {

    @Shadow private Minecraft minecraft;
    @Shadow private ReloadInstance reload;
    @Shadow private long fadeOutStart;
    @Shadow private long fadeInStart;
    @Shadow private float currentProgress;

    /**
     * Non-destructive HEAD injection keeps vanilla bytecode and constants intact
     * for RRLS and other LoadingOverlay mixins. When RRLS is installed, CS yields
     * this overlay completely so RRLS can own its animation lifecycle.
     */
    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true)
    private void csclient$extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY,
            float delta, CallbackInfo ci) {
        if (FabricLoader.getInstance().isModLoaded("rrls")) return;

        int screenWidth = context.guiWidth();
        int screenHeight = context.guiHeight();
        long currentTime = Util.getMillis();

        if (fadeInStart == -1L) {
            fadeInStart = currentTime;
        }

        float fadeOutProgress = fadeOutStart > -1L
                ? (float) (currentTime - fadeOutStart) / LoadingVisuals.FADE_OUT_MILLIS
                : -1f;
        int alpha = fadeOutProgress >= 0f
                ? Mth.ceil((1.0f - Mth.clamp(fadeOutProgress, 0f, 1f)) * 255f)
                : 255;

        RenderScope scope = new RenderScopeImpl(context);
        if (fadeOutProgress >= 0.0F) {
            renderCurrentScreen(context, mouseX, mouseY, delta);
            int overlayAlpha = computeOverlayAlpha(fadeOutProgress);
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(overlayAlpha, 0xFFFFFFFF));
        } else {
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(alpha, 0xFFFFFFFF));
        }

        float actualProgress = reload.getActualProgress();
        currentProgress = Mth.clamp(currentProgress * 0.95F + actualProgress * 0.050000012F, 0.0F, 1.0F);
        LoadingVisuals.render(scope, screenWidth, screenHeight, currentProgress, alpha, currentTime);

        // Vanilla tick has already invoked onFinish and set fadeOutStart. This
        // shorter visual fade is intentional; no second completion callback.
        if (fadeOutProgress >= 1.0F) {
            minecraft.gui.setOverlay(null);
        }
        ci.cancel();
    }

    private void renderCurrentScreen(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        if (minecraft.gui.screen() != null) {
            minecraft.gui.screen().extractRenderStateWithTooltipAndSubtitles(context, mouseX, mouseY, delta);
        }
    }

    private int computeOverlayAlpha(float progress) {
        return Mth.ceil((1.0F - Mth.clamp(progress, 0.0F, 1.0F)) * 255.0F);
    }
}
