package com.craftstudio.csclient.impl.features.mixins.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.level.BlockOutlineRenderState;
import com.craftstudio.csclient.mod.mods.BlockOverlayMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/** Recolors only the native 26.2 block-outline submit; no world geometry changes. */
@Mixin(LevelRenderer.class)
public class BlockOverlayMixin {
    @ModifyArgs(method = "submitBlockOutline", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/LevelRenderer;submitHitOutline("
                    + "Lcom/mojang/blaze3d/vertex/PoseStack;"
                    + "Lnet/minecraft/client/renderer/SubmitNodeCollector;"
                    + "Lnet/minecraft/client/renderer/rendertype/RenderType;"
                    + "Lnet/minecraft/client/renderer/state/level/BlockOutlineRenderState;IFZ)V"))
    private void csclient$outlineStyle(Args args) {
        if (!BlockOverlayMod.isActive()) return;
        // Argument order: pose, collector, render type, outline state, color, width, after-terrain.
        args.set(4, BlockOverlayMod.color());
        args.set(5, BlockOverlayMod.lineWidth());
    }
}
