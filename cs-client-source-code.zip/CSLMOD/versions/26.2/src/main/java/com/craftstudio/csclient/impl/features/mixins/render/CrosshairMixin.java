package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import com.craftstudio.csclient.mod.mods.CrosshairMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Hud.class)
public class CrosshairMixin {
    @Inject(method = "extractCrosshair", at = @At("HEAD"), cancellable = true)
    private void csclient$customCrosshair(GuiGraphicsExtractor context, DeltaTracker tracker, CallbackInfo ci) {
        if (CrosshairMod.shouldReplaceVanilla()) ci.cancel();
    }
}
