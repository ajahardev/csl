package com.craftstudio.csclient.impl.features.mixins.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import com.craftstudio.csclient.common.feature.EntityFeature;
import com.craftstudio.csclient.branding.BrandingRenderState;
import com.craftstudio.csclient.impl.features.entity.HealthRenderState;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod;
import com.craftstudio.csclient.mod.mods.ClientBrandingMod;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod.HeartRow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Captures living health into render state and submits optional mob heart labels
 * directly to the current name-tag queue. Direct submission avoids relying on
 * a mob's vanilla custom-name visibility before a label is rendered.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState> {
    private static final Identifier CS_HEART_FONT = Identifier.fromNamespaceAndPath("csclient", "health_hearts");
    private static final Component[] CS_BRAND_LABELS = {
            brandLabel("brand_logo_small"), brandLabel("brand_logo"), brandLabel("brand_logo_large")
    };

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void csclient$captureHealth(T entity, S state, float tickDelta, CallbackInfo ci) {
        if (!(state instanceof HealthRenderState hrs)) return;

        float health = entity.getHealth();
        float maxHealth = entity.getMaxHealth();
        hrs.csclient$setHealth(health, maxHealth);
        hrs.csclient$setAbsorption(entity.getAbsorptionAmount());

        EntityFeature.EntityType type;
        if (entity instanceof Player) type = EntityFeature.EntityType.PLAYER;
        else if (entity instanceof Monster) type = EntityFeature.EntityType.HOSTILE;
        else if (entity instanceof AgeableMob) type = EntityFeature.EntityType.PASSIVE;
        else type = EntityFeature.EntityType.OTHER;
        hrs.csclient$setEntityType(type);
    }

    @Inject(method = "submit", at = @At("TAIL"))
    private void csclient$submitMobHealth(S state, PoseStack pose,
            SubmitNodeCollector queue, CameraRenderState camera, CallbackInfo ci) {
        if (state instanceof BrandingRenderState branding && branding.csclient$showBrandLogo()) {
            Vec3 base = state.nameTagAttachment != null
                    ? state.nameTagAttachment : new Vec3(0.0, state.boundingBoxHeight + 0.55, 0.0);
            queue.submitNameTag(pose, base.add(0.0, 0.36, 0.0), 0,
                    CS_BRAND_LABELS[ClientBrandingMod.logoScale()], !state.isDiscrete, state.lightCoords, camera);
        }

        if (!(state instanceof HealthRenderState hrs)
                || hrs.csclient$getEntityType() == EntityFeature.EntityType.PLAYER
                || !HealthDisplayMod.shouldShowMob(state.isInvisible, state.distanceToCameraSq,
                        hrs.csclient$getHealth(), hrs.csclient$getMaxHealth())) return;

        Vec3 position = state.nameTagAttachment != null
                ? state.nameTagAttachment
                : new Vec3(0.0, state.boundingBoxHeight + 0.55, 0.0);
        queue.submitNameTag(pose, position, 0,
                buildHeartRow(HealthDisplayMod.createHeartRow(hrs.csclient$getHealth(),
                        hrs.csclient$getMaxHealth(), hrs.csclient$getAbsorption())),
                true, state.lightCoords, camera);
    }

    private static Component brandLabel(String fontPath) {
        Identifier font = Identifier.fromNamespaceAndPath("csclient", fontPath);
        return Component.literal(ClientBrandingMod.logoGlyph()).withStyle(style -> style
                .withFont(new FontDescription.Resource(font)).withColor(0xFFFFFF));
    }

    private static Component buildHeartRow(HeartRow row) {
        MutableComponent text = Component.empty();
        appendHearts(text, row.fullGlyphs(), row.fullColor());
        appendHearts(text, row.halfGlyphs(), row.fullColor());
        appendHearts(text, row.emptyGlyphs(), row.emptyColor());
        appendHearts(text, row.absorptionGlyphs(), row.absorptionColor());
        return text;
    }

    private static void appendHearts(MutableComponent text, String glyphs, int color) {
        if (glyphs.isEmpty()) return;
        text.append(Component.literal(glyphs).withStyle(style -> style
                .withFont(new FontDescription.Resource(CS_HEART_FONT))
                .withColor(color & 0x00FFFFFF)));
    }
}
