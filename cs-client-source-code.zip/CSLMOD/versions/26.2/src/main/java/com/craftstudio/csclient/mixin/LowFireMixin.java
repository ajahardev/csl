package com.craftstudio.csclient.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import com.craftstudio.csclient.mod.mods.LowFireMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lowers, rather than hides, Minecraft 26.2's native first-person fire quad. */
@Mixin(ScreenEffectRenderer.class)
public class LowFireMixin {
    @Inject(method = "submitFire", at = @At("HEAD"))
    private static void csclient$beginLowFire(PoseStack matrices, SubmitNodeCollector queue,
            TextureAtlasSprite sprite, CallbackInfo ci) {
        if (!LowFireMod.isActive()) return;
        matrices.pushPose();
        matrices.translate(0f, LowFireMod.verticalOffset(), 0f);
    }

    @Inject(method = "submitFire", at = @At("RETURN"))
    private static void csclient$endLowFire(PoseStack matrices, SubmitNodeCollector queue,
            TextureAtlasSprite sprite, CallbackInfo ci) {
        if (LowFireMod.isActive()) matrices.popPose();
    }
}
