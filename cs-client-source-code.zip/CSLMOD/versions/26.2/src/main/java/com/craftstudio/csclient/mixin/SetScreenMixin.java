package com.craftstudio.csclient.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.impl.ui.CSClientScreenFabric;
import com.craftstudio.csclient.ui.screens.TitleMenu;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Minecraft 26.2 moved current-screen ownership from Minecraft to Gui. */
@Mixin(Gui.class)
public class SetScreenMixin {
    @Shadow @Final private Minecraft minecraft;

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen csclient$replaceTitleScreen(Screen screen) {
        if (screen instanceof PauseScreen) {
            return new CSClientScreenFabric(new PauseMenu());
        }

        if (Config.csTitleScreen.value) {
            if (screen instanceof TitleScreen) {
                return new CSClientScreenFabric(new TitleMenu());
            }
            if (screen == null && minecraft.level == null) {
                return new CSClientScreenFabric(new TitleMenu());
            }
        }

        return screen;
    }
}
