package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ClearFluidsMod;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Removes only selected first-person overlays. 26.2 owns both paths in
 * ScreenEffectRenderer#submit, so the predicates are redirected rather than
 * cancelling the complete screen-effect pass.
 */
@Mixin(ScreenEffectRenderer.class)
public class ClearFluidsOverlayMixin {
    @Redirect(method = "submit", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;isEyeInFluid(Lnet/minecraft/tags/TagKey;)Z"))
    private boolean csclient$skipWaterOverlay(LocalPlayer player, TagKey<Fluid> fluidTag) {
        return !ClearFluidsMod.shouldClearWater() && player.isEyeInFluid(fluidTag);
    }

    @Redirect(method = "submit", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;isOnFire()Z"))
    private boolean csclient$skipLavaFireOverlay(LocalPlayer player) {
        return player.isOnFire()
                && !(ClearFluidsMod.shouldClearLava() && player.isInLava());
    }
}
