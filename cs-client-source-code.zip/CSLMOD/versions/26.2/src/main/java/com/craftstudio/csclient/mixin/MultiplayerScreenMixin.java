package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.server.FeaturedServers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.ServerSelectionList;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** PlantMC server-entry protection. */
@Mixin(JoinMultiplayerScreen.class)
public abstract class MultiplayerScreenMixin extends Screen {
    @Shadow private Button editButton;
    @Shadow private Button deleteButton;
    @Shadow protected ServerSelectionList serverSelectionList;

    protected MultiplayerScreenMixin(Component title) { super(title); }

    @Inject(method = "onSelectedChange", at = @At("TAIL"))
    private void csclient$protectPlantControls(CallbackInfo ci) {
        ServerSelectionList.Entry entry = serverSelectionList.getSelected();
        if (entry instanceof ServerSelectionList.OnlineServerEntry online
                && FeaturedServers.isCanonicalPlantMcAddress(online.getServerData().ip)) {
            editButton.active = false;
            deleteButton.active = false;
        }
    }

    @Inject(method = "deleteCallback", at = @At("HEAD"), cancellable = true)
    private void csclient$denyPlantDelete(boolean confirmed, CallbackInfo ci) {
        ServerSelectionList.Entry entry = serverSelectionList.getSelected();
        if (!confirmed || !(entry instanceof ServerSelectionList.OnlineServerEntry online)
                || !FeaturedServers.isCanonicalPlantMcAddress(online.getServerData().ip)) return;
        Minecraft.getInstance().gui.setScreen((JoinMultiplayerScreen) (Object) this);
        ci.cancel();
    }
}
