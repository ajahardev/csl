package com.craftstudio.csclient.impl.skin;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import com.mojang.blaze3d.platform.NativeImage;
import com.craftstudio.csclient.account.LocalSkinManager;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

/** Render-thread dynamic skin + cape texture state for unobfuscated Minecraft 26.2. */
public final class LocalSkinRuntime {
    private static Identifier skinTextureId;
    private static Identifier capeTextureId;
    private static String model = LocalSkinManager.CLASSIC;
    private static int counter;

    private LocalSkinRuntime() { }

    public static boolean apply(Path skinPng, Path capePng, String requestedModel) {
        NativeImage skinImage = null;
        NativeImage capeImage = null;
        Identifier nextSkin = null;
        Identifier nextCape = null;
        try {
            skinImage = read(skinPng, 64, 64);
            capeImage = read(capePng, 64, 32);
            Minecraft client = Minecraft.getInstance();
            if (skinImage != null) {
                nextSkin = Identifier.fromNamespaceAndPath("csclient", "local_skin_" + ++counter);
                NativeImage registeredSkin = skinImage;
                client.getTextureManager().register(nextSkin,
                        new DynamicTexture(() -> "csclient_local_skin", registeredSkin));
                skinImage = null;
            }
            if (capeImage != null) {
                nextCape = Identifier.fromNamespaceAndPath("csclient", "local_cape_" + ++counter);
                NativeImage registeredCape = capeImage;
                client.getTextureManager().register(nextCape,
                        new DynamicTexture(() -> "csclient_local_cape", registeredCape));
                capeImage = null;
            }

            Identifier previousSkin = skinTextureId;
            Identifier previousCape = capeTextureId;
            skinTextureId = nextSkin;
            capeTextureId = nextCape;
            model = normalize(requestedModel);
            if (previousSkin != null) client.getTextureManager().release(previousSkin);
            if (previousCape != null) client.getTextureManager().release(previousCape);
            return skinTextureId != null || capeTextureId != null;
        } catch (Exception ignored) {
            Minecraft client = Minecraft.getInstance();
            if (nextSkin != null) client.getTextureManager().release(nextSkin);
            if (nextCape != null) client.getTextureManager().release(nextCape);
            if (skinImage != null) skinImage.close();
            if (capeImage != null) capeImage.close();
            return false;
        }
    }

    private static NativeImage read(Path path, int width, int height) throws Exception {
        if (path == null) return null;
        try (InputStream input = Files.newInputStream(path)) {
            NativeImage image = NativeImage.read(input);
            if (image.getWidth() != width || image.getHeight() != height) {
                image.close();
                throw new IllegalArgumentException("invalid local texture dimensions");
            }
            return image;
        }
    }

    public static void reset() {
        Minecraft client = Minecraft.getInstance();
        Identifier previousSkin = skinTextureId;
        Identifier previousCape = capeTextureId;
        skinTextureId = null;
        capeTextureId = null;
        model = LocalSkinManager.CLASSIC;
        if (previousSkin != null) client.getTextureManager().release(previousSkin);
        if (previousCape != null) client.getTextureManager().release(previousCape);
    }

    public static boolean isActive() { return skinTextureId != null || capeTextureId != null; }

    public static PlayerSkin override(PlayerSkin original) {
        if (!isActive() || original == null) return original;
        ClientAsset.Texture body = skinTextureId == null ? original.body()
                : new ClientAsset.ResourceTexture(skinTextureId);
        ClientAsset.Texture cape = capeTextureId == null ? original.cape()
                : new ClientAsset.ResourceTexture(capeTextureId);
        ClientAsset.Texture elytra = capeTextureId == null ? original.elytra() : cape;
        PlayerModelType type = skinTextureId == null ? original.model()
                : model.equals(LocalSkinManager.SLIM) ? PlayerModelType.SLIM : PlayerModelType.WIDE;
        return new PlayerSkin(body, cape, elytra, type, original.secure());
    }

    public static PlayerSkin getPreviewSkin() {
        Minecraft client = Minecraft.getInstance();
        PlayerSkin fallback = client.player != null
                ? client.player.getSkin()
                : DefaultPlayerSkin.get(client.getGameProfile());
        return isActive() ? override(fallback) : fallback;
    }

    private static String normalize(String value) {
        return value != null && value.equalsIgnoreCase(LocalSkinManager.SLIM)
                ? LocalSkinManager.SLIM : LocalSkinManager.CLASSIC;
    }
}
