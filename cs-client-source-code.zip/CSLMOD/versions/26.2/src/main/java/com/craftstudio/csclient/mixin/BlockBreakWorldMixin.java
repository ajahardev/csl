package com.craftstudio.csclient.mixin;

import java.util.List;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import com.craftstudio.csclient.impl.render.BlockBreakLayers;

import net.minecraft.client.renderer.SubmitNodeCollection;
import net.minecraft.client.renderer.rendertype.RenderType;

/**
 * Minecraft 26.2 submits destruction overlays through SubmitNodeCollection.
 * Replace only the native destroy-stage RenderType list; no block state,
 * mining progress, packet, or server behaviour is modified.
 */
@Mixin(SubmitNodeCollection.class)
public abstract class BlockBreakWorldMixin {
    @Redirect(method = "submitBreakingBlockModel", at = @At(value = "FIELD",
            target = "Lnet/minecraft/client/resources/model/ModelBakery;DESTROY_TYPES:Ljava/util/List;",
            opcode = Opcodes.GETSTATIC))
    private List<RenderType> csclient$selectBlockBreakLayers() {
        return BlockBreakLayers.active();
    }
}
