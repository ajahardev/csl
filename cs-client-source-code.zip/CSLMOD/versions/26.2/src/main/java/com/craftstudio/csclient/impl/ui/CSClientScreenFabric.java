package com.craftstudio.csclient.impl.ui;

import java.time.Duration;
import java.time.Instant;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.PlayerSkinWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.texture.SimpleTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.impl.skin.LocalSkinRuntime;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.CSClientScreen.ScreenProvider;
import com.craftstudio.csclient.ui.resources.Textures;
import com.craftstudio.csclient.ui.screens.ComingSoonScreen;
import com.craftstudio.csclient.ui.screens.ServerComingSoonScreen;
import com.craftstudio.csclient.ui.screens.ConfigEditor;
import com.craftstudio.csclient.ui.screens.ExternalLinkConfirmScreen;
import com.craftstudio.csclient.ui.screens.HudEditor;
import com.craftstudio.csclient.ui.screens.LocalAccountsScreen;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import com.craftstudio.csclient.ui.screens.TitleMenu;

public class CSClientScreenFabric extends Screen implements ScreenProvider {
    protected static final Identifier PANORAMA = Identifier.fromNamespaceAndPath("minecraft",
            "textures/gui/title/background/panorama");
    public final CSClientScreen screen;
    private PlayerSkinWidget skinPreviewWidget;

    public static void preload(Minecraft client) {
        TextureManager textureManager = client.getTextureManager();
        for (int i = 0; i < 6; i++) {
            String var10001 = PANORAMA.getPath();
            Identifier tex = PANORAMA.withPath(var10001 + "_" + i + ".png");
            SimpleTexture resourceTexture = new SimpleTexture(tex);
            textureManager.registerAndLoad(tex, resourceTexture);
        }
    }

    public CSClientScreenFabric(CSClientScreen screen) {
        super(Component.literal(screen.title));
        screen.provider = this;
        this.screen = screen;
    }

    @Override
    protected void init() {
        clearWidgets();
        screen.init();
        skinPreviewWidget = null;
        if (screen instanceof LocalAccountsScreen accounts && accounts.showsNativeSkinPreview()) {
            float scale = getUiScale();
            int previewWidth = Math.max(80, Math.round(accounts.getSkinPreviewWidth() * scale));
            int previewHeight = Math.max(100, Math.round(accounts.getSkinPreviewHeight() * scale));
            skinPreviewWidget = new PlayerSkinWidget(previewWidth, previewHeight,
                    minecraft.getEntityModels(), LocalSkinRuntime::getPreviewSkin);
            skinPreviewWidget.setX(Math.round(accounts.getSkinPreviewX() * scale));
            skinPreviewWidget.setY(Math.round(accounts.getSkinPreviewY() * scale));
            addRenderableWidget(skinPreviewWidget);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        if (screen.start == null) {
            screen.start = Instant.now();
        }
        long elapsed = Duration.between(screen.start, Instant.now()).toMillis();
        int nativeMouseX = mouseX;
        int nativeMouseY = mouseY;

        // Keep hover rendering and click dispatch in the same GUI-coordinate
        // space. CSClientScreen already applies the responsive UI scale.

        boolean titleContext = minecraft.level == null && minecraft.getCurrentServer() == null;
        boolean panoramaContext = screen instanceof TitleMenu || screen instanceof ComingSoonScreen
                || screen instanceof ServerComingSoonScreen
                || screen instanceof ExternalLinkConfirmScreen
                || (screen instanceof ConfigEditor editor && editor.isModuleEditor());
        if (titleContext && panoramaContext) {
            // Minecraft 26.2's extraction renderer owns the cube-map draw state.
            // CS Client supplies the six panorama faces through the resource pack.
            this.extractPanorama(context, delta);
        }

        RenderScope renderScope = new RenderScopeImpl(context);

        boolean fullScreenEditor = screen instanceof HudEditor;
        boolean pauseGlass = screen instanceof PauseMenu;
        boolean ownsChrome = fullScreenEditor || pauseGlass || screen instanceof TitleMenu;
        int baseAlpha = titleContext ? 72 : (fullScreenEditor ? 105 : (pauseGlass ? 58 : 218));
        int alpha = Math.round(baseAlpha * Math.max(0f, Math.min(1f, screen.backgroundOpacity)));
        int background = Theme.withAlpha(alpha, Theme.BACKGROUND.value);
        renderScope.drawRectangle(0, 0, this.width, this.height, background);

        // Every CS screen now owns its responsive header/chrome.
        screen.render(renderScope, mouseX, mouseY, delta, elapsed);
        if (skinPreviewWidget != null) {
            skinPreviewWidget.extractRenderState(context, nativeMouseX, nativeMouseY, delta);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
        if (screen.mouseClicked(click.x(), click.y(), click.button())) {
            return true;
        }

        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent click, double offsetX, double offsetY) {
        if (screen.mouseDragged(click.x(), click.y(), click.button(), 0.0, 0.0)) {
            return true;
        }

        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent click) {
        if (screen.mouseReleased(click.x(), click.y(), click.button())) {
            return true;
        }

        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (screen.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) {
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyEvent input) {
        if (screen.keyPressed(input.input(), input.scancode(), input.modifiers())) {
            return true;
        }

        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (screen.charTyped(event.codepointAsString(), 0)) return true;
        return super.charTyped(event);
    }

    // @Override
    // public void resize(MinecraftClient client, int width, int height) {
    //     screen.resize(width, height);
    //     super.resize(client, width, height);
    // }

    @Override
    public void onClose() {
        this.screen.onClose();
        super.onClose();
    }

    @Override
    public void close() {
        this.onClose();
    }

    @Override
    public int getWidth() {
        return Math.round(width / getUiScale());
    }

    @Override
    public int getHeight() {
        return Math.round(height / getUiScale());
    }

    @Override
    public float getUiScale() {
        return CSClientScreen.calculateUiScale(width, height);
    }
}