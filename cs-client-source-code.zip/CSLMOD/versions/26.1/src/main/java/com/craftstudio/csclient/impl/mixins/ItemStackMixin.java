package com.craftstudio.csclient.impl.mixins;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin implements ItemStackRef {
    @Shadow public abstract boolean isEmpty();
    @Shadow public abstract int getMaxDamage();
    @Shadow public abstract int getDamageValue();
    @Shadow public abstract int getCount();
    @Shadow public abstract Component getHoverName();
    @Shadow public abstract boolean isEnchanted();

    /** Bridge the common durability contract to the Mojang-named API. */
    @Override public int getDamage() { return getDamageValue(); }
    @Override public String getItemName() { return getHoverName().getString(); }
}
