package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.renderer.LevelRenderer;
import com.craftstudio.csclient.mod.mods.BlockOverlayMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(LevelRenderer.class)
public class BlockOverlayMixin {
    @ModifyVariable(method = "renderHitOutline", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private int csclient$outlineColor(int original) {
        return BlockOverlayMod.isActive() ? BlockOverlayMod.color() : original;
    }

    @ModifyVariable(method = "renderHitOutline", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float csclient$outlineWidth(float original) {
        return BlockOverlayMod.isActive() ? BlockOverlayMod.lineWidth() : original;
    }
}
