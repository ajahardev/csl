package com.craftstudio.csclient.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import com.craftstudio.csclient.mod.mods.LowShieldMod;
import com.craftstudio.csclient.mod.mods.ShieldRenderContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public class LowShieldMixin {
    @Unique private boolean csclient$shieldTransform;

    @Inject(method = "renderArmWithItem", at = @At("HEAD"))
    private void csclient$beginLowShield(AbstractClientPlayer player, float tickDelta,
            float pitch, InteractionHand hand, float swingProgress, ItemStack stack,
            float equipProgress, PoseStack matrices, SubmitNodeCollector queue,
            int light, CallbackInfo ci) {
        ShieldRenderContext.beginFirstPersonShield(stack.is(Items.SHIELD));
        if (!LowShieldMod.isActive() || !stack.is(Items.SHIELD)) return;
        csclient$shieldTransform = true;
        matrices.pushPose();
        float scale = LowShieldMod.fixedScale();
        matrices.translate(0f, LowShieldMod.lowerOffset(), 0f);
        matrices.scale(scale, scale, scale);
    }

    @Inject(method = "renderArmWithItem", at = @At("RETURN"))
    private void csclient$endLowShield(AbstractClientPlayer player, float tickDelta,
            float pitch, InteractionHand hand, float swingProgress, ItemStack stack,
            float equipProgress, PoseStack matrices, SubmitNodeCollector queue,
            int light, CallbackInfo ci) {
        ShieldRenderContext.endFirstPersonShield();
        if (!csclient$shieldTransform) return;
        matrices.popPose();
        csclient$shieldTransform = false;
    }
}
