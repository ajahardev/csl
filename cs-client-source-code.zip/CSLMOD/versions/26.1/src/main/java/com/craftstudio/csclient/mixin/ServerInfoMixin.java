package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.server.FeaturedServers;
import net.minecraft.client.multiplayer.ServerData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevents a server ping from replacing the packaged PlantMC icon. */
@Mixin(ServerData.class)
public class ServerInfoMixin {
    @Shadow public String ip;
    @Shadow private byte[] iconBytes;

    @Inject(method = "setIconBytes", at = @At("HEAD"), cancellable = true)
    private void csclient$keepPlantIcon(byte[] ignored, CallbackInfo ci) {
        if (!FeaturedServers.isCanonicalPlantMcAddress(ip)) return;
        byte[] icon = FeaturedServers.plantMcIconBytes();
        iconBytes = icon.length == 0 ? null : icon;
        ci.cancel();
    }
}
