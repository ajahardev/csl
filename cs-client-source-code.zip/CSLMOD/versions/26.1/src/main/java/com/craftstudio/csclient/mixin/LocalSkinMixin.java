package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.account.LocalSkinManager;
import com.craftstudio.csclient.impl.skin.LocalSkinRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;

/** Client-only body skin override for the active CS local/offline player. */
@Mixin(value = AbstractClientPlayer.class, remap = false)
public abstract class LocalSkinMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true, remap = false)
    private void csclient$overrideLocalSkin(CallbackInfoReturnable<PlayerSkin> cir) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || (Object) this != client.player) return;
        if (!LocalSkinManager.isActiveAppearanceProfile() || !LocalSkinRuntime.isActive()) return;
        cir.setReturnValue(LocalSkinRuntime.override(cir.getReturnValue()));
    }
}
