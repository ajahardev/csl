package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ChatEnhancementsMod;
import com.craftstudio.csclient.mod.mods.ChatEnhancementsMod.IncomingDecision;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.multiplayer.chat.GuiMessageTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.MessageSignature;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatComponent.class)
public abstract class ChatEnhancementsMixin {
    @Unique private boolean csclient$decoratingChat;

    @Inject(method = "addClientSystemMessage", at = @At("HEAD"), cancellable = true)
    private void csclient$clientMessage(Component message, CallbackInfo ci) {
        if (handle(message, true, decorated -> ((ChatComponent) (Object) this).addClientSystemMessage(decorated))) ci.cancel();
    }

    @Inject(method = "addServerSystemMessage", at = @At("HEAD"), cancellable = true)
    private void csclient$serverMessage(Component message, CallbackInfo ci) {
        if (handle(message, true, decorated -> ((ChatComponent) (Object) this).addServerSystemMessage(decorated))) ci.cancel();
    }

    @Inject(method = "addPlayerMessage", at = @At("HEAD"), cancellable = true)
    private void csclient$playerMessage(Component message, @Nullable MessageSignature signature,
            @Nullable GuiMessageTag tag, CallbackInfo ci) {
        if (handle(message, false, decorated -> ((ChatComponent) (Object) this)
                .addPlayerMessage(decorated, signature, tag))) ci.cancel();
    }

    @Unique
    private boolean handle(Component message, boolean allowSuppression,
            java.util.function.Consumer<Component> readd) {
        if (csclient$decoratingChat || !ChatEnhancementsMod.isActive()) return false;
        IncomingDecision decision = ChatEnhancementsMod.processIncoming(message.getString());
        // Signed player messages must remain in vanilla's reportable history.
        if (decision.suppress()) return allowSuppression;
        if (decision.timestamp().isEmpty() && !decision.mention()) return false;
        MutableComponent decorated = Component.empty();
        if (!decision.timestamp().isEmpty()) {
            decorated.append(Component.literal(decision.timestamp())
                    .withStyle(style -> style.withColor(ChatEnhancementsMod.timestampColor())));
        }
        if (decision.mention()) {
            decorated.append(Component.literal("◆ ")
                    .withStyle(style -> style.withColor(ChatEnhancementsMod.mentionColor())));
        }
        decorated.append(message);
        csclient$decoratingChat = true;
        try { readd.accept(decorated); }
        finally { csclient$decoratingChat = false; }
        return true;
    }

    @Inject(method = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/gui/Font;IIILnet/minecraft/client/gui/components/ChatComponent$DisplayMode;Z)V",
            at = @At("HEAD"), cancellable = true)
    private void csclient$hideChat(GuiGraphicsExtractor graphics, Font font, int currentTick,
            int mouseX, int mouseY, ChatComponent.DisplayMode mode, boolean hudHidden, CallbackInfo ci) {
        if (ChatEnhancementsMod.shouldHideChat()) ci.cancel();
    }
}
