package com.craftstudio.csclient.impl.render;

import java.util.List;
import java.util.stream.IntStream;

import com.craftstudio.csclient.mod.mods.BlockBreakAnimationMod;

import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.resources.Identifier;

/** Dynamic destruction-layer selection without a resource reload. */
public final class BlockBreakLayers {
    private static final List<RenderType> CS_LAYERS = IntStream.range(0, 10)
            .mapToObj(stage -> RenderTypes.crumbling(Identifier.fromNamespaceAndPath("csclient",
                    "textures/block/destroy_stage_" + stage + ".png")))
            .toList();

    private BlockBreakLayers() {
    }

    public static List<RenderType> active() {
        return BlockBreakAnimationMod.useCsStages() ? CS_LAYERS : ModelBakery.DESTROY_TYPES;
    }
}
