package com.craftstudio.csclient.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.impl.ui.CSClientScreenFabric;
import com.craftstudio.csclient.ui.screens.TitleMenu;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Minecraft.class)
public class SetScreenMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen replaceTitleScreen(Screen screen) {
        if (screen instanceof PauseScreen)
            return new CSClientScreenFabric(new PauseMenu());

        if (Config.csTitleScreen.value) {
            if (screen instanceof TitleScreen)
                return new CSClientScreenFabric(new TitleMenu());
            if (screen == null && ((Minecraft) (Object) this).level == null)
                return new CSClientScreenFabric(new TitleMenu());
        }

        return screen;
    }
}