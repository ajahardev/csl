package com.craftstudio.csclient.event;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.screens.LocalAccountsScreen;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import com.craftstudio.csclient.ui.screens.ShiftMenu;
import com.craftstudio.csclient.ui.screens.TitleMenu;

/** Registers CS quick-menu and local skin-studio keys. */
public final class KeyInputHandler {
    private static final Identifier KEY_CATEGORY = Identifier.fromNamespaceAndPath("csclient", "key.category.csclient");
    private static KeyMapping mainMenuKeyBinding;
    private static KeyMapping skinMenuKeyBinding;

    private KeyInputHandler() {
    }

    public static void register() {
        KeyMapping.Category category = KeyMapping.Category.register(KEY_CATEGORY);
        mainMenuKeyBinding = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.csclient.main_menu", GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        skinMenuKeyBinding = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.csclient.local_skin", GLFW.GLFW_KEY_H, category));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (mainMenuKeyBinding.consumeClick()) {
                Providers.csClient.getClient().setScreen(new ShiftMenu());
            }
            if (skinMenuKeyBinding.consumeClick()) {
                CSClientScreen parent = client.level == null ? new TitleMenu() : new PauseMenu();
                Providers.csClient.getClient().setScreen(
                        new LocalAccountsScreen(LocalAccountsScreen.Tab.SKIN, parent));
            }
        });
    }
}
