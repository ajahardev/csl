package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.Camera;
import com.craftstudio.csclient.mod.mods.ZoomMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies CS Client's zoom to the camera FOV used by Minecraft 26.1. */
@Mixin(Camera.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void csclient$modifyFov(CallbackInfoReturnable<Float> cir) {
        if (ZoomMod.shouldZoom()) {
            cir.setReturnValue(cir.getReturnValue() / ZoomMod.getZoomLevel());
        }
    }
}
