package com.craftstudio.csclient.impl.features.player;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.ref.game.EffectRef;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.client.gui.components.debug.DebugScreenEntryStatus;
import com.craftstudio.csclient.impl.features.mixins.render.BossBarHudAccessor;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Fabric implementation of {@link PlayerFeature}.
 *
 * All access to {@link Minecraft} and {@link LocalPlayer}
 * is encapsulated here. Features only ever see the {@link PlayerFeature}
 * interface; they never import Minecraft classes directly.
 *
 * Every method guards against a missing player and returns a safe
 * default so features are free of null checks.
 */
public class PlayerFeatureImpl implements PlayerFeature {

    private ItemStack shieldCooldownStack;
    private final Minecraft mc;

    public PlayerFeatureImpl(Minecraft mc) {
        this.mc = mc;
    }

    // ---------------------------------------------------------------
    // Internal helper — never returns null
    // ---------------------------------------------------------------

    /** Returns the local player, or {@code null} if one is not loaded. */
    private LocalPlayer player() {
        return mc.player;
    }

    // ---------------------------------------------------------------
    // Presence
    // ---------------------------------------------------------------

    @Override
    public boolean hasPlayer() {
        return mc.player != null;
    }

    // ---------------------------------------------------------------
    // Position
    // ---------------------------------------------------------------

    @Override
    public int getX() {
        return hasPlayer() ? (int) player().getX() : 0;
    }

    @Override
    public int getY() {
        return hasPlayer() ? (int) player().getY() : 0;
    }

    @Override
    public int getZ() {
        return hasPlayer() ? (int) player().getZ() : 0;
    }

    // ---------------------------------------------------------------
    // Input / movement
    // ---------------------------------------------------------------

    @Override
    public boolean isForwardPressed() {
        return mc.options.keyUp.isDown();
    }

    @Override
    public boolean isBackPressed() {
        return mc.options.keyDown.isDown();
    }

    @Override
    public boolean isLeftPressed() {
        return mc.options.keyLeft.isDown();
    }

    @Override
    public boolean isRightPressed() {
        return mc.options.keyRight.isDown();
    }

    @Override
    public boolean isJumpPressed() {
        return mc.options.keyJump.isDown();
    }

    @Override
    public boolean isAttackPressed() {
        return mc.options.keyAttack.isDown();
    }

    @Override
    public boolean isUsePressed() {
        return mc.options.keyUse.isDown();
    }

    @Override
    public boolean isSneaking() {
        return hasPlayer() && player().isShiftKeyDown();
    }

    @Override
    public boolean isSprinting() {
        return hasPlayer() && player().isSprinting();
    }

    @Override
    public float getYaw() {
        return hasPlayer() ? player().getYRot() : 0.0f;
    }

    @Override
    public boolean isUsingItem() {
        return hasPlayer() && player().isUsingItem();
    }

    @Override
    public boolean hasHorizontalCollision() {
        return hasPlayer() && player().horizontalCollision;
    }

    @Override
    public boolean isOnGround() {
        return hasPlayer() && player().onGround();
    }

    @Override
    public void setSprinting(boolean sprinting) {
        if (hasPlayer())
            player().setSprinting(sprinting);
    }

    // ---------------------------------------------------------------
    // Velocity
    // ---------------------------------------------------------------

    @Override
    public Velocity getVelocity() {
        if (!hasPlayer())
            return Velocity.ZERO;
        var v = player().getDeltaMovement();
        return new Velocity(v.x, v.y, v.z);
    }

    // ---------------------------------------------------------------
    // Stats
    // ---------------------------------------------------------------

    @Override
    public float getHealth() {
        return hasPlayer() ? player().getHealth() : 0f;
    }

    @Override
    public float getMaxHealth() {
        return hasPlayer() ? player().getMaxHealth() : 20f;
    }

    @Override
    public float getAbsorptionHealth() {
        return hasPlayer() ? player().getAbsorptionAmount() : 0f;
    }

    @Override
    public int getFoodLevel() {
        return hasPlayer() ? player().getFoodData().getFoodLevel() : 0;
    }

    @Override
    public float getSaturationLevel() {
        return hasPlayer() ? player().getFoodData().getSaturationLevel() : 0.0f;
    }

    @Override
    public int getSelectedItemTotalCount() {
        if (!hasPlayer()) return 0;
        ItemStack held = player().getMainHandItem();
        if (held.isEmpty()) return 0;
        int total = 0;
        for (int i = 0; i < player().getInventory().getContainerSize(); i++) {
            ItemStack stack = player().getInventory().getItem(i);
            if (stack.is(held.getItem())) total += stack.getCount();
        }
        return total;
    }

    @Override
    public int getTotemCount() {
        if (!hasPlayer()) return 0;
        int total = 0;
        for (int i = 0; i < player().getInventory().getContainerSize(); i++) {
            ItemStack stack = player().getInventory().getItem(i);
            if (stack.is(Items.TOTEM_OF_UNDYING)) total += stack.getCount();
        }
        return total;
    }

    @Override
    public ItemStackRef getTotemStack() {
        return wrap(new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    @Override
    public boolean isShieldDisabled() {
        return getShieldCooldownRemaining(0.0f) > 0.0f;
    }

    @Override
    public float getShieldCooldownRemaining(float tickDelta) {
        if (!hasPlayer()) return 0.0f;
        if (shieldCooldownStack == null) shieldCooldownStack = new ItemStack(Items.SHIELD);
        return player().getCooldowns().getCooldownPercent(shieldCooldownStack, tickDelta);
    }

    @Override
    public float getAttackCooldown() {
        // Vanilla's HUD intentionally samples half a tick ahead for the visual indicator.
        return hasPlayer() ? player().getAttackStrengthScale(0.5f) : 1.0f;
    }

    @Override
    public String getServerAddress() {
        var server = mc.getCurrentServer();
        return server == null ? "SINGLEPLAYER" : server.ip;
    }

    @Override
    public String getScoreboardTitle() {
        Objective objective = getSidebarObjective();
        return objective == null ? "SCOREBOARD" : objective.getDisplayName().getString();
    }

    @Override
    public List<ScoreboardLine> getScoreboardLines() {
        Objective objective = getSidebarObjective();
        if (objective == null || mc.level == null) return List.of();
        Scoreboard board = mc.level.getScoreboard();
        return board.listPlayerScores(objective).stream()
                .filter(entry -> !entry.isHidden() && !entry.owner().startsWith("#"))
                .sorted(Comparator.comparingInt(PlayerScoreEntry::value).reversed())
                .limit(15)
                .map(entry -> {
                    String text = entry.ownerName() == null ? entry.owner()
                            : PlayerTeam.formatNameForTeam(board.getPlayersTeam(entry.owner()), entry.ownerName()).getString();
                    return new ScoreboardLine(text, entry.value());
                })
                .toList();
    }

    /** Matches Minecraft's team-color sidebar selection before SIDEBAR fallback. */
    private Objective getSidebarObjective() {
        if (mc.level == null || mc.player == null) return null;
        Scoreboard board = mc.level.getScoreboard();
        PlayerTeam team = board.getPlayersTeam(mc.player.getScoreboardName());
        Objective objective = null;
        if (team != null) {
            DisplaySlot slot = DisplaySlot.teamColorToSlot(team.getColor());
            if (slot != null) objective = board.getDisplayObjective(slot);
        }
        return objective != null ? objective : board.getDisplayObjective(DisplaySlot.SIDEBAR);
    }

    @Override
    public List<BossInfo> getBossBars() {
        try {
            return ((BossBarHudAccessor) mc.gui.getBossOverlay()).csclient$getBossBars().values().stream()
                    .map(bar -> new BossInfo(bar.getName().getString(), bar.getProgress())).toList();
        } catch (LinkageError | RuntimeException ignored) {
            return List.of();
        }
    }

    @Override
    public void setHitboxesEnabled(boolean enabled) {
        mc.debugEntries.setStatus(DebugScreenEntries.ENTITY_HITBOXES,
                enabled ? DebugScreenEntryStatus.ALWAYS_ON : DebugScreenEntryStatus.NEVER);
    }

    @Override
    public boolean areHitboxesEnabled() {
        return mc.debugEntries.isCurrentlyEnabled(DebugScreenEntries.ENTITY_HITBOXES);
    }

    // ---------------------------------------------------------------
    // Equipment
    // ---------------------------------------------------------------

    @Override
    public ItemStackRef getMainHand() {
        return wrap(hasPlayer() ? player().getMainHandItem() : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getOffHand() {
        return wrap(hasPlayer() ? player().getOffhandItem() : ItemStack.EMPTY);
    }

    @Override
    public List<? extends ItemStackRef> getInventoryItems() {
        if (!hasPlayer()) return List.of();
        List<ItemStackRef> items = new ArrayList<>(36);
        int size = Math.min(36, player().getInventory().getContainerSize());
        for (int i = 0; i < size; i++) items.add(wrap(player().getInventory().getItem(i)));
        while (items.size() < 36) items.add(wrap(ItemStack.EMPTY));
        return items;
    }

    @Override
    public ItemStackRef getHelmet() {
        return wrap(hasPlayer() ? player().getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getChestplate() {
        return wrap(hasPlayer() ? player().getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getLeggings() {
        return wrap(hasPlayer() ? player().getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getBoots() {
        return wrap(hasPlayer() ? player().getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY);
    }

    // ---------------------------------------------------------------
    // Dummy equipment
    // ---------------------------------------------------------------

    @Override
    public ItemStackRef getDummyMainHand() {
        return wrap(new ItemStack(Items.DIAMOND_SWORD));
    }

    @Override
    public ItemStackRef getDummyHelmet() {
        return wrap(new ItemStack(Items.DIAMOND_HELMET));
    }

    @Override
    public ItemStackRef getDummyChestplate() {
        return wrap(new ItemStack(Items.DIAMOND_CHESTPLATE));
    }

    @Override
    public ItemStackRef getDummyLeggings() {
        return wrap(new ItemStack(Items.DIAMOND_LEGGINGS));
    }

    @Override
    public ItemStackRef getDummyBoots() {
        return wrap(new ItemStack(Items.DIAMOND_BOOTS));
    }
    @Override
    public ItemStackRef getDummyOffHand() {
        return wrap(new ItemStack(Items.SHIELD));
    }


    // ---------------------------------------------------------------
    // Status effects
    // ---------------------------------------------------------------

    @Override
    public List<? extends EffectRef> getActiveEffects() {
        if (!hasPlayer())
            return Collections.emptyList();

        var effects = player().getActiveEffectsMap().values();
        List<EffectRef> result = new ArrayList<>(effects.size());
        for (MobEffectInstance instance : effects) {
            result.add((EffectRef) instance);
        }
        return result;
    }

    @Override
    public List<? extends EffectRef> getDummyEffects() {
        return List.of(
                (EffectRef) new MobEffectInstance(
                        BuiltInRegistries.MOB_EFFECT.get(Identifier.withDefaultNamespace("speed")).get(), 12000, 2),
                (EffectRef) new MobEffectInstance(
                        BuiltInRegistries.MOB_EFFECT.get(Identifier.withDefaultNamespace("strength")).get(), 12000, 2),
                (EffectRef) new MobEffectInstance(
                        BuiltInRegistries.MOB_EFFECT.get(Identifier.withDefaultNamespace("fire_resistance")).get(), 12000, 2));
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private static ItemStackRef wrap(ItemStack stack) {
        return (ItemStackRef) (Object) stack;
    }
}
