package com.craftstudio.csclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

import com.craftstudio.csclient.account.LocalAccountManager;
import com.craftstudio.csclient.branding.net.CSBrandingClientNetworking;
import com.craftstudio.csclient.account.LocalSkinManager;
import com.craftstudio.csclient.account.LauncherIntegration;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.impl.provider.FeatureProviderFabric;
import com.craftstudio.csclient.impl.provider.GLFWProviderImpl;
import com.craftstudio.csclient.impl.provider.RefConstructorImpl;
import com.craftstudio.csclient.impl.provider.CSClientProviderImpl;
import com.craftstudio.csclient.impl.ui.CSClientScreenFabric;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.event.KeyInputHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CSClient implements ClientModInitializer {
    public static final String MOD_ID = "csclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static Minecraft client;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing " + MOD_ID);
        client = Minecraft.getInstance();

        Providers.csClient = new CSClientProviderImpl();
        Providers.refConstructor = new RefConstructorImpl();
        Providers.GLFW = new GLFWProviderImpl();
        Providers.feature = new FeatureProviderFabric(client);
        CSBrandingClientNetworking.initialize();

        Config.init();
        // Startup diagnostics: make the active instance's game directory and
        // server-list state explicit (data-persistence issues must be visible).
        java.io.File csRunDir = Providers.csClient.getClient().getRunDirectory();
        java.io.File csServerList = new java.io.File(csRunDir, "servers.dat");
        LOGGER.info("CS Client game directory: {} (servers.dat: exists={}, size={})",
                csRunDir.getAbsolutePath(), csServerList.exists(), csServerList.length());
        LocalAccountManager.initialize(Providers.csClient.getClient().getRunDirectory());
        LocalSkinManager.initialize(Providers.csClient.getClient().getRunDirectory());
        LauncherIntegration.publishCapabilities(Providers.csClient.getClient().getRunDirectory());
        ModManager.init();
        client.execute(() -> {
            CSClientScreenFabric.preload(client);
            LocalSkinManager.activateForCurrentAccount();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(_o -> {
            ConfigManager.save();
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ModManager.tick();
        });
        KeyInputHandler.register();
    }
}
