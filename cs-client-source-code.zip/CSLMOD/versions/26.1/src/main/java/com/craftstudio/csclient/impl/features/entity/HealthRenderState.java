package com.craftstudio.csclient.impl.features.entity;

import com.craftstudio.csclient.common.feature.EntityFeature;

/**
 * Injected interface on
 * {@link net.minecraft.client.renderer.entity.state.LivingEntityRenderState}.
 *
 * Carries the entity's health snapshot and classification into the render
 * pipeline so that {@link NametagsMixin} can read them without touching
 * the live entity again.
 */
public interface HealthRenderState {

    float csclient$getHealth();

    float csclient$getMaxHealth();

    void csclient$setHealth(float health, float maxHealth);

    float csclient$getAbsorption();

    void csclient$setAbsorption(float absorption);

    EntityFeature.EntityType csclient$getEntityType();

    void csclient$setEntityType(EntityFeature.EntityType type);
}
