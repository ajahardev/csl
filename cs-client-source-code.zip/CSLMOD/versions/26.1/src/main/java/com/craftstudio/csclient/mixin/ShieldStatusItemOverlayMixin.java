package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ShieldStatusesMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiGraphicsExtractor.class)
public abstract class ShieldStatusItemOverlayMixin {
    @Inject(method = "itemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",
            at = @At("TAIL"))
    private void csclient$drawShieldStatus(Font font, ItemStack stack, int x, int y,
            @Nullable String countOverride, CallbackInfo ci) {
        if (!ShieldStatusesMod.itemIconOutlineEnabled() || !stack.is(Items.SHIELD)) return;
        float tickDelta = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
        int color = ShieldStatusesMod.iconColor(tickDelta);
        GuiGraphicsExtractor self = (GuiGraphicsExtractor) (Object) this;
        self.fill(x, y, x + 16, y + 1, color);
        self.fill(x, y + 15, x + 16, y + 16, color);
        self.fill(x, y + 1, x + 1, y + 15, color);
        self.fill(x + 15, y + 1, x + 16, y + 15, color);
    }
}
