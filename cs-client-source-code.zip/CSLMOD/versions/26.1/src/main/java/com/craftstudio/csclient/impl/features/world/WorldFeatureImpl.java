package com.craftstudio.csclient.impl.features.world;

import com.craftstudio.csclient.common.feature.WorldFeature;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;

/** Mojang-named world queries used by lightweight CS information modules. */
public class WorldFeatureImpl implements WorldFeature {
    private final Minecraft mc;

    public WorldFeatureImpl(Minecraft mc) { this.mc = mc; }
    @Override public boolean hasWorld() { return mc.level != null; }
    @Override public long getWorldAge() { return hasWorld() ? mc.level.getGameTime() : 0L; }

    @Override
    public BlockInfo getTargetBlockInfo() {
        if (!hasWorld() || !(mc.hitResult instanceof BlockHitResult hit)) return BlockInfo.EMPTY;
        BlockPos pos = hit.getBlockPos();
        BlockState state = mc.level.getBlockState(pos);
        if (state.isAir()) return BlockInfo.EMPTY;
        String name = state.getBlock().getName().getString().toUpperCase();
        String id = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
        float hardness = state.getDestroySpeed(mc.level, pos);
        String detail = hardness < 0 ? "Unbreakable" : String.format("Hardness %.1f%s", hardness,
                state.requiresCorrectToolForDrops() ? " • Tool required" : "");
        return new BlockInfo(name, id, detail);
    }

    @Override
    public ItemStackRef getTargetBlockIcon() {
        if (!hasWorld() || !(mc.hitResult instanceof BlockHitResult hit)) return null;
        BlockState state = mc.level.getBlockState(hit.getBlockPos());
        if (state.isAir()) return null;
        return (ItemStackRef) (Object) new ItemStack(state.getBlock());
    }

    @Override
    public boolean isUnderground() {
        if (!hasWorld() || mc.player == null) return false;
        int top = mc.level.getHeight(Heightmap.Types.WORLD_SURFACE,
                mc.player.getBlockX(), mc.player.getBlockZ());
        return top > mc.player.getBlockY() + 5;
    }

    @Override
    public float getBlockBreakProgress() {
        if (mc.gameMode == null || !mc.gameMode.isDestroying()) return 0f;
        return Math.max(0f, Math.min(1f, (mc.gameMode.getDestroyStage() + 1) / 10f));
    }

    @Override
    public int[] getMinimapColors(int cells, int blocksPerCell) {
        int[] result = new int[Math.max(1, cells * cells)];
        if (!hasWorld() || mc.player == null) return result;
        int half = cells / 2;
        int centerX = mc.player.getBlockX();
        int centerZ = mc.player.getBlockZ();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        boolean cave = isUnderground();
        int playerY = mc.player.getBlockY();
        for (int gy = 0; gy < cells; gy++) for (int gx = 0; gx < cells; gx++) {
            int x = centerX + (gx - half) * blocksPerCell;
            int z = centerZ + (gy - half) * blocksPerCell;
            int y;
            BlockState state;
            if (cave) {
                y = playerY + 1;
                pos.set(x, y, z);
                state = mc.level.getBlockState(pos);
                while (y > playerY - 12 && state.isAir()) {
                    y--;
                    pos.set(x, y, z);
                    state = mc.level.getBlockState(pos);
                }
                if (state.isAir()) {
                    result[gy * cells + gx] = 0xFF11151A;
                    continue;
                }
            } else {
                y = mc.level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
                pos.set(x, y, z);
                state = mc.level.getBlockState(pos);
            }
            result[gy * cells + gx] = shade(state.getMapColor(mc.level, pos).col, y - playerY);
        }
        return result;
    }

    private static int shade(int rgb, int heightDelta) {
        int delta = Math.max(-28, Math.min(28, heightDelta * 3));
        int r = Math.max(0, Math.min(255, ((rgb >> 16) & 255) + delta));
        int g = Math.max(0, Math.min(255, ((rgb >> 8) & 255) + delta));
        int b = Math.max(0, Math.min(255, (rgb & 255) + delta));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    public boolean isLineOfSightClear(double x0, double y0, double z0,
            double x1, double y1, double z1) {
        if (!hasWorld()) return true;
        double dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = (int) (distance * 2.0) + 1; // ~0.5 block probe spacing
        if (steps <= 1) return true;
        if (steps > 256) steps = 256;
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            if (t > 0.92f) break; // safety margin: never cull through the target's own blocks
            int bx = (int) Math.floor(x0 + dx * t);
            int by = (int) Math.floor(y0 + dy * t);
            int bz = (int) Math.floor(z0 + dz * t);
            BlockState state = mc.level.getBlockState(new BlockPos(bx, by, bz));
            if (state.isSolidRender()) return false;
        }
        return true;
    }
}
