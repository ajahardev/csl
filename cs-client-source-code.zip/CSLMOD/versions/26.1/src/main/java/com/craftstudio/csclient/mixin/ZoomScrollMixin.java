package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ZoomMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Scroll changes magnification only during active gameplay zoom. */
@Mixin(MouseHandler.class)
public class ZoomScrollMixin {
    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void csclient$scrollZoom(long window, double horizontal, double vertical, CallbackInfo ci) {
        Minecraft client = Minecraft.getInstance();
        if (client.screen == null && client.player != null && ZoomMod.handleMouseWheel(vertical)) {
            ci.cancel();
        }
    }
}
