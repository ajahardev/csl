package com.craftstudio.csclient.impl.mixins;

import net.minecraft.resources.Identifier;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(Identifier.class)
public abstract class IdentifierMixin implements IdentifierRef {
    @Shadow
    public abstract String toString();
}
