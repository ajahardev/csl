package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ChatEnhancementsMod;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin extends Screen {
    protected ChatScreenMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void csclient$addChatActions(CallbackInfo ci) {
        if (!ChatEnhancementsMod.isActive()) return;
        Button copy = Button.builder(Component.literal("Copy Last"), button -> {
            ChatEnhancementsMod.copyLastMessage();
            button.setMessage(Component.literal("Copied"));
        }).bounds(Math.max(4, width - 184), 4, 86, 20).build();
        Button visibility = Button.builder(visibilityText(), button -> {
            ChatEnhancementsMod.toggleChatVisibility();
            button.setMessage(visibilityText());
        }).bounds(Math.max(94, width - 94), 4, 90, 20).build();
        addRenderableWidget(copy);
        addRenderableWidget(visibility);
    }

    private static Component visibilityText() {
        return Component.literal(ChatEnhancementsMod.shouldHideChat() ? "Show Chat" : "Hide Chat");
    }
}
