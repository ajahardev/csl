package com.craftstudio.csclient.impl.features.mixins.world;

import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import com.craftstudio.csclient.mod.mods.TpsMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Feeds world-time packets into {@link TpsMod}'s TPS estimator.
 *
 * This is the only place in the entire codebase that reads a network
 * packet and passes data to a feature. The feature's
 * {@link TpsMod#onTimePacket(long)} method handles all averaging
 * logic; the mixin is intentionally reduced to a single forwarding call.
 *
 * The only change from the original is renaming the import from
 * {@code feature.features.Tps} to {@link TpsMod}.
 */
@Mixin(ClientPacketListener.class)
public class TpsMixin {

    @Inject(method = "handleSetTime", at = @At("HEAD"))
    private void onWorldTimeUpdate(ClientboundSetTimePacket packet, CallbackInfo ci) {
        TpsMod.onTimePacket(packet.gameTime());
    }
}
