package com.craftstudio.csclient.impl.features.mixins.render;

import java.util.Comparator;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.numbers.NumberFormat;
import net.minecraft.network.chat.numbers.StyledFormat;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

import com.craftstudio.csclient.mod.mods.ScoreboardMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Moves Minecraft's own sidebar draw commands instead of recreating the scoreboard. */
@Mixin(Gui.class)
public class ScoreboardMixin {
    @Unique private boolean csclient$scoreboardPosePushed;

    @Inject(method = "displayScoreboardSidebar", at = @At("HEAD"))
    private void csclient$moveNativeSidebar(GuiGraphicsExtractor graphics, Objective objective, CallbackInfo ci) {
        csclient$scoreboardPosePushed = false;
        try {
            Bounds bounds = csclient$measure(graphics, objective);
            ScoreboardMod.updateNativeBounds(bounds.width(), bounds.height(), bounds.left(), bounds.top());
            if (!ScoreboardMod.shouldMoveVanilla()) return;

            graphics.pose().pushMatrix();
            csclient$scoreboardPosePushed = true;
            graphics.pose().translate(ScoreboardMod.targetX(), ScoreboardMod.targetY());
            float scale = ScoreboardMod.targetScale();
            graphics.pose().scale(scale, scale);
            graphics.pose().translate(-bounds.left(), -bounds.top());
        } catch (LinkageError | RuntimeException ignored) {
            // Fail open: vanilla renders in its normal location if measuring fails.
            if (csclient$scoreboardPosePushed) {
                graphics.pose().popMatrix();
                csclient$scoreboardPosePushed = false;
            }
        }
    }

    @Inject(method = "displayScoreboardSidebar", at = @At("RETURN"))
    private void csclient$restoreNativeSidebarPose(GuiGraphicsExtractor graphics, Objective objective, CallbackInfo ci) {
        if (!csclient$scoreboardPosePushed) return;
        graphics.pose().popMatrix();
        csclient$scoreboardPosePushed = false;
    }

    @Unique
    private static Bounds csclient$measure(GuiGraphicsExtractor graphics, Objective objective) {
        Scoreboard scoreboard = objective.getScoreboard();
        NumberFormat scoreFormat = objective.numberFormatOrDefault(StyledFormat.SIDEBAR_DEFAULT);
        Font font = Minecraft.getInstance().font;
        List<PlayerScoreEntry> entries = scoreboard.listPlayerScores(objective).stream()
                .filter(entry -> !entry.isHidden())
                .sorted(Comparator.comparing(PlayerScoreEntry::value).reversed()
                        .thenComparing(PlayerScoreEntry::owner, String.CASE_INSENSITIVE_ORDER))
                .limit(15L).toList();

        int contentWidth = font.width(objective.getDisplayName());
        int spacerWidth = font.width(": ");
        for (PlayerScoreEntry entry : entries) {
            Component name = PlayerTeam.formatNameForTeam(
                    scoreboard.getPlayersTeam(entry.owner()), entry.ownerName());
            Component score = entry.formatValue(scoreFormat);
            int scoreWidth = font.width(score);
            contentWidth = Math.max(contentWidth,
                    font.width(name) + (scoreWidth > 0 ? spacerWidth + scoreWidth : 0));
        }

        int contentHeight = entries.size() * font.lineHeight;
        int bottom = graphics.guiHeight() / 2 + contentHeight / 3;
        int left = graphics.guiWidth() - contentWidth - 3;
        int top = bottom - contentHeight - font.lineHeight - 1;
        return new Bounds(left - 2, top, contentWidth + 4,
                contentHeight + font.lineHeight + 1);
    }

    @Unique private record Bounds(int left, int top, int width, int height) { }
}
