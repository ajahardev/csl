package com.craftstudio.csclient.impl.ui;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Objects;

import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import com.mojang.blaze3d.textures.GpuTextureView;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.common.ref.render.MatrixStackRef;
import com.craftstudio.csclient.impl.ref.Matrix3x2fStackRef;
import com.craftstudio.csclient.CSClient;
import com.craftstudio.csclient.mixin.DrawContextAccessor;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.SvgTexture;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.ReportedException;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.BlitRenderState;
import net.minecraft.client.renderer.state.gui.ColoredRectangleRenderState;
import net.minecraft.client.renderer.state.gui.GuiItemRenderState;
import net.minecraft.client.renderer.state.gui.GuiRenderState;
import net.minecraft.client.renderer.state.gui.GuiTextRenderState;
import net.minecraft.client.renderer.state.gui.pip.GuiEntityRenderState;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.item.TrackingItemStackRenderState;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class RenderScopeImpl implements RenderScope {

    public Matrix3x2fStackRef matrices;
    public GuiRenderState state;

    private ScissorStack scissorStack;
    private int opacity = 0xFF << 24;

    public RenderScopeImpl(GuiGraphicsExtractor context) {
        this(context.pose(), ((DrawContextAccessor) (Object) context).getState());
    }

    public RenderScopeImpl(Matrix3x2fStack matrices, GuiRenderState state) {
        this.matrices = new Matrix3x2fStackRef(matrices);
        this.state = state;
        this.scissorStack = new ScissorStack();
    }

    /**
     * Rebinds this scope to the current frame's context. The render path is
     * single-threaded, so one reusable scope replaces a per-frame allocation.
     */
    public void rebind(Matrix3x2fStack matrices, GuiRenderState state) {
        this.matrices.stack = matrices;
        this.state = state;
        this.scissorStack.clear();
        this.opacity = 0xFF << 24;
    }

    @Override
    public MatrixStackRef getMatrixStack() {
        return matrices;
    }

    @Override
    public void setOpacity(float alpha) {
        this.opacity = ((int) (alpha * 255)) << 24;
    }

    @Override
    public int getColor(int color) {
        int originalAlpha = (color >>> 24) & 0xFF;
        int newAlpha = (opacity >>> 24) & 0xFF;
        int mixedAlpha = (originalAlpha * newAlpha) / 255;
        return (mixedAlpha << 24) | (color & 0x00FFFFFF);
    }

    @Override
    public void fill(int x1, int y1, int x2, int y2, int color) {
        this.state.addGuiElement(
                new ColoredRectangleRenderState(
                        RenderPipelines.GUI,
                        TextureSetup.noTexture(),
                        new Matrix3x2f(this.matrices.stack),
                        x1, y1, x2, y2, color, color,
                        this.scissorStack.peekLast()));
    }

    @Override
    public void drawRectangle(int x, int y, int width, int height, int color) {
        if (color == 0)
            return;
        color = getColor(color);

        int x1 = x;
        int x2 = x + width;
        int y1 = y;
        int y2 = y + height;

        if (x2 < x1) {
            int tmp = x1;
            x1 = x2;
            x2 = tmp;
        }
        if (y2 < y1) {
            int tmp = y1;
            y1 = y2;
            y2 = tmp;
        }

        this.fill(x1, y1, x2, y2, color);
    }

    @Override
    public void drawText(String text, int x, int y, int font, int color) {
        drawText(1.0f, text, x, y, font, color);
    }

    @Override
    public void drawText(float scale, String text, int x, int y, int font, int color) {
        if (color == 0)
            return;
        if (font == 0)
            scale *= 2;

        String safeText = text == null ? "" : text;
        int lineIndex = 0;
        int lineStart = 0;
        while (true) {
            int newline = safeText.indexOf('\n', lineStart);
            String line = lineStart == 0 && newline < 0 ? safeText
                    : safeText.substring(lineStart, newline < 0 ? safeText.length() : newline);
            int finalColor = getColor(color);

            matrices.push();
            matrices.translate(x, y + (lineIndex * Fonts.getHeight()));
            matrices.scale(scale, scale);

            this.state.addText(
                    new GuiTextRenderState(
                            CSClient.client.font,
                            ((Component) Fonts.setFont(line, font)).getVisualOrderText(),
                            new Matrix3x2f(this.matrices.stack),
                            0, font == 0 ? 1 : 8,
                            finalColor, 0, false, false, this.scissorStack.peekLast()));

            matrices.pop();

            lineIndex++;
            if (newline < 0) break;
            lineStart = newline + 1;
        }
    }

    @Override
    public int getScaledWindowWidth() {
        return CSClient.client.getWindow().getGuiScaledWidth();
    }

    @Override
    public int getScaledWindowHeight() {
        return CSClient.client.getWindow().getGuiScaledHeight();
    }

    // Texture rendering
    @Override
    public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height) {
        drawTexture(sprite, x, y, u, v, width, height, -1);
    }

    @Override
    public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height, int color) {
        drawTexture(sprite, x, y, u, v, width, height, width, height, width, height, color);
    }

    @Override
    public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height,
            int regionWidth, int regionHeight, int textureWidth, int textureHeight) {
        drawTexture(sprite, x, y, u, v, width, height, regionWidth, regionHeight, textureWidth, textureHeight, -1);
    }

    @Override
    public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height,
            int regionWidth, int regionHeight, int textureWidth, int textureHeight, int color) {
        drawTexturedQuad((Identifier) (Object) sprite, x, x + width, y, y + height,
                (u + 0f) / textureWidth,
                (u + regionWidth) / textureWidth,
                (v + 0f) / textureHeight,
                (v + regionHeight) / textureHeight,
                color);
    }

    private void drawTexturedQuad(Identifier sprite, int x1, int x2, int y1, int y2,
            float u1, float u2, float v1, float v2, int color) {
        if (color == 0)
            return;
        color = getColor(color);

        if (sprite.getPath().endsWith(".svg")) {
            sprite = (Identifier) (Object) SvgTexture.getSvg(
                    (IdentifierRef) (Object) sprite,
                    (x2 - x1) * 2, (y2 - y1) * 2);
        }

        GpuTextureView gpuTextureView = CSClient.client.getTextureManager()
                .getTexture(sprite).getTextureView();

        AbstractTexture abstractTexture = CSClient.client.getTextureManager().getTexture(sprite);

        this.state.addGuiElement(new BlitRenderState(
                RenderPipelines.GUI_TEXTURED,
                TextureSetup.singleTexture(gpuTextureView, abstractTexture.getSampler()),
                new Matrix3x2f(this.matrices.stack),
                x1, y1, x2, y2, u1, u2, v1, v2, color,
                this.scissorStack.peekLast()));
    }

    // Scissor management
    @Override
    public void enableScissor(int x1, int y1, int x2, int y2) {
        ScreenRectangle rect = new ScreenRectangle(x1, y1, x2 - x1, y2 - y1).transformAxisAligned(this.matrices.stack);
        scissorStack.push(rect);
    }

    @Override
    public void disableScissor() {
        scissorStack.pop();
    }

    @Override
    public boolean scissorContains(int x, int y) {
        return scissorStack.contains(x, y);
    }

    public static class ScissorStack {
        private final Deque<ScreenRectangle> stack = new ArrayDeque<>();

        public void clear() { stack.clear(); }

        public ScreenRectangle push(ScreenRectangle rect) {
            ScreenRectangle last = stack.peekLast();
            if (last != null) {
                ScreenRectangle intersection = Objects.requireNonNullElse(rect.intersection(last), ScreenRectangle.empty());
                stack.addLast(intersection);
                return intersection;
            } else {
                stack.addLast(rect);
                return rect;
            }
        }

        @Nullable
        public ScreenRectangle pop() {
            if (stack.isEmpty())
                throw new IllegalStateException("Scissor stack underflow");
            stack.removeLast();
            return stack.peekLast();
        }

        @Nullable
        public ScreenRectangle peekLast() {
            return stack.peekLast();
        }

        public boolean contains(int x, int y) {
            return stack.isEmpty() || stack.peekLast().containsPoint(x, y);
        }
    }

    // Item rendering
    @Override
    public void drawItem(ItemStackRef stack, int x, int y) {
        drawItem(null, CSClient.client.level, stack, x, y, 0);
    }

    private void drawItem(@Nullable LivingEntity entity, @Nullable Level world, ItemStackRef stack, int x, int y,
            int seed) {
        drawItem(entity, world, (ItemStack) (Object) stack, x, y, seed, 0);
    }

    private void drawItem(@Nullable LivingEntity entity, @Nullable Level world, ItemStack stack, int x, int y, int seed,
            int z) {
        if (!stack.isEmpty()) {
            TrackingItemStackRenderState keyedItemRenderState = new TrackingItemStackRenderState();
            CSClient.client.getItemModelResolver().updateForTopItem(keyedItemRenderState, stack,
                    ItemDisplayContext.GUI, world,
                    entity, seed);

            try {
                this.state.addItem(new GuiItemRenderState(new Matrix3x2f(this.matrices.stack), keyedItemRenderState, x, y,
                        this.scissorStack.peekLast()));
            } catch (Throwable throwable) {
                CrashReport crashReport = CrashReport.forThrowable(throwable, "Rendering item");
                CrashReportCategory crashReportSection = crashReport.addCategory("Item being rendered");
                crashReportSection.setDetail("Item Type", () -> String.valueOf(stack.getItem()));
                crashReportSection.setDetail("Item Components", () -> String.valueOf(stack.getComponents()));
                crashReportSection.setDetail("Item Foil", () -> String.valueOf(stack.hasFoil()));
                throw new ReportedException(crashReport);
            }
        }
    }

    @Override
    public void drawSpriteStretched(SpriteRef sprite, int x, int y, int width, int height) {
        drawSpriteStretched(sprite, x, y, width, height, -1);
    }

    @Override
    public void drawSpriteStretched(SpriteRef sprite, int x, int y, int width, int height, int color) {
        TextureAtlasSprite mcSprite = (TextureAtlasSprite) sprite;
        if (color == 0 || width == 0 || height == 0)
            return;

        drawTexturedQuad(mcSprite.atlasLocation(), x, x + width, y, y + height,
                mcSprite.getU0(), mcSprite.getU1(), mcSprite.getV0(), mcSprite.getV1(), color);
    }

    @Override
    public void draw() {
        // No-op for now
    }

    public void drawBorder(int x, int y, int width, int height, int color) {
        fill(x, y, x + width, y + 1, color);
        fill(x, y + height - 1, x + width, y + height, color);
        fill(x, y + 1, x + 1, y + height - 1, color);
        fill(x + width - 1, y + 1, x + width, y + height - 1, color);
    }

    public void addEntity(EntityRenderState entityState, float scale, Vector3f translation, Quaternionf rotation,
            @Nullable Quaternionf overrideCameraAngle, int x1, int y1, int x2, int y2) {

        Matrix3x2f mat = this.matrices.stack;
        float offsetX = mat.m20;
        float offsetY = mat.m21;
        float scaleX = mat.m00; // current matrix X scale
        float scaleY = mat.m11; // current matrix Y scale

        int adjustedX1 = (int) (x1 * scaleX + offsetX);
        int adjustedY1 = (int) (y1 * scaleY + offsetY);
        int adjustedX2 = (int) (x2 * scaleX + offsetX);
        int adjustedY2 = (int) (y2 * scaleY + offsetY);

        float adjustedScale = scale * scaleX; // apply matrix scale to entity scale too

        this.state.addPicturesInPictureState(new GuiEntityRenderState(entityState, translation, rotation,
                overrideCameraAngle, adjustedX1, adjustedY1, adjustedX2, adjustedY2, adjustedScale,
                this.scissorStack.peekLast()));
    }
}