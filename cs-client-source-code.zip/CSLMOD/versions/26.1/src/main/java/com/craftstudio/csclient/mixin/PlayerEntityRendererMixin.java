package com.craftstudio.csclient.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.ClientAvatarEntity;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.player.Player;
import com.craftstudio.csclient.branding.BrandingRenderState;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod;
import com.craftstudio.csclient.mod.mods.ClientBrandingMod;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod.HeartRow;
import com.craftstudio.csclient.mod.mods.NametagsMod;
import com.craftstudio.csclient.mod.mods.TotemCounterMod;
import com.craftstudio.csclient.mod.tracking.TotemTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds only the configurable health-heart row; all cosmetic render layers were removed. */
@Mixin(AvatarRenderer.class)
public abstract class PlayerEntityRendererMixin
        extends LivingEntityRenderer<Player, AvatarRenderState, PlayerModel> {
    private static final Identifier CS_HEART_FONT = Identifier.fromNamespaceAndPath("csclient", "health_hearts");
    /** Allocated once, not per player per frame. */
    private static final FontDescription.Resource HEART_FONT = new FontDescription.Resource(CS_HEART_FONT);
    private static final Component[] CS_BRAND_PREFIXES = {
            brandPrefix("brand_logo_small"), brandPrefix("brand_logo"), brandPrefix("brand_logo_large")
    };

    /**
     * Per-frame allocation elimination: player names, heart states and totem
     * counts are stable for long stretches, so the composed components are
     * interned. The renderer only reads these texts; appends elsewhere copy first.
     */
    private record BrandKey(String name, int prefix) { }
    private static final java.util.Map<BrandKey, MutableComponent> BRANDED_TAGS = new java.util.HashMap<>();
    private static final java.util.Map<HeartRow, MutableComponent> HEART_ROWS = new java.util.HashMap<>();
    private static final java.util.Map<Long, Component> POP_SUFFIXES = new java.util.HashMap<>();

    protected PlayerEntityRendererMixin() {
        super(null, null, 0.0f);
    }

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    public <A extends Avatar & ClientAvatarEntity> void updateRenderState(
            A entity, AvatarRenderState state, float f, CallbackInfo ci) {
        if (entity == null) return;
        Minecraft mc = Minecraft.getInstance();
        boolean ownPlayer = mc.player != null
                && entity.getUUID().equals(mc.player.getUUID());

        boolean showBrand = ClientBrandingMod.shouldRender(
                entity.getUUID(), ownPlayer, state.isInvisible, state.distanceToCameraSq,
                state.nameTag != null);
        if (state instanceof BrandingRenderState branding) {
            if (showBrand && state.nameTag != null) {
                // Prefix Minecraft's real nametag component; no separate OpenGL or overlay pass.
                state.nameTag = brandedTag(state.nameTag, ClientBrandingMod.logoScale());
                branding.csclient$setShowBrandLogo(false);
            } else {
                // Camera entities have no native tag, so self uses the safe attachment fallback.
                branding.csclient$setShowBrandLogo(showBrand && ownPlayer);
            }
        }
        int pops = TotemTracker.getPops(entity.getUUID());
        if (pops > 0 && state.nameTag != null && TotemCounterMod.shouldShowNametagPops()) {
            state.nameTag = state.nameTag.copy().append(popSuffix(pops));
        }
        if (state.nameTag != null && HealthDisplayMod.shouldShow(
                ownPlayer, state.isInvisible, state.distanceToCameraSq,
                entity.getHealth(), entity.getMaxHealth())) {
            HeartRow row = HealthDisplayMod.createHeartRow(
                    entity.getHealth(), entity.getMaxHealth(), entity.getAbsorptionAmount());
            state.scoreText = cachedHeartRow(row);
        }
    }

    private static MutableComponent brandedTag(Component displayName, int prefix) {
        String name = displayName.getString();
        BrandKey key = new BrandKey(name, prefix);
        MutableComponent cached = BRANDED_TAGS.get(key);
        if (cached != null) return cached;
        MutableComponent composed = Component.empty().append(CS_BRAND_PREFIXES[prefix]).append(displayName);
        if (BRANDED_TAGS.size() > 512) BRANDED_TAGS.clear();
        BRANDED_TAGS.put(key, composed);
        return composed;
    }

    private static Component popSuffix(int pops) {
        int color = TotemCounterMod.getPopColor() & 0x00FFFFFF;
        long key = ((long) pops << 32) ^ (color & 0xFFFFFFFFL);
        Component cached = POP_SUFFIXES.get(key);
        if (cached != null) return cached;
        Component suffix = Component.literal("  ✦ " + pops + " POP" + (pops == 1 ? "" : "S"))
                .withStyle(style -> style.withColor(color));
        if (POP_SUFFIXES.size() > 64) POP_SUFFIXES.clear();
        POP_SUFFIXES.put(key, suffix);
        return suffix;
    }

    private static MutableComponent cachedHeartRow(HeartRow row) {
        MutableComponent cached = HEART_ROWS.get(row);
        if (cached != null) return cached;
        MutableComponent built = buildHeartRow(row);
        if (HEART_ROWS.size() > 1024) HEART_ROWS.clear();
        HEART_ROWS.put(row, built);
        return built;
    }

    private static Component brandPrefix(String fontPath) {
        Identifier font = Identifier.fromNamespaceAndPath("csclient", fontPath);
        return Component.empty()
                .append(Component.literal(ClientBrandingMod.logoGlyph()).withStyle(style -> style
                        .withFont(new FontDescription.Resource(font)).withColor(0xFFFFFF)))
                .append(Component.literal(" "));
    }

    private static MutableComponent buildHeartRow(HeartRow row) {
        MutableComponent text = Component.empty();
        appendHearts(text, row.fullGlyphs(), row.fullColor());
        appendHearts(text, row.halfGlyphs(), row.fullColor());
        appendHearts(text, row.emptyGlyphs(), row.emptyColor());
        appendHearts(text, row.absorptionGlyphs(), row.absorptionColor());
        return text;
    }

    private static void appendHearts(MutableComponent text, String glyphs, int color) {
        if (glyphs.isEmpty()) return;
        text.append(Component.literal(glyphs).withStyle(style -> style
                .withFont(HEART_FONT)
                .withColor(color & 0x00FFFFFF)));
    }
}
