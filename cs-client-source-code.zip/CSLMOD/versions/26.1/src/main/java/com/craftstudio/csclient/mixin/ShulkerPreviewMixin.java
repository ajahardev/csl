package com.craftstudio.csclient.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.mods.ShulkerPreviewMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerScreen.class)
public abstract class ShulkerPreviewMixin {
    @Shadow protected Slot hoveredSlot;

    @Inject(method = "extractTooltip", at = @At("HEAD"), cancellable = true)
    private void csclient$drawShulkerPreview(GuiGraphicsExtractor context, int mouseX, int mouseY, CallbackInfo ci) {
        if (!ShulkerPreviewMod.isActive() || hoveredSlot == null || !hoveredSlot.hasItem()) return;
        if (ShulkerPreviewMod.requireShift()
                && !Providers.GLFW.isKeyPressed(GLFWProvider.GLFW_KEY_LEFT_SHIFT)
                && !Providers.GLFW.isKeyPressed(GLFWProvider.GLFW_KEY_RIGHT_SHIFT)) return;
        ItemStack hovered = hoveredSlot.getItem();
        if (!(hovered.getItem() instanceof BlockItem blockItem)
                || !(blockItem.getBlock() instanceof ShulkerBoxBlock)) return;
        ItemContainerContents container = hovered.get(DataComponents.CONTAINER);
        NonNullList<ItemStack> stacks = NonNullList.withSize(27, ItemStack.EMPTY);
        if (container != null) container.copyInto(stacks);

        Minecraft client = Minecraft.getInstance();
        int windowW = context.guiWidth();
        int windowH = context.guiHeight();
        int panelW = 172, panelH = 72;
        float scale = ShulkerPreviewMod.scale();
        int scaledW = Math.round(panelW * scale);
        int scaledH = Math.round(panelH * scale);
        int x = switch (ShulkerPreviewMod.position()) {
            case 1 -> Math.max(6, mouseX - scaledW - 16);
            case 2 -> Math.max(6, Math.min(windowW - scaledW - 6, mouseX + 18));
            default -> mouseX + 18 + scaledW < windowW ? mouseX + 18 : Math.max(6, mouseX - scaledW - 16);
        };
        int y = Math.max(6, Math.min(windowH - scaledH - 6, mouseY - Math.round(18 * scale)));

        context.pose().pushMatrix();
        context.pose().translate(x, y);
        context.pose().scale(scale, scale);
        int bg = ShulkerPreviewMod.style() == 1 ? 0xF0101010 : 0xF012171D;
        context.fill(0, 0, panelW, panelH, bg);
        context.fill(0, 0, panelW, 1, 0xFF9AA1AA);
        context.text(client.font, hovered.getHoverName(), 7, 6, 0xFFF0F2F4, false);
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++) {
            int sx = 5 + col * 18, sy = 18 + row * 18;
            context.fill(sx, sy, sx + 18, sy + 18, 0x781A2027);
            ItemStack stack = stacks.get(row * 9 + col);
            if (!stack.isEmpty()) {
                context.item(stack, sx + 1, sy + 1);
                context.itemDecorations(client.font, stack, sx + 1, sy + 1);
            }
        }
        context.pose().popMatrix();
        // Suppress the vanilla item-name/text tooltip while the CS grid is visible.
        ci.cancel();
    }
}
