package com.craftstudio.csclient.mixin;

import java.util.List;

import org.objectweb.asm.Opcodes;
import com.craftstudio.csclient.impl.render.BlockBreakLayers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import net.minecraft.client.renderer.feature.BlockFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;

@Mixin(BlockFeatureRenderer.class)
public abstract class BlockBreakWorldMixin {
    @Redirect(method = "renderBreakingBlockModelSubmits", at = @At(value = "FIELD",
            target = "Lnet/minecraft/client/resources/model/ModelBakery;DESTROY_TYPES:Ljava/util/List;",
            opcode = Opcodes.GETSTATIC))
    private List<RenderType> csclient$selectBlockBreakLayers() {
        return BlockBreakLayers.active();
    }
}
