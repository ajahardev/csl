package com.craftstudio.csclient.impl.mixins;

import net.minecraft.client.gui.Gui;
import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;
import com.craftstudio.csclient.common.ref.game.EffectRef;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(MobEffectInstance.class)
public abstract class StatusEffectMixin implements EffectRef {

    @Shadow
    public abstract boolean showIcon();

    @Shadow
    public abstract boolean isInfiniteDuration();

    @Shadow
    public abstract int getDuration();

    @Shadow
    public abstract Holder<MobEffect> getEffect();

    @Override
    public boolean shouldShowIcon() {
        return showIcon();
    }

    @Override
    public boolean isInfinite() {
        return isInfiniteDuration();
    }

    @Override
    public SpriteRef getIcon() {
        return null;
    }

    @Override
    public IdentifierRef getIconId() {
        Identifier id = Gui.getMobEffectSprite(getEffect());

        return IdentifierRef.of(id.getNamespace(), "textures/" + id.getPath() + ".png");
    }

    @Override
    public String getInfiniteText() {
        return "∞";
    }

    @Override
    public int getDurationSeconds() {
        return getDuration() / 20; // ticks → seconds
    }
}