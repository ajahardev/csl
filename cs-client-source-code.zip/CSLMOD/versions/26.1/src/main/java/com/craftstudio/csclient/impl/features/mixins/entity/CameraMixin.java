package com.craftstudio.csclient.impl.features.mixins.entity;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import com.craftstudio.csclient.impl.features.entity.CameraOverriddenEntity;
import com.craftstudio.csclient.mod.mods.FreelookMod;
import com.craftstudio.csclient.CSClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Unique
    private boolean csclient$firstFreelookFrame = true;

    @Shadow
    private Entity entity;

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    /**
     * Minecraft 26.1 moved camera setup into Camera#update. Apply the
     * independent freelook rotation immediately after vanilla aligns the camera
     * with its focused entity, before the view/projection matrices are built.
     */
    @Inject(
            method = "update",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/Camera;alignWithEntity(F)V",
                    shift = At.Shift.AFTER))
    private void csclient$lockRotation(DeltaTracker deltaTracker, CallbackInfo ci) {
        Entity cameraEntity = this.entity;

        if (FreelookMod.isFreeLooking() && cameraEntity instanceof LocalPlayer) {
            CameraOverriddenEntity overridden = (CameraOverriddenEntity) cameraEntity;

            if (this.csclient$firstFreelookFrame && CSClient.client.player != null) {
                overridden.freelook$setCameraPitch(CSClient.client.player.getXRot());
                overridden.freelook$setCameraYaw(CSClient.client.player.getYRot());
                this.csclient$firstFreelookFrame = false;
            }

            this.setRotation(overridden.freelook$getCameraYaw(), overridden.freelook$getCameraPitch());
        } else if (cameraEntity instanceof LocalPlayer) {
            this.csclient$firstFreelookFrame = true;
        }
    }
}
