package com.craftstudio.csclient.impl.mixins;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.ProfileResult;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.blaze3d.platform.Window;
import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Path;
import java.util.Optional;
import java.util.UUID;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import org.jetbrains.annotations.Nullable;
import com.craftstudio.csclient.account.LocalAccountManager;
import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;
import com.craftstudio.csclient.common.ref.render.WindowRef;
import com.craftstudio.csclient.impl.skin.LocalSkinRuntime;
import com.craftstudio.csclient.impl.ui.CSClientScreenFabric;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.util.ExternalLinks;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import com.craftstudio.csclient.ui.screens.TitleMenu;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.User;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.ShareToLanScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.social.PlayerSocialManager;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.multiplayer.ProfileKeyPairManager;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.chat.report.ReportEnvironment;
import net.minecraft.client.multiplayer.chat.report.ReportingContext;
import net.minecraft.client.telemetry.ClientTelemetryManager;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;
import net.minecraft.server.Services;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.world.level.GameType;
import net.minecraft.server.packs.resources.ReloadableResourceManager;

@Mixin(Minecraft.class)
public abstract class MinecraftClientMixin implements MinecraftClientRef {
    @Shadow public File gameDirectory;
    @Shadow private Window window;
    @Shadow private ReloadableResourceManager resourceManager;
    @Shadow public Options options;
    @Shadow @Final private java.net.Proxy proxy;

    @Shadow @Final @Mutable private User user;
    @Shadow @Final @Mutable private CompletableFuture<ProfileResult> profileFuture;
    @Shadow @Final @Mutable private UserApiService userApiService;
    @Shadow @Final @Mutable private CompletableFuture<UserApiService.UserProperties> userPropertiesFuture;
    @Shadow @Final @Mutable private PlayerSocialManager playerSocialManager;
    @Shadow @Final @Mutable private ClientTelemetryManager telemetryManager;
    @Shadow @Final @Mutable private ProfileKeyPairManager profileKeyPairManager;
    @Shadow @Final @Mutable private Services services;
    @Shadow private ReportingContext reportingContext;

    @Shadow public abstract void setScreen(@Nullable Screen screen);
    @Shadow public abstract void stop();

    @Override
    public void scheduleStop() { stop(); }

    @Override
    public File getRunDirectory() { return gameDirectory; }

    @Override
    public InputStream getResource(IdentifierRef identifier) {
        try {
            return resourceManager.getResource((Identifier) (Object) identifier).get().open();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public WindowRef getWindow() { return (WindowRef) (Object) window; }

    @Override
    public void setScreen(CSClientScreen screen) { setScreen(new CSClientScreenFabric(screen)); }

    @Override
    public void setScreen(MinecraftScreen screen) {
        boolean inGame = ((Minecraft) (Object) this).level != null;
        CSClientScreenFabric exitTarget = new CSClientScreenFabric(inGame ? new PauseMenu() : new TitleMenu());
        switch (screen) {
            case SelectWorld -> setScreen(new SelectWorldScreen(exitTarget));
            case Multiplayer -> setScreen(new JoinMultiplayerScreen(exitTarget));
            case Options -> setScreen(new OptionsScreen(exitTarget, options, Minecraft.getInstance().level != null));
            case Disconnect -> ((Minecraft) (Object) this)
                    .disconnect(new CSClientScreenFabric(new TitleMenu()), false);
        }
    }

    @Override
    public Object currentScreen() {
        return ((Minecraft) (Object) this).screen;
    }

    @Override
    public boolean openNativeScreen(Object screen) {
        if (screen instanceof Screen nativeScreen) {
            setScreen(nativeScreen);
            return true;
        }
        return false;
    }

    @Override
    public UUID getUuid() { return user == null ? null : user.getProfileId(); }

    @Override
    public String getUsername() { return user == null ? null : user.getName(); }

    @Override
    public boolean isLauncherOfflineProfile() {
        UUID uuid = getUuid();
        String username = getUsername();
        if (uuid == null || username == null || username.isBlank()
                || LocalAccountManager.isLocalAccount(uuid) || user == null) {
            return false;
        }

        return LocalAccountManager.isLikelyOfflineLauncherSession(
                username, uuid, user.getAccessToken());
    }

    @Override
    public boolean switchLocalAccount(String username, UUID uuid) {
        Minecraft client = (Minecraft) (Object) this;
        if (client.level != null || client.player != null || client.getConnection() != null
                || username == null || uuid == null) return false;
        try {
            User localUser = new User(username, uuid, "", Optional.empty(), Optional.empty());
            UserApiService offlineApi = UserApiService.OFFLINE;
            YggdrasilAuthenticationService authentication = YggdrasilAuthenticationService.createOffline(proxy);
            Services offlineServices = Services.create(authentication, gameDirectory);

            user = localUser;
            profileFuture = CompletableFuture.completedFuture(null);
            userApiService = offlineApi;
            userPropertiesFuture = CompletableFuture.completedFuture(UserApiService.OFFLINE_PROPERTIES);
            playerSocialManager = new PlayerSocialManager(client, offlineApi);
            try { telemetryManager.close(); } catch (Exception ignored) { }
            telemetryManager = new ClientTelemetryManager(client, offlineApi, localUser);
            profileKeyPairManager = ProfileKeyPairManager.EMPTY_KEY_MANAGER;
            reportingContext = ReportingContext.create(ReportEnvironment.local(), offlineApi);
            services = offlineServices;
            return true;
        } catch (Throwable throwable) {
            com.craftstudio.csclient.common.provider.Providers.csClient
                    .logError("Unable to switch local Minecraft profile", throwable);
            return false;
        }
    }

    @Override
    public void onClientStopping(Runnable handler) {
        ClientLifecycleEvents.CLIENT_STOPPING.register(_o -> handler.run());
    }

    @Override
    public void executeOnThread(Runnable runnable) {
        ((java.util.concurrent.Executor) (Object) this).execute(runnable);
    }

    @Override
    public String getClipboardText() {
        String text = ((Minecraft) (Object) this).keyboardHandler.getClipboard();
        return text == null ? "" : text;
    }

    @Override
    public void setClipboardText(String text) {
        ((Minecraft) (Object) this).keyboardHandler.setClipboard(text == null ? "" : text);
    }

    @Override
    public boolean applyLocalAppearance(Path skinPng, Path capePng, String model) {
        return LocalSkinRuntime.apply(skinPng, capePng, model);
    }

    @Override
    public void resetLocalSkin() {
        LocalSkinRuntime.reset();
    }

    @Override
    public IdentifierRef getActiveSkinTexture() {
        try {
            return (IdentifierRef) (Object) LocalSkinRuntime.getPreviewSkin().body().texturePath();
        } catch (LinkageError | RuntimeException ignored) {
            return null;
        }
    }

    @Override
    public boolean openNativePngPicker(String title, Consumer<Path> result) {
        try {
            CompletableFuture.runAsync(() -> {
                Path selected = null;
                try (MemoryStack stack = MemoryStack.stackPush()) {
                    PointerBuffer filters = stack.mallocPointer(1);
                    filters.put(stack.UTF8("*.png")).flip();
                    String path = TinyFileDialogs.tinyfd_openFileDialog(
                            title == null ? "Choose PNG" : title,
                            gameDirectory.toPath().toAbsolutePath().toString(),
                            filters, "PNG image", false);
                    if (path != null && !path.isBlank()) selected = Path.of(path);
                } catch (Throwable error) {
                    com.craftstudio.csclient.common.provider.Providers.csClient
                            .logError("Native PNG chooser is unavailable", error);
                }
                Path chosen = selected;
                executeOnThread(() -> { if (result != null) result.accept(chosen); });
            });
            return true;
        } catch (RuntimeException error) {
            return false;
        }
    }

    /** Opens Minecraft's native connection flow only for the exact Home PlantMC slot. */
    @Override
    public boolean joinFeaturedServer() {
        if (!FeaturedServers.isApprovedJoinAddress(FeaturedServers.PLANTMC_ADDRESS)) return false;
        Minecraft client = (Minecraft) (Object) this;
        if (client.level != null || client.getConnection() != null) return false;
        try {
            Screen parent = client.screen;
            if (parent == null) parent = new CSClientScreenFabric(new TitleMenu());
            ServerData server = new ServerData("PlantMC", FeaturedServers.PLANTMC_ADDRESS,
                    ServerData.Type.OTHER);
            ConnectScreen.startConnecting(parent, client,
                    ServerAddress.parseString(FeaturedServers.PLANTMC_ADDRESS), server, false, null);
            return true;
        } catch (Exception error) {
            com.craftstudio.csclient.common.provider.Providers.csClient
                    .logError("Unable to open the featured server connection", error);
            return false;
        }
    }

    @Override
    public boolean openExternalUrl(String url) {
        if (!ExternalLinks.isApprovedExternalLink(url)) return false;
        try {
            Util.getPlatform().openUri(URI.create(url));
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    @Override
    public boolean sendChatMessage(String message) {
        String safe = message == null ? "" : message.trim();
        if (safe.isEmpty() || safe.startsWith("/") || safe.indexOf('\n') >= 0 || safe.indexOf('\r') >= 0) return false;
        var handler = ((Minecraft) (Object) this).getConnection();
        if (handler == null) return false;
        handler.sendChat(safe);
        return true;
    }

    @Override
    public String getCurrentServerAddress() {
        var server = ((Minecraft) (Object) this).getCurrentServer();
        return server == null || server.ip == null ? "" : server.ip;
    }

    @Override
    public boolean isModLoaded(String modId) { return FabricLoader.getInstance().isModLoaded(modId); }

    @Override
    public String getExternalModCount() {
        if (!isModLoaded("modmenu")) return "";
        try {
            Object count = Class.forName("com.terraformersmc.modmenu.ModMenu")
                    .getMethod("getDisplayedModCount").invoke(null);
            if (count != null && !count.toString().isBlank()) return count.toString();
        } catch (ReflectiveOperationException ignored) {
            // Older/future Mod Menu builds may not expose the display helper.
        }
        return Integer.toString(FabricLoader.getInstance().getAllMods().size());
    }

    @Override
    public List<LoadedModInfo> getLoadedMods() {
        return FabricLoader.getInstance().getAllMods().stream()
                .map(container -> new LoadedModInfo(container.getMetadata().getId(),
                        container.getMetadata().getName(),
                        container.getMetadata().getVersion().getFriendlyString()))
                .sorted(Comparator.comparing(LoadedModInfo::name, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    @Override
    public void openExternalModMenu() {
        if (!isModLoaded("modmenu")) return;
        Screen parent = ((Minecraft) (Object) this).screen;
        try {
            // This is Mod Menu's documented compatibility API and preserves Done/back.
            Class<?> api = Class.forName("com.terraformersmc.modmenu.api.ModMenuApi");
            Screen mods = (Screen) api.getMethod("createModsScreen", Screen.class).invoke(null, parent);
            setScreen(mods);
            return;
        } catch (ReflectiveOperationException ignored) {
            // Fall back for legacy versions that predate createModsScreen.
        }
        try {
            Class<?> type = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            setScreen((Screen) type.getConstructor(Screen.class).newInstance(parent));
        } catch (ReflectiveOperationException error) {
            com.craftstudio.csclient.common.provider.Providers.csClient
                    .logError("Unable to open optional Mod Menu screen", error);
        }
    }

    @Override
    public boolean canOpenNativeWorldHost() {
        Minecraft client = (Minecraft) (Object) this;
        IntegratedServer server = client.getSingleplayerServer();
        return client.level != null && server != null && !server.isPublished();
    }

    @Override
    public boolean openNativeWorldHost(CSClientScreen parent) {
        if (!canOpenNativeWorldHost()) return false;
        try {
            Screen background = new CSClientScreenFabric(parent == null ? new PauseMenu() : parent);
            setScreen(new ShareToLanScreen(background));
            return true;
        } catch (LinkageError | RuntimeException error) {
            return false;
        }
    }

    @Override
    @SuppressWarnings("resource")
    public String getPlayerListEntry(UUID uuid) {
        var handler = ((Minecraft) (Object) this).getConnection();
        if (handler == null) return null;
        var entry = handler.getPlayerInfo(uuid);
        return entry == null ? null : entry.getProfile().name();
    }

    @Override
    @SuppressWarnings("resource")
    public UUID getPlayerListEntryUUID(String name) {
        var handler = ((Minecraft) (Object) this).getConnection();
        if (handler == null) return null;
        var entry = handler.getPlayerInfo(name);
        return entry == null ? null : entry.getProfile().id();
    }
}
