package com.craftstudio.csclient.impl.mixins;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(TextureAtlasSprite.class)
public abstract class SpriteMixin implements SpriteRef {
}