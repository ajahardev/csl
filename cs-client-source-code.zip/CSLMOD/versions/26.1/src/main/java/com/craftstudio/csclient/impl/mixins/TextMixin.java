package com.craftstudio.csclient.impl.mixins;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription.Resource;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.render.TextRef;
import com.craftstudio.csclient.CSClient;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Component.class)
public interface TextMixin extends TextRef {

    @Override
    public default TextRef withFont(IdentifierRef font) {
        return (TextRef) (Component) (((Component) this).copy().setStyle(Style.EMPTY.withFont(new Resource((Identifier) (Object) font))));
    }

    @Override
    public default int getWidth() {
        return CSClient.client.font.width((Component) this);
    }
}
