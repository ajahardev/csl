package com.craftstudio.csclient.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import com.craftstudio.csclient.mod.mods.LowFireMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public class LowFireMixin {
    @Inject(method = "renderFire", at = @At(value = "INVOKE",
            target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V"))
    private static void csclient$lowerFire(PoseStack matrices, MultiBufferSource vertices,
            TextureAtlasSprite sprite, CallbackInfo ci) {
        if (LowFireMod.isActive()) matrices.translate(0f, LowFireMod.verticalOffset(), 0f);
    }
}
