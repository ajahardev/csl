package com.craftstudio.csclient.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import com.craftstudio.csclient.mod.tracking.TotemTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Observes vanilla entity events; it never changes combat behavior. */
@Mixin(ClientPacketListener.class)
public class TotemTrackerMixin {
    @Inject(method = "handleEntityEvent", at = @At("HEAD"))
    private void csclient$trackTotemPop(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        Minecraft client = Minecraft.getInstance();
        if (client.level == null) return;
        Entity entity = packet.getEntity(client.level);
        if (!(entity instanceof Player player)) return;
        byte status = packet.getEventId();
        if (status == 35) {
            boolean local = client.player != null && player.getUUID().equals(client.player.getUUID());
            TotemTracker.recordPop(player.getUUID(), player.getName().getString(), local);
        } else if (status == 3) {
            TotemTracker.resetPlayer(player.getUUID());
        }
    }
}
