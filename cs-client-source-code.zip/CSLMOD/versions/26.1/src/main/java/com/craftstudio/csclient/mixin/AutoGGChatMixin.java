package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.AutoGGTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;

/** Observes server system result lines only; player chat cannot trigger Auto GG. */
@Mixin(ChatComponent.class)
public abstract class AutoGGChatMixin {
    @Inject(method = "addServerSystemMessage", at = @At("HEAD"))
    private void csclient$observeServerGameEnd(Component text, CallbackInfo ci) {
        if (text != null) AutoGGTracker.onIncomingMessage(text.getString());
    }
}
