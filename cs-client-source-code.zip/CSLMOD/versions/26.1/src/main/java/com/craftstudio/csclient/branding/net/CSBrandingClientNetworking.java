package com.craftstudio.csclient.branding.net;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import com.craftstudio.csclient.branding.ClientBrandingState;

/** Client half of the optional server-relayed capability exchange. */
public final class CSBrandingClientNetworking {
    private static boolean initialized;
    private CSBrandingClientNetworking() { }

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        CSBrandingProtocol.initialize();
        ClientPlayNetworking.registerGlobalReceiver(CSBrandingProtocol.PresencePayload.TYPE,
                (payload, context) -> context.client().execute(() -> {
                    ClientBrandingState.setBridgeAvailable(true);
                    ClientBrandingState.update(payload.uuid(), payload.csClient());
                }));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ClientBrandingState.clear();
            boolean bridge = ClientPlayNetworking.canSend(CSBrandingProtocol.HelloPayload.TYPE);
            ClientBrandingState.setBridgeAvailable(bridge);
            // Our own client identity is locally certain even on servers without a relay.
            if (client.player != null) ClientBrandingState.update(client.player.getUUID(), true);
            if (bridge) ClientPlayNetworking.send(
                    new CSBrandingProtocol.HelloPayload(ClientBrandingState.PROTOCOL_VERSION));
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientBrandingState.clear());
    }
}
