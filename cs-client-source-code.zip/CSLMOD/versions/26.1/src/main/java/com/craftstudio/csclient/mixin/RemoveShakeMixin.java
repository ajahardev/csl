package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.RemoveShakeMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import net.minecraft.client.renderer.GameRenderer;

@Mixin(GameRenderer.class)
public abstract class RemoveShakeMixin {
    @ModifyConstant(method = "bobHurt", constant = @Constant(doubleValue = 14.0D))
    private double csclient$scaleHurtCamera(double vanilla) {
        return RemoveShakeMod.isActive() ? vanilla * RemoveShakeMod.multiplier() : vanilla;
    }
}
