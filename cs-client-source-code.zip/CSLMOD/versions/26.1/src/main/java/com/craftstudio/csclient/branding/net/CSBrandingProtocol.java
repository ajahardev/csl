package com.craftstudio.csclient.branding.net;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import com.craftstudio.csclient.branding.ClientBrandingState;

/** Optional Fabric server relay. No gameplay state is modified. */
public final class CSBrandingProtocol implements ModInitializer {
    private static final Set<UUID> CS_PLAYERS = new HashSet<>();
    private static boolean initialized;

    public record HelloPayload(int protocol) implements CustomPacketPayload {
        public static final Type<HelloPayload> TYPE = new Type<>(
                Identifier.fromNamespaceAndPath("csclient", "brand_hello"));
        public static final StreamCodec<RegistryFriendlyByteBuf, HelloPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, HelloPayload::protocol, HelloPayload::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record PresencePayload(UUID uuid, boolean csClient) implements CustomPacketPayload {
        public static final Type<PresencePayload> TYPE = new Type<>(
                Identifier.fromNamespaceAndPath("csclient", "brand_presence"));
        public static final StreamCodec<RegistryFriendlyByteBuf, PresencePayload> CODEC = StreamCodec.composite(
                UUIDUtil.STREAM_CODEC, PresencePayload::uuid,
                ByteBufCodecs.BOOL, PresencePayload::csClient,
                PresencePayload::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    @Override public void onInitialize() { initialize(); }

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        PayloadTypeRegistry.serverboundPlay().register(HelloPayload.TYPE, HelloPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(PresencePayload.TYPE, PresencePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(HelloPayload.TYPE, (payload, context) -> {
            if (payload.protocol() != ClientBrandingState.PROTOCOL_VERSION) return;
            ServerPlayer player = context.player();
            UUID uuid = player.getUUID();
            synchronized (CS_PLAYERS) { CS_PLAYERS.add(uuid); }
            sendSnapshot(player);
            broadcast(context.server(), new PresencePayload(uuid, true));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID uuid = handler.getPlayer().getUUID();
            boolean removed;
            synchronized (CS_PLAYERS) { removed = CS_PLAYERS.remove(uuid); }
            if (removed) broadcast(server, new PresencePayload(uuid, false));
        });
    }

    private static void sendSnapshot(ServerPlayer target) {
        if (!ServerPlayNetworking.canSend(target, PresencePayload.TYPE)) return;
        UUID[] snapshot;
        synchronized (CS_PLAYERS) { snapshot = CS_PLAYERS.toArray(UUID[]::new); }
        for (UUID uuid : snapshot) ServerPlayNetworking.send(target, new PresencePayload(uuid, true));
    }

    private static void broadcast(MinecraftServer server, PresencePayload payload) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (ServerPlayNetworking.canSend(player, PresencePayload.TYPE)) {
                ServerPlayNetworking.send(player, payload);
            }
        }
    }
}
