package com.craftstudio.csclient.mixin;

import com.mojang.blaze3d.platform.Window;
import java.util.Optional;
import java.util.function.Consumer;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.impl.ui.RenderScopeImpl;
import com.craftstudio.csclient.ui.LoadingVisuals;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.server.packs.resources.ReloadInstance;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

@Mixin(value = LoadingOverlay.class, priority = 900)
public abstract class SplashOverlayMixin {

    @Shadow
    private Minecraft minecraft;
    @Shadow
    private ReloadInstance reload;

    @Shadow
    private long fadeOutStart;

    @Shadow
    private long fadeInStart;

    @Shadow
    @Final
    private boolean fadeIn;

    @Shadow
    @Final
    private Consumer<Optional<Throwable>> onFinish;

    @Shadow
    private float currentProgress;

    /**
     * Non-destructive injection preserves LoadingOverlay bytecode for RRLS and
     * other animation mixins. RRLS owns the overlay whenever it is installed.
     */
    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true)
    private void csclient$extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY,
            float delta, CallbackInfo ci) {
        if (FabricLoader.getInstance().isModLoaded("rrls")) return;

        int screenWidth = context.guiWidth();
        int screenHeight = context.guiHeight();
        long currentTime = Util.getMillis();

        // Initialize reload start time if not set
        if (fadeInStart == -1L) {
            fadeInStart = currentTime;
        }

        // Compute fade-out progress after reload completes
        float fadeOutProgress = fadeOutStart > -1L
                ? (float) (currentTime - fadeOutStart) / LoadingVisuals.FADE_OUT_MILLIS
                : -1f;

        int alpha = fadeOutProgress >= 0f
                ? Mth.ceil((1.0f - Mth.clamp(fadeOutProgress, 0f, 1f)) * 255f)
                : 255;

        // Compute fade-in progress while reloading
        float reloadProgress = fadeInStart > -1L
                ? (float) (currentTime - fadeInStart) / LoadingVisuals.FADE_IN_MILLIS
                : -1f;

        // Get render scope for better UI
        RenderScope scope = new RenderScopeImpl(context);

        // Draw background overlay
        if (fadeOutProgress >= 0.0F) {
            renderCurrentScreen(context, mouseX, mouseY, delta);
            int overlayAlpha = computeOverlayAlpha(fadeOutProgress);
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(overlayAlpha, 0xFFFFFFFF));
        } else if (fadeIn) {
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(alpha, 0xFFFFFFFF));
        } else {
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(alpha, 0xFFFFFFFF));
        }

        float u = this.reload.getActualProgress();
        this.currentProgress = Mth.clamp(this.currentProgress * 0.95F + u * 0.050000012F, 0.0F, 1.0F);

        // Shared animated CS loading composition.
        LoadingVisuals.render(scope, screenWidth, screenHeight, currentProgress, alpha, currentTime);

        // Remove overlay after fade-out completes
        if (fadeOutProgress >= 1.0F) {
            minecraft.setOverlay(null);
        }

        // Handle reload completion and exceptions
        handleReloadCompletion(context);
        ci.cancel();
    }

    private void renderCurrentScreen(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        if (minecraft.screen != null) {
            minecraft.screen.extractRenderStateWithTooltipAndSubtitles(context, mouseX, mouseY, delta);
        }
    }

    /** Compute overlay alpha from fade progress */
    private int computeOverlayAlpha(float progress) {
        return Mth.ceil((1.0F - Mth.clamp(progress, 0.0F, 1.0F)) * 255.0F);
    }

    /** Handle reload completion logic */
    private void handleReloadCompletion(GuiGraphicsExtractor context) {
        float reloadProgress = fadeInStart > -1L
                ? (float) (Util.getMillis() - fadeInStart) / LoadingVisuals.FADE_IN_MILLIS
                : -1f;

        if (fadeOutStart == -1L && reload.isDone() && (!fadeIn || reloadProgress >= 0.7F)) {
            try {
                reload.checkExceptions();
                onFinish.accept(Optional.empty());
            } catch (Throwable ex) {
                onFinish.accept(Optional.of(ex));
            }

            fadeOutStart = Util.getMillis();

            Window window = minecraft.getWindow();
            if (minecraft.screen != null) {
                minecraft.screen.init(window.getGuiScaledWidth(), window.getGuiScaledHeight());
            }
        }
    }
}