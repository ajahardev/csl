package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.CSClient;
import com.craftstudio.csclient.mod.mods.PerformanceBoostMod;
import com.craftstudio.csclient.performance.EntityOcclusionCulling;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Skips the render pass of entities hidden behind opaque blocks (Feather/Lunar
 * class occlusion culling). Only changes what is drawn — never simulation.
 */
@Mixin(EntityRenderer.class)
public abstract class EntityOcclusionMixin {

    @Inject(method = "shouldRender", at = @At("TAIL"), cancellable = true)
    private void csclient$occlusionCull(Entity entity, Frustum frustum,
            double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> ci) {
        if (entity == null || ci.getReturnValueZ() != Boolean.TRUE
                || !PerformanceBoostMod.occlusionCulling()) {
            return;
        }
        try {
            Minecraft mc = CSClient.client;
            boolean own = mc.player != null && mc.player.getUUID().equals(entity.getUUID());
            Vec3 eye = entity.getEyePosition(0f);
            if (EntityOcclusionCulling.shouldSkip(entity.getUUID(), eye.x, eye.y, eye.z,
                    camX, camY, camZ, entity instanceof Player, own)) {
                ci.setReturnValue(false);
            }
        } catch (Throwable failure) {
            EntityOcclusionCulling.disableSafely(failure);
        }
    }
}
