package com.craftstudio.csclient.impl.provider;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import com.craftstudio.csclient.common.provider.RefConstructorProvider;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.render.TextRef;

public class RefConstructorImpl implements RefConstructorProvider {
    @Override
    public IdentifierRef identifier(String fullPath) {
        return (IdentifierRef) (Object) Identifier.parse(fullPath);
    }

    @Override
    public IdentifierRef identifier(String namespace, String path) {
        return (IdentifierRef) (Object) Identifier.fromNamespaceAndPath(namespace, path);
    }

    @Override
    public TextRef text(String text) {
        return (TextRef) (Component) Component.literal(text);
    }
}
