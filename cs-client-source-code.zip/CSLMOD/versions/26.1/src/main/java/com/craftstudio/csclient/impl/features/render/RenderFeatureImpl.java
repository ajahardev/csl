package com.craftstudio.csclient.impl.features.render;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import com.craftstudio.csclient.common.feature.RenderFeature;

/** Mojang-named adapter for window, FPS, and camera perspective only. */
public class RenderFeatureImpl implements RenderFeature {
    private final Minecraft mc;

    public RenderFeatureImpl(Minecraft mc) { this.mc = mc; }
    @Override public int getScaledWindowWidth() { return mc.getWindow().getGuiScaledWidth(); }
    @Override public int getScaledWindowHeight() { return mc.getWindow().getGuiScaledHeight(); }
    @Override public int getFps() { return mc.getFps(); }
    @Override public boolean isFirstPerson() { return mc.options.getCameraType() == CameraType.FIRST_PERSON; }
    @Override public void setFirstPerson() { mc.options.setCameraType(CameraType.FIRST_PERSON); }
    @Override public void setThirdPersonBack() { mc.options.setCameraType(CameraType.THIRD_PERSON_BACK); }
}
