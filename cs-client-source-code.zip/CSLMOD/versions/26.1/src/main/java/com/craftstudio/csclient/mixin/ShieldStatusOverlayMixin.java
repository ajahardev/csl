package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ShieldRenderContext;
import com.craftstudio.csclient.mod.mods.ShieldStatusesMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.object.equipment.ShieldModel;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.special.ShieldSpecialRenderer;
import net.minecraft.client.resources.model.sprite.SpriteGetter;
import net.minecraft.client.resources.model.sprite.SpriteId;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.util.Unit;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Second translucent model pass; the original/resource-pack shield pass remains untouched. */
@Mixin(ShieldSpecialRenderer.class)
public abstract class ShieldStatusOverlayMixin {
    @Shadow @Final private SpriteGetter sprites;
    @Shadow @Final private ShieldModel model;

    @Inject(method = "submit(Lnet/minecraft/core/component/DataComponentMap;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;IIZI)V",
            at = @At("TAIL"))
    private void csclient$submitShieldStatusOverlay(DataComponentMap components, PoseStack matrices,
            SubmitNodeCollector queue, int light, int overlay, boolean glint, int outlineColor,
            CallbackInfo ci) {
        if (!ShieldStatusesMod.firstPersonOverlayEnabled() || !ShieldRenderContext.isFirstPersonShield()) return;
        float tickDelta = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
        int color = ShieldStatusesMod.firstPersonColor(tickDelta);
        SpriteId sprite = Sheets.SHIELD_BASE_NO_PATTERN;
        matrices.pushPose();
        matrices.scale(1.0015f, 1.0015f, 1.0015f);
        queue.submitModel(model, Unit.INSTANCE, matrices,
                sprite.renderType(RenderTypes::entityTranslucent), light, overlay, color,
                sprites.get(sprite), outlineColor, null);
        matrices.popPose();
    }
}
