package com.craftstudio.csclient.impl.features.network;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import com.craftstudio.csclient.common.feature.NetworkFeature;

/**
 * Fabric implementation of {@link NetworkFeature}.
 *
 * Connection presence is checked via the network handler.
 * Ping is read from the player's {@link PlayerInfo} which the
 * server populates; returns {@code -1} when unavailable.
 */
public class NetworkFeatureImpl implements NetworkFeature {

    private final Minecraft mc;

    public NetworkFeatureImpl(Minecraft mc) {
        this.mc = mc;
    }

    @Override
    public boolean hasNetwork() {
        return mc.getConnection() != null;
    }

    @Override
    public int getPing() {
        if (mc.player == null || mc.getConnection() == null)
            return -1;

        PlayerInfo entry = mc.getConnection().getPlayerInfo(mc.player.getUUID());

        return entry != null ? entry.getLatency() : -1;
    }
}
