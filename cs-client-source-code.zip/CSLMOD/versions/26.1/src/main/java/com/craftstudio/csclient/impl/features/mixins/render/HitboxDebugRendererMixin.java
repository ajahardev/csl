package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.debug.EntityHitboxDebugRenderer;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;

import com.craftstudio.csclient.mod.mods.HitboxMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Filters vanilla debug hitbox visuals without changing any actual entity hitbox. */
@Mixin(EntityHitboxDebugRenderer.class)
public class HitboxDebugRendererMixin {
    @Inject(method = "showHitboxes", at = @At("HEAD"), cancellable = true)
    private void csclient$filterHitbox(Entity entity, float tickProgress, boolean inLocalServer, CallbackInfo ci) {
        if (!HitboxMod.isActive()) return; // Preserve unmodified F3+B behavior while the module is off.
        if (!shouldRender(entity)) ci.cancel();
    }

    private static boolean shouldRender(Entity entity) {
        Minecraft client = Minecraft.getInstance();
        if (entity == null || client.player == null) return false;
        int range = HitboxMod.maxDistance();
        if (entity.distanceToSqr(client.player) > range * (double) range) return false;
        if (entity instanceof Player) return HitboxMod.showPlayers();
        if (entity instanceof Monster) return HitboxMod.showHostile();
        if (entity instanceof AgeableMob) return HitboxMod.showPassive();
        return entity instanceof Mob && HitboxMod.showOtherMobs();
    }
}
