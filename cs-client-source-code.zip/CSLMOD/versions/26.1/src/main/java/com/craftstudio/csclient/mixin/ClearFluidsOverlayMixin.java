package com.craftstudio.csclient.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import com.craftstudio.csclient.mod.mods.ClearFluidsMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Removes only the first-person fluid overlays selected in Clear Fluids. */
@Mixin(ScreenEffectRenderer.class)
public class ClearFluidsOverlayMixin {
    @Inject(method = "renderWater", at = @At("HEAD"), cancellable = true)
    private static void csclient$skipWaterOverlay(Minecraft minecraft, PoseStack matrices,
            MultiBufferSource vertices, CallbackInfo ci) {
        if (ClearFluidsMod.shouldClearWater()) ci.cancel();
    }

    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void csclient$skipLavaFireOverlay(PoseStack matrices,
            MultiBufferSource vertices, TextureAtlasSprite sprite, CallbackInfo ci) {
        if (!ClearFluidsMod.shouldClearLava()) return;
        Minecraft client = Minecraft.getInstance();
        if (client.player != null && client.player.isInLava()) ci.cancel();
    }
}
