package com.craftstudio.csclient.impl.features.mixins.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.TntRenderer;
import net.minecraft.client.renderer.entity.state.TntRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import com.craftstudio.csclient.mod.mods.TntTimerMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds a billboarded, client-side fuse countdown above primed TNT. */
@Mixin(TntRenderer.class)
public class TntTimerRendererMixin {
    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/TntRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("TAIL"))
    private void csclient$renderTimer(TntRenderState state, PoseStack pose,
            SubmitNodeCollector queue, CameraRenderState camera, CallbackInfo ci) {
        if (!TntTimerMod.shouldShow(state.fuseRemainingInTicks, state.distanceToCameraSq)) return;

        Vec3 position = state.nameTagAttachment != null
                ? state.nameTagAttachment
                : new Vec3(0.0, state.boundingBoxHeight + 0.55, 0.0);
        int color = TntTimerMod.color(state.fuseRemainingInTicks);
        Component timer = Component.literal(TntTimerMod.format(state.fuseRemainingInTicks))
                .withStyle(style -> style.withBold(true).withColor(color & 0x00FFFFFF));
        queue.submitNameTag(pose, position, 0, timer, true,
                state.lightCoords, state.distanceToCameraSq, camera);
    }
}
