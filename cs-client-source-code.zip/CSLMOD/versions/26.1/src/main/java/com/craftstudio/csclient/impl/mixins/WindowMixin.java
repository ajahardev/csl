package com.craftstudio.csclient.impl.mixins;

import com.mojang.blaze3d.platform.Window;
import com.craftstudio.csclient.common.ref.render.WindowRef;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(Window.class)
public abstract class WindowMixin implements WindowRef {
    @Shadow
    public abstract int getScreenWidth();

    @Shadow
    public abstract int getScreenHeight();

    @Shadow
    public abstract int getWidth();

    @Shadow
    public abstract int getHeight();

    /** 26.1 names the physical framebuffer dimensions screen width/height. */
    @Override
    public int getFramebufferWidth() {
        return getScreenWidth();
    }

    @Override
    public int getFramebufferHeight() {
        return getScreenHeight();
    }
}
