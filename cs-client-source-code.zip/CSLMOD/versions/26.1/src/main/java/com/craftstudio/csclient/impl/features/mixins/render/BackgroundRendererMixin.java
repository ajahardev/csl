package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.FogRenderer;
import net.minecraft.world.level.material.FogType;
import com.craftstudio.csclient.mod.mods.ClearFluidsMod;
import com.craftstudio.csclient.mod.mods.NoFogMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 26.1 exposes a mutable FogData return from setupFog. Fluid-only clearing is
 * applied after vanilla has selected the Water/Lava environment, without
 * touching gameplay state or the actual fluid block rendering.
 */
@Mixin(FogRenderer.class)
public class BackgroundRendererMixin {
    @Inject(method = "setupFog", at = @At("RETURN"))
    private void csclient$disableFog(CallbackInfoReturnable<FogData> cir) {
        if (!NoFogMod.isActive()) return;
        setClearPlanes(cir.getReturnValue());
    }

    @Inject(method = "setupFog", at = @At("RETURN"))
    private void csclient$clearFluidFog(Camera camera, int renderDistanceChunks, DeltaTracker deltaTracker,
            float darkenWorldAmount, ClientLevel level, CallbackInfoReturnable<FogData> cir) {
        // Broad No Fog is already responsible for every environment.
        if (NoFogMod.isActive()) return;

        FogType type = camera.getFluidInCamera();
        if ((type == FogType.WATER && ClearFluidsMod.shouldClearWater())
                || (type == FogType.LAVA && ClearFluidsMod.shouldClearLava())) {
            setClearPlanes(cir.getReturnValue());
        }
    }

    /**
     * FogData.color alpha is the vanilla core-shader fog multiplier. Clearing
     * it for an active fluid removes the remaining blue/orange tint instead of
     * merely extending the fog plane.
     */
    private static void setClearPlanes(FogData fog) {
        float distance = ClearFluidsMod.CLEAR_FOG_DISTANCE;
        fog.color.w = 0.0f;
        fog.environmentalStart = 0.0f;
        fog.environmentalEnd = distance;
        fog.renderDistanceStart = 0.0f;
        fog.renderDistanceEnd = distance;
        fog.skyEnd = distance;
        fog.cloudEnd = distance;
    }
}
