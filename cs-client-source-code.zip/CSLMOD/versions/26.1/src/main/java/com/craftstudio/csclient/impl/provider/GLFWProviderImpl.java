package com.craftstudio.csclient.impl.provider;

import org.lwjgl.glfw.GLFW;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.CSClient;

public class GLFWProviderImpl implements GLFWProvider {
    @Override
    public boolean isKeyPressed(int key) {
        return GLFW.glfwGetKey(CSClient.client.getWindow().handle(), key) == GLFW.GLFW_PRESS
                && CSClient.client.screen == null;
    }

    @Override
    public String getKeyName(int key) {
        return GLFW.glfwGetKeyName(key, GLFW.glfwGetKeyScancode(key));
    }
}
