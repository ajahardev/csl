package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.server.PlantMcServerDecoration;
import com.craftstudio.csclient.impl.ui.RenderScopeImpl;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.ServerSelectionList;
import net.minecraft.client.multiplayer.ServerData;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cancels row-arrow and Shift+Arrow moves involving the pinned first entry. */
@Mixin(ServerSelectionList.OnlineServerEntry.class)
public class MultiplayerServerEntryMixin {
    @Shadow @Final private JoinMultiplayerScreen screen;
    @Shadow @Final private ServerData serverData;

    @Inject(method = "extractContent", at = @At("HEAD"))
    private void csclient$drawPlantBanner(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
            boolean hovered, float delta, CallbackInfo ci) {
        if (!FeaturedServers.isCanonicalPlantMcAddress(serverData.ip)) return;
        ServerSelectionList.OnlineServerEntry entry =
                (ServerSelectionList.OnlineServerEntry) (Object) this;
        PlantMcServerDecoration.render(new RenderScopeImpl(graphics),
                entry.getContentX(), entry.getContentY(),
                entry.getContentWidth(), entry.getContentHeight(), hovered);
    }

    @Inject(method = "swap", at = @At("HEAD"), cancellable = true)
    private void csclient$protectPinnedRow(int current, int destination, CallbackInfo ci) {
        if (FeaturedServers.isCanonicalPlantMcAddress(serverData.ip)) {
            ci.cancel();
            return;
        }
        if (destination >= 0 && destination < screen.getServers().size()
                && FeaturedServers.isCanonicalPlantMcAddress(screen.getServers().get(destination).ip)) {
            ci.cancel();
        }
    }
}
