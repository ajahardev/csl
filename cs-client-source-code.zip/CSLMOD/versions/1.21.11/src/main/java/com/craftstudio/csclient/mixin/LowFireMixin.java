package com.craftstudio.csclient.mixin;

import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import com.craftstudio.csclient.mod.mods.LowFireMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class LowFireMixin {
    @Inject(method = "renderFireOverlay", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V"))
    private static void csclient$lowerFire(MatrixStack matrices,
            VertexConsumerProvider vertices, Sprite sprite, CallbackInfo ci) {
        if (LowFireMod.isActive()) matrices.translate(0f, LowFireMod.verticalOffset(), 0f);
    }
}
