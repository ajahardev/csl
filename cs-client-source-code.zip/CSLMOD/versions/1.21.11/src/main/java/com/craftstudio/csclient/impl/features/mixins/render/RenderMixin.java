package com.craftstudio.csclient.impl.features.mixins.render;


import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;

import com.craftstudio.csclient.impl.ui.RenderScopeImpl;
import com.craftstudio.csclient.mixin.DrawContextAccessor;
import com.craftstudio.csclient.impl.ui.CSClientScreenFabric;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.mod.ModRuntimeGuard;
import com.craftstudio.csclient.performance.PerformanceEngine;
import com.craftstudio.csclient.CSClient;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.screens.HudEditor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Drives per-frame rendering for all registered features.
 *
 * This mixin is intentionally kept thin: it creates a {@link RenderScope},
 * iterates the enabled feature list from {@link ModManager}, and
 * dispatches either {@link HudMod#renderHud} (for HUD elements) or
 * {@link Mod#render} (for world-overlay features like Crosshair).
 *
 * No feature-specific logic lives here — all decisions about what to
 * draw are made inside each feature class.
 *
 * Changes from the original:
 * - Package imports updated to the refactored feature names (no
 * more {@code feature.features.*}).
 * - The HUD-editor screen check still uses the existing
 * {@link CSClientScreenFabric} / {@link HudEditor} pair; that is
 * unchanged infrastructure.
 */
@Mixin(InGameHud.class)
public class RenderMixin {

    /** Single-threaded render path: one reusable scope instead of a per-frame allocation. */
    private static RenderScopeImpl scopeCache;

    private static com.craftstudio.csclient.ui.RenderScope acquireScope(DrawContext context) {
        RenderScopeImpl cached = scopeCache;
        if (cached == null) {
            scopeCache = new RenderScopeImpl(context);
            return scopeCache;
        }
        cached.rebind(context.getMatrices(), ((DrawContextAccessor) (Object) context).getState());
        return cached;
    }

    @Inject(method = "renderChat", at = @At("TAIL"))
    public void renderMods(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        PerformanceEngine.onFrame(System.nanoTime());
        if (ModManager.RENDER_ENTRIES.length == 0)
            return;
        TextRenderer textRenderer = CSClient.client.textRenderer;

        // Skip rendering while the HUD editor is open so the editor
        // can draw its own preview layout without double-drawing.
        if (textRenderer == null)
            return;
        if (CSClient.client.currentScreen instanceof CSClientScreenFabric f
                && f.screen instanceof HudEditor)
            return;

        RenderScope scope = acquireScope(context);

        for (ModManager.RenderEntry entry : ModManager.RENDER_ENTRIES) {
            Mod feature = entry.mod();
            if (ModRuntimeGuard.isQuarantined(feature)) continue;
            try {
                HudMod hud = entry.hud();
                if (hud != null) {
                    if (!hud.shouldRenderHud()) continue;
                    ModLayout dim = entry.layout();
                    scope.getMatrixStack().push();
                    try {
                        scope.getMatrixStack().translate(dim.x.value, (float) dim.y.value);
                        scope.getMatrixStack().scale(dim.scale.value, dim.scale.value);
                        hud.renderBackground(scope);
                        hud.renderHud(scope);
                    } finally {
                        scope.getMatrixStack().pop();
                    }
                } else {
                    feature.render(scope);
                }
            } catch (LinkageError | RuntimeException failure) {
                ModRuntimeGuard.quarantine(feature, "render", failure);
            }
        }
    }
}
