package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ZoomMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Scroll changes magnification only during active gameplay zoom. */
@Mixin(Mouse.class)
public class ZoomScrollMixin {
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void csclient$scrollZoom(long window, double horizontal, double vertical, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.currentScreen == null && client.player != null && ZoomMod.handleMouseWheel(vertical)) {
            ci.cancel();
        }
    }
}
