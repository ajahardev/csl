package com.craftstudio.csclient.mixin;

import java.util.Optional;
import java.util.function.Consumer;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.impl.ui.RenderScopeImpl;
import com.craftstudio.csclient.ui.LoadingVisuals;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.client.util.Window;
import net.minecraft.resource.ResourceReload;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

@Mixin(value = SplashOverlay.class, priority = 900)
public abstract class SplashOverlayMixin {

    @Shadow
    private MinecraftClient client;
    @Shadow
    private ResourceReload reload;

    @Shadow
    private long reloadCompleteTime;

    @Shadow
    private long reloadStartTime;

    @Shadow
    @Final
    private boolean reloading;

    @Shadow
    @Final
    private Consumer<Optional<Throwable>> exceptionHandler;

    @Shadow
    private float progress;

    /**
     * Non-destructive injection preserves the vanilla splash method for RRLS and
     * other animation mixins. RRLS owns the overlay whenever it is installed.
     */
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void csclient$render(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (FabricLoader.getInstance().isModLoaded("rrls")) return;

        int screenWidth = context.getScaledWindowWidth();
        int screenHeight = context.getScaledWindowHeight();
        long currentTime = Util.getMeasuringTimeMs();

        // Initialize reload start time if not set
        if (reloadStartTime == -1L) {
            reloadStartTime = currentTime;
        }

        // Compute fade-out progress after reload completes
        float fadeOutProgress = reloadCompleteTime > -1L
                ? (float) (currentTime - reloadCompleteTime) / LoadingVisuals.FADE_OUT_MILLIS
                : -1f;

        int alpha = fadeOutProgress >= 0f
                ? MathHelper.ceil((1.0f - MathHelper.clamp(fadeOutProgress, 0f, 1f)) * 255f)
                : 255;

        // Compute fade-in progress while reloading
        float reloadProgress = reloadStartTime > -1L
                ? (float) (currentTime - reloadStartTime) / LoadingVisuals.FADE_IN_MILLIS
                : -1f;

        // Get render scope for better UI
        RenderScope scope = new RenderScopeImpl(context);

        // Draw background overlay
        if (fadeOutProgress >= 0.0F) {
            renderCurrentScreen(context, mouseX, mouseY, delta);
            int overlayAlpha = computeOverlayAlpha(fadeOutProgress);
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(overlayAlpha, 0xFFFFFFFF));
        } else if (reloading) {
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(alpha, 0xFFFFFFFF));
        } else {
            scope.drawTexture(Textures.SPLASH, 0, 0, 0, 0, screenWidth, screenHeight,
                    Theme.withAlpha(alpha, 0xFFFFFFFF));
        }

        float u = this.reload.getProgress();
        this.progress = MathHelper.clamp(this.progress * 0.95F + u * 0.050000012F, 0.0F, 1.0F);

        // Shared animated CS loading composition.
        LoadingVisuals.render(scope, screenWidth, screenHeight, progress, alpha, currentTime);

        // Remove overlay after fade-out completes
        if (fadeOutProgress >= 1.0F) {
            client.setOverlay(null);
        }

        // Handle reload completion and exceptions
        handleReloadCompletion(context);
        ci.cancel();
    }

    private void renderCurrentScreen(DrawContext context, int mouseX, int mouseY, float delta) {
        if (client.currentScreen != null) {
            client.currentScreen.render(context, mouseX, mouseY, delta);
        }
    }

    /** Compute overlay alpha from fade progress */
    private int computeOverlayAlpha(float progress) {
        return MathHelper.ceil((1.0F - MathHelper.clamp(progress, 0.0F, 1.0F)) * 255.0F);
    }

    /** Handle reload completion logic */
    private void handleReloadCompletion(DrawContext context) {
        float reloadProgress = reloadStartTime > -1L
                ? (float) (Util.getMeasuringTimeMs() - reloadStartTime) / LoadingVisuals.FADE_IN_MILLIS
                : -1f;

        if (reloadCompleteTime == -1L && reload.isComplete() && (!reloading || reloadProgress >= 0.7F)) {
            try {
                reload.throwException();
                exceptionHandler.accept(Optional.empty());
            } catch (Throwable ex) {
                exceptionHandler.accept(Optional.of(ex));
            }

            reloadCompleteTime = Util.getMeasuringTimeMs();

            Window window = client.getWindow();
            if (client.currentScreen != null) {
                client.currentScreen.init(window.getScaledWidth(), window.getScaledHeight());
            }
        }
    }
}