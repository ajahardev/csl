package com.craftstudio.csclient.impl.mixins;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Path;
import java.util.Optional;
import java.util.UUID;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.ProfileResult;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import org.jetbrains.annotations.Nullable;
import com.craftstudio.csclient.account.LocalAccountManager;
import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;
import com.craftstudio.csclient.common.ref.render.WindowRef;
import com.craftstudio.csclient.impl.skin.LocalSkinRuntime;
import com.craftstudio.csclient.impl.ui.CSClientScreenFabric;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.util.ExternalLinks;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import com.craftstudio.csclient.ui.screens.TitleMenu;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.OpenToLanScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.network.SocialInteractionsManager;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.session.ProfileKeys;
import net.minecraft.client.session.Session;
import net.minecraft.client.session.report.AbuseReportContext;
import net.minecraft.client.session.report.ReporterEnvironment;
import net.minecraft.client.session.telemetry.TelemetryManager;
import net.minecraft.client.util.Window;
import net.minecraft.resource.ReloadableResourceManagerImpl;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.world.GameMode;
import net.minecraft.util.ApiServices;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin implements MinecraftClientRef {
    @Shadow public File runDirectory;
    @Shadow private Window window;
    @Shadow private ReloadableResourceManagerImpl resourceManager;
    @Shadow public GameOptions options;
    @Shadow @Final private java.net.Proxy networkProxy;

    @Shadow @Final @Mutable private Session session;
    @Shadow @Final @Mutable private CompletableFuture<ProfileResult> gameProfileFuture;
    @Shadow @Final @Mutable private UserApiService userApiService;
    @Shadow @Final @Mutable private CompletableFuture<UserApiService.UserProperties> userPropertiesFuture;
    @Shadow @Final @Mutable private SocialInteractionsManager socialInteractionsManager;
    @Shadow @Final @Mutable private TelemetryManager telemetryManager;
    @Shadow @Final @Mutable private ProfileKeys profileKeys;
    @Shadow @Final @Mutable private ApiServices apiServices;
    @Shadow private AbuseReportContext abuseReportContext;

    @Shadow public abstract void setScreen(@Nullable Screen screen);
    @Shadow @Override public abstract void scheduleStop();

    @Override
    public File getRunDirectory() { return runDirectory; }

    @Override
    public InputStream getResource(IdentifierRef identifier) {
        try {
            return resourceManager.getResource((Identifier) (Object) identifier).get().getInputStream();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public WindowRef getWindow() { return (WindowRef) (Object) window; }

    @Override
    public void setScreen(CSClientScreen screen) { setScreen(new CSClientScreenFabric(screen)); }

    @Override
    public void setScreen(MinecraftScreen screen) {
        boolean inGame = ((MinecraftClient) (Object) this).world != null;
        CSClientScreenFabric exitTarget = new CSClientScreenFabric(inGame ? new PauseMenu() : new TitleMenu());
        switch (screen) {
            case SelectWorld -> setScreen(new SelectWorldScreen(exitTarget));
            case Multiplayer -> setScreen(new MultiplayerScreen(exitTarget));
            case Options -> setScreen(new OptionsScreen(exitTarget, options));
            case Disconnect -> ((MinecraftClient) (Object) this)
                    .disconnect(new CSClientScreenFabric(new TitleMenu()), false);
        }
    }

    @Override
    public Object currentScreen() {
        return ((MinecraftClient) (Object) this).currentScreen;
    }

    @Override
    public boolean openNativeScreen(Object screen) {
        if (screen instanceof Screen nativeScreen) {
            setScreen(nativeScreen);
            return true;
        }
        return false;
    }

    @Override
    public UUID getUuid() { return session == null ? null : session.getUuidOrNull(); }

    @Override
    public String getUsername() { return session == null ? null : session.getUsername(); }

    @Override
    public boolean isLauncherOfflineProfile() {
        UUID uuid = getUuid();
        String username = getUsername();
        if (uuid == null || username == null || username.isBlank()
                || LocalAccountManager.isLocalAccount(uuid) || session == null) {
            return false;
        }

        return LocalAccountManager.isLikelyOfflineLauncherSession(
                username, uuid, session.getAccessToken());
    }

    @Override
    public boolean switchLocalAccount(String username, UUID uuid) {
        MinecraftClient client = (MinecraftClient) (Object) this;
        if (client.world != null || client.player != null || client.getNetworkHandler() != null
                || username == null || uuid == null) return false;
        try {
            Session localSession = new Session(username, uuid, "", Optional.empty(), Optional.empty());
            UserApiService offlineApi = UserApiService.OFFLINE;
            YggdrasilAuthenticationService authentication = YggdrasilAuthenticationService.createOffline(networkProxy);
            ApiServices offlineServices = ApiServices.create(authentication, runDirectory);

            // Modern Minecraft caches account-bound services. Replacing only the
            // Session field leaves multiplayer/profile code attached to the old user.
            session = localSession;
            gameProfileFuture = CompletableFuture.completedFuture(null);
            userApiService = offlineApi;
            userPropertiesFuture = CompletableFuture.completedFuture(UserApiService.OFFLINE_PROPERTIES);
            socialInteractionsManager = new SocialInteractionsManager(client, offlineApi);
            try { telemetryManager.close(); } catch (Exception ignored) { }
            telemetryManager = new TelemetryManager(client, offlineApi, localSession);
            profileKeys = ProfileKeys.MISSING;
            abuseReportContext = AbuseReportContext.create(ReporterEnvironment.ofIntegratedServer(), offlineApi);
            apiServices = offlineServices;
            return true;
        } catch (Throwable throwable) {
            com.craftstudio.csclient.common.provider.Providers.csClient
                    .logError("Unable to switch local Minecraft profile", throwable);
            return false;
        }
    }

    @Override
    public void onClientStopping(Runnable handler) {
        ClientLifecycleEvents.CLIENT_STOPPING.register(_o -> handler.run());
    }

    @Override
    public void executeOnThread(Runnable runnable) {
        ((java.util.concurrent.Executor) (Object) this).execute(runnable);
    }

    @Override
    public String getClipboardText() {
        String text = ((MinecraftClient) (Object) this).keyboard.getClipboard();
        return text == null ? "" : text;
    }

    @Override
    public void setClipboardText(String text) {
        ((MinecraftClient) (Object) this).keyboard.setClipboard(text == null ? "" : text);
    }

    @Override
    public boolean applyLocalAppearance(Path skinPng, Path capePng, String model) {
        return LocalSkinRuntime.apply(skinPng, capePng, model);
    }

    @Override
    public void resetLocalSkin() {
        LocalSkinRuntime.reset();
    }

    @Override
    public IdentifierRef getActiveSkinTexture() {
        try {
            return (IdentifierRef) (Object) LocalSkinRuntime.getPreviewSkin().body().texturePath();
        } catch (LinkageError | RuntimeException ignored) {
            return null;
        }
    }

    @Override
    public boolean openNativePngPicker(String title, Consumer<Path> result) {
        try {
            CompletableFuture.runAsync(() -> {
                Path selected = null;
                try (MemoryStack stack = MemoryStack.stackPush()) {
                    PointerBuffer filters = stack.mallocPointer(1);
                    filters.put(stack.UTF8("*.png")).flip();
                    String path = TinyFileDialogs.tinyfd_openFileDialog(
                            title == null ? "Choose PNG" : title,
                            runDirectory.toPath().toAbsolutePath().toString(),
                            filters, "PNG image", false);
                    if (path != null && !path.isBlank()) selected = Path.of(path);
                } catch (Throwable error) {
                    com.craftstudio.csclient.common.provider.Providers.csClient
                            .logError("Native PNG chooser is unavailable", error);
                }
                Path chosen = selected;
                executeOnThread(() -> { if (result != null) result.accept(chosen); });
            });
            return true;
        } catch (RuntimeException error) {
            return false;
        }
    }

    /** Opens Minecraft's native connection flow only for the exact Home PlantMC slot. */
    @Override
    public boolean joinFeaturedServer() {
        if (!FeaturedServers.isApprovedJoinAddress(FeaturedServers.PLANTMC_ADDRESS)) return false;
        MinecraftClient client = (MinecraftClient) (Object) this;
        if (client.world != null || client.getNetworkHandler() != null) return false;
        try {
            Screen parent = client.currentScreen;
            if (parent == null) parent = new CSClientScreenFabric(new TitleMenu());
            ServerInfo server = new ServerInfo("PlantMC", FeaturedServers.PLANTMC_ADDRESS,
                    ServerInfo.ServerType.OTHER);
            ConnectScreen.connect(parent, client, ServerAddress.parse(FeaturedServers.PLANTMC_ADDRESS),
                    server, false, null);
            return true;
        } catch (Exception error) {
            com.craftstudio.csclient.common.provider.Providers.csClient
                    .logError("Unable to open the featured server connection", error);
            return false;
        }
    }

    @Override
    public boolean openExternalUrl(String url) {
        if (!ExternalLinks.isApprovedExternalLink(url)) return false;
        try {
            Util.getOperatingSystem().open(URI.create(url));
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    @Override
    public boolean sendChatMessage(String message) {
        String safe = message == null ? "" : message.trim();
        if (safe.isEmpty() || safe.startsWith("/") || safe.indexOf('\n') >= 0 || safe.indexOf('\r') >= 0) return false;
        var handler = ((MinecraftClient) (Object) this).getNetworkHandler();
        if (handler == null) return false;
        handler.sendChatMessage(safe);
        return true;
    }

    @Override
    public String getCurrentServerAddress() {
        var server = ((MinecraftClient) (Object) this).getCurrentServerEntry();
        return server == null || server.address == null ? "" : server.address;
    }

    @Override
    public boolean isModLoaded(String modId) { return FabricLoader.getInstance().isModLoaded(modId); }

    @Override
    public String getExternalModCount() {
        if (!isModLoaded("modmenu")) return "";
        try {
            Object count = Class.forName("com.terraformersmc.modmenu.ModMenu")
                    .getMethod("getDisplayedModCount").invoke(null);
            if (count != null && !count.toString().isBlank()) return count.toString();
        } catch (ReflectiveOperationException ignored) {
            // Older/future Mod Menu builds may not expose the display helper.
        }
        return Integer.toString(FabricLoader.getInstance().getAllMods().size());
    }

    @Override
    public List<LoadedModInfo> getLoadedMods() {
        return FabricLoader.getInstance().getAllMods().stream()
                .map(container -> new LoadedModInfo(container.getMetadata().getId(),
                        container.getMetadata().getName(),
                        container.getMetadata().getVersion().getFriendlyString()))
                .sorted(Comparator.comparing(LoadedModInfo::name, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    @Override
    public void openExternalModMenu() {
        if (!isModLoaded("modmenu")) return;
        Screen parent = ((MinecraftClient) (Object) this).currentScreen;
        try {
            // This is Mod Menu's documented compatibility API and preserves Done/back.
            Class<?> api = Class.forName("com.terraformersmc.modmenu.api.ModMenuApi");
            Screen mods = (Screen) api.getMethod("createModsScreen", Screen.class).invoke(null, parent);
            setScreen(mods);
            return;
        } catch (ReflectiveOperationException ignored) {
            // Fall back for legacy versions that predate createModsScreen.
        }
        try {
            Class<?> type = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            setScreen((Screen) type.getConstructor(Screen.class).newInstance(parent));
        } catch (ReflectiveOperationException error) {
            com.craftstudio.csclient.common.provider.Providers.csClient
                    .logError("Unable to open optional Mod Menu screen", error);
        }
    }

    @Override
    public boolean canOpenNativeWorldHost() {
        MinecraftClient client = (MinecraftClient) (Object) this;
        IntegratedServer server = client.getServer();
        return client.world != null && server != null && !server.isRemote();
    }

    @Override
    public boolean openNativeWorldHost(CSClientScreen parent) {
        if (!canOpenNativeWorldHost()) return false;
        try {
            Screen background = new CSClientScreenFabric(parent == null ? new PauseMenu() : parent);
            setScreen(new OpenToLanScreen(background));
            return true;
        } catch (LinkageError | RuntimeException error) {
            return false;
        }
    }

    @Override
    @SuppressWarnings("resource")
    public String getPlayerListEntry(UUID uuid) {
        var handler = ((MinecraftClient) (Object) this).getNetworkHandler();
        if (handler == null) return null;
        var entry = handler.getPlayerListEntry(uuid);
        return entry == null ? null : entry.getProfile().name();
    }

    @Override
    @SuppressWarnings("resource")
    public UUID getPlayerListEntryUUID(String name) {
        var handler = ((MinecraftClient) (Object) this).getNetworkHandler();
        if (handler == null) return null;
        var entry = handler.getPlayerListEntry(name);
        return entry == null ? null : entry.getProfile().id();
    }
}
