package com.craftstudio.csclient.event;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.screens.LocalAccountsScreen;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import com.craftstudio.csclient.ui.screens.ShiftMenu;
import com.craftstudio.csclient.ui.screens.TitleMenu;

/** Registers CS quick-menu and local skin-studio keys. */
public final class KeyInputHandler {
    private static final Identifier KEY_CATEGORY = Identifier.of("csclient", "key.category.csclient");
    private static KeyBinding mainMenuKeyBinding;
    private static KeyBinding skinMenuKeyBinding;

    private KeyInputHandler() {
    }

    public static void register() {
        KeyBinding.Category category = KeyBinding.Category.create(KEY_CATEGORY);
        mainMenuKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.csclient.main_menu", GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        skinMenuKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.csclient.local_skin", GLFW.GLFW_KEY_H, category));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (mainMenuKeyBinding.wasPressed()) {
                Providers.csClient.getClient().setScreen(new ShiftMenu());
            }
            if (skinMenuKeyBinding.wasPressed()) {
                CSClientScreen parent = client.world == null ? new TitleMenu() : new PauseMenu();
                Providers.csClient.getClient().setScreen(
                        new LocalAccountsScreen(LocalAccountsScreen.Tab.SKIN, parent));
            }
        });
    }
}
