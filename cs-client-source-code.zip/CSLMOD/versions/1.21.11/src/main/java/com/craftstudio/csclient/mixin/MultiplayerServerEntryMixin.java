package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.server.PlantMcServerDecoration;
import com.craftstudio.csclient.impl.ui.RenderScopeImpl;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget;
import net.minecraft.client.network.ServerInfo;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cancels row-arrow and Shift+Arrow moves involving the pinned first entry. */
@Mixin(MultiplayerServerListWidget.ServerEntry.class)
public class MultiplayerServerEntryMixin {
    @Shadow @Final private MultiplayerScreen screen;
    @Shadow @Final private ServerInfo server;

    @Inject(method = "render", at = @At("HEAD"))
    private void csclient$drawPlantBanner(DrawContext context, int mouseX, int mouseY,
            boolean hovered, float delta, CallbackInfo ci) {
        if (!FeaturedServers.isCanonicalPlantMcAddress(server.address)) return;
        MultiplayerServerListWidget.ServerEntry entry =
                (MultiplayerServerListWidget.ServerEntry) (Object) this;
        PlantMcServerDecoration.render(new RenderScopeImpl(context),
                entry.getContentX(), entry.getContentY(),
                entry.getContentWidth(), entry.getContentHeight(), hovered);
    }

    @Inject(method = "swapEntries", at = @At("HEAD"), cancellable = true)
    private void csclient$protectPinnedRow(int current, int destination, CallbackInfo ci) {
        if (FeaturedServers.isCanonicalPlantMcAddress(server.address)) {
            ci.cancel();
            return;
        }
        if (destination >= 0 && destination < screen.getServerList().size()
                && FeaturedServers.isCanonicalPlantMcAddress(screen.getServerList().get(destination).address)) {
            ci.cancel();
        }
    }
}
