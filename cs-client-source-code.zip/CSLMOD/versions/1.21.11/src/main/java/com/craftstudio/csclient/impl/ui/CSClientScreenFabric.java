package com.craftstudio.csclient.impl.ui;

import java.time.Duration;
import java.time.Instant;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.impl.skin.LocalSkinRuntime;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.CSClientScreen.ScreenProvider;
import com.craftstudio.csclient.ui.resources.Textures;
import com.craftstudio.csclient.ui.screens.ComingSoonScreen;
import com.craftstudio.csclient.ui.screens.ServerComingSoonScreen;
import com.craftstudio.csclient.ui.screens.ConfigEditor;
import com.craftstudio.csclient.ui.screens.ExternalLinkConfirmScreen;
import com.craftstudio.csclient.ui.screens.HudEditor;
import com.craftstudio.csclient.ui.screens.LocalAccountsScreen;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import com.craftstudio.csclient.ui.screens.TitleMenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.CubeMapRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.RotatingCubeMapRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.PlayerSkinWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.texture.ResourceTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class CSClientScreenFabric extends Screen implements ScreenProvider {
    protected static final Identifier PANORAMA = Identifier.of("minecraft",
            "textures/gui/title/background/panorama");
    protected static final CubeMapRenderer PANORAMA_RENDERER = new CubeMapRenderer(PANORAMA);

    public static final RotatingCubeMapRenderer ROTATING_PANORAMA_RENDERER;

    static {
        ROTATING_PANORAMA_RENDERER = new RotatingCubeMapRenderer(PANORAMA_RENDERER);
    }

    public final CSClientScreen screen;
    private PlayerSkinWidget skinPreviewWidget;

    public static void preload(MinecraftClient client) {
        TextureManager textureManager = client.getTextureManager();
        for (int i = 0; i < 6; i++) {
            String var10001 = PANORAMA.getPath();
            Identifier tex = PANORAMA.withPath(var10001 + "_" + i + ".png");
            ResourceTexture resourceTexture = new ResourceTexture(tex);
            textureManager.registerTexture(tex, resourceTexture);
        }
    }

    public CSClientScreenFabric(CSClientScreen screen) {
        super(Text.literal(screen.title));
        screen.provider = this;
        this.screen = screen;
    }

    @Override
    protected void init() {
        clearChildren();
        screen.init();
        skinPreviewWidget = null;
        if (screen instanceof LocalAccountsScreen accounts && accounts.showsNativeSkinPreview()) {
            float scale = getUiScale();
            int previewWidth = Math.max(80, Math.round(accounts.getSkinPreviewWidth() * scale));
            int previewHeight = Math.max(100, Math.round(accounts.getSkinPreviewHeight() * scale));
            skinPreviewWidget = new PlayerSkinWidget(previewWidth, previewHeight,
                    client.getLoadedEntityModels(), LocalSkinRuntime::getPreviewSkin);
            skinPreviewWidget.setX(Math.round(accounts.getSkinPreviewX() * scale));
            skinPreviewWidget.setY(Math.round(accounts.getSkinPreviewY() * scale));
            addDrawableChild(skinPreviewWidget);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (screen.start == null) {
            screen.start = Instant.now();
        }
        long elapsed = Duration.between(screen.start, Instant.now()).toMillis();
        int nativeMouseX = mouseX;
        int nativeMouseY = mouseY;

        // Mouse input and rendering must use the same GUI-coordinate space.
        // The shared screen applies its own responsive UI scale; multiplying the
        // render-time cursor here shifted hover animations away from click targets.

        boolean titleContext = client.world == null && client.getCurrentServerEntry() == null;
        boolean panoramaContext = screen instanceof TitleMenu || screen instanceof ComingSoonScreen
                || screen instanceof ServerComingSoonScreen
                || screen instanceof ExternalLinkConfirmScreen
                || (screen instanceof ConfigEditor editor && editor.isModuleEditor());
        if (titleContext && panoramaContext) {
            ROTATING_PANORAMA_RENDERER.render(context, this.width, this.height, true);
        }

        RenderScope renderScope = new RenderScopeImpl(context);

        boolean fullScreenEditor = screen instanceof HudEditor;
        boolean pauseGlass = screen instanceof PauseMenu;
        boolean ownsChrome = fullScreenEditor || pauseGlass || screen instanceof TitleMenu;
        int baseAlpha = titleContext ? 72 : (fullScreenEditor ? 105 : (pauseGlass ? 58 : 218));
        int alpha = Math.round(baseAlpha * Math.max(0f, Math.min(1f, screen.backgroundOpacity)));
        int background = Theme.withAlpha(alpha, Theme.BACKGROUND.value);
        renderScope.drawRectangle(0, 0, this.width, this.height, background);

        // Every CS screen now owns its responsive header/chrome.
        screen.render(renderScope, mouseX, mouseY, delta, elapsed);
        if (skinPreviewWidget != null) {
            skinPreviewWidget.render(context, nativeMouseX, nativeMouseY, delta);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (screen.mouseClicked(click.x(), click.y(), click.button())) {
            return true;
        }

        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (screen.mouseDragged(click.x(), click.y(), click.button(), 0.0, 0.0)) {
            return true;
        }

        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (screen.mouseReleased(click.x(), click.y(), click.button())) {
            return true;
        }

        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (screen.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) {
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (screen.keyPressed(input.getKeycode(), input.scancode(), input.modifiers())) {
            return true;
        }

        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (screen.charTyped(input.asString(), input.modifiers())) return true;
        return super.charTyped(input);
    }

    // @Override
    // public void resize(MinecraftClient client, int width, int height) {
    //     screen.resize(width, height);
    //     super.resize(client, width, height);
    // }

    @Override
    public void close() {
        this.screen.onClose();
        super.close();
    }

    @Override
    public int getWidth() {
        return Math.round(width / getUiScale());
    }

    @Override
    public int getHeight() {
        return Math.round(height / getUiScale());
    }

    @Override
    public float getUiScale() {
        return CSClientScreen.calculateUiScale(width, height);
    }
}