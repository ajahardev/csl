package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ChatEnhancementsMod;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Touch-friendly chat actions for Pojav/mobile users. */
@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin extends Screen {
    protected ChatScreenMixin(Text title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void csclient$addChatActions(CallbackInfo ci) {
        if (!ChatEnhancementsMod.isActive()) return;
        ButtonWidget copy = ButtonWidget.builder(Text.literal("Copy Last"), button -> {
            ChatEnhancementsMod.copyLastMessage();
            button.setMessage(Text.literal("Copied"));
        }).dimensions(Math.max(4, width - 184), 4, 86, 20).build();
        ButtonWidget visibility = ButtonWidget.builder(visibilityText(), button -> {
            ChatEnhancementsMod.toggleChatVisibility();
            button.setMessage(visibilityText());
        }).dimensions(Math.max(94, width - 94), 4, 90, 20).build();
        addDrawableChild(copy);
        addDrawableChild(visibility);
    }

    private static Text visibilityText() {
        return Text.literal(ChatEnhancementsMod.shouldHideChat() ? "Show Chat" : "Hide Chat");
    }
}
