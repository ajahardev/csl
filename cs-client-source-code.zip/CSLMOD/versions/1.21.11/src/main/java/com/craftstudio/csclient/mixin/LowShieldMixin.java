package com.craftstudio.csclient.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import com.craftstudio.csclient.mod.mods.LowShieldMod;
import com.craftstudio.csclient.mod.mods.ShieldRenderContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class LowShieldMixin {
    @Unique private boolean csclient$shieldTransform;

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void csclient$beginLowShield(AbstractClientPlayerEntity player, float tickDelta,
            float pitch, Hand hand, float swingProgress, ItemStack stack, float equipProgress,
            MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        ShieldRenderContext.beginFirstPersonShield(stack.isOf(Items.SHIELD));
        if (!LowShieldMod.isActive() || !stack.isOf(Items.SHIELD)) return;
        csclient$shieldTransform = true;
        matrices.push();
        float scale = LowShieldMod.fixedScale();
        matrices.translate(0f, LowShieldMod.lowerOffset(), 0f);
        matrices.scale(scale, scale, scale);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void csclient$endLowShield(AbstractClientPlayerEntity player, float tickDelta,
            float pitch, Hand hand, float swingProgress, ItemStack stack, float equipProgress,
            MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        ShieldRenderContext.endFirstPersonShield();
        if (!csclient$shieldTransform) return;
        matrices.pop();
        csclient$shieldTransform = false;
    }
}
