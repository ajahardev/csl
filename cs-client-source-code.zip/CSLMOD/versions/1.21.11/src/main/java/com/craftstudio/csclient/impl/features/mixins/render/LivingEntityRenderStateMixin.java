package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.render.entity.state.LivingEntityRenderState;

import com.craftstudio.csclient.common.feature.EntityFeature;
import com.craftstudio.csclient.branding.BrandingRenderState;
import com.craftstudio.csclient.impl.features.entity.HealthRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Implements {@link HealthRenderState} on
 * {@link LivingEntityRenderState}, injecting health and entity-type
 * storage into every living entity's render-state snapshot.
 *
 * Previously imported {@code NametagsInterface.EntityType}; the enum
 * now lives in {@link EntityFeature.EntityType} which is the single
 * canonical definition shared by the mixin layer and the feature layer.
 *
 * The stored values are written by
 * {@link LivingEntityRendererMixin#csclient$captureHealth} each time a
 * render state is extracted from a live entity, and read by
 * {@link NametagsMixin} at render time.
 */
@Mixin(LivingEntityRenderState.class)
public class LivingEntityRenderStateMixin implements HealthRenderState, BrandingRenderState {

    @Unique
    private float csclient$health = 0f;
    @Unique
    private float csclient$maxHealth = 1f;
    @Unique
    private float csclient$absorption = 0f;
    @Unique
    private EntityFeature.EntityType csclient$entityType = EntityFeature.EntityType.OTHER;
    @Unique
    private boolean csclient$showBrandLogo;

    @Override
    public float csclient$getHealth() {
        return csclient$health;
    }

    @Override
    public float csclient$getMaxHealth() {
        return csclient$maxHealth;
    }

    @Override
    public void csclient$setHealth(float health, float maxHealth) {
        this.csclient$health = health;
        this.csclient$maxHealth = maxHealth;
    }

    @Override
    public float csclient$getAbsorption() {
        return csclient$absorption;
    }

    @Override
    public void csclient$setAbsorption(float absorption) {
        csclient$absorption = absorption;
    }

    @Override
    public EntityFeature.EntityType csclient$getEntityType() {
        return csclient$entityType;
    }

    @Override
    public void csclient$setEntityType(EntityFeature.EntityType type) {
        csclient$entityType = type;
    }
    @Override
    public boolean csclient$showBrandLogo() {
        return csclient$showBrandLogo;
    }

    @Override
    public void csclient$setShowBrandLogo(boolean show) {
        csclient$showBrandLogo = show;
    }

}
