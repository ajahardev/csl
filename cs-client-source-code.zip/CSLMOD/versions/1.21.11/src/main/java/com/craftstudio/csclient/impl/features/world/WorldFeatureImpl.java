package com.craftstudio.csclient.impl.features.world;

import com.craftstudio.csclient.common.feature.WorldFeature;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;

import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

/** Fabric/Yarn world queries used by lightweight CS information modules. */
public class WorldFeatureImpl implements WorldFeature {
    private final MinecraftClient mc;

    public WorldFeatureImpl(MinecraftClient mc) {
        this.mc = mc;
    }

    @Override public boolean hasWorld() { return mc.world != null; }
    @Override public long getWorldAge() { return hasWorld() ? mc.world.getTime() : 0L; }

    @Override
    public BlockInfo getTargetBlockInfo() {
        if (!hasWorld() || !(mc.crosshairTarget instanceof BlockHitResult hit)) return BlockInfo.EMPTY;
        BlockPos pos = hit.getBlockPos();
        BlockState state = mc.world.getBlockState(pos);
        if (state.isAir()) return BlockInfo.EMPTY;
        String name = state.getBlock().getName().getString().toUpperCase();
        String id = Registries.BLOCK.getId(state.getBlock()).toString();
        float hardness = state.getHardness(mc.world, pos);
        String detail = hardness < 0 ? "Unbreakable" : String.format("Hardness %.1f%s", hardness,
                state.isToolRequired() ? " • Tool required" : "");
        return new BlockInfo(name, id, detail);
    }

    @Override
    public ItemStackRef getTargetBlockIcon() {
        if (!hasWorld() || !(mc.crosshairTarget instanceof BlockHitResult hit)) return null;
        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (state.isAir()) return null;
        return (ItemStackRef) (Object) new ItemStack(state.getBlock());
    }

    @Override
    public boolean isUnderground() {
        if (!hasWorld() || mc.player == null) return false;
        int top = mc.world.getTopY(Heightmap.Type.WORLD_SURFACE,
                mc.player.getBlockX(), mc.player.getBlockZ());
        return top > mc.player.getBlockY() + 5;
    }

    @Override
    public float getBlockBreakProgress() {
        if (mc.interactionManager == null || !mc.interactionManager.isBreakingBlock()) return 0f;
        return Math.max(0f, Math.min(1f, (mc.interactionManager.getBlockBreakingProgress() + 1) / 10f));
    }

    @Override
    public boolean isLineOfSightClear(double x0, double y0, double z0,
            double x1, double y1, double z1) {
        if (!hasWorld()) return true;
        double dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = (int) (distance * 2.0) + 1; // ~0.5 block probe spacing
        if (steps <= 1) return true;
        if (steps > 256) steps = 256;
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            if (t > 0.92f) break; // safety margin: never cull through the target's own blocks
            int bx = (int) Math.floor(x0 + dx * t);
            int by = (int) Math.floor(y0 + dy * t);
            int bz = (int) Math.floor(z0 + dz * t);
            BlockState state = mc.world.getBlockState(new BlockPos(bx, by, bz));
            if (!state.isAir() && !state.isTransparent()) return false;
        }
        return true;
    }

    @Override
    public int[] getMinimapColors(int cells, int blocksPerCell) {
        int[] result = new int[Math.max(1, cells * cells)];
        if (!hasWorld() || mc.player == null) return result;
        int half = cells / 2;
        int centerX = mc.player.getBlockX();
        int centerZ = mc.player.getBlockZ();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        boolean cave = isUnderground();
        int playerY = mc.player.getBlockY();
        for (int gy = 0; gy < cells; gy++) for (int gx = 0; gx < cells; gx++) {
            int x = centerX + (gx - half) * blocksPerCell;
            int z = centerZ + (gy - half) * blocksPerCell;
            int y;
            BlockState state;
            if (cave) {
                y = playerY + 1;
                state = mc.world.getBlockState(pos.set(x, y, z));
                while (y > playerY - 12 && state.isAir()) {
                    y--;
                    state = mc.world.getBlockState(pos.set(x, y, z));
                }
                if (state.isAir()) {
                    result[gy * cells + gx] = 0xFF11151A;
                    continue;
                }
            } else {
                y = mc.world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
                pos.set(x, y, z);
                state = mc.world.getBlockState(pos);
            }
            int color = state.getMapColor(mc.world, pos).color;
            result[gy * cells + gx] = shade(color, y - playerY);
        }
        return result;
    }

    private static int shade(int rgb, int heightDelta) {
        int delta = Math.max(-28, Math.min(28, heightDelta * 3));
        int r = Math.max(0, Math.min(255, ((rgb >> 16) & 255) + delta));
        int g = Math.max(0, Math.min(255, ((rgb >> 8) & 255) + delta));
        int b = Math.max(0, Math.min(255, (rgb & 255) + delta));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
