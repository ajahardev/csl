package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.debug.EntityHitboxDebugRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;

import com.craftstudio.csclient.mod.mods.HitboxMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Filters vanilla debug hitbox visuals without changing any actual entity hitbox. */
@Mixin(EntityHitboxDebugRenderer.class)
public class HitboxDebugRendererMixin {
    @Inject(method = "drawHitbox", at = @At("HEAD"), cancellable = true)
    private void csclient$filterHitbox(Entity entity, float tickProgress, boolean inLocalServer, CallbackInfo ci) {
        if (!HitboxMod.isActive()) return; // Preserve unmodified F3+B behavior while the module is off.
        if (!shouldRender(entity)) ci.cancel();
    }

    private static boolean shouldRender(Entity entity) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (entity == null || client.player == null) return false;
        int range = HitboxMod.maxDistance();
        if (entity.squaredDistanceTo(client.player) > range * (double) range) return false;
        if (entity instanceof PlayerEntity) return HitboxMod.showPlayers();
        if (entity instanceof HostileEntity) return HitboxMod.showHostile();
        if (entity instanceof PassiveEntity) return HitboxMod.showPassive();
        return entity instanceof MobEntity && HitboxMod.showOtherMobs();
    }
}
