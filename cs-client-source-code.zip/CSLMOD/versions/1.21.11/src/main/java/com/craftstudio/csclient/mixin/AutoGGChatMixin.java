package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.AutoGGTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;

/** Observes each fully assembled incoming chat line exactly once. */
@Mixin(ChatHud.class)
public abstract class AutoGGChatMixin {
    @Inject(
            method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"))
    private void csclient$observeGameEnd(Text text, MessageSignatureData signature,
            MessageIndicator indicator, CallbackInfo ci) {
        if (text != null) AutoGGTracker.onIncomingMessage(text.getString());
    }
}
