package com.craftstudio.csclient.impl.mixins;

import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin implements ItemStackRef {
    @Shadow public abstract boolean isEmpty();
    @Shadow public abstract int getMaxDamage();
    @Shadow public abstract int getDamage();
    @Shadow public abstract int getCount();
    @Shadow public abstract Text getName();
    @Shadow public abstract boolean hasEnchantments();

    @Override public String getItemName() { return getName().getString(); }
    @Override public boolean isEnchanted() { return hasEnchantments(); }
}
