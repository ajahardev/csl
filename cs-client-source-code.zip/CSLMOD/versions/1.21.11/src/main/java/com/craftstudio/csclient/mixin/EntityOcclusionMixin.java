package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.CSClient;
import com.craftstudio.csclient.mod.mods.PerformanceBoostMod;
import com.craftstudio.csclient.performance.EntityOcclusionCulling;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Skips the render pass of entities hidden behind opaque blocks (Feather/Lunar
 * class occlusion culling). Only changes what is drawn — never simulation.
 */
@Mixin(EntityRenderer.class)
public abstract class EntityOcclusionMixin {

    @Inject(method = "shouldRender", at = @At("TAIL"), cancellable = true)
    private void csclient$occlusionCull(Entity entity, Frustum frustum,
            double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> ci) {
        if (entity == null || ci.getReturnValueZ() != Boolean.TRUE
                || !PerformanceBoostMod.occlusionCulling()) {
            return;
        }
        try {
            boolean own = CSClient.client.player != null
                    && CSClient.client.player.getUuid().equals(entity.getUuid());
            Vec3d eye = entity.getEyePos();
            if (EntityOcclusionCulling.shouldSkip(entity.getUuid(), eye.x, eye.y, eye.z,
                    camX, camY, camZ, entity instanceof PlayerEntity, own)) {
                ci.setReturnValue(false);
            }
        } catch (Throwable failure) {
            EntityOcclusionCulling.disableSafely(failure);
        }
    }
}
