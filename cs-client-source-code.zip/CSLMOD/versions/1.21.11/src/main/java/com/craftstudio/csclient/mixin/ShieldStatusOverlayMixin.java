package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ShieldStatusesMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.ShieldEntityModel;
import net.minecraft.client.render.model.ModelBaker;
import net.minecraft.client.render.item.model.special.ShieldModelRenderer;
import net.minecraft.client.texture.SpriteHolder;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.ComponentMap;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.util.Unit;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Second translucent model pass; the original/resource-pack shield pass remains untouched. */
@Mixin(ShieldModelRenderer.class)
public abstract class ShieldStatusOverlayMixin {
    @Shadow @Final private SpriteHolder spriteHolder;
    @Shadow @Final private ShieldEntityModel model;

    @Inject(method = "render(Lnet/minecraft/component/ComponentMap;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;IIZI)V",
            at = @At("TAIL"))
    private void csclient$submitShieldStatusOverlay(ComponentMap components, ItemDisplayContext context,
            MatrixStack matrices, OrderedRenderCommandQueue queue, int light, int overlay,
            boolean glint, int outlineColor, CallbackInfo ci) {
        if (!ShieldStatusesMod.firstPersonOverlayEnabled() || !context.isFirstPerson()) return;
        float tickDelta = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
        int color = ShieldStatusesMod.firstPersonColor(tickDelta);
        SpriteIdentifier sprite = ModelBaker.SHIELD_BASE_NO_PATTERN;
        matrices.push();
        matrices.scale(1.0f, -1.0f, -1.0f);
        matrices.scale(1.0015f, 1.0015f, 1.0015f);
        queue.submitModel(model, Unit.INSTANCE, matrices,
                RenderLayers.entityTranslucent(sprite.getAtlasId()), light, overlay, color,
                spriteHolder.getSprite(sprite), outlineColor, null);
        matrices.pop();
    }
}
