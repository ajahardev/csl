package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.TntEntityRenderer;
import net.minecraft.client.render.entity.state.TntEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import com.craftstudio.csclient.mod.mods.TntTimerMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds a billboarded, client-side fuse countdown above primed TNT. */
@Mixin(TntEntityRenderer.class)
public class TntTimerRendererMixin {
    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/TntEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("TAIL"))
    private void csclient$renderTimer(TntEntityRenderState state, MatrixStack matrices,
            OrderedRenderCommandQueue queue, CameraRenderState camera, CallbackInfo ci) {
        if (!TntTimerMod.shouldShow(state.fuse, state.squaredDistanceToCamera)) return;

        Vec3d position = state.nameLabelPos != null
                ? state.nameLabelPos
                : new Vec3d(0.0, state.height + 0.55, 0.0);
        int color = TntTimerMod.color(state.fuse);
        Text timer = Text.literal(TntTimerMod.format(state.fuse))
                .styled(style -> style.withBold(true).withColor(color & 0x00FFFFFF));
        queue.submitLabel(matrices, position, 0, timer, true,
                state.light, state.squaredDistanceToCamera, camera);
    }
}
