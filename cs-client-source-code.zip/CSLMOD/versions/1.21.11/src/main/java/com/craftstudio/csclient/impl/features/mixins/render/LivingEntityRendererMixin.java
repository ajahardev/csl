package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import com.craftstudio.csclient.common.feature.EntityFeature;
import com.craftstudio.csclient.branding.BrandingRenderState;
import com.craftstudio.csclient.impl.features.entity.HealthRenderState;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod;
import com.craftstudio.csclient.mod.mods.ClientBrandingMod;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod.HeartRow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Captures living health into render state and submits optional mob heart labels
 * directly to the current label queue. Direct submission avoids relying on a
 * mob's vanilla custom-name visibility before a label is rendered.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState> {
    private static final Identifier CS_HEART_FONT = Identifier.of("csclient", "health_hearts");
    private static final Text[] CS_BRAND_LABELS = {
            brandLabel("brand_logo_small"), brandLabel("brand_logo"), brandLabel("brand_logo_large")
    };

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void csclient$captureHealth(T entity, S state, float tickDelta, CallbackInfo ci) {
        if (!(state instanceof HealthRenderState hrs)) return;

        float health = entity.getHealth();
        float maxHealth = entity.getMaxHealth();
        hrs.csclient$setHealth(health, maxHealth);
        hrs.csclient$setAbsorption(entity.getAbsorptionAmount());

        EntityFeature.EntityType type;
        if (entity instanceof PlayerEntity) type = EntityFeature.EntityType.PLAYER;
        else if (entity instanceof HostileEntity) type = EntityFeature.EntityType.HOSTILE;
        else if (entity instanceof PassiveEntity) type = EntityFeature.EntityType.PASSIVE;
        else type = EntityFeature.EntityType.OTHER;
        hrs.csclient$setEntityType(type);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void csclient$submitMobHealth(S state, MatrixStack matrices,
            OrderedRenderCommandQueue queue, CameraRenderState camera, CallbackInfo ci) {
        if (state instanceof BrandingRenderState branding && branding.csclient$showBrandLogo()) {
            Vec3d base = state.nameLabelPos != null
                    ? state.nameLabelPos : new Vec3d(0.0, state.height + 0.55, 0.0);
            queue.submitLabel(matrices, base.add(0.0, 0.36, 0.0), 0,
                    CS_BRAND_LABELS[ClientBrandingMod.logoScale()], !state.sneaking,
                    state.light, state.squaredDistanceToCamera, camera);
        }

        if (!(state instanceof HealthRenderState hrs)
                || hrs.csclient$getEntityType() == EntityFeature.EntityType.PLAYER
                || !HealthDisplayMod.shouldShowMob(state.invisible, state.squaredDistanceToCamera,
                        hrs.csclient$getHealth(), hrs.csclient$getMaxHealth())) return;

        Vec3d position = state.nameLabelPos != null
                ? state.nameLabelPos
                : new Vec3d(0.0, state.height + 0.55, 0.0);
        queue.submitLabel(matrices, position, 0,
                buildHeartRow(HealthDisplayMod.createHeartRow(hrs.csclient$getHealth(),
                        hrs.csclient$getMaxHealth(), hrs.csclient$getAbsorption())),
                true, state.light, state.squaredDistanceToCamera, camera);
    }

    private static Text brandLabel(String fontPath) {
        Identifier font = Identifier.of("csclient", fontPath);
        return Text.literal(ClientBrandingMod.logoGlyph()).styled(style -> style
                .withFont(new StyleSpriteSource.Font(font)).withColor(0xFFFFFF));
    }

    private static Text buildHeartRow(HeartRow row) {
        MutableText text = Text.empty();
        appendHearts(text, row.fullGlyphs(), row.fullColor());
        appendHearts(text, row.halfGlyphs(), row.fullColor());
        appendHearts(text, row.emptyGlyphs(), row.emptyColor());
        appendHearts(text, row.absorptionGlyphs(), row.absorptionColor());
        return text;
    }

    private static void appendHearts(MutableText text, String glyphs, int color) {
        if (glyphs.isEmpty()) return;
        text.append(Text.literal(glyphs).styled(style -> style
                .withFont(new StyleSpriteSource.Font(CS_HEART_FONT))
                .withColor(color & 0x00FFFFFF)));
    }
}
