package com.craftstudio.csclient.impl.provider;

import java.awt.image.BufferedImage;

import com.craftstudio.csclient.common.provider.CSClientProvider;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;
import com.craftstudio.csclient.impl.ui.IdentifierUtils;
import com.craftstudio.csclient.CSClient;

public class CSClientProviderImpl implements CSClientProvider {
    @Override
    public MinecraftClientRef getClient() {
        return (MinecraftClientRef) CSClient.client;
    }

    @Override
    public void logInfo(String message) {
        CSClient.LOGGER.info(message);
    }

    @Override
    public void logError(String message) {
        CSClient.LOGGER.error(message);
    }

    @Override
    public void logError(String message, Throwable throwable) {
        CSClient.LOGGER.error(message, throwable);
    }

    @Override
    public void registerBufferedImageTexture(IdentifierRef identifier, BufferedImage image) {
        IdentifierUtils.registerBufferedImageTextureFast(identifier, image);
    }
}
