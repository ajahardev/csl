package com.craftstudio.csclient.impl.render;

import java.util.List;
import java.util.stream.IntStream;

import com.craftstudio.csclient.mod.mods.BlockBreakAnimationMod;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.model.ModelBaker;
import net.minecraft.util.Identifier;

/** Dynamic destruction-layer selection without a resource reload. */
public final class BlockBreakLayers {
    private static final List<RenderLayer> CS_LAYERS = IntStream.range(0, 10)
            .mapToObj(stage -> RenderLayers.crumbling(Identifier.of("csclient",
                    "textures/block/destroy_stage_" + stage + ".png")))
            .toList();

    private BlockBreakLayers() {
    }

    public static List<RenderLayer> active() {
        return BlockBreakAnimationMod.useCsStages()
                ? CS_LAYERS : ModelBaker.BLOCK_DESTRUCTION_RENDER_LAYERS;
    }
}
