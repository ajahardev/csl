package com.craftstudio.csclient.impl.features.mixins.entity;

import com.craftstudio.csclient.impl.features.entity.CameraOverriddenEntity;
import com.craftstudio.csclient.mod.mods.FreelookMod;
import com.craftstudio.csclient.CSClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Unique
    boolean firstTime = true;

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", ordinal = 1, shift = At.Shift.AFTER))
    public void lockRotation(
            World focusedBlock,
            Entity cameraEntity,
            boolean isThirdPerson,
            boolean isFrontFacing,
            float tickDelta,
            CallbackInfo ci) {
        if (FreelookMod.isFreeLooking() && cameraEntity instanceof ClientPlayerEntity) {
            CameraOverriddenEntity cameraOverriddenEntity = (CameraOverriddenEntity) cameraEntity;

            if (firstTime && CSClient.client.player != null) {
                cameraOverriddenEntity.freelook$setCameraPitch(CSClient.client.player.getPitch());
                cameraOverriddenEntity.freelook$setCameraYaw(CSClient.client.player.getYaw());
                firstTime = false;
            }
            this.setRotation(cameraOverriddenEntity.freelook$getCameraYaw(),
                    cameraOverriddenEntity.freelook$getCameraPitch());

        }
        if (!FreelookMod.isFreeLooking() && cameraEntity instanceof ClientPlayerEntity) {
            firstTime = true;
        }
    }

}