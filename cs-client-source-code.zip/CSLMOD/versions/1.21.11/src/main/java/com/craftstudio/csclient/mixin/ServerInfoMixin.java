package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.server.FeaturedServers;
import net.minecraft.client.network.ServerInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevents a server ping from replacing the packaged PlantMC icon. */
@Mixin(ServerInfo.class)
public class ServerInfoMixin {
    @Shadow public String address;
    @Shadow private byte[] favicon;

    @Inject(method = "setFavicon", at = @At("HEAD"), cancellable = true)
    private void csclient$keepPlantIcon(byte[] ignored, CallbackInfo ci) {
        if (!FeaturedServers.isCanonicalPlantMcAddress(address)) return;
        byte[] icon = FeaturedServers.plantMcIconBytes();
        favicon = icon.length == 0 ? null : icon;
        ci.cancel();
    }
}
