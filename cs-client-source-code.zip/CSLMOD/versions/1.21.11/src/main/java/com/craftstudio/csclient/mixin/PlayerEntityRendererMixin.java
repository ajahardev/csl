package com.craftstudio.csclient.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerLikeEntity;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import com.craftstudio.csclient.branding.BrandingRenderState;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod;
import com.craftstudio.csclient.mod.mods.ClientBrandingMod;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod.HeartRow;
import com.craftstudio.csclient.mod.mods.TotemCounterMod;
import com.craftstudio.csclient.mod.tracking.TotemTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds only the configurable health-heart row; all cosmetic render layers were removed. */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin
        extends LivingEntityRenderer<PlayerEntity, PlayerEntityRenderState, PlayerEntityModel> {
    private static final Identifier CS_HEART_FONT = Identifier.of("csclient", "health_hearts");
    /** Allocated once, not per player per frame. */
    private static final StyleSpriteSource.Font HEART_FONT = new StyleSpriteSource.Font(CS_HEART_FONT);
    private static final Text[] CS_BRAND_PREFIXES = {
            brandPrefix("brand_logo_small"), brandPrefix("brand_logo"), brandPrefix("brand_logo_large")
    };

    /**
     * Per-frame allocation elimination: player names, heart states and totem
     * counts are stable for long stretches, so the composed components are
     * interned. The renderer only reads these texts; appends elsewhere copy first.
     */
    private record BrandKey(String name, int prefix) { }
    private static final java.util.Map<BrandKey, MutableText> BRANDED_TAGS = new java.util.HashMap<>();
    private static final java.util.Map<HeartRow, MutableText> HEART_ROWS = new java.util.HashMap<>();
    private static final java.util.Map<Long, Text> POP_SUFFIXES = new java.util.HashMap<>();

    protected PlayerEntityRendererMixin() {
        super(null, null, 0.0f);
    }

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    public <A extends PlayerLikeEntity & ClientPlayerLikeEntity> void updateRenderState(
            A entity, PlayerEntityRenderState state, float f, CallbackInfo ci) {
        if (entity == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean ownPlayer = mc.player != null
                && entity.getUuid().equals(mc.player.getUuid());

        boolean showBrand = ClientBrandingMod.shouldRender(
                entity.getUuid(), ownPlayer, state.invisible, state.squaredDistanceToCamera,
                state.displayName != null);
        if (state instanceof BrandingRenderState branding) {
            if (showBrand && state.displayName != null) {
                // Put the glyph inside Minecraft's real nametag component so it shares
                // team visibility, crouching, depth/occlusion and batching behavior.
                state.displayName = brandedTag(state.displayName, ClientBrandingMod.logoScale());
                branding.csclient$setShowBrandLogo(false);
            } else {
                // Local camera entities have no vanilla nametag; the renderer uses its
                // safe attachment fallback only when the explicit self option is on.
                branding.csclient$setShowBrandLogo(showBrand && ownPlayer);
            }
        }
        int pops = TotemTracker.getPops(entity.getUuid());
        if (pops > 0 && state.displayName != null && TotemCounterMod.shouldShowNametagPops()) {
            state.displayName = state.displayName.copy().append(popSuffix(pops));
        }
        if (state.displayName != null && HealthDisplayMod.shouldShow(
                ownPlayer, state.invisible, state.squaredDistanceToCamera,
                entity.getHealth(), entity.getMaxHealth())) {
            HeartRow row = HealthDisplayMod.createHeartRow(
                    entity.getHealth(), entity.getMaxHealth(), entity.getAbsorptionAmount());
            state.playerName = cachedHeartRow(row);
        }
    }

    private static MutableText brandedTag(Text displayName, int prefix) {
        String name = displayName.getString();
        BrandKey key = new BrandKey(name, prefix);
        MutableText cached = BRANDED_TAGS.get(key);
        if (cached != null) return cached;
        MutableText composed = Text.empty().append(CS_BRAND_PREFIXES[prefix]).append(displayName);
        if (BRANDED_TAGS.size() > 512) BRANDED_TAGS.clear();
        BRANDED_TAGS.put(key, composed);
        return composed;
    }

    private static Text popSuffix(int pops) {
        int color = TotemCounterMod.getPopColor() & 0x00FFFFFF;
        long key = ((long) pops << 32) ^ (color & 0xFFFFFFFFL);
        Text cached = POP_SUFFIXES.get(key);
        if (cached != null) return cached;
        Text suffix = Text.literal("  ✦ " + pops + " POP" + (pops == 1 ? "" : "S"))
                .styled(style -> style.withColor(color));
        if (POP_SUFFIXES.size() > 64) POP_SUFFIXES.clear();
        POP_SUFFIXES.put(key, suffix);
        return suffix;
    }

    private static MutableText cachedHeartRow(HeartRow row) {
        MutableText cached = HEART_ROWS.get(row);
        if (cached != null) return cached;
        MutableText built = buildHeartRow(row);
        if (HEART_ROWS.size() > 1024) HEART_ROWS.clear();
        HEART_ROWS.put(row, built);
        return built;
    }

    private static Text brandPrefix(String fontPath) {
        Identifier font = Identifier.of("csclient", fontPath);
        return Text.empty()
                .append(Text.literal(ClientBrandingMod.logoGlyph()).styled(style -> style
                        .withFont(new StyleSpriteSource.Font(font)).withColor(0xFFFFFF)))
                .append(Text.literal(" "));
    }

    private static MutableText buildHeartRow(HeartRow row) {
        MutableText text = Text.empty();
        appendHearts(text, row.fullGlyphs(), row.fullColor());
        appendHearts(text, row.halfGlyphs(), row.fullColor());
        appendHearts(text, row.emptyGlyphs(), row.emptyColor());
        appendHearts(text, row.absorptionGlyphs(), row.absorptionColor());
        return text;
    }

    private static void appendHearts(MutableText text, String glyphs, int color) {
        if (glyphs.isEmpty()) return;
        text.append(Text.literal(glyphs).styled(style -> style
                .withFont(HEART_FONT)
                .withColor(color & 0x00FFFFFF)));
    }
}
