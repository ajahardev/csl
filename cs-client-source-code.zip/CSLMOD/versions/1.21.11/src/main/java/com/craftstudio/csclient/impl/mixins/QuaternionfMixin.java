package com.craftstudio.csclient.impl.mixins;

import org.joml.Quaternionf;
import com.craftstudio.csclient.common.ref.render.QuaternionfRef;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Quaternionf.class)
public abstract class QuaternionfMixin implements QuaternionfRef {
}
