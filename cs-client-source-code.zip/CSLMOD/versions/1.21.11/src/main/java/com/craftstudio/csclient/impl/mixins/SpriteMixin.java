package com.craftstudio.csclient.impl.mixins;

import net.minecraft.client.texture.Sprite;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Sprite.class)
public abstract class SpriteMixin implements SpriteRef {
}