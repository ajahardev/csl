package com.craftstudio.csclient.branding.net;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;

import com.craftstudio.csclient.branding.ClientBrandingState;

/** Optional Fabric server relay. No gameplay state is modified. */
public final class CSBrandingProtocol implements ModInitializer {
    private static final Set<UUID> CS_PLAYERS = new HashSet<>();
    private static boolean initialized;

    public record HelloPayload(int protocol) implements CustomPayload {
        public static final Id<HelloPayload> ID = new Id<>(Identifier.of("csclient", "brand_hello"));
        public static final PacketCodec<RegistryByteBuf, HelloPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, HelloPayload::protocol, HelloPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record PresencePayload(UUID uuid, boolean csClient) implements CustomPayload {
        public static final Id<PresencePayload> ID = new Id<>(Identifier.of("csclient", "brand_presence"));
        public static final PacketCodec<RegistryByteBuf, PresencePayload> CODEC = PacketCodec.tuple(
                Uuids.PACKET_CODEC, PresencePayload::uuid,
                PacketCodecs.BOOLEAN, PresencePayload::csClient,
                PresencePayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    @Override public void onInitialize() { initialize(); }

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        PayloadTypeRegistry.playC2S().register(HelloPayload.ID, HelloPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PresencePayload.ID, PresencePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(HelloPayload.ID, (payload, context) -> {
            if (payload.protocol() != ClientBrandingState.PROTOCOL_VERSION) return;
            ServerPlayerEntity player = context.player();
            UUID uuid = player.getUuid();
            synchronized (CS_PLAYERS) { CS_PLAYERS.add(uuid); }
            sendSnapshot(player);
            broadcast(context.server(), new PresencePayload(uuid, true));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID uuid = handler.getPlayer().getUuid();
            boolean removed;
            synchronized (CS_PLAYERS) { removed = CS_PLAYERS.remove(uuid); }
            if (removed) broadcast(server, new PresencePayload(uuid, false));
        });
    }

    private static void sendSnapshot(ServerPlayerEntity target) {
        if (!ServerPlayNetworking.canSend(target, PresencePayload.ID)) return;
        UUID[] snapshot;
        synchronized (CS_PLAYERS) { snapshot = CS_PLAYERS.toArray(UUID[]::new); }
        for (UUID uuid : snapshot) ServerPlayNetworking.send(target, new PresencePayload(uuid, true));
    }

    private static void broadcast(MinecraftServer server, PresencePayload payload) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (ServerPlayNetworking.canSend(player, PresencePayload.ID)) {
                ServerPlayNetworking.send(player, payload);
            }
        }
    }
}
