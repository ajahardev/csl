package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ChatEnhancementsMod;
import com.craftstudio.csclient.mod.mods.ChatEnhancementsMod.IncomingDecision;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Display-only decoration keeps the original signed network message/signature intact. */
@Mixin(ChatHud.class)
public abstract class ChatEnhancementsMixin {
    @Unique private boolean csclient$decoratingChat;

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"), cancellable = true)
    private void csclient$improveChat(Text message, @Nullable MessageSignatureData signature,
            @Nullable MessageIndicator indicator, CallbackInfo ci) {
        if (csclient$decoratingChat || !ChatEnhancementsMod.isActive()) return;
        IncomingDecision decision = ChatEnhancementsMod.processIncoming(message.getString());
        // Never remove signed player messages from vanilla's reportable chat history.
        if (decision.suppress()) { if (signature == null) ci.cancel(); return; }
        if (decision.timestamp().isEmpty() && !decision.mention()) return;
        MutableText decorated = Text.empty();
        if (!decision.timestamp().isEmpty()) {
            decorated.append(Text.literal(decision.timestamp())
                    .styled(style -> style.withColor(ChatEnhancementsMod.timestampColor())));
        }
        if (decision.mention()) {
            decorated.append(Text.literal("◆ ")
                    .styled(style -> style.withColor(ChatEnhancementsMod.mentionColor())));
        }
        decorated.append(message);
        csclient$decoratingChat = true;
        try {
            ((ChatHud) (Object) this).addMessage(decorated, signature, indicator);
        } finally {
            csclient$decoratingChat = false;
        }
        ci.cancel();
    }

    @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V",
            at = @At("HEAD"), cancellable = true)
    private void csclient$hideChat(DrawContext context, TextRenderer renderer, int currentTick,
            int mouseX, int mouseY, boolean focused, boolean hudHidden, CallbackInfo ci) {
        if (ChatEnhancementsMod.shouldHideChat()) ci.cancel();
    }
}
