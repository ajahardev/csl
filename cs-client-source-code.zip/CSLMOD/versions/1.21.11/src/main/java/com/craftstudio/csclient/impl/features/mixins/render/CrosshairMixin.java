package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import com.craftstudio.csclient.mod.mods.CrosshairMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class CrosshairMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void csclient$customCrosshair(DrawContext context, RenderTickCounter tracker, CallbackInfo ci) {
        if (CrosshairMod.shouldReplaceVanilla()) ci.cancel();
    }
}
