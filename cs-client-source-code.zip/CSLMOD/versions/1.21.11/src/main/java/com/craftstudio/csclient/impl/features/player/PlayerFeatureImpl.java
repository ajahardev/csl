package com.craftstudio.csclient.impl.features.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.client.gui.hud.debug.DebugHudEntries;
import net.minecraft.client.gui.hud.debug.DebugHudEntryVisibility;
import com.craftstudio.csclient.impl.features.mixins.render.BossBarHudAccessor;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.ref.game.EffectRef;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Fabric implementation of {@link PlayerFeature}.
 *
 * All access to {@link MinecraftClient} and {@link ClientPlayerEntity}
 * is encapsulated here. Features only ever see the {@link PlayerFeature}
 * interface; they never import Minecraft classes directly.
 *
 * Every method guards against a missing player and returns a safe
 * default so features are free of null checks.
 */
public class PlayerFeatureImpl implements PlayerFeature {

    private ItemStack shieldCooldownStack;
    private final MinecraftClient mc;

    public PlayerFeatureImpl(MinecraftClient mc) {
        this.mc = mc;
    }

    // ---------------------------------------------------------------
    // Internal helper — never returns null
    // ---------------------------------------------------------------

    /** Returns the local player, or {@code null} if one is not loaded. */
    private ClientPlayerEntity player() {
        return mc.player;
    }

    // ---------------------------------------------------------------
    // Presence
    // ---------------------------------------------------------------

    @Override
    public boolean hasPlayer() {
        return mc.player != null;
    }

    // ---------------------------------------------------------------
    // Position
    // ---------------------------------------------------------------

    @Override
    public int getX() {
        return hasPlayer() ? (int) player().getX() : 0;
    }

    @Override
    public int getY() {
        return hasPlayer() ? (int) player().getY() : 0;
    }

    @Override
    public int getZ() {
        return hasPlayer() ? (int) player().getZ() : 0;
    }

    // ---------------------------------------------------------------
    // Input / movement
    // ---------------------------------------------------------------

    @Override
    public boolean isForwardPressed() {
        return mc.options.forwardKey.isPressed();
    }

    @Override
    public boolean isBackPressed() {
        return mc.options.backKey.isPressed();
    }

    @Override
    public boolean isLeftPressed() {
        return mc.options.leftKey.isPressed();
    }

    @Override
    public boolean isRightPressed() {
        return mc.options.rightKey.isPressed();
    }

    @Override
    public boolean isJumpPressed() {
        return mc.options.jumpKey.isPressed();
    }

    @Override
    public boolean isAttackPressed() {
        return mc.options.attackKey.isPressed();
    }

    @Override
    public boolean isUsePressed() {
        return mc.options.useKey.isPressed();
    }

    @Override
    public boolean isSneaking() {
        return hasPlayer() && player().isSneaking();
    }

    @Override
    public boolean isSprinting() {
        return hasPlayer() && player().isSprinting();
    }

    @Override
    public float getYaw() {
        return hasPlayer() ? player().getYaw() : 0.0f;
    }

    @Override
    public boolean isUsingItem() {
        return hasPlayer() && player().isUsingItem();
    }

    @Override
    public boolean hasHorizontalCollision() {
        return hasPlayer() && player().horizontalCollision;
    }

    @Override
    public boolean isOnGround() {
        return hasPlayer() && player().isOnGround();
    }

    @Override
    public void setSprinting(boolean sprinting) {
        if (hasPlayer())
            player().setSprinting(sprinting);
    }

    // ---------------------------------------------------------------
    // Velocity
    // ---------------------------------------------------------------

    @Override
    public Velocity getVelocity() {
        if (!hasPlayer())
            return Velocity.ZERO;
        var v = player().getVelocity();
        return new Velocity(v.x, v.y, v.z);
    }

    // ---------------------------------------------------------------
    // Stats
    // ---------------------------------------------------------------

    @Override
    public float getHealth() {
        return hasPlayer() ? player().getHealth() : 0f;
    }

    @Override
    public float getMaxHealth() {
        return hasPlayer() ? player().getMaxHealth() : 20f;
    }

    @Override
    public float getAbsorptionHealth() {
        return hasPlayer() ? player().getAbsorptionAmount() : 0f;
    }

    @Override
    public int getFoodLevel() {
        return hasPlayer() ? player().getHungerManager().getFoodLevel() : 0;
    }

    @Override
    public float getSaturationLevel() {
        return hasPlayer() ? player().getHungerManager().getSaturationLevel() : 0.0f;
    }

    @Override
    public int getSelectedItemTotalCount() {
        if (!hasPlayer()) return 0;
        ItemStack held = player().getMainHandStack();
        if (held.isEmpty()) return 0;
        int total = 0;
        for (int i = 0; i < player().getInventory().size(); i++) {
            ItemStack stack = player().getInventory().getStack(i);
            if (stack.isOf(held.getItem())) total += stack.getCount();
        }
        return total;
    }

    @Override
    public int getTotemCount() {
        if (!hasPlayer()) return 0;
        int total = 0;
        for (int i = 0; i < player().getInventory().size(); i++) {
            ItemStack stack = player().getInventory().getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) total += stack.getCount();
        }
        return total;
    }

    @Override
    public ItemStackRef getTotemStack() {
        return wrap(new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    @Override
    public boolean isShieldDisabled() {
        return getShieldCooldownRemaining(0.0f) > 0.0f;
    }

    @Override
    public float getShieldCooldownRemaining(float tickDelta) {
        if (!hasPlayer()) return 0.0f;
        if (shieldCooldownStack == null) shieldCooldownStack = new ItemStack(Items.SHIELD);
        return player().getItemCooldownManager().getCooldownProgress(shieldCooldownStack, tickDelta);
    }

    @Override
    public float getAttackCooldown() {
        // Vanilla's HUD intentionally samples half a tick ahead for the visual indicator.
        return hasPlayer() ? player().getAttackCooldownProgress(0.5f) : 1.0f;
    }

    @Override
    public String getServerAddress() {
        var server = mc.getCurrentServerEntry();
        return server == null ? "SINGLEPLAYER" : server.address;
    }

    @Override
    public String getScoreboardTitle() {
        ScoreboardObjective objective = getSidebarObjective();
        return objective == null ? "SCOREBOARD" : objective.getDisplayName().getString();
    }

    @Override
    public List<ScoreboardLine> getScoreboardLines() {
        ScoreboardObjective objective = getSidebarObjective();
        if (objective == null || mc.world == null) return List.of();
        Scoreboard board = mc.world.getScoreboard();
        return board.getScoreboardEntries(objective).stream()
                .filter(entry -> !entry.hidden() && !entry.owner().startsWith("#"))
                .sorted(Comparator.comparingInt(ScoreboardEntry::value).reversed())
                .limit(15)
                .map(entry -> {
                    String text = entry.name() == null ? entry.owner()
                            : Team.decorateName(board.getTeam(entry.owner()), entry.name()).getString();
                    return new ScoreboardLine(text, entry.value());
                })
                .toList();
    }

    /** Matches Minecraft's team-color sidebar selection before SIDEBAR fallback. */
    private ScoreboardObjective getSidebarObjective() {
        if (mc.world == null || mc.player == null) return null;
        Scoreboard board = mc.world.getScoreboard();
        Team team = board.getTeam(mc.player.getNameForScoreboard());
        ScoreboardObjective objective = null;
        if (team != null) {
            ScoreboardDisplaySlot slot = ScoreboardDisplaySlot.fromFormatting(team.getColor());
            if (slot != null) objective = board.getObjectiveForSlot(slot);
        }
        return objective != null ? objective : board.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
    }

    @Override
    public List<BossInfo> getBossBars() {
        try {
            return ((BossBarHudAccessor) mc.inGameHud.getBossBarHud()).csclient$getBossBars().values().stream()
                    .map(bar -> new BossInfo(bar.getName().getString(), bar.getPercent())).toList();
        } catch (LinkageError | RuntimeException ignored) {
            return List.of();
        }
    }

    @Override
    public void setHitboxesEnabled(boolean enabled) {
        mc.debugHudEntryList.setEntryVisibility(DebugHudEntries.ENTITY_HITBOXES,
                enabled ? DebugHudEntryVisibility.ALWAYS_ON : DebugHudEntryVisibility.NEVER);
    }

    @Override
    public boolean areHitboxesEnabled() {
        return mc.debugHudEntryList.isEntryVisible(DebugHudEntries.ENTITY_HITBOXES);
    }

    // ---------------------------------------------------------------
    // Equipment
    // ---------------------------------------------------------------

    @Override
    public ItemStackRef getMainHand() {
        return wrap(hasPlayer() ? player().getMainHandStack() : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getOffHand() {
        return wrap(hasPlayer() ? player().getOffHandStack() : ItemStack.EMPTY);
    }

    @Override
    public List<? extends ItemStackRef> getInventoryItems() {
        if (!hasPlayer()) return List.of();
        List<ItemStackRef> items = new ArrayList<>(36);
        int size = Math.min(36, player().getInventory().size());
        for (int i = 0; i < size; i++) items.add(wrap(player().getInventory().getStack(i)));
        while (items.size() < 36) items.add(wrap(ItemStack.EMPTY));
        return items;
    }

    @Override
    public ItemStackRef getHelmet() {
        return wrap(hasPlayer() ? player().getEquippedStack(EquipmentSlot.HEAD) : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getChestplate() {
        return wrap(hasPlayer() ? player().getEquippedStack(EquipmentSlot.CHEST) : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getLeggings() {
        return wrap(hasPlayer() ? player().getEquippedStack(EquipmentSlot.LEGS) : ItemStack.EMPTY);
    }

    @Override
    public ItemStackRef getBoots() {
        return wrap(hasPlayer() ? player().getEquippedStack(EquipmentSlot.FEET) : ItemStack.EMPTY);
    }

    // ---------------------------------------------------------------
    // Dummy equipment
    // ---------------------------------------------------------------

    @Override
    public ItemStackRef getDummyMainHand() {
        return wrap(new ItemStack(Items.DIAMOND_SWORD));
    }

    @Override
    public ItemStackRef getDummyHelmet() {
        return wrap(new ItemStack(Items.DIAMOND_HELMET));
    }

    @Override
    public ItemStackRef getDummyChestplate() {
        return wrap(new ItemStack(Items.DIAMOND_CHESTPLATE));
    }

    @Override
    public ItemStackRef getDummyLeggings() {
        return wrap(new ItemStack(Items.DIAMOND_LEGGINGS));
    }

    @Override
    public ItemStackRef getDummyBoots() {
        return wrap(new ItemStack(Items.DIAMOND_BOOTS));
    }
    @Override
    public ItemStackRef getDummyOffHand() {
        return wrap(new ItemStack(Items.SHIELD));
    }


    // ---------------------------------------------------------------
    // Status effects
    // ---------------------------------------------------------------

    @Override
    public List<? extends EffectRef> getActiveEffects() {
        if (!hasPlayer())
            return Collections.emptyList();

        var effects = player().getActiveStatusEffects().values();
        List<EffectRef> result = new ArrayList<>(effects.size());
        for (StatusEffectInstance instance : effects) {
            result.add((EffectRef) instance);
        }
        return result;
    }

    @Override
    public List<? extends EffectRef> getDummyEffects() {
        return List.of(
                (EffectRef) new StatusEffectInstance(
                        Registries.STATUS_EFFECT.getEntry(Identifier.ofVanilla("speed")).get(), 12000, 2),
                (EffectRef) new StatusEffectInstance(
                        Registries.STATUS_EFFECT.getEntry(Identifier.ofVanilla("strength")).get(), 12000, 2),
                (EffectRef) new StatusEffectInstance(
                        Registries.STATUS_EFFECT.getEntry(Identifier.ofVanilla("fire_resistance")).get(), 12000, 2));
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private static ItemStackRef wrap(ItemStack stack) {
        return (ItemStackRef) (Object) stack;
    }
}
