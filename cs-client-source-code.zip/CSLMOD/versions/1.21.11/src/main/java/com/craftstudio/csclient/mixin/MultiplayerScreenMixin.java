package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.server.FeaturedServers;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** PlantMC server-entry protection. */
@Mixin(MultiplayerScreen.class)
public abstract class MultiplayerScreenMixin extends Screen {
    @Shadow private ButtonWidget buttonEdit;
    @Shadow private ButtonWidget buttonDelete;
    @Shadow private ServerInfo selectedEntry;

    protected MultiplayerScreenMixin(Text title) { super(title); }

    @Inject(method = "updateButtonActivationStates", at = @At("TAIL"))
    private void csclient$protectPlantControls(CallbackInfo ci) {
        if (selectedEntry != null && FeaturedServers.isCanonicalPlantMcAddress(selectedEntry.address)) {
            buttonEdit.active = false;
            buttonDelete.active = false;
        }
    }

    @Inject(method = "removeEntry", at = @At("HEAD"), cancellable = true)
    private void csclient$denyPlantDelete(boolean confirmed, CallbackInfo ci) {
        if (!confirmed || selectedEntry == null
                || !FeaturedServers.isCanonicalPlantMcAddress(selectedEntry.address)) return;
        MinecraftClient.getInstance().setScreen((MultiplayerScreen) (Object) this);
        ci.cancel();
    }
}
