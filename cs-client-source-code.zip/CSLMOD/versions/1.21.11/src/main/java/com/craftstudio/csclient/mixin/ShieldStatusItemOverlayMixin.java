package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.mod.mods.ShieldStatusesMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Thin status outline preserves every resource-pack pixel of the shield icon. */
@Mixin(DrawContext.class)
public abstract class ShieldStatusItemOverlayMixin {
    @Inject(method = "drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V",
            at = @At("TAIL"))
    private void csclient$drawShieldStatus(TextRenderer textRenderer, ItemStack stack, int x, int y,
            @Nullable String countOverride, CallbackInfo ci) {
        if (!ShieldStatusesMod.itemIconOutlineEnabled() || !stack.isOf(Items.SHIELD)) return;
        float tickDelta = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
        int color = ShieldStatusesMod.iconColor(tickDelta);
        DrawContext self = (DrawContext) (Object) this;
        self.fill(x, y, x + 16, y + 1, color);
        self.fill(x, y + 15, x + 16, y + 16, color);
        self.fill(x, y + 1, x + 1, y + 15, color);
        self.fill(x + 15, y + 1, x + 16, y + 15, color);
    }
}
