package com.craftstudio.csclient.impl.skin;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import com.craftstudio.csclient.account.LocalSkinManager;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;

/** Render-thread dynamic skin + cape texture state for Yarn 1.21.11. */
public final class LocalSkinRuntime {
    private static Identifier skinTextureId;
    private static Identifier capeTextureId;
    private static String model = LocalSkinManager.CLASSIC;
    private static int counter;

    private LocalSkinRuntime() { }

    public static boolean apply(Path skinPng, Path capePng, String requestedModel) {
        NativeImage skinImage = null;
        NativeImage capeImage = null;
        Identifier nextSkin = null;
        Identifier nextCape = null;
        try {
            skinImage = read(skinPng, 64, 64);
            capeImage = read(capePng, 64, 32);
            MinecraftClient client = MinecraftClient.getInstance();
            if (skinImage != null) {
                nextSkin = Identifier.of("csclient", "local_skin_" + ++counter);
                NativeImage registeredSkin = skinImage;
                client.getTextureManager().registerTexture(nextSkin,
                        new NativeImageBackedTexture(() -> "csclient_local_skin", registeredSkin));
                skinImage = null; // ownership transferred to the native-backed texture
            }
            if (capeImage != null) {
                nextCape = Identifier.of("csclient", "local_cape_" + ++counter);
                NativeImage registeredCape = capeImage;
                client.getTextureManager().registerTexture(nextCape,
                        new NativeImageBackedTexture(() -> "csclient_local_cape", registeredCape));
                capeImage = null;
            }

            Identifier previousSkin = skinTextureId;
            Identifier previousCape = capeTextureId;
            skinTextureId = nextSkin;
            capeTextureId = nextCape;
            model = normalize(requestedModel);
            if (previousSkin != null) client.getTextureManager().destroyTexture(previousSkin);
            if (previousCape != null) client.getTextureManager().destroyTexture(previousCape);
            return skinTextureId != null || capeTextureId != null;
        } catch (Exception ignored) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (nextSkin != null) client.getTextureManager().destroyTexture(nextSkin);
            if (nextCape != null) client.getTextureManager().destroyTexture(nextCape);
            if (skinImage != null) skinImage.close();
            if (capeImage != null) capeImage.close();
            return false;
        }
    }

    private static NativeImage read(Path path, int width, int height) throws Exception {
        if (path == null) return null;
        try (InputStream input = Files.newInputStream(path)) {
            NativeImage image = NativeImage.read(input);
            if (image.getWidth() != width || image.getHeight() != height) {
                image.close();
                throw new IllegalArgumentException("invalid local texture dimensions");
            }
            return image;
        }
    }

    public static void reset() {
        MinecraftClient client = MinecraftClient.getInstance();
        Identifier previousSkin = skinTextureId;
        Identifier previousCape = capeTextureId;
        skinTextureId = null;
        capeTextureId = null;
        model = LocalSkinManager.CLASSIC;
        if (previousSkin != null) client.getTextureManager().destroyTexture(previousSkin);
        if (previousCape != null) client.getTextureManager().destroyTexture(previousCape);
    }

    public static boolean isActive() { return skinTextureId != null || capeTextureId != null; }

    public static SkinTextures override(SkinTextures original) {
        if (!isActive() || original == null) return original;
        AssetInfo.TextureAsset body = skinTextureId == null ? original.body()
                : new AssetInfo.TextureAssetInfo(skinTextureId, skinTextureId);
        AssetInfo.TextureAsset cape = capeTextureId == null ? original.cape()
                : new AssetInfo.TextureAssetInfo(capeTextureId, capeTextureId);
        AssetInfo.TextureAsset elytra = capeTextureId == null ? original.elytra() : cape;
        PlayerSkinType type = skinTextureId == null ? original.model()
                : model.equals(LocalSkinManager.SLIM) ? PlayerSkinType.SLIM : PlayerSkinType.WIDE;
        return new SkinTextures(body, cape, elytra, type, original.secure());
    }

    public static SkinTextures getPreviewSkin() {
        MinecraftClient client = MinecraftClient.getInstance();
        SkinTextures fallback = client.player != null
                ? client.player.getSkin()
                : DefaultSkinHelper.getSkinTextures(client.getGameProfile());
        return isActive() ? override(fallback) : fallback;
    }

    private static String normalize(String value) {
        return value != null && value.equalsIgnoreCase(LocalSkinManager.SLIM)
                ? LocalSkinManager.SLIM : LocalSkinManager.CLASSIC;
    }
}
