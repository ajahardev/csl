package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.impl.ui.CSClientScreenFabric;
import com.craftstudio.csclient.ui.screens.TitleMenu;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;

@Mixin(MinecraftClient.class)
public class SetScreenMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen replaceTitleScreen(Screen screen) {
        if (screen instanceof GameMenuScreen)
            return new CSClientScreenFabric(new PauseMenu());

        if (Config.csTitleScreen.value) {
            if (screen instanceof TitleScreen)
                return new CSClientScreenFabric(new TitleMenu());
            if (screen == null && ((MinecraftClient) (Object) this).world == null)
                return new CSClientScreenFabric(new TitleMenu());
        }

        return screen;
    }
}