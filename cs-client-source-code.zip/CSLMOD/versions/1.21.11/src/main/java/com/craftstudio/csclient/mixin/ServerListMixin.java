package com.craftstudio.csclient.mixin;

import java.nio.file.Path;

import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.server.ServerListPinning;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps PlantMC canonical, visible, protected and permanently at index zero. */
@Mixin(ServerList.class)
public abstract class ServerListMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("csclient");

    @Shadow @Final private java.util.List<ServerInfo> servers;
    @Shadow @Final private java.util.List<ServerInfo> hiddenServers;
    @Shadow private MinecraftClient client;

    /** Set when a load produced zero entries although servers.dat has content on disk. */
    @Unique private boolean csclient$loadFailed;
    /** Refusal is logged only once per list instance. */
    @Unique private boolean csclient$wipeRefused;

    /**
     * Load path: normalize the in-memory list only. This hook must never save —
     * if servers.dat was unreadable (legacy format, corruption) the lists come
     * back empty and a save triggered here would destroy the user's saved
     * server list on every relaunch.
     */
    @Inject(method = "loadFile", at = @At("RETURN"))
    private void csclient$afterLoad(CallbackInfo ci) {
        long savedBytes = csclient$savedListFileBytes();
        csclient$loadFailed = ServerListPinning.wouldDestroySavedData(
                servers.size() + hiddenServers.size(), savedBytes > 0L, savedBytes);
        csclient$guardUnreadableListFile();
        csclient$ensurePlantMc();
    }

    @Inject(method = "saveFile", at = @At("HEAD"), cancellable = true)
    private void csclient$beforeSave(CallbackInfo ci) {
        // Never write an empty list over a servers.dat that actually holds
        // saved servers. This protects non-latest instances whose file format
        // this client cannot parse: the user's list must survive a relaunch.
        if (csclient$loadFailed && servers.isEmpty() && hiddenServers.isEmpty()) {
            if (!csclient$wipeRefused) {
                csclient$wipeRefused = true;
                LOGGER.error("CS Client: refusing to save an empty server list over an existing servers.dat (unreadable or foreign format). Your saved servers are preserved.");
            }
            ci.cancel();
            return;
        }
        csclient$loadFailed = false;
        csclient$guardUnreadableListFile();
        csclient$ensurePlantMc();
    }

    // Normal add/edit/delete/reorder methods remain completely vanilla for every
    // non-PlantMC address. Only deletion of the exact canonical pinned object is denied.
    @Inject(method = "remove", at = @At("HEAD"), cancellable = true)
    private void csclient$protectCanonicalRemove(ServerInfo server, CallbackInfo ci) {
        if (server != null && FeaturedServers.isCanonicalPlantMcAddress(server.address)) ci.cancel();
    }

    @Unique
    private long csclient$savedListFileBytes() {
        if (client == null) return 0L;
        try {
            Path file = client.runDirectory.toPath().resolve("servers.dat");
            return java.nio.file.Files.isRegularFile(file)
                    ? java.nio.file.Files.size(file) : 0L;
        } catch (java.io.IOException e) {
            return 0L;
        }
    }

    @Unique
    private void csclient$guardUnreadableListFile() {
        if (!servers.isEmpty() || !hiddenServers.isEmpty() || client == null) return;
        Path backup = ServerListPinning.backupUnreadableListFile(
                client.runDirectory.toPath().resolve("servers.dat"));
        if (backup != null) {
            LOGGER.error("CS Client: servers.dat exists but no entries could be read; "
                    + "the original file was preserved as {}", backup.getFileName());
        }
    }

    @Unique
    private boolean csclient$ensurePlantMc() {
        return ServerListPinning.ensurePinned(
                ServerListPinning.view(servers, ServerListMixin::adapt),
                ServerListPinning.view(hiddenServers, ServerListMixin::adapt),
                () -> adapt(new ServerInfo(FeaturedServers.PLANTMC_LIST_NAME,
                        FeaturedServers.PLANTMC_ADDRESS, ServerInfo.ServerType.OTHER)));
    }

    private static ServerListPinning.Entry adapt(ServerInfo info) {
        return new ServerListPinning.Entry() {
            @Override
            public String name() {
                return info.name;
            }

            @Override
            public String address() {
                return info.address;
            }

            @Override
            public void pin(String name, String address, byte[] icon) {
                info.name = name;
                info.address = address;
                if (icon != null && icon.length > 0) info.setFavicon(icon);
            }

            @Override
            public Object nativeEntry() {
                return info;
            }
        };
    }
}
