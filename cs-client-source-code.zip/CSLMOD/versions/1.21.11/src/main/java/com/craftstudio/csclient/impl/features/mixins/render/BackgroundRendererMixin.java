package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.render.fog.FogRenderer;
import org.joml.Vector4f;
import com.craftstudio.csclient.mod.mods.ClearFluidsMod;
import com.craftstudio.csclient.mod.mods.NoFogMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * 1.21.11 writes fog planes directly into its GPU fog buffer rather than
 * exposing a mutable FogData result. Alter only the final fog-plane arguments,
 * after vanilla has selected Water/Lava/atmospheric behavior.
 */
@Mixin(FogRenderer.class)
public class BackgroundRendererMixin {
    @Unique private Camera csclient$activeFogCamera;

    private static final String WRITE_FOG_PLANES =
            "Lnet/minecraft/client/render/fog/FogRenderer;applyFog(Ljava/nio/ByteBuffer;"
            + "ILorg/joml/Vector4f;FFFFFF)V";

    /** Captures the exact camera passed to this fog frame; do not query a later renderer camera. */
    @Inject(method = "applyFog", at = @At("HEAD"))
    private void csclient$captureFogCamera(Camera camera, int viewDistance, RenderTickCounter tickCounter,
            float skyDarkness, ClientWorld world, CallbackInfoReturnable<Vector4f> cir) {
        csclient$activeFogCamera = camera;
    }

    @ModifyArgs(method = "applyFog", at = @At(value = "INVOKE", target = WRITE_FOG_PLANES))
    private void csclient$configureFogPlanes(Args args) {
        // No Fog remains the broad all-environment feature and takes precedence when enabled.
        if (NoFogMod.isActive()) {
            setClearPlanes(args);
            return;
        }

        Camera camera = csclient$activeFogCamera;
        if (camera == null) return;
        CameraSubmersionType submersion = camera.getSubmersionType();
        if ((submersion == CameraSubmersionType.WATER && ClearFluidsMod.shouldClearWater())
                || (submersion == CameraSubmersionType.LAVA && ClearFluidsMod.shouldClearLava())) {
            setClearPlanes(args);
        }
    }

    /**
     * Args 3–8 are environmental/render-distance/sky/cloud fog planes.
     * Fog color alpha is the vanilla core-shader fog multiplier. Setting it
     * to zero only for active fluids removes the remaining blue/orange tint
     * instead of merely pushing the fog farther away.
     */
    private static void setClearPlanes(Args args) {
        float distance = ClearFluidsMod.CLEAR_FOG_DISTANCE;
        Vector4f color = (Vector4f) args.get(2);
        args.set(2, new Vector4f(color.x, color.y, color.z, 0.0f));
        args.set(3, 0.0f);
        args.set(4, distance);
        args.set(5, 0.0f);
        args.set(6, distance);
        args.set(7, distance);
        args.set(8, distance);
    }
}
