package com.craftstudio.csclient.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import com.craftstudio.csclient.mod.mods.ClearFluidsMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Removes only the first-person fluid overlays selected in Clear Fluids. */
@Mixin(InGameOverlayRenderer.class)
public class ClearFluidsOverlayMixin {
    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true)
    private static void csclient$skipWaterOverlay(MinecraftClient client, MatrixStack matrices,
            VertexConsumerProvider vertices, CallbackInfo ci) {
        if (ClearFluidsMod.shouldClearWater()) ci.cancel();
    }

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void csclient$skipLavaFireOverlay(MatrixStack matrices,
            VertexConsumerProvider vertices, Sprite sprite, CallbackInfo ci) {
        if (!ClearFluidsMod.shouldClearLava()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && client.player.isInLava()) ci.cancel();
    }
}
