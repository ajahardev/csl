package com.craftstudio.csclient.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import com.craftstudio.csclient.mod.tracking.TotemTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Observes vanilla entity-status packets; it never changes combat behavior. */
@Mixin(ClientPlayNetworkHandler.class)
public class TotemTrackerMixin {
    @Inject(method = "onEntityStatus", at = @At("HEAD"))
    private void csclient$trackTotemPop(EntityStatusS2CPacket packet, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        Entity entity = packet.getEntity(client.world);
        if (!(entity instanceof PlayerEntity player)) return;
        byte status = packet.getStatus();
        if (status == 35) {
            boolean local = client.player != null && player.getUuid().equals(client.player.getUuid());
            TotemTracker.recordPop(player.getUuid(), player.getName().getString(), local);
        } else if (status == 3) {
            TotemTracker.resetPlayer(player.getUuid());
        }
    }
}
