package com.craftstudio.csclient.impl.features.render;

import com.craftstudio.csclient.common.feature.RenderFeature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;

/** Yarn adapter for window, FPS, and camera perspective only. */
public class RenderFeatureImpl implements RenderFeature {
    private final MinecraftClient mc;

    public RenderFeatureImpl(MinecraftClient mc) { this.mc = mc; }
    @Override public int getScaledWindowWidth() { return mc.getWindow().getScaledWidth(); }
    @Override public int getScaledWindowHeight() { return mc.getWindow().getScaledHeight(); }
    @Override public int getFps() { return mc.getCurrentFps(); }
    @Override public boolean isFirstPerson() { return mc.options.getPerspective() == Perspective.FIRST_PERSON; }
    @Override public void setFirstPerson() { mc.options.setPerspective(Perspective.FIRST_PERSON); }
    @Override public void setThirdPersonBack() { mc.options.setPerspective(Perspective.THIRD_PERSON_BACK); }
}
