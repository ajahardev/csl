package com.craftstudio.csclient.mixin;

import java.util.List;

import org.objectweb.asm.Opcodes;
import com.craftstudio.csclient.impl.render.BlockBreakLayers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.WorldRenderer;

@Mixin(WorldRenderer.class)
public abstract class BlockBreakWorldMixin {
    @Redirect(method = "renderBlockDamage", at = @At(value = "FIELD",
            target = "Lnet/minecraft/client/render/model/ModelBaker;BLOCK_DESTRUCTION_RENDER_LAYERS:Ljava/util/List;",
            opcode = Opcodes.GETSTATIC))
    private List<RenderLayer> csclient$selectBlockBreakLayers() {
        return BlockBreakLayers.active();
    }
}
