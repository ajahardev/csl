package com.craftstudio.csclient.impl.features.mixins.render;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.BossBarHud;
import com.craftstudio.csclient.mod.mods.BossBarMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Moves Minecraft's exact boss-bar draw commands; never recreates or cancels server bars. */
@Mixin(BossBarHud.class)
public class BossBarMixin {
    @Unique private boolean csclient$bossPosePushed;

    @Inject(method = "render", at = @At("HEAD"))
    private void csclient$moveNativeBossBars(DrawContext context, CallbackInfo ci) {
        csclient$bossPosePushed = false;
        try {
            int available = ((BossBarHudAccessor) (Object) this).csclient$getBossBars().size();
            if (available <= 0) return;
            int limit = context.getScaledWindowHeight() / 3;
            int maxBars = Math.max(1, Math.max(0, limit - 12) / 19 + 1);
            int count = Math.min(available, maxBars);
            int width = 182;
            int height = (count - 1) * 19 + 14;
            int defaultX = context.getScaledWindowWidth() / 2 - 91;
            int defaultY = 3;
            BossBarMod.updateNativeBounds(width, height, defaultX, defaultY);
            if (!BossBarMod.shouldMoveVanilla()) return;

            context.getMatrices().pushMatrix();
            csclient$bossPosePushed = true;
            context.getMatrices().translate(
                    BossBarMod.targetX() - defaultX,
                    BossBarMod.targetY() - defaultY);
        } catch (LinkageError | RuntimeException ignored) {
            if (csclient$bossPosePushed) {
                context.getMatrices().popMatrix();
                csclient$bossPosePushed = false;
            }
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void csclient$restoreNativeBossPose(DrawContext context, CallbackInfo ci) {
        if (!csclient$bossPosePushed) return;
        context.getMatrices().popMatrix();
        csclient$bossPosePushed = false;
    }
}
