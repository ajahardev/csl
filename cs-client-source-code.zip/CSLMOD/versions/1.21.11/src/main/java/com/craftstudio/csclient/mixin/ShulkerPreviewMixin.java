package com.craftstudio.csclient.mixin;

import java.util.List;

import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.collection.DefaultedList;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.mods.ShulkerPreviewMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws a fixed 9×3 shulker inventory preview outside the vanilla tooltip. */
@Mixin(HandledScreen.class)
public abstract class ShulkerPreviewMixin {
    @Shadow protected Slot focusedSlot;

    @Inject(method = "drawMouseoverTooltip", at = @At("HEAD"), cancellable = true)
    private void csclient$drawShulkerPreview(DrawContext context, int mouseX, int mouseY, CallbackInfo ci) {
        if (!ShulkerPreviewMod.isActive() || focusedSlot == null || !focusedSlot.hasStack()) return;
        if (ShulkerPreviewMod.requireShift()
                && !Providers.GLFW.isKeyPressed(GLFWProvider.GLFW_KEY_LEFT_SHIFT)
                && !Providers.GLFW.isKeyPressed(GLFWProvider.GLFW_KEY_RIGHT_SHIFT)) return;
        ItemStack hovered = focusedSlot.getStack();
        if (!(hovered.getItem() instanceof BlockItem blockItem)
                || !(blockItem.getBlock() instanceof ShulkerBoxBlock)) return;
        ContainerComponent container = hovered.get(DataComponentTypes.CONTAINER);
        DefaultedList<ItemStack> stacks = DefaultedList.ofSize(27, ItemStack.EMPTY);
        if (container != null) container.copyTo(stacks);

        MinecraftClient client = MinecraftClient.getInstance();
        int windowW = context.getScaledWindowWidth();
        int windowH = context.getScaledWindowHeight();
        int panelW = 172, panelH = 72;
        float scale = ShulkerPreviewMod.scale();
        int scaledW = Math.round(panelW * scale);
        int scaledH = Math.round(panelH * scale);
        int x = switch (ShulkerPreviewMod.position()) {
            case 1 -> Math.max(6, mouseX - scaledW - 16);
            case 2 -> Math.max(6, Math.min(windowW - scaledW - 6, mouseX + 18));
            default -> mouseX + 18 + scaledW < windowW ? mouseX + 18 : Math.max(6, mouseX - scaledW - 16);
        };
        int y = Math.max(6, Math.min(windowH - scaledH - 6, mouseY - Math.round(18 * scale)));

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        int bg = ShulkerPreviewMod.style() == 1 ? 0xF0101010 : 0xF012171D;
        context.fill(0, 0, panelW, panelH, bg);
        context.fill(0, 0, panelW, 1, 0xFF9AA1AA);
        context.drawText(client.textRenderer, hovered.getName(), 7, 6, 0xFFF0F2F4, false);
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++) {
            int sx = 5 + col * 18, sy = 18 + row * 18;
            context.fill(sx, sy, sx + 18, sy + 18, 0x781A2027);
            ItemStack stack = stacks.get(row * 9 + col);
            if (!stack.isEmpty()) {
                context.drawItem(stack, sx + 1, sy + 1);
                context.drawStackOverlay(client.textRenderer, stack, sx + 1, sy + 1);
            }
        }
        context.getMatrices().popMatrix();
        // The CS grid replaces the vanilla name/text tooltip for shulkers.
        ci.cancel();
    }
}
