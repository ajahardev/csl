package com.craftstudio.csclient.mixin;

import com.craftstudio.csclient.account.LocalSkinManager;
import com.craftstudio.csclient.impl.skin.LocalSkinRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;

/** Client-only body skin override for the active CS local/offline player. */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class LocalSkinMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void csclient$overrideLocalSkin(CallbackInfoReturnable<SkinTextures> cir) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || (Object) this != client.player) return;
        if (!LocalSkinManager.isActiveAppearanceProfile() || !LocalSkinRuntime.isActive()) return;
        cir.setReturnValue(LocalSkinRuntime.override(cir.getReturnValue()));
    }
}
