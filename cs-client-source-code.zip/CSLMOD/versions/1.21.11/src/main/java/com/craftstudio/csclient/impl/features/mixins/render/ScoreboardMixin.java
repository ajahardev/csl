package com.craftstudio.csclient.impl.features.mixins.render;

import java.util.Comparator;
import java.util.List;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.Text;

import com.craftstudio.csclient.mod.mods.ScoreboardMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Moves Minecraft's own sidebar draw commands instead of recreating the scoreboard. */
@Mixin(InGameHud.class)
public class ScoreboardMixin {
    @Unique private boolean csclient$scoreboardPosePushed;

    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At("HEAD"))
    private void csclient$moveNativeSidebar(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
        csclient$scoreboardPosePushed = false;
        try {
            Bounds bounds = csclient$measure(context, objective);
            ScoreboardMod.updateNativeBounds(bounds.width(), bounds.height(), bounds.left(), bounds.top());
            if (!ScoreboardMod.shouldMoveVanilla()) return;

            context.getMatrices().pushMatrix();
            csclient$scoreboardPosePushed = true;
            context.getMatrices().translate(ScoreboardMod.targetX(), ScoreboardMod.targetY());
            float scale = ScoreboardMod.targetScale();
            context.getMatrices().scale(scale, scale);
            context.getMatrices().translate(-bounds.left(), -bounds.top());
        } catch (LinkageError | RuntimeException ignored) {
            // Fail open: vanilla renders in its normal location if measuring fails.
            if (csclient$scoreboardPosePushed) {
                context.getMatrices().popMatrix();
                csclient$scoreboardPosePushed = false;
            }
        }
    }

    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At("RETURN"))
    private void csclient$restoreNativeSidebarPose(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
        if (!csclient$scoreboardPosePushed) return;
        context.getMatrices().popMatrix();
        csclient$scoreboardPosePushed = false;
    }

    @Unique
    private static Bounds csclient$measure(DrawContext context, ScoreboardObjective objective) {
        Scoreboard scoreboard = objective.getScoreboard();
        NumberFormat scoreFormat = objective.getNumberFormatOr(StyledNumberFormat.RED);
        TextRenderer font = MinecraftClient.getInstance().textRenderer;
        List<ScoreboardEntry> entries = scoreboard.getScoreboardEntries(objective).stream()
                .filter(entry -> !entry.hidden())
                .sorted(Comparator.comparingInt(ScoreboardEntry::value).reversed()
                        .thenComparing(ScoreboardEntry::owner, String.CASE_INSENSITIVE_ORDER))
                .limit(15L).toList();

        int contentWidth = font.getWidth(objective.getDisplayName());
        int spacerWidth = font.getWidth(": ");
        for (ScoreboardEntry entry : entries) {
            Text name = Team.decorateName(scoreboard.getTeam(entry.owner()), entry.name());
            Text score = entry.formatted(scoreFormat);
            int scoreWidth = font.getWidth(score);
            contentWidth = Math.max(contentWidth,
                    font.getWidth(name) + (scoreWidth > 0 ? spacerWidth + scoreWidth : 0));
        }

        int contentHeight = entries.size() * font.fontHeight;
        int bottom = context.getScaledWindowHeight() / 2 + contentHeight / 3;
        int left = context.getScaledWindowWidth() - contentWidth - 3;
        int top = bottom - contentHeight - font.fontHeight - 1;
        return new Bounds(left - 2, top, contentWidth + 4,
                contentHeight + font.fontHeight + 1);
    }

    @Unique private record Bounds(int left, int top, int width, int height) { }
}
