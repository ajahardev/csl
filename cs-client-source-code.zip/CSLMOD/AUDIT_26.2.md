# CS Client V1 — Minecraft 26.2 verification

## Fixes included

- `ItemStackRef.getDamage()` now has a safe default and a concrete 26.2 bridge to `ItemStack.getDamageValue()`.
- `EffectRef.shouldShowIcon()` and `EffectRef.isInfinite()` now have safe defaults and concrete 26.2 bridges to `showIcon()` and `isInfiniteDuration()`.
- `WindowRef` framebuffer bridges, semantic Fabric metadata, GUI text shader fallback, RRLS loading-overlay compatibility, offline-launcher appearance support, and mouse-coordinate fixes remain included.
- HUD Editor no longer applies the obsolete `/2` pointer correction.
- HUD collision handling prevents drag, resize, scroll-resize, keyboard movement, reset, and loaded preset positions from overlapping another scaled widget.
- Module render/tick fault isolation prevents one unexpected module linkage/runtime failure from crashing the whole game.
- Performance Engine contains no Minecraft/Sodium graphics-setting mutation or restoration path. It adds actual render-frame telemetry, adaptive CS-only profiles, local benchmark export, immutable module snapshots, bounded styled-text caching, and lower-allocation text/render loops.
- Scoreboard and Boss Bar are automatic, non-toggleable HUD adapters. They appear only with server data and remain movable through Right Shift → HUD Layout.
- Scoreboard follows vanilla team-color objective selection and fails open instead of hiding an unreadable/empty sidebar.
- Boss Bar fails open if active boss events cannot be read.
- Release JAR contains zero Markdown entries; packaged notices/licence index use `.txt`.
- Shulker Preview uses a cancellable HEAD injection, supports empty boxes, and clamps its 9×3 grid to the screen.
- Health Indicator uses Minecraft's exact runtime heart sprites rather than the old custom atlas.
- Auto GG result detection, separate Clear Water/Lava toggles, and No Fog paths were re-audited.
- CS branding adds a server-relayed UUID capability cache, official cached logo glyphs, three settings, 48-block cutoff, and vanilla nametag visibility/occlusion behavior.
- Same JAR provides the optional Fabric server relay; ordinary servers without relay support receive no client hello and remote players remain UNKNOWN.
- CS Worlds uses e4mc 6.2.1 in a reproducibly patched classic-relay profile: normal startup gates hosting OFF; explicit LAN publish gates classic hosting ON; conflicting Dialtone/login/DNS mixins are absent; Join World uses native Direct Connect.
- The custom Escape menu has a labelled vanilla Open to LAN action. On 26.2 it opens the native Multiplayer Options screen and remains separate from CS Worlds relay hosting.
- If vanilla LAN was already open, a later explicit Host World click reuses the unchanged in-memory listener inputs and starts upstream QuiclimeSession; this removes the silent no-session timeout without starting a relay from the LAN click alone.
- Dedicated-server initialization forces bundled e4mc host/Dialtone flags OFF before the listener starts; server boot reached Done with no broker/domain request.
- Chat Improvements adds local timestamps, mentions, Copy Last, Hide/Show and safe duplicate handling without deleting signed reportable player messages.
- Screenshot Manager is sandboxed to the active profile's direct `screenshots` directory, with bounded lazy image decoding and no upload service.
- Shield Statuses uses native cooldown progress plus item-outline/first-person translucent overlay passes; resource-pack shield textures are not replaced.

## Automated checks

- Minecraft 26.2 production build: **passed**.
- Common module smoke test: **57/57 passed**.
  - Exercises module enable/disable, keybind handling, tick, overlay render, HUD eligibility, dummy render, editor render, and live HUD render paths with deterministic providers.
- HUD collision smoke test: **passed** (drag and resize overlap rejection).
- Performance settings safety gate: **passed** (forbidden graphics/distance/particle/cloud/entity-distance/Sodium/restoration tokens absent).
- Performance frame metrics and local CSV/JSON benchmark export smoke test: **passed**.
- Immutable enabled-module snapshot and Sodium/settings ownership checks: **passed**.
- Scoreboard/Boss fail-open, Shulker configuration, Auto GG detection, fog/fluid toggles, and exact vanilla-heart provider checks: **passed**.
- 26.2 production compilation and client-start mixin application: **passed before the expected missing-DISPLAY stop**.
- CS Worlds domain normalization/extraction, pre-opened LAN listener reuse, broker response, and normal-client startup host-gate checks: **passed**.
- Dedicated-server e4mc exposure safety: **passed** (`hostEnabled=false`, `dialtoneHostEnabled=false`, no domain assigned).
- Krypton 0.3.1 compatibility startup: **passed**; 0 redirect conflicts, no e4mc login/Connection/DNS mixin classes, CS initialized normally before the expected missing-DISPLAY stop.
- Chat state, screenshot sandbox/thumbnail codec, and Shield Status red/orange/green/interpolation smoke checks: **passed**.
- Chat/Shield GUI and cooldown selector audit across all three targets: **passed**.
- Declared CS mixins packaged: **49/49**.
- JAR ZIP integrity: **passed**.
- Fabric metadata: `1.0.0+26.2`.
- Release file: `cs-client-V1+26.2.jar`.

## Release checksum

```text
16b956da97f43ad4fb8a4b473e2312c39e3cfb94d2450b938eaa6bd865f53ff6  cs-client-V1+26.2.jar
```

## Runtime boundary

The sandbox does not provide the user's exact Android GPU, MobileGlues/LWJGL/e4mc native stack, launcher, two external networks, local-account multiplayer pair, world, custom shield resource packs, or complete modpack. Automated checks cover code paths, target compilation, selectors, e4mc artifacts/broker/server safety, screenshot codec, and package integrity; real e4mc Host/Join, Chat touch layout and Shield translucency still require physical testing.
