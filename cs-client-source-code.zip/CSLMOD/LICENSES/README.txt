# Third-party licenses

- `Apache-2.0.txt` applies to Apache-2.0-derived portions identified in `NOTICES.txt`.
- The version-specific `WhoAmI.java` files remain under the Mozilla Public License 2.0, as stated in their source headers: https://mozilla.org/MPL/2.0/
- `Shulker-Preview-MIT.txt` covers MIT-licensed Shulker Preview behavior/source adaptations.
- `Clear-Water-MIT.txt` covers MIT-licensed Clear Water behavior/source adaptations.
- `AutoGG-MIT.txt` covers MIT-licensed AutoGG behavior/source adaptations.
- `NoFog-MIT.txt` covers MIT-licensed NoFog behavior/source adaptations.
- `Shield-Status-MIT.txt` covers the MIT-licensed Shield Status behavior reference; CS's implementation is independent and does not bundle WalksyLib or upstream assets.

HealthIndicators is LGPL-3.0 and is used for research only; no LGPL source or assets are incorporated. CS uses an independent implementation referencing Minecraft's runtime heart sprites.

These third-party portions are excluded from the CS Client V1 proprietary restrictions and retain the rights granted by their original licenses.
