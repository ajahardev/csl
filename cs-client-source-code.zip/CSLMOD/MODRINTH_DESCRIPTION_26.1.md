# ✦ CS Client V1 — Minecraft 26.1

> **This download is for Minecraft 26.1.** Required: Java 25, Fabric Loader 0.19.3+, and Fabric API 0.145.1+26.1.

> A responsive, customizable Fabric client for players who want a cleaner interface, useful HUD information, visual controls, PvP feedback, local appearance tools, and practical performance options in one package.

CS Client V1 is designed to keep every important option easy to find. Modules can be enabled individually, HUD elements can be moved and resized, colors can be customized, and most features include their own settings.

---

## ◆ Available Minecraft Versions

CS Client V1 is available as **three separate builds**:

| Minecraft version | Java | Fabric Loader | Fabric API | Download file |
|---|---:|---:|---:|---|
| **1.21.11** | **21** | **0.18.2+** | **0.141.3+1.21.11** | `cs-client-V1+1.21.11.jar` |
| **26.1** | **25** | **0.19.3+** | **0.145.1+26.1** | `cs-client-V1+26.1.jar` |
| **26.2** | **25** | **0.19.3+** | **0.157.0+26.2** | `cs-client-V1+26.2.jar` |

> Download the JAR matching your exact Minecraft version. Install only one CS Client JAR at a time.

---

# ✦ Main Client Experience

## ◆ Responsive Interface

CS Client provides a complete dark-graphite interface built around simple navigation and readable controls.

- Responsive Home and Pause screens.
- Dedicated Modules, Settings, HUD Layout, Theme Studio, and Appearance screens.
- Smooth panel, button, hover, and transition animations.
- Compact layouts for smaller windows and higher GUI scales.
- Quick access to Singleplayer, Multiplayer, Minecraft Settings, CS Settings, and installed mods.
- Custom loading visuals, panorama support, logos, icons, and interface components.
- Optional access to Mod Menu when it is installed.

## ◆ Easy Controls

| Action | Default key |
|---|---|
| Open the CS Client quick menu | **Right Shift** |
| Open local Appearance Studio | **H** |
| Toggle individual modules | Configurable inside each module |

---

# ✦ HUD Layout & Presets

The HUD editor lets players build a layout that fits their own screen and play style.

- Drag supported HUD modules anywhere on the screen.
- Resize widgets with individual scale controls.
- Preview modules before returning to gameplay.
- Newly enabled widgets receive automatic starting positions to reduce overlap.
- Save and manage different HUD layouts.
- Use preset categories for PvP, BedWars, Survival, Streaming, Performance, and Minimal layouts.
- Configure colors, text style, visibility, and module-specific behavior.

---

# ✦ 54 Configurable Modules

Every module can be managed separately. The descriptions below explain what each feature does.

## ◆ HUD & Information

| Module | What it does |
|---|---|
| **Armor Display** | Shows the helmet, chestplate, leggings, and boots currently equipped. |
| **Block Information** | Displays the name and basic details of the block under the crosshair. |
| **Boss Bar** | Provides movable compact boss bars with color and percentage controls. |
| **Chunk Position** | Shows the player’s current chunk coordinates. |
| **Clock** | Displays the current real-world time. |
| **Connection Status** | Shows the current connection state and network latency. |
| **Coordinates** | Displays the player’s current X, Y, and Z coordinates. |
| **Day Counter** | Shows how many in-game days have passed in the world. |
| **Direction Display** | Shows compass direction and player yaw. |
| **Distance Tracker** | Tracks horizontal distance travelled during gameplay. |
| **FPS Display** | Shows the current frame rate in a compact HUD widget. |
| **Inventory HUD** | Displays a movable view of real inventory slots and item counts. |
| **Item Counter** | Counts the selected item across the player’s inventory. |
| **Item Info** | Shows held-item name, enchantment state, and durability information. |
| **Keystrokes** | Displays WASD, mouse CPS, borders, and smooth key-press animations. |
| **Memory Usage** | Shows current Java heap-memory usage. |
| **Movement Status** | Shows sprinting, sneaking, jumping, and airborne states. |
| **Ping Display** | Displays network ping to the current server. |
| **Saturation** | Shows food level and the normally hidden saturation value. |
| **Scoreboard** | Moves and scales the server’s original Minecraft scoreboard without rebuilding its content. |
| **Server Address** | Shows the address of the server currently being played. |
| **Speedometer** | Displays current movement speed. |
| **Status Effects** | Shows active potion and status effects. |
| **Stopwatch** | Provides a key-controlled stopwatch for gameplay sessions. |
| **TPS Display** | Estimates and displays server ticks per second. |

## ◆ PvP & Combat Feedback

| Module | What it does |
|---|---|
| **Attack Indicator** | Shows vanilla-style attack strength with a target-ready cue. |
| **Auto GG** | Sends one delayed “GG” after a supported verified game-end message. |
| **Combo Counter** | Counts consecutive attacks while targeting an entity. |
| **CPS Display** | Shows left-click and right-click counts per second. |
| **Custom Crosshair** | Offers crosshair presets, colors, target highlighting, and attack animation. |
| **Health Indicator** | Shows full, half, and absorption hearts above players and optional mobs. |
| **Hit Indicator** | Displays an animated hit marker around the crosshair. |
| **Hitbox** | Shows filtered visual hitboxes with eye and look-direction guides. It does not change real entity hitboxes. |
| **Reach Display** | Shows the distance of the latest targeted hit. |
| **Target Indicator** | Indicates when the crosshair is pointing at a living entity. |
| **TNT Timer** | Shows a color-coded fuse countdown above primed TNT. |
| **Totem Counter** | Shows inventory totems and observed totem pops for the player and opponent. |

## ◆ Visual, Camera & World

| Module | What it does |
|---|---|
| **Block Break Animation** | Uses CS block-crack stages and can restore Minecraft or resource-pack stages when disabled. |
| **Block Overlay** | Customizes block-outline color and thickness. |
| **Clear Fluids** | Controls water and lava fog, tint, and matching first-person overlays. |
| **Freelook** | Lets the camera look around without changing character direction. |
| **Fullbright** | Improves visibility in dark areas. |
| **Low Fire** | Lowers first-person fire while keeping a visible flame warning. |
| **Low Shield** | Makes the first-person shield smaller and lower without removing its texture. |
| **Minimap** | Provides a lightweight cached terrain map with size, shape, and zoom controls. |
| **Nametags** | Adds configurable entity nametag presentation. |
| **CS Client Branding** | Shows the official CS badge before server-relay-confirmed CS Client player names. |
| **No Fog** | Prevents normal fog rendering while enabled. |
| **Perspective Toggle** | Switches quickly between first-person and third-person perspectives. |
| **Remove Shake** | Controls camera tilt after damage without changing gameplay damage. |
| **Shulker Box Preview** | Shows shulker-box contents from an inventory hover preview. |
| **Zoom** | Provides a closer camera view with configurable behavior. |

## ◆ Movement & Performance

| Module | What it does |
|---|---|
| **Auto Sprint** | Keeps sprint active when normal sprinting conditions are met. |
| **Performance Engine** | Measures real frametimes and optimizes only CS-owned HUD, text, cache, and minimap work. |

---

# ✦ Appearance Studio

Appearance Studio provides local, password-free profile and cosmetic controls.

## ◆ Local Profiles

- Create a local profile with a valid Minecraft-style username.
- Switch local profiles while on the title screen.
- Each profile receives its own isolated appearance folder.
- No Microsoft password, launcher cookie, or account credential is requested by the local profile manager.
- Local profiles are offline identities and do not replace an authenticated Minecraft account for online-mode servers.

## ◆ Local Skins & Capes

- Import a **64×64 PNG skin** using the built-in file picker.
- Import a direct public skin PNG URL.
- Copy a public Mojang skin by entering a Minecraft username.
- Select **Classic** or **Slim** player models.
- Import a local **64×32 PNG cape**.
- Reset the skin, cape, or full appearance separately.
- Imported textures are size-checked, dimension-checked, and converted into canonical PNG files.
- Appearance data is stored separately for each eligible profile.

---

# ✦ Theme Studio

Players can adjust the visual style without editing resource files.

- Choose interface and accent colors.
- Use included theme presets.
- Preview changes before applying them.
- Control interface animation behavior.
- Use the built-in hue, saturation, brightness, and transparency picker.
- Select standard or alternate logo presentation.

---

# ✦ Performance Controls

Performance Engine measures actual render frames and controls only CS-owned algorithms.

- **Low:** maximum compatibility and frequent CS value refresh.
- **Balanced:** moderate CS HUD/minimap refresh reduction.
- **High Performance:** strongest safe CS-side refresh reduction.
- Optional adaptive mode uses p95/p99 frametimes with hysteresis.
- A configurable key exports local CSV frame samples and a JSON benchmark summary with FPS, 1%/0.1% lows, frametime percentiles, heap, GC and CPU-load data.
- Minecraft graphics and Sodium settings are never read, changed, saved, or restored.

CS Client can be used alongside popular optimization mods. It does not bundle, patch, or reconfigure those mods automatically.

---

# ✦ Dependencies & Compatibility

## ◆ Required

- A supported Minecraft version: **1.21.11**, **26.1**, or **26.2**.
- Matching **Fabric Loader**.
- Matching **Fabric API**.
- Correct Java version shown in the version table above.

## ◆ Optional Suggestions

- Sodium
- Lithium
- ImmediatelyFast
- EntityCulling
- FerriteCore
- Mod Menu

These are optional suggestions and are not required for CS Client to load.

### Minecraft 26.2 Renderer Note

Minecraft 26.2 may provide an experimental Vulkan backend. CS Client uses Minecraft’s normal GUI, HUD, and renderer submission APIs rather than adding a direct OpenGL rendering path. Device, driver, launcher, and experimental-renderer combinations should still be tested individually.

---

# ✦ Installation

1. Install one of the three supported Minecraft versions.
2. Install the matching Fabric Loader.
3. Add the matching Fabric API build to the `mods` folder.
4. Confirm the launcher is using the required Java version.
5. Place the matching CS Client V1 JAR in the `mods` folder.
6. Remove any CS Client JAR made for a different Minecraft version.
7. Start Minecraft with the Fabric profile.

> Never install multiple CS Client version JARs together.

---

# ✦ Privacy & External Actions

- The local profile manager does not request account passwords or Microsoft credentials.
- Public Mojang appearance imports use Mojang profile and Minecraft texture services.
- Direct texture imports apply URL, response-size, redirect, and local-network checks.
- Community browser links require a confirmation screen before opening.
- Local configuration, HUD layouts, profiles, skins, and capes remain inside the Minecraft game directory.

---

# ✦ Licence

**CS Client V1 is proprietary and source-available, not open source.**

Official unmodified builds may be used for personal, non-commercial gameplay. Editing, publishing modified versions, re-uploading, redistribution, or sale requires prior written permission from Craft Studio. Identified third-party components retain their original licences.

---

## ◆ Quick Summary

**CS Client V1 combines a responsive interface, 54 configurable modules, a complete HUD editor, local appearance tools, theme customization, and renderer-safe CS performance controls. Separate builds are available for Minecraft 1.21.11, 26.1, and 26.2.**
