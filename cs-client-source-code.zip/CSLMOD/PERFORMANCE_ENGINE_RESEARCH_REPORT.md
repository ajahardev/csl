# CS Client — Advanced Performance Engine Research Report

**Research date:** 2026-08-18  
**Status:** Research and design only — no Performance Engine implementation was started in this phase.  
**Targets:** Minecraft 1.21.11, 26.1/26.1.x, and 26.2

---

## Executive decision

CS Client should **not** attempt to become another Sodium, Lithium, C2ME, FerriteCore, or ImmediatelyFast. Those projects optimize different, large subsystems and carry years of compatibility work. CS Client should become a **measured, complementary optimization layer** with three responsibilities:

1. Eliminate overhead created by CS Client itself.
2. Reduce optional CS-owned rendering work—HUD, text, health labels, TNT labels, minimap sampling, and other CS overlays—without changing gameplay or visual settings.
3. Enable only carefully measured optimizations for unowned gaps, and automatically step aside when a specialist mod already owns that area.

The first engineering milestone must be a benchmark/telemetry foundation. No optimization should ship without an identified hot path, a controlled before/after test, and a compatibility/regression result.

### Non-negotiable invariant

The Performance Engine must never mutate:

- Minecraft graphics mode or presets
- Render distance or simulation distance
- Entity distance
- Particles, clouds, weather, biome blend, shadows, AO, VSync, FPS limit, or similar visual settings
- Sodium/Embeddium/Rubidium/Canvas/VulkanMod settings
- `options.txt`, `sodium-options.json`, or equivalent renderer configuration

There must be no “restore settings on shutdown” system because the engine must never take ownership of those settings in the first place.

---

# 1. Audit of the current CS Performance Boost

## What is acceptable today

The current module has two CS-owned ideas that are valid starting points:

- Throttled refresh of CS HUD values that do not need to be recomputed every rendered frame.
- Lower-frequency minimap sampling.

These affect CS-owned work and can be controlled without changing Minecraft quality.

## What is fundamentally wrong

The current code still contains a forbidden graphics-preset path:

- `common/.../PerformanceBoostMod.java` exposes `Adjust Vanilla Graphics (No Sodium)`.
- `RenderFeature.applyPerformancePreset(...)` is implemented in every target.
- The target implementations change view distance, simulation distance, graphics preset/mode, entity distance, clouds, particles, VSync, shadows, FPS limit, weather radius, AO, transparency, chunk fade, and other options.
- They save those options and contain restoration state.

Even though this path is now opt-in and blocked for known external renderers, it violates the new strict requirement. It should be removed completely during implementation Phase 1—not merely hidden.

## Why the current module is not an engine

- It has no real frame-time recorder.
- It does not measure 1% low, 0.1% low, allocation rate, GC pauses, or CPU/GPU bottlenecks.
- Profiles are fixed refresh intervals rather than decisions backed by a measured workload.
- It does not know whether the client is CPU-bound, GPU-bound, allocation-bound, thermally throttled, or waiting on chunk work.
- It has no capability/ownership registry beyond renderer detection around the old settings path.
- It contains no benchmark export or reproducible comparison mode.

## Current CS-owned hot paths worth measuring

Static source review found multiple likely allocation or repeated-work sites:

- Every HUD frame copies `ModManager.ENABLED_MODS` into a new `ArrayList`.
- The client tick also copies the enabled list.
- `CSClientScreen.render` and multiple input methods copy element lists.
- `Fonts.getWidth` uses `String.split` and creates styled text objects repeatedly.
- Text drawing creates components/ordered text and matrices per line.
- Scoreboard and boss-bar adapters construct streams/lists repeatedly.
- Rounded UI geometry has a cache, but the generated SVG-shape cache is unbounded.
- Many UI screens rebuild complete element trees and strings on initialization; this is acceptable if initialization-only, but must not leak into every-frame paths.
- Minimap world sampling is synchronous and must be measured for main-thread spikes.

These are better first targets than patching Minecraft's world renderer.

---

# 2. What established performance projects actually do

## Sodium

**Primary ownership:** terrain/chunk rendering and renderer architecture.

Observed techniques in the current source and releases:

- Dedicated chunk rendering pipeline and chunk-section data structures.
- Compact/native buffers and optimized vertex writing.
- Chunk mesh preparation and task scheduling.
- Multi-draw batching to reduce CPU draw-submission overhead.
- Frustum and graph/occlusion-based chunk visibility.
- Material/render-pass simplification where geometry does not require an expensive pass.
- Texture animation visibility tracking.
- Optimized immediate vertex consumers, sorting, matrix operations, model processing, color handling, clouds, and biome blending.
- 26.1/26.2 work includes asynchronous graph culling and frame-independent task scheduling.
- Separate compatibility and driver workarounds.

**Lesson for CS:** do not patch Sodium's chunk renderer, native buffers, visibility graph, or scheduler. When Sodium is present, CS should treat chunk rendering as an externally owned capability.

**Safe complementary area:** CS-owned HUD/text/overlay caching and conservative filtering before CS creates render states.

## Lithium

**Primary ownership:** game logic and integrated-server hot paths.

Observed optimization families:

- Entity collision and shape-query shortcuts.
- Event/listener-driven invalidation instead of repeated world polling.
- Mob AI sensor/task/POI lookup optimizations.
- Faster collections and entity/chunk iteration.
- Block and fluid ticking improvements.
- Hopper/inventory/comparator tracking.
- Explosion raycast/block-access caches and lower allocation paths.
- Chunk palettes, serialization, ticket collections, and block-entity ticking.
- Client-tick and biome-particle optimizations in modern releases.

**Lesson for CS:** AI, physics, ticking, redstone, block entities, explosions, and world simulation are behavior-sensitive. CS should not reproduce these in a client module. Recommend Lithium as the owner and disable any future overlapping CS patch when it is installed.

## FerriteCore

**Primary ownership:** memory footprint.

Documented techniques include:

- Compact block-state neighbor/property storage.
- Deduplication/canonicalization of block-state caches and immutable shapes.
- Deduplication of model predicates, model instances, strings, and baked quad data.
- Smaller threading detectors and data-component structures in modern versions.
- Replacing object-heavy maps/tables with compact indexed structures.

**Lesson for CS:** the general principles—canonical immutable data, compact keys, primitive arrays, and deduplication—are useful for CS-owned caches. CS should not patch global block-state/model internals when FerriteCore or ModernFix is available.

## ImmediatelyFast

**Primary ownership:** immediate-mode, GUI/HUD, text, entity, map, and block-entity rendering submission.

Observed techniques:

- Enhanced batching of immediate rendering.
- Map texture atlas generation.
- Font-atlas sizing and fast glyph/text lookups.
- Sign-text buffering.
- Avoidance of redundant framebuffer switching.
- Resource-pack/core-shader conflict detection before enabling risky paths.
- Targeted Apple GPU buffer-upload workaround.
- Reduced translucent text sorting where safe.

**Lesson for CS:** this overlaps directly with generic GUI batching. If ImmediatelyFast is present, CS should avoid its own low-level batching and concentrate on not generating unnecessary CS elements in the first place. Without ImmediatelyFast, any batching experiment must use supported Blaze3D/extraction APIs and must be benchmarked independently for each target.

## EntityCulling

**Primary ownership:** hidden entity/block-entity visibility.

Observed design:

- Asynchronous path-tracing/line-of-sight calculations.
- Small main-thread snapshots with visibility work on a worker.
- Visibility cache with periodic invalidation.
- Conservative near-camera behavior.
- Entity/block-entity whitelists for unusual render bounds.
- Optional client-side tick culling with warnings for modded entities.
- Designed to complement Sodium's cheaper chunk/frustum visibility.

**Lesson for CS:** this is not a trivial raycast in a render callback. It needs snapshot safety, worker budgeting, stale-result handling, camera-movement invalidation, whitelists, fail-visible behavior, and debug toggles. If EntityCulling is installed, CS culling must disable itself.

## MoreCulling

**Primary ownership:** block face/model/item-frame/map/sign/painting/leaves culling.

Observed techniques:

- Improved block-face and cull-shape decisions.
- Cached model/quad opacity information.
- Item-frame and painting face checks.
- Map/sign-related culling.
- Leaves and non-full-block rules.
- Explicit Sodium and VulkanMod compatibility layers.

**Risk:** aggressive geometric assumptions can cause missing faces with custom models/resource packs/mods. The project's issue history demonstrates why every culling feature needs a per-feature disable and compatibility list.

**Lesson for CS:** do not add global block/model-face culling in the first engine. Defer to MoreCulling; at most optimize CS-owned world labels.

## ModernFix

**Primary ownership:** broad memory, startup, reload, resource, and compatibility fixes.

Observed techniques:

- Dynamic/lazy model and resource loading with bounded/expiring caches.
- Resource listing and texture-stitching improvements.
- Reduced block-state cache rebuilds.
- Compact registries, entity models, chunk/worldgen data, NBT, and ingredients.
- Lazy creative search structures and dynamic sounds/languages.
- Protochunk release and world/dimension leak cleanup.
- Thread-spin, priority, reload executor, and synchronization fixes.
- Extensive per-mixin configuration and automatic compatibility overrides.

**Lesson for CS:** bounded caches and explicit invalidation are valuable. Global dynamic resource/model loading is invasive and must not be copied into CS, especially across three rapidly changing versions.

## C2ME

**Primary ownership:** chunk generation, chunk I/O, loading, lighting, scheduling, and scalability.

Observed architecture:

- Fully threaded chunk scheduling.
- Parallel world generation and lighting.
- Chunk I/O/serializer rewrites.
- Priority scheduling, cancellation, and reduced server-thread ping-pong.
- Allocation/math/worldgen caches and optional native/OpenCL acceleration.
- Dedicated threading-bug fix modules and test infrastructure.

**Lesson for CS:** random multithreading of chunks is unsafe. CS should not implement chunk concurrency. Detect C2ME and defer. A future CS-only contribution could be a non-invasive benchmark/display of chunk-task latency, not another scheduler.

## Noisium

**Primary ownership:** narrow world-generation hot paths.

Observed techniques:

- Direct palette writes during noise population when normal block-update abstractions are unnecessary during generation.
- Faster indexed loops for block-state sampling and chunk unlocking.
- Cached generation-shape values.
- Biome population optimization, with C2ME preferred for multithreading.

**Lesson for CS:** these are integrated-server/worldgen changes, not a general client FPS feature. Recommend Noisium/C2ME for singleplayer world generation; do not reproduce in CS.

## FPSFlow

**Primary ownership claimed by project:** entity/block-entity culling, entity LOD, particle limits, background FPS, HUD caching, and adaptive profiles.

Useful ideas:

- Explicit mod-ownership detection.
- Fail-safe near-camera exemptions.
- Bounded visibility queues and camera-movement invalidation.
- Dirty flags for HUD values.
- Resource-reload invalidation.

Important concerns from source review:

- Entity LOD intentionally renders distant entities only on some frames. That changes visual motion and conflicts with the CS requirement.
- Particle caps/distance thinning change visuals and are forbidden for this engine.
- Block-entity distance culling can hide visible content and needs more than a distance check.
- “Async” entity checks in the reviewed manager are queued in concurrent collections but processed from the client tick path; the label does not by itself prove off-thread execution.
- The reviewed scheduler estimates “FPS” from client-tick intervals, which is not a valid frame-rate measurement.
- The source is AGPL-3.0; it cannot be copied into a proprietary closed-source client.

**Lesson for CS:** borrow no code. Keep only the general ideas of capability ownership, dirty flags, conservative near ranges, and bounded queues—then validate them with correct frame instrumentation.

## “Smart Entity Optimizer”

No single authoritative project matching that exact name and scope could be verified. Search results point to unrelated server plugins/mods that throttle AI, freeze distant entities, or change block-entity ticking. Those approaches can alter farms, AI, combat, or gameplay and do not meet this specification. No design should be based on that name until an exact official source URL is provided.

## Closed performance clients

Claims about Lunar/Feather/other closed clients cannot be treated as engineering evidence because their relevant internals and reproducible benchmarks are not public. UI inspiration is not proof of performance technique. CS decisions should rely on inspectable source, supported APIs, and its own benchmarks.

---

# 3. Optimization ownership and overlap matrix

| Area | Preferred owner when installed | CS default behavior |
|---|---|---|
| Chunk renderer, mesh building, render graph | Sodium / compatible renderer | Do not patch |
| Immediate GUI/HUD/text batching | ImmediatelyFast | Do not duplicate |
| Game logic, AI, collisions, ticking | Lithium | Do not duplicate |
| Global memory/model/blockstate dedup | FerriteCore / ModernFix | Do not duplicate |
| Entity/block-entity occlusion | EntityCulling | Disable CS occlusion |
| Block/model/face/item-frame culling | MoreCulling | Do not duplicate |
| Chunk generation/I/O/scheduling | C2ME | Do not duplicate |
| Worldgen hot loops | Noisium | Do not duplicate |
| CS HUD/text/labels/minimap | CS Client | Optimize independently |
| Frame/GC/allocation measurement | CS Client | Implement as foundation |

This ownership registry should be explicit and testable. “Mod present” is not enough; each CS feature should declare which capability it owns, which mods supersede it, and why it was disabled.

---

# 4. Optimizations CS can safely pursue

## Tier 0 — measurement and zero-behavior-change work

### A. Real frame telemetry

Implement a fixed-size primitive ring buffer recording timestamps from the actual render-frame boundary—not the 20 TPS client tick. Derive:

- Average FPS
- Average frame time
- p50, p95, p99, and p99.9 frame time
- 1% and 0.1% low FPS equivalents
- Worst frame and spike count over configurable thresholds

No object allocation should occur per frame after initialization.

### B. Allocation elimination in CS render paths

- Replace per-frame `new ArrayList<>(ENABLED_MODS)` with an immutable snapshot replaced only when module state changes.
- Replace repeated element-list copies with versioned snapshots or mutation queues.
- Replace regex `String.split` in text width/render paths with index-based line scanning.
- Cache formatted text/width per `(value, font, scale, language/resource generation)`.
- Replace per-frame streams/list collection for scoreboard/boss data with tick-updated immutable snapshots.
- Avoid lambdas/streams in measured per-frame hot loops when they allocate.

### C. Bounded caches and invalidation

- Add hard entry/byte limits to generated SVG/shape caches.
- Invalidate text/resource caches on language, resource-pack, font, GUI-scale, or theme changes.
- Track hit rate, miss rate, and eviction count so a cache that costs more than it saves can be removed.

### D. Event-driven CS state

- Recompute module lists only on enable/disable.
- Recompute layout collision data only on editor/layout changes.
- Update scoreboard/boss/status snapshots on client ticks or source changes—not multiple times in one frame.
- Mark HUD components dirty when their input changes; do not skip a complete vanilla HUD render.

## Tier 1 — conservative CS-owned render filtering

- Distance/frustum-check CS-added health labels, TNT timers, custom name additions, and overlay elements before building components or render states.
- Always preserve players, the local player, targeted entities, name-tag-important entities, bosses, and near-camera entities.
- Use squared distances and existing `CameraRenderState`/frustum information.
- Fail visible if state is missing or stale.
- Disable the feature when EntityCulling or an incompatible renderer/mod already owns the path.

This reduces only CS-added work; it does not suppress vanilla entity rendering or ticking.

## Tier 2 — optional visibility cache for CS overlays

Only after Tier 0/1 benchmarks:

- Cache visibility of CS labels—not whole entities.
- Snapshot immutable positions/bounds on the client thread.
- Use a bounded worker queue with strict per-frame/per-tick budgets.
- Invalidate on camera translation/rotation, entity movement, dimension/world changes, and resource reload.
- Never access mutable world/chunk objects off-thread.
- Near-camera and stale results must resolve to visible.
- Add per-type whitelist and a live debug visualization.

## Tier 3 — extraction-aware CS GUI optimization

On 1.21.11/26.x, the GUI system already records render states before submission. Optimize by submitting fewer CS states, not by issuing raw OpenGL calls.

Potential measured work:

- Combine adjacent CS rectangles only when pipeline, texture, scissor, opacity, order, and blend semantics are identical.
- Reuse immutable CS layout descriptors.
- Cache static menu text/components between interaction changes.
- Let ImmediatelyFast own generic batching if present.

---

# 5. Optimizations to avoid

## Forbidden by product requirements

- Any automatic graphics/quality/settings mutation
- Render/simulation distance changes
- Particle thinning/caps
- Entity distance changes
- Cloud/shadow/AO/visual toggles
- Settings restoration on exit

## Unsafe or overlapping

- Sodium renderer/chunk graph/buffer patches
- Global immediate-mode batching while ImmediatelyFast is present
- Vanilla entity AI/tick throttling
- Player render LOD or skipped animation frames
- Distance-only block-entity hiding
- Global block-face/model culling
- Async world access without immutable snapshots
- Chunk generation/I/O/lighting threading
- Forced `System.gc()` or GC-algorithm changes
- Unbounded caches or broad string interning
- Raw OpenGL calls, especially for 26.2
- Hardware-name-based “optimizations” without benchmark evidence

---

# 6. Sodium and renderer compatibility architecture

## Capability registry

At startup, build an immutable capability map using Fabric Loader IDs and supported APIs:

- `terrain_renderer_owner`: Sodium / Embeddium / Rubidium / Canvas / vanilla
- `backend`: OpenGL / Vulkan / unknown
- `immediate_batch_owner`: ImmediatelyFast / vanilla
- `entity_occlusion_owner`: EntityCulling / CS optional / none
- `model_face_culling_owner`: MoreCulling / none
- `logic_owner`: Lithium / vanilla
- `memory_owner`: FerriteCore / ModernFix / vanilla
- `chunk_scheduler_owner`: C2ME / vanilla
- `worldgen_optimizer_owner`: Noisium / C2ME / vanilla

Every CS optimization must declare required and conflicting capabilities.

## Hard rules

- Never read/write Sodium settings.
- Never reflect into Sodium internals for normal operation.
- Never assume OpenGL when 26.2 can be Vulkan.
- No Sodium-specific mixin unless a stable public compatibility API explicitly requires it.
- If compatibility is uncertain, disable only the affected CS optimization and continue.
- Emit one clear diagnostic explaining the ownership decision.

---

# 7. Version architecture strategy

## Minecraft 1.21.11

- Java 21, Yarn/intermediary target in this project.
- GUI uses `DrawContext` plus `GuiRenderState`/render-state objects.
- Rendering has already moved toward extraction/state recording, but names and APIs differ from 26.x.
- World/HUD targets include `InGameHud`, Yarn mappings, and 1.21-specific render-state classes.

## Minecraft 26.1

- Java 25 and Mojang-named/unobfuscated target in this project.
- `GuiGraphicsExtractor`/`Gui` replace many 1.21.11 paths.
- Extraction/submission boundaries are more explicit.
- It is the final OpenGL-only release family according to Fabric's migration guidance.

## Minecraft 26.2

- Java 25, changed `Gui`/`Hud` ownership and additional extraction/render-state APIs.
- OpenGL and experimental Vulkan backends are selectable.
- Raw OpenGL is not a supported cross-backend strategy; use Blaze3D/RenderPipeline/RenderState abstractions.
- Backend-specific behavior, synchronization, pipelines, and shader compilation must be tested separately.

## Common abstraction recommendation

Create common interfaces only for semantic actions:

- frame sample input
- immutable module snapshot
- text/layout cache invalidation
- CS-overlay visibility request/result
- capability registry
- benchmark event sink

Keep game-class access, render-state construction, frustum adapters, and backend detection in each version module. Do not force mismatched Minecraft methods behind abstract mixin interfaces without concrete bridges and safe defaults.

---

# 8. Mobile/low-end strategy

## What matters on ARM/Adreno/Mali

- Mobile SoCs are power and thermal constrained; peak benchmark FPS is not sustained FPS.
- Adreno and Mali are tile-based/binned architectures where bandwidth, overdraw, render-pass transitions, state changes, and small draw submissions matter.
- Allocation/GC pressure is especially damaging on smaller heaps and slower ARM cores.
- Excess worker threads can compete with the render thread, heat the SoC, and cause worse sustained performance.

## Safe mobile priorities

1. Remove CS per-frame allocations.
2. Reduce CS render-state count and text/component construction.
3. Bound every cache and queue.
4. Keep worker count conservative; default to zero workers until an optional visibility experiment is enabled.
5. Avoid framebuffer switches and extra full-screen passes.
6. Use Blaze3D only; no GL calls or assumptions about translation layers.
7. Record backend, CPU architecture, memory budget, frame-time distribution, and thermal state when available—but do not upload it.
8. Use hysteresis: profiles should not oscillate every few frames.

## Adaptive profiles without quality changes

### LOW / Compatibility

- Telemetry
- Immutable module snapshots
- Text/value cache
- Bounded resource caches
- CS-only frustum/distance checks
- No worker thread

### BALANCED

- LOW features
- More aggressive CS snapshot intervals based on measured value-change frequency
- Conservative CS-overlay visibility cache
- One small bounded worker only if the CPU has measured headroom

### HIGH PERFORMANCE

- BALANCED features
- Larger but still bounded caches where hit-rate data justifies them
- More frequent visibility refresh for moving cameras while keeping fail-visible behavior
- Stronger removal of redundant CS render-state preparation

Profiles must never alter Minecraft visuals or settings. Selection should use measured CS CPU time, allocation rate, frame-time variance, backend ownership, and thermal/headroom information—not GPU model names alone.

---

# 9. Benchmark system and methodology

## Required variants

For each target/version and hardware device:

1. Vanilla/Fabric baseline
2. Sodium baseline
3. Sodium + CS Client with Performance Engine off
4. Sodium + CS Client with each Performance Engine profile
5. Optional specialist stack comparison: Sodium + Lithium + FerriteCore + ImmediatelyFast + EntityCulling

The critical comparison is **Sodium vs Sodium + CS Engine** with all user graphics settings byte-identical.

## Test scenarios

- Empty controlled world
- Normal survival base
- Dense forest
- Village
- Mob farm
- Many visible entities
- Many entities hidden behind walls
- Many dropped items
- Redstone-heavy area
- Chunk loading along a fixed path
- High render distance, unchanged across variants
- HUD-heavy server view with scoreboard/boss bars/chat
- Resource reload and world join

Separate singleplayer integrated-server tests from multiplayer client-render tests.

## Test control

- Clone the same world for every run.
- Lock resolution, GUI scale, graphics settings, resource packs, seed, time, weather, camera path, JVM, launcher, and mod versions.
- Hash `options.txt` and renderer config before/after every run; fail the test if changed.
- Warm up JIT, chunks, textures, and shaders before the measured window.
- Record cold-start/world-join separately from steady state.
- Randomize variant order to reduce thermal/order bias.
- Perform repeated runs and report median plus spread; never publish one run as a result.
- On mobile, wait for a consistent starting temperature and record thermal/frequency state throughout.

## Metrics

### Frame metrics

- Frame count and elapsed time
- Average FPS
- Average frame time
- p50/p95/p99/p99.9 frame time
- 1% low and 0.1% low FPS equivalents
- Worst frame time
- Counts of frames beyond chosen budgets (for example 16.67 ms, 33.33 ms, 50 ms)

Frame percentiles should be calculated from frame-time samples. Client-tick intervals are not FPS.

### JVM/CPU/memory

- Java heap used and committed
- Process RSS where available
- Allocation bytes/second
- GC count, total pause, maximum pause
- CPU samples by method
- Thread park/block/monitor time
- Worker queue depth and task latency

Use JFR/JMC or the `jfr` tool for CPU samples, allocations, GC, and lock contention.

### GPU/backend

- Backend name (OpenGL/Vulkan)
- GPU frame timing where available
- GPU utilization, tiler/fragment load, bandwidth, and overdraw using vendor tools
- Minecraft 26.2 Tracy GPU timing via `--tracy` where supported
- Android Perfetto trace for CPU scheduling/frequency/thermal correlation
- Snapdragon Profiler for Adreno and Arm Performance Studio/Streamline for Mali where available

### CS-specific counters

- CS render states submitted per frame
- CS text components/layouts created
- Cache hit/miss/eviction counts
- CS overlay candidates, frustum rejects, visible results, stale/fail-visible results
- Minimap sampling time
- Per-module render/tick time in debug builds

## Acceptance gates

An optimization is accepted only if:

- It improves the targeted metric outside run-to-run noise.
- It does not worsen p99/p99.9 frame time materially.
- Visual output and gameplay regression tests pass.
- Settings hashes remain unchanged.
- Sodium-on and Sodium-off tests pass.
- OpenGL and Vulkan paths pass for 26.2.
- Mobile sustained performance is not worse after thermal stabilization.

---

# 10. Realistic expected impact

No percentage is claimed before the benchmark system produces data.

Expected behavior by bottleneck:

- **Sodium, GPU-bound terrain scene:** CS Engine may show little or no improvement because CS does not own the bottleneck.
- **HUD/text-heavy server:** CS text/layout caching and fewer render-state submissions may produce measurable CPU/frametime improvement.
- **Many CS health/TNT/name overlays:** conservative CS-only culling can reduce component creation and submission work.
- **Mobile CPU/allocation-bound device:** allocation reduction may improve p99 frame time and reduce GC-related stutter more than average FPS.
- **Chunk-generation bottleneck:** no CS gain should be promised; C2ME/Noisium/Lithium own that area.
- **Global memory-heavy modpack:** CS cache discipline helps only CS memory; FerriteCore/ModernFix remain the appropriate owners for global savings.

The success target is lower CS overhead and better frame stability, not a universal FPS multiplier.

---

# 11. Phased implementation plan

## Phase 0 — enforce the contract

- Remove `ADJUST_VANILLA_GRAPHICS`.
- Remove every `applyPerformancePreset` implementation and call.
- Remove settings capture/restore and shutdown restoration.
- Add tests that hash Minecraft/Sodium config before and after profile changes.
- Add a source/bytecode denylist test for forbidden option setters.

**Exit gate:** profile switching produces zero settings writes.

## Phase 1 — benchmark foundation

- Primitive frame-time ring buffer.
- CSV/JSON local export.
- JFR launch presets and documentation.
- CS-specific counters and scenario labels.
- No optimization behavior yet.

**Exit gate:** metrics validated against an external frame tool on desktop and Perfetto/available tooling on Android.

## Phase 2 — CS-owned allocation cleanup

- Immutable enabled-module snapshots.
- No per-frame element-list copies where mutation is absent.
- Index-based multiline text scan.
- Text/component/width caches with complete invalidation.
- Tick-updated scoreboard/boss/status snapshots.
- Bounded SVG/shape cache.

**Exit gate:** lower measured CS allocation rate and no visual regressions.

## Phase 3 — conservative CS render filtering

- Frustum/distance filters for CS overlays only.
- Priority exemptions for players/targets/near entities.
- Capability ownership registry.
- Auto-disable when overlapping specialist mods are present.

**Exit gate:** fewer CS submissions with identical screenshots/behavior.

## Phase 4 — optional CS-overlay occlusion experiment

- Immutable main-thread snapshots.
- Bounded worker and queue.
- Fail-visible caching with aggressive invalidation.
- Debug visualization and whitelist.
- Disabled by default until multi-device benchmarks pass.

**Exit gate:** stable p99 improvement in hidden-entity scenarios without pop-in/regression.

## Phase 5 — adaptive internal profiles

- Hysteresis-based selection from measured CS CPU time, allocation rate, frame-time variance, backend ownership, and thermal headroom.
- Profiles adjust only CS cache budgets, refresh intervals, and optional CS-overlay visibility work.
- Manual override always available.

**Exit gate:** sustained mobile and desktop tests outperform fixed profile without oscillation.

## Phase 6 — release matrix

- Full scenario matrix for 1.21.11, 26.1, and 26.2.
- Sodium/ImmediatelyFast/EntityCulling/MoreCulling/C2ME compatibility matrix.
- 26.2 OpenGL and Vulkan.
- ARM/Adreno and ARM/Mali sustained thermal tests.

---

# 12. Direct answers to requested research questions

## A. Existing performance mods kya karte hain?

They specialize: Sodium owns rendering/chunks; Lithium game logic; FerriteCore memory; ImmediatelyFast immediate/GUI/text submission; EntityCulling visibility; MoreCulling faces/models; ModernFix startup/resources/memory; C2ME chunk concurrency; Noisium worldgen hot loops.

## B. Genuinely useful optimizations?

Measured allocation removal, compact immutable data, event-driven invalidation, bounded caches, fewer render-state submissions, conservative visibility filtering, correct batching ownership, and specialist-mod compatibility gates.

## C. CS mein safely kya implement ho sakta hai?

Frame telemetry, CS allocation cleanup, immutable module snapshots, text/layout caches, bounded SVG caches, tick-updated data snapshots, and conservative culling of CS-added overlays.

## D. Sodium overlap?

Chunk renderer, mesh building, graph/frustum culling, vertex/buffer management, chunk task scheduling, material passes, terrain batching, and Sodium settings all overlap and must be left alone.

## E. Mobile par highest-priority benefit?

Lower CS allocations/GC, fewer CS text/render states, bounded memory, less overdraw/state churn through supported extraction APIs, conservative worker use, and thermal-aware measurement.

## F. No-visual-quality-loss optimizations?

Removing redundant work, caching identical results, compact snapshots, event-driven updates, fail-visible culling of genuinely hidden CS overlays, fewer duplicate state submissions, and memory/allocation optimization.

## G. Dangerous/unstable?

Random multithreading, off-thread world reads, entity AI/tick throttling, player LOD, particle dropping, distance-only block-entity culling, global model/face culling, raw GL, renderer internals, and unbounded caches.

## H. Architectural differences?

1.21.11 uses Java 21/Yarn and `DrawContext`/`GuiRenderState`; 26.1 uses Java 25/Mojang names and `GuiGraphicsExtractor`; 26.2 changes GUI/HUD ownership further and supports OpenGL plus experimental Vulkan. Version-specific adapters are mandatory.

## I. Realistic improvement?

No numeric estimate is defensible yet. Benefits will be workload-dependent and smaller with Sodium where terrain rendering already dominates. The engine should first prove lower CS allocation, CS CPU time, and p99/p99.9 frame times.

---

# 13. Primary references

- Sodium source: https://github.com/CaffeineMC/sodium
- Sodium project description: https://github.com/CaffeineMC/sodium/blob/dev/README.md
- Lithium source: https://github.com/CaffeineMC/lithium
- Lithium releases: https://github.com/CaffeineMC/lithium/releases
- FerriteCore source and technical summary: https://github.com/malte0811/FerriteCore
- FerriteCore summary: https://github.com/malte0811/FerriteCore/blob/1.19/summary.md
- ImmediatelyFast source: https://github.com/RaphiMC/ImmediatelyFast
- EntityCulling source: https://github.com/tr7zw/EntityCulling
- MoreCulling source: https://github.com/FxMorin/MoreCulling
- ModernFix source/wiki: https://github.com/embeddedt/ModernFix
- ModernFix changelog: https://github.com/embeddedt/ModernFix/wiki/Changelog
- C2ME source: https://github.com/RelativityMC/C2ME-fabric
- Noisium source (archived): https://github.com/Steveplays28/noisium
- FPSFlow source: https://github.com/McAffe13/FPSFlow
- Fabric 26.2 rendering concepts: https://docs.fabricmc.net/develop/rendering/basic-concepts
- Fabric 26.1 migration notes: https://fabricmc.net/2026/03/14/261.html
- Fabric 26.2 migration notes: https://fabricmc.net/2026/06/15/262.html
- Minecraft Java 26.2 notes: https://www.minecraft.net/en-us/article/minecraft-java-edition-26-2
- Android game performance/slow sessions: https://developer.android.com/games/optimize/vitals/slow-session
- Android Thermal API: https://developer.android.com/games/optimize/adpf/thermal
- Android FPS throttling/Perfetto verification: https://developer.android.com/games/optimize/adpf/gamemode/fps-throttling
- Qualcomm Adreno best practices: https://docs.qualcomm.com/nav/home/mobile_best_practices.html?product=1601111740035277
- Arm Mali GPU best practices: https://documentation-service.arm.com/static/67a62b17091bfc3e0a947695
- Oracle JDK 21 diagnostic/JFR tools: https://docs.oracle.com/en/java/javase/21/troubleshoot/diagnostic-tools.html

---

## Final recommendation

Do not begin with chunk threading, a renderer rewrite, or aggressive entity culling. Begin by deleting all graphics-setting mutation paths and building the benchmark foundation. Then optimize CS's own allocations and render-state generation. Only after that data exists should CS add conservative, optional visibility work for CS overlays.

That path is compatible with Sodium, respects user settings, is maintainable across 1.21.11/26.1/26.2, and gives the project a credible way to prove performance instead of advertising an unmeasured “FPS booster.”
