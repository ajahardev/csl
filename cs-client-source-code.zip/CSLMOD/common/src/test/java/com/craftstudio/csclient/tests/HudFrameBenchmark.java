package com.craftstudio.csclient.tests;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.ui.RenderScope;

/**
 * HUD render-path micro-benchmark. Enables a typical widget set, renders N
 * static frames through the real module render path and reports average
 * frame cost + text draw calls. With HUD frame-skip active, static frames
 * must cost almost nothing (a handful of comparisons, no GPU submission).
 *
 * Usage: {@code <runDir>}
 */
public final class HudFrameBenchmark {
    private static final String[] WIDGETS = {
            "FPS Display", "Ping Display", "TPS Display", "Coordinates",
            "Server Address", "Speedometer", "Direction Display", "Memory Usage"
    };

    private HudFrameBenchmark() { }

    public static void main(String[] args) throws Exception {
        File runDirectory = Files.createTempDirectory("csclient-hud-bench").toFile();
        ModuleSmokeTest.installFakeProviders(runDirectory);
        Config.init();
        ModManager.init();

        List<Mod> widgets = new ArrayList<>();
        for (String name : WIDGETS) {
            Mod mod = ModManager.MODS.stream().filter(m -> m.getName().equals(name)).findFirst().orElseThrow();
            mod.setEnabled(true);
            if (mod instanceof HudMod) widgets.add(mod);
        }

        // Warm-up (class init, cache fills)
        for (int i = 0; i < 30; i++) renderFrame(widgets);

        int frames = 600;
        long start = System.nanoTime();
        int textDraws = 0;
        for (int i = 0; i < frames; i++) textDraws += renderFrame(widgets);
        long elapsedNanos = System.nanoTime() - start;

        for (Mod mod : widgets) mod.setEnabled(false);

        double nsPerFrame = (double) elapsedNanos / frames;
        double usPerFrame = nsPerFrame / 1_000.0;
        double textDrawsPerFrame = (double) textDraws / frames;
        System.out.printf("HUD benchmark: %d widgets, %d frames%n", widgets.size(), frames);
        System.out.printf("  avg frame cost      : %.2f us/frame (%.1f ns/widget)%n",
                usPerFrame, nsPerFrame / widgets.size());
        System.out.printf("  text draw passes    : %.3f per frame (static content)%n", textDrawsPerFrame);
        System.out.printf("  equivalent at 60fps : %.2f ms/s of render thread spent on CS HUD%n",
                usPerFrame * 60 / 1000.0);
        if (usPerFrame > 200.0) {
            throw new AssertionError("HUD frame cost regressed: " + usPerFrame + " us/frame");
        }
        if (textDrawsPerFrame > 4.0) {
            throw new AssertionError("Frame skip ineffective in benchmark: "
                    + textDrawsPerFrame + " text draws/frame");
        }
        System.out.println("HUD micro-benchmark OK");
    }

    private static int renderFrame(List<Mod> widgets) {
        Counting scope = new Counting();
        for (Mod mod : widgets) {
            ((HudMod) mod).renderHud(scope);
        }
        return scope.textDraws;
    }

    private static final class Counting implements RenderScope {
        int textDraws;

        @Override public com.craftstudio.csclient.common.ref.render.MatrixStackRef getMatrixStack() {
            throw new IllegalStateException("not needed");
        }
        @Override public void setOpacity(float alpha) { }
        @Override public int getColor(int color) { return color; }
        @Override public void drawRectangle(int x, int y, int width, int height, int color) { }
        @Override public void drawRoundedRectangle(int x, int y, int width, int height, int radius, int color) { }
        @Override public void drawBorder(int x, int y, int width, int height, int color) { }
        @Override public void drawRoundedBorder(int x, int y, int width, int height, int radius, int color) { }
        @Override public void fill(int x1, int y1, int x2, int y2, int color) { }
        @Override public void drawText(String text, int x, int y, int font, int color) { textDraws++; }
        @Override public void drawText(float scale, String text, int x, int y, int font, int color) { textDraws++; }
        @Override public void drawTexture(com.craftstudio.csclient.common.ref.asset.IdentifierRef sprite,
                int x, int y, float u, float v, int width, int height) { }
        @Override public void drawTexture(com.craftstudio.csclient.common.ref.asset.IdentifierRef sprite,
                int x, int y, float u, float v, int width, int height, int color) { }
        @Override public void drawTexture(com.craftstudio.csclient.common.ref.asset.IdentifierRef sprite,
                int x, int y, float u, float v, int width, int height,
                int regionWidth, int regionHeight, int textureWidth, int textureHeight) { }
        @Override public void drawTexture(com.craftstudio.csclient.common.ref.asset.IdentifierRef sprite,
                int x, int y, float u, float v, int width, int height,
                int regionWidth, int regionHeight, int textureWidth, int textureHeight, int color) { }
        @Override public void drawSpriteStretched(com.craftstudio.csclient.common.ref.asset.SpriteRef sprite,
                int x, int y, int width, int height) { }
        @Override public void drawSpriteStretched(com.craftstudio.csclient.common.ref.asset.SpriteRef sprite,
                int x, int y, int width, int height, int color) { }
        @Override public void drawItem(com.craftstudio.csclient.common.ref.game.ItemStackRef item, int x, int y) { }
        @Override public void enableScissor(int x1, int y1, int x2, int y2) { }
        @Override public void disableScissor() { }
        @Override public boolean scissorContains(int x, int y) { return true; }
        @Override public int getScaledWindowWidth() { return 960; }
        @Override public int getScaledWindowHeight() { return 540; }
        @Override public void draw() { }
    }
}
