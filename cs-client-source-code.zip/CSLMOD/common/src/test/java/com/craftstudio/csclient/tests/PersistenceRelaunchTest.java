package com.craftstudio.csclient.tests;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.craftstudio.csclient.account.LauncherIntegration;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.ui.components.inputs.IntInput;
import com.craftstudio.csclient.ui.components.inputs.StringInput;

/**
 * Settings persistence relaunch test. Each launch is a fresh JVM sharing one
 * run directory, exactly like closing and relaunching the game:
 *
 * <ol>
 *   <li>Set a custom server IP and a custom FPS value.</li>
 *   <li>Close the game (values must already be on disk).</li>
 *   <li>Relaunch it (fresh JVM) and confirm both values are unchanged.</li>
 *   <li>Repeat for several cycles.</li>
 * </ol>
 *
 * Arguments: {@code <runDir> <write|verify> <cycle>}
 */
public final class PersistenceRelaunchTest {
    private static final String CUSTOM_IP = "play.testmc.net:25565";
    private static final int CUSTOM_FPS = 144;
    private static final String LAUNCHER_IP = "launcher.testmc.net:25565";
    private static final int LAUNCHER_FPS = 120;

    private PersistenceRelaunchTest() { }

    public static void main(String[] args) throws Exception {
        File runDirectory = new File(args[0]);
        String phase = args[1];
        int cycle = Integer.parseInt(args[2]);
        Files.createDirectories(runDirectory.toPath());
        ModuleSmokeTest.installFakeProviders(runDirectory);

        Config.init();
        ModManager.init();
        Property fps = fpsGoal();

        if ("write".equals(phase)) {
            if (cycle > 1) {
                // Repeated test: the values from the previous cycle must have
                // survived the relaunch.
                if (!CUSTOM_IP.equals(Config.savedServerIp()))
                    throw new AssertionError("cycle " + cycle + ": server IP lost between cycles: '"
                            + Config.savedServerIp() + "'");
                if (((IntProperty) fps).value != CUSTOM_FPS)
                    throw new AssertionError("cycle " + cycle + ": FPS setting lost between cycles: "
                            + ((IntProperty) fps).value);
                // Simulate a clean exit of this run.
                ConfigManager.save();
                System.out.println("Persistence cycle " + cycle + " write phase OK (previous values survived)");
                return;
            }

            // Fresh install: defaults must be the only values in play.
            if (!Config.savedServerIp().isEmpty())
                throw new AssertionError("fresh install: server IP default must be blank");
            if (((IntProperty) fps).value != 120)
                throw new AssertionError("fresh install: FPS default must be 120, got "
                        + ((IntProperty) fps).value);

            // Simulate the launcher having saved user preferences in the bridge
            // file during an earlier session, then the client's init publish.
            writeBridge(runDirectory, LAUNCHER_IP, LAUNCHER_FPS);
            LauncherIntegration.publishCapabilities(runDirectory);
            String bridge = Files.readString(LauncherIntegration.bridgeFile(runDirectory));
            if (!bridge.contains("\"serverIp\" : \"" + LAUNCHER_IP + "\""))
                throw new AssertionError("init publish wiped launcher-saved server IP: " + bridge);
            if (!bridge.contains("\"preferredFrameRate\" : " + LAUNCHER_FPS))
                throw new AssertionError("init publish reset launcher-saved frame rate: " + bridge);

            // User saves a custom server IP from the settings UI. It must be
            // written to persistent storage immediately (no clean exit needed).
            StringInput ipInput = new StringInput(Config.serverIp);
            for (char c : CUSTOM_IP.toCharArray()) ipInput.charTyped(c);
            String onDisk = Files.readString(runDirectory.toPath().resolve("cs-client.json"));
            if (!onDisk.contains("\"Server IP\" : \"" + CUSTOM_IP + "\""))
                throw new AssertionError("typed server IP was not written to persistent storage");

            // User changes the FPS goal the way the UI allows it: clear the
            // current value, then type the new one. Must persist immediately.
            IntInput fpsInput = new IntInput((IntProperty) fps);
            int digits = String.valueOf(((IntProperty) fps).value).length();
            fpsInput.cursorPosition = digits;
            for (int i = 0; i < digits; i++) {
                fpsInput.keyPressed(GLFWProvider.GLFW_KEY_BACKSPACE, 0, 0);
            }
            for (char c : Integer.toString(CUSTOM_FPS).toCharArray()) fpsInput.charTyped(c);
            if (((IntProperty) fps).value != CUSTOM_FPS)
                throw new AssertionError("typed FPS value not applied in memory: " + ((IntProperty) fps).value);
            onDisk = Files.readString(runDirectory.toPath().resolve("cs-client.json"));
            if (!onDisk.contains("\"Adaptive Smoothness Goal (30-360)\" : " + CUSTOM_FPS))
                throw new AssertionError("typed FPS value was not written to persistent storage");

            // The next init publish must carry the client-saved IP while still
            // preserving the saved frame-rate preference.
            LauncherIntegration.publishCapabilities(runDirectory);
            bridge = Files.readString(LauncherIntegration.bridgeFile(runDirectory));
            if (!bridge.contains("\"serverIp\" : \"" + CUSTOM_IP + "\""))
                throw new AssertionError("client-saved server IP not published: " + bridge);
            if (!bridge.contains("\"preferredFrameRate\" : " + LAUNCHER_FPS))
                throw new AssertionError("publish reset saved frame-rate preference: " + bridge);

            // Clean exit.
            ConfigManager.save();
            System.out.println("Persistence cycle " + cycle + " write phase OK (IP + FPS saved, bridge merge-safe)");
        } else {
            // Fresh JVM == relaunch. Saved values must be restored.
            if (!CUSTOM_IP.equals(Config.savedServerIp()))
                throw new AssertionError("server IP reset after relaunch: got '"
                        + Config.savedServerIp() + "' expected '" + CUSTOM_IP + "'");
            if (((IntProperty) fps).value != CUSTOM_FPS)
                throw new AssertionError("FPS setting reset after relaunch: got "
                        + ((IntProperty) fps).value + " expected " + CUSTOM_FPS);

            // The init publish must keep every saved value intact.
            LauncherIntegration.publishCapabilities(runDirectory);
            String bridge = Files.readString(LauncherIntegration.bridgeFile(runDirectory));
            if (!bridge.contains("\"serverIp\" : \"" + CUSTOM_IP + "\""))
                throw new AssertionError("relaunch init publish lost saved server IP: " + bridge);
            if (!bridge.contains("\"preferredFrameRate\" : " + LAUNCHER_FPS))
                throw new AssertionError("relaunch init publish lost saved frame-rate preference: " + bridge);

            System.out.println("Persistence cycle " + cycle + " verify phase OK (IP + FPS restored, bridge intact)");
        }
    }

    private static Property fpsGoal() {
        for (Mod mod : ModManager.MODS) {
            if (mod.getName().equals("Performance Engine")) {
                Property property = mod.getConfig().getProperties().get("Adaptive Smoothness Goal (30-360)");
                if (property != null) return property;
            }
        }
        throw new AssertionError("Performance Engine FPS goal property is missing");
    }

    private static void writeBridge(File runDirectory, String ip, int fps) throws Exception {
        Path target = LauncherIntegration.bridgeFile(runDirectory);
        Files.createDirectories(target.getParent());
        Files.writeString(target, "{\n"
                + "  \"protocol\": 1,\n"
                + "  \"productVersion\": \"V1\",\n"
                + "  \"preferredDisplayMode\": \"MAX_SUPPORTED_REFRESH_RATE\",\n"
                + "  \"preferredFrameRate\": " + fps + ",\n"
                + "  \"serverIp\": \"" + ip + "\",\n"
                + "  \"nativePngPicker\": true,\n"
                + "  \"appearanceIndex\": \"../profiles/appearance-index.json\",\n"
                + "  \"appearanceSync\": \"BIDIRECTIONAL_ATOMIC\"\n"
                + "}\n");
    }
}
