package com.craftstudio.csclient.tests;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.craftstudio.csclient.common.feature.EntityFeature;
import com.craftstudio.csclient.branding.ClientBrandingState;
import com.craftstudio.csclient.account.LauncherIntegration;
import com.craftstudio.csclient.common.feature.NetworkFeature;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.feature.RenderFeature;
import com.craftstudio.csclient.common.feature.WorldFeature;
import com.craftstudio.csclient.common.provider.CSClientProvider;
import com.craftstudio.csclient.common.provider.FeatureProvider;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.provider.RefConstructorProvider;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;
import com.craftstudio.csclient.common.ref.game.EffectRef;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;
import com.craftstudio.csclient.common.ref.render.MatrixStackRef;
import com.craftstudio.csclient.common.ref.render.TextRef;
import com.craftstudio.csclient.common.ref.render.WindowRef;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.mod.HudDirtyTracker;
import com.craftstudio.csclient.mod.ModRuntimeGuard;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.mod.mods.AutoGGTracker;
import com.craftstudio.csclient.mod.mods.PerformanceBoostMod;
import com.craftstudio.csclient.performance.EntityOcclusionCulling;
import com.craftstudio.csclient.mod.mods.BossBarMod;
import com.craftstudio.csclient.mod.mods.ClearFluidsMod;
import com.craftstudio.csclient.mod.mods.ClientBrandingMod;
import com.craftstudio.csclient.mod.mods.ChatEnhancementsMod;
import com.craftstudio.csclient.mod.mods.ShieldStatusesMod;
import com.craftstudio.csclient.mod.mods.HealthDisplayMod;
import com.craftstudio.csclient.mod.mods.NoFogMod;
import com.craftstudio.csclient.mod.mods.ScoreboardMod;
import com.craftstudio.csclient.mod.mods.ShulkerPreviewMod;
import com.craftstudio.csclient.mod.mods.ZoomMod;
import com.craftstudio.csclient.performance.PerformanceEngine;
import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.server.ServerListPinning;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.util.IntStrings;
import com.craftstudio.csclient.screenshot.ScreenshotRepository;
import com.craftstudio.csclient.screenshot.ScreenshotThumbnailCache;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.screens.HudEditor;
import com.craftstudio.csclient.ui.RenderScope;

/** Framework-free smoke test that exercises every registered common module. */
public final class ModuleSmokeTest {
    private ModuleSmokeTest() { }

    /**
     * Installs the deterministic fake game providers. Shared with the
     * persistence relaunch test so both see the exact same client surface.
     */
    public static void installFakeProviders(File runDirectory) {
        FakeItem item = new FakeItem(false, 64, 12, 3, "Diamond Chestplate", true);
        FakeEffect effect = new FakeEffect();

        MinecraftClientRef client = (MinecraftClientRef) Proxy.newProxyInstance(
                ModuleSmokeTest.class.getClassLoader(), new Class<?>[] { MinecraftClientRef.class },
                (proxy, method, methodArgs) -> switch (method.getName()) {
                    case "getRunDirectory" -> runDirectory;
                    case "getResource" -> (InputStream) null;
                    case "getWindow" -> new FakeWindow();
                    case "getUuid" -> UUID.fromString("123e4567-e89b-42d3-a456-426614174000");
                    case "getUsername" -> "SmokePlayer";
                    case "executeOnThread" -> {
                        ((Runnable) methodArgs[0]).run();
                        yield null;
                    }
                    case "getPlayerListEntry" -> "Opponent";
                    case "getPlayerListEntryUUID" -> UUID.fromString("123e4567-e89b-42d3-a456-426614174001");
                    case "isModLoaded" -> methodArgs != null && methodArgs.length > 0
                            && "sodium".equals(String.valueOf(methodArgs[0]));
                    default -> defaultValue(method.getReturnType());
                });

        Providers.refConstructor = new RefConstructorProvider() {
            @Override public IdentifierRef identifier(String namespace, String path) {
                return new FakeIdentifier(namespace + ":" + path);
            }
            @Override public IdentifierRef identifier(String fullPath) { return new FakeIdentifier(fullPath); }
            @Override public TextRef text(String text) { return new FakeText(text); }
        };
        Providers.csClient = new CSClientProvider() {
            @Override public MinecraftClientRef getClient() { return client; }
            @Override public void logInfo(String message) { }
            @Override public void logError(String message) { System.err.println(message); }
            @Override public void logError(String message, Throwable throwable) {
                System.err.println(message);
                throwable.printStackTrace();
            }
            @Override public void registerBufferedImageTexture(IdentifierRef identifier, BufferedImage image) { }
        };
        Providers.GLFW = new GLFWProvider() {
            @Override public boolean isKeyPressed(int key) { return false; }
            @Override public String getKeyName(int key) { return Integer.toString(key); }
        };

        PlayerFeature player = proxy(PlayerFeature.class, (method, methodArgs) -> switch (method.getName()) {
            case "hasPlayer", "isForwardPressed", "isAttackPressed", "isSprinting", "isOnGround" -> true;
            case "getX" -> 120;
            case "getY" -> 64;
            case "getZ" -> -35;
            case "getYaw" -> 92.5f;
            case "getVelocity" -> new PlayerFeature.Velocity(0.2, 0.0, 0.15);
            case "getHealth" -> 17.5f;
            case "getMaxHealth" -> 20.0f;
            case "getAbsorptionHealth" -> 4.0f;
            case "getFoodLevel" -> 18;
            case "getSaturationLevel" -> 7.5f;
            case "getSelectedItemTotalCount" -> 32;
            case "getTotemCount" -> 2;
            case "getAttackCooldown" -> 0.72f;
            case "getServerAddress" -> "example.invalid";
            case "getScoreboardTitle" -> "SMOKE BOARD";
            case "getScoreboardLines" -> List.of(new PlayerFeature.ScoreboardLine("Line", 1));
            case "getBossBars" -> List.of(new PlayerFeature.BossInfo("Boss", 0.65f));
            case "getActiveEffects", "getDummyEffects" -> List.of(effect);
            case "getInventoryItems" -> repeated(item, 36);
            case "getMainHand", "getOffHand", "getHelmet", "getChestplate", "getLeggings", "getBoots",
                    "getDummyMainHand", "getDummyHelmet", "getDummyChestplate", "getDummyLeggings",
                    "getDummyBoots", "getTotemStack", "getDummyOffHand" -> item;
            default -> defaultValue(method.getReturnType());
        });
        WorldFeature world = proxy(WorldFeature.class, (method, methodArgs) -> switch (method.getName()) {
            case "hasWorld" -> true;
            case "getWorldAge" -> 72_000L;
            case "getTargetBlockInfo" -> new WorldFeature.BlockInfo("Stone", "minecraft:stone", "Solid");
            case "getTargetBlockIcon" -> item;
            case "getMinimapColors" -> new int[Math.max(1, (int) methodArgs[0] * (int) methodArgs[0])];
            case "getBlockBreakProgress" -> 0.6f;
            // Deterministic line-of-sight for the occlusion culling test:
            // everything at target x >= 5 is "behind a wall".
            case "isLineOfSightClear" -> (Double) methodArgs[3] < 5.0;
            default -> defaultValue(method.getReturnType());
        });
        EntityFeature entity = proxy(EntityFeature.class, (method, methodArgs) -> switch (method.getName()) {
            case "isTargetingLivingEntity" -> true;
            case "getTargetDistance" -> 2.75d;
            default -> defaultValue(method.getReturnType());
        });
        NetworkFeature network = proxy(NetworkFeature.class, (method, methodArgs) -> switch (method.getName()) {
            case "hasNetwork" -> true;
            case "getPing" -> 42;
            default -> defaultValue(method.getReturnType());
        });
        RenderFeature render = proxy(RenderFeature.class, (method, methodArgs) -> switch (method.getName()) {
            case "getScaledWindowWidth" -> 960;
            case "getScaledWindowHeight" -> 540;
            case "getFps" -> 144;
            case "isFirstPerson" -> true;
            default -> defaultValue(method.getReturnType());
        });
        Providers.feature = new FeatureProvider() {
            @Override public PlayerFeature player() { return player; }
            @Override public WorldFeature world() { return world; }
            @Override public EntityFeature entity() { return entity; }
            @Override public RenderFeature render() { return render; }
            @Override public NetworkFeature network() { return network; }
        };
    }

    public static void main(String[] args) throws Exception {
        File runDirectory = Files.createTempDirectory("csclient-module-smoke").toFile();
        installFakeProviders(runDirectory);

        Config.init();
        LauncherIntegration.publishCapabilities(runDirectory);
        Path launcherRequest = runDirectory.toPath().resolve("config/cs-client/launcher-bridge/client-request.json");
        if (!Files.isRegularFile(launcherRequest)
                || !Files.readString(launcherRequest).contains("MAX_SUPPORTED_REFRESH_RATE")) {
            throw new AssertionError("Launcher high-refresh/appearance bridge request was not published");
        }
        // Fresh install: no saved server IP, and the bridge publish must be
        // merge-safe — saved user values survive an init-time republish.
        if (!Config.savedServerIp().isEmpty()) {
            throw new AssertionError("Fresh install must not carry a saved server IP");
        }
        {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            com.fasterxml.jackson.databind.node.ObjectNode bridgeNode =
                    (com.fasterxml.jackson.databind.node.ObjectNode) mapper.readTree(Files.readString(launcherRequest));
            bridgeNode.put("serverIp", "smoke.testmc.net:25565");
            bridgeNode.put("preferredFrameRate", 90);
            Files.writeString(launcherRequest, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(bridgeNode));
            LauncherIntegration.publishCapabilities(runDirectory);
            String republished = Files.readString(launcherRequest);
            if (!republished.contains("\"serverIp\" : \"smoke.testmc.net:25565\"")
                    || !republished.contains("\"preferredFrameRate\" : 90")) {
                throw new AssertionError("Launcher bridge republish wiped saved user values: " + republished);
            }
        }
        ModManager.init();
        if (ModManager.MODS.size() != 57) {
            throw new AssertionError("Expected 57 modules, got " + ModManager.MODS.size());
        }

        Mod chat = ModManager.MODS.stream().filter(mod -> mod.getName().equals("Chat Improvements"))
                .findFirst().orElseThrow();
        chat.setEnabled(true);
        ChatEnhancementsMod.IncomingDecision firstChat = ChatEnhancementsMod.processIncoming("hello smoke");
        ChatEnhancementsMod.IncomingDecision duplicateChat = ChatEnhancementsMod.processIncoming("hello smoke");
        ChatEnhancementsMod.IncomingDecision mentionChat = ChatEnhancementsMod.processIncoming("Hi SmokePlayer!");
        if (firstChat.suppress() || !duplicateChat.suppress() || !mentionChat.mention()) {
            throw new AssertionError("Chat timestamp/duplicate/mention state failed");
        }
        ChatEnhancementsMod.toggleChatVisibility();
        if (!ChatEnhancementsMod.shouldHideChat()) throw new AssertionError("Chat hide toggle failed");
        ChatEnhancementsMod.toggleChatVisibility();
        chat.setEnabled(false);

        int red = ShieldStatusesMod.colorForRemaining(1.0f, false);
        int orange = ShieldStatusesMod.colorForRemaining(0.1f, false);
        int green = ShieldStatusesMod.colorForRemaining(0.0f, false);
        if (((red >>> 16) & 255) <= ((red >>> 8) & 255)
                || ((orange >>> 16) & 255) <= ((orange >>> 8) & 255)
                || ((green >>> 8) & 255) <= ((green >>> 16) & 255)) {
            throw new AssertionError("Shield Status red/orange/green mapping failed");
        }

        Path screenshots = runDirectory.toPath().resolve("screenshots");
        Files.createDirectories(screenshots);
        Path screenshot = screenshots.resolve("smoke.png");
        javax.imageio.ImageIO.write(new BufferedImage(32, 18, BufferedImage.TYPE_INT_ARGB), "png", screenshot.toFile());
        ScreenshotThumbnailCache.Thumbnail thumbnail = null;
        long thumbnailDeadline = System.currentTimeMillis() + 3_000L;
        while (thumbnail == null && System.currentTimeMillis() < thumbnailDeadline) {
            thumbnail = ScreenshotThumbnailCache.request(screenshot, 160, 90);
            if (thumbnail == null) Thread.sleep(10L);
        }
        if (ScreenshotRepository.list().size() != 1
                || !ScreenshotRepository.isSafePng(screenshot)
                || ScreenshotRepository.isSafePng(runDirectory.toPath().resolve("outside.png"))
                || thumbnail == null || thumbnail.failed() || thumbnail.texture() == null
                || !ScreenshotRepository.delete(screenshot)
                || !ScreenshotRepository.list().isEmpty()) {
            throw new AssertionError("Profile screenshot sandbox/thumbnail/list/delete check failed");
        }
        BufferedImage plantIcon = javax.imageio.ImageIO.read(
                new ByteArrayInputStream(FeaturedServers.plantMcIconBytes()));
        BufferedImage plantBanner;
        BufferedImage indiaFlag;
        try (InputStream banner = ModuleSmokeTest.class.getClassLoader().getResourceAsStream(
                    "assets/csclient/textures/gui/servers/plantmc_banner.png");
             InputStream flag = ModuleSmokeTest.class.getClassLoader().getResourceAsStream(
                    "assets/csclient/textures/gui/servers/india_flag.png")) {
            plantBanner = banner == null ? null : javax.imageio.ImageIO.read(banner);
            indiaFlag = flag == null ? null : javax.imageio.ImageIO.read(flag);
        }
        if (!FeaturedServers.isPlantMcAddress("play.plantmc.fun:25627")
                || !FeaturedServers.isPlantMcAddress("play.plantmc.fun")
                || !FeaturedServers.isCanonicalPlantMcAddress("play.plantmc.fun:25627")
                || FeaturedServers.isCanonicalPlantMcAddress("play.plantmc.fun")
                || FeaturedServers.isPlantMcAddress("play.example.net:25627")
                || FeaturedServers.isPlantMcAddress("play.hypixel.net")
                || FeaturedServers.isPlantMcAddress("play.othernetwork.fun:25565")
                || FeaturedServers.isPlantMcAddress("play.plantmc.fun.example.net:25627")
                || FeaturedServers.slots().isEmpty()
                || FeaturedServers.slots().get(0) != FeaturedServers.PLANTMC
                || plantIcon == null || plantIcon.getWidth() != 64 || plantIcon.getHeight() != 64
                || plantBanner == null || plantBanner.getWidth() != 1009 || plantBanner.getHeight() != 202
                || indiaFlag == null || indiaFlag.getWidth() != 54 || indiaFlag.getHeight() != 36) {
            throw new AssertionError("Pinned PlantMC icon/banner/India-flag validation failed");
        }
        // Server-list pinning: user entries must survive normalization; an
        // unreadable servers.dat must be preserved for recovery.
        runServerListPinningSmoke();
        // Performance: HUD frame-skip, int-string table and width cache.
        runHudPerformanceSmoke();
        // Entity occlusion culling: hidden entities skip, visible/own/players-safe.
        runOcclusionCullingSmoke();
        try {
            ModManager.ENABLED_MODS.add(ModManager.MODS.get(0));
            throw new AssertionError("Enabled-module render snapshot is mutable");
        } catch (UnsupportedOperationException expected) { }

        NoopScope scope = new NoopScope();
        List<String> passed = new ArrayList<>();
        for (Mod mod : new ArrayList<>(ModManager.MODS)) {
            try {
                mod.setEnabled(true);
                mod.handleGlobalKeybind();
                mod.tick();
                mod.render(scope);
                if (mod instanceof HudMod hud) {
                    hud.shouldRenderHud();
                    hud.renderDummy(scope);
                    hud.renderEditor(scope);
                    hud.renderHud(scope);
                }
                mod.setEnabled(false);
                passed.add(mod.getName());
            } catch (Throwable failure) {
                throw new AssertionError("Module smoke test failed: " + mod.getName(), failure);
            }
        }
        if (passed.size() != 57) throw new AssertionError("Only " + passed.size() + " modules passed");
        if (!AutoGGTracker.isAnchoredGameEnd("Winner: SmokePlayer")
                || !AutoGGTracker.isAnchoredGameEnd("The match has ended!")
                || AutoGGTracker.isAnchoredGameEnd("ordinary player chat")) {
            throw new AssertionError("Auto GG detector smoke check failed");
        }
        if (!AutoGGTracker.isSupportedNetworkAddress("mc.hypixel.net:25565")
                || !AutoGGTracker.isSupportedNetworkAddress("bedwarspractice.club")
                || AutoGGTracker.isSupportedNetworkAddress("example.invalid")) {
            throw new AssertionError("Auto GG network allowlist smoke check failed");
        }
        Mod scoreboard = ModManager.MODS.stream().filter(mod -> mod.getName().equals("Scoreboard")).findFirst().orElseThrow();
        Mod bossBar = ModManager.MODS.stream().filter(mod -> mod.getName().equals("Boss Bar")).findFirst().orElseThrow();
        scoreboard.setEnabled(false);
        bossBar.setEnabled(false);
        if (scoreboard.isToggleable() || bossBar.isToggleable()
                || !scoreboard.isEnabled() || !bossBar.isEnabled()
                || !ModManager.ENABLED_MODS.contains(scoreboard) || !ModManager.ENABLED_MODS.contains(bossBar)
                || scoreboard.getConfig().getProperties().containsKey("Enabled")
                || bossBar.getConfig().getProperties().containsKey("Enabled")
                || scoreboard.getConfig().getProperties().containsKey("Module Toggle Key")
                || bossBar.getConfig().getProperties().containsKey("Module Toggle Key")) {
            throw new AssertionError("Automatic Scoreboard/Boss Bar still exposes an on/off control");
        }
        if (!ScoreboardMod.shouldReplaceVanilla() || !BossBarMod.shouldReplaceVanilla()) {
            throw new AssertionError("Scoreboard/Boss fail-open readiness check failed");
        }
        if (((HudMod) scoreboard).canScale() || ((HudMod) bossBar).canScale()
                || !((HudMod) scoreboard).usesNativeDefaultPosition()
                || !((HudMod) bossBar).usesNativeDefaultPosition()
                || ScoreboardMod.shouldMoveVanilla() || BossBarMod.shouldMoveVanilla()) {
            throw new AssertionError("Native Scoreboard/Boss Bar must start at vanilla position and be move-only");
        }
        for (Mod candidate : ModManager.MODS) {
            if (candidate instanceof HudMod hud && hud.getDimensions().renderBackground
                    && hud.getDimensions().background.defaultValue) {
                throw new AssertionError("HUD background is ON by default: " + candidate.getName());
            }
        }

        Mod clearFluids = ModManager.MODS.stream().filter(mod -> mod.getName().equals("Clear Fluids")).findFirst().orElseThrow();
        Mod noFog = ModManager.MODS.stream().filter(mod -> mod.getName().equals("No Fog")).findFirst().orElseThrow();
        Mod shulker = ModManager.MODS.stream().filter(mod -> mod.getName().equals("Shulker Box Preview")).findFirst().orElseThrow();
        clearFluids.setEnabled(true);
        noFog.setEnabled(true);
        shulker.setEnabled(true);
        if (!ClearFluidsMod.shouldClearWater() || !ClearFluidsMod.shouldClearLava()
                || !NoFogMod.isActive() || !ShulkerPreviewMod.isActive()
                || ShulkerPreviewMod.scale() < 0.6f || ShulkerPreviewMod.scale() > 1.6f) {
            throw new AssertionError("Visual utility configuration smoke check failed");
        }
        clearFluids.setEnabled(false);
        noFog.setEnabled(false);
        shulker.setEnabled(false);

        try (InputStream fontJson = ModuleSmokeTest.class.getClassLoader()
                .getResourceAsStream("assets/csclient/font/health_hearts.json")) {
            if (fontJson == null || !new String(fontJson.readAllBytes()).contains("minecraft:gui/sprites/hud/heart/full.png")) {
                throw new AssertionError("Exact vanilla heart font provider is missing");
            }
        }

        HealthDisplayMod.HeartRow hearts = HealthDisplayMod.createHeartRow(15f, 20f, 4f);
        if (hearts.full() != 7 || hearts.half() != 1 || hearts.empty() != 2
                || hearts.absorption() != 2
                || hearts.absorptionGlyphs().charAt(0) != HealthDisplayMod.ABSORPTION_HEART) {
            throw new AssertionError("Vanilla heart-row smoke check failed");
        }
        Mod brandingMod = ModManager.MODS.stream().filter(mod -> mod.getName().equals("CS Client Branding"))
                .findFirst().orElseThrow();
        brandingMod.setEnabled(true);
        UUID branded = UUID.fromString("123e4567-e89b-42d3-a456-426614174099");
        ClientBrandingState.setBridgeAvailable(true);
        ClientBrandingState.update(branded, true);
        if (!ClientBrandingMod.shouldRender(branded, false, false, 64.0, true)
                || !ClientBrandingMod.shouldRender(UUID.randomUUID(), true, false, 64.0, false)
                || ClientBrandingMod.shouldRender(UUID.randomUUID(), false, false, 64.0, true)) {
            throw new AssertionError("CS branding capability/settings smoke check failed");
        }
        ClientBrandingState.clear();

        Mod zoom = ModManager.MODS.stream().filter(mod -> mod.getName().equals("Zoom")).findFirst().orElseThrow();
        zoom.setEnabled(true);
        ZoomMod.isZooming = true;
        ZoomMod.zoomLevel.value = 3.0f;
        if (!ZoomMod.handleMouseWheel(1.0) || ZoomMod.configuredZoomLevel() <= 3.0f
                || ZoomMod.handleMouseWheel(0.0)) {
            throw new AssertionError("Smooth scroll zoom adjustment failed");
        }
        ZoomMod.isZooming = false;
        zoom.setEnabled(false);
        if (ModManager.RENDER_ENTRIES.length != ModManager.ENABLED_MODS.size()) {
            throw new AssertionError("Pre-resolved render entry snapshot is out of sync");
        }

        runPerformanceMetricsSmoke(runDirectory.toPath());
        runHudCollisionSmoke(scope);
        System.out.println("Module smoke test passed: " + passed.size() + "/57");
        System.out.println("Chat Improvements, profile Screenshot Manager, and Shield Status color checks passed");
        System.out.println("HUD collision smoke test passed");
        System.out.println("Sodium/settings ownership safety check passed");
        System.out.println("Performance metrics, pre-resolved render snapshot, and benchmark export checks passed");
        System.out.println("Smooth scroll-wheel zoom checks passed");
        System.out.println("CS branding capability/settings smoke test passed");
        System.out.println("Default-off HUD backgrounds, distinct styles, move-only Scoreboard, and launcher bridge checks passed");
        System.out.println("Pinned PlantMC icon, responsive banner, and India flag checks passed");
        System.out.println("Automatic Boss Bar, Shulker, Auto GG, fog/fluid, and vanilla-heart checks passed");
    }

    private static final class FakeServerEntry implements ServerListPinning.Entry {
        String name;
        String address;
        byte[] icon;

        FakeServerEntry(String name, String address) {
            this.name = name;
            this.address = address;
        }

        @Override public String name() { return name; }
        @Override public String address() { return address; }
        @Override public void pin(String name, String address, byte[] icon) {
            this.name = name;
            this.address = address;
            this.icon = icon;
        }
        @Override public Object nativeEntry() { return this; }

        @Override
        public String toString() {
            return name + " <" + address + ">";
        }
    }

    private static void runServerListPinningSmoke() throws Exception {
        List<FakeServerEntry> nativeServers = new ArrayList<>(List.of(
                new FakeServerEntry("My Survival", "play.example.net:25565"),
                new FakeServerEntry("Old Pin", "play.plantmc.fun"),
                new FakeServerEntry("Retired", "play.firemc.fun:25565"),
                new FakeServerEntry("Duplicate Pin", "play.plantmc.fun:25627")));
        List<FakeServerEntry> nativeHidden = new ArrayList<>(List.of(
                new FakeServerEntry("Hidden Pin", "play.plantmc.fun")));

        ServerListPinning.ensurePinned(
                ServerListPinning.view(nativeServers, entry -> entry),
                ServerListPinning.view(nativeHidden, entry -> entry),
                () -> new FakeServerEntry(FeaturedServers.PLANTMC_LIST_NAME,
                        FeaturedServers.PLANTMC_ADDRESS));

        // "Old Pin" (play.plantmc.fun) IS a plantmc address, so it becomes the
        // canonical pinned entry; "Retired" and the duplicate are removed.
        if (nativeServers.size() != 2 || nativeHidden.size() != 0
                || !FeaturedServers.PLANTMC_ADDRESS.equals(nativeServers.get(0).address())
                || !FeaturedServers.PLANTMC_LIST_NAME.equals(nativeServers.get(0).name())
                || nativeServers.get(0).icon == null || nativeServers.get(0).icon.length == 0
                || nativeServers.stream()
                        .filter(entry -> FeaturedServers.isPlantMcAddress(entry.address()))
                        .count() != 1
                || nativeServers.stream()
                        .noneMatch(entry -> "play.example.net:25565".equals(entry.address()))) {
            throw new AssertionError("Server-list pinning damaged user entries: " + nativeServers);
        }

        final boolean[] factoryCalled = {false};
        boolean secondPass = ServerListPinning.ensurePinned(
                ServerListPinning.view(nativeServers, entry -> entry),
                ServerListPinning.view(nativeHidden, entry -> entry),
                () -> {
                    factoryCalled[0] = true;
                    return new FakeServerEntry("never", "created");
                });
        if (secondPass || factoryCalled[0]) {
            throw new AssertionError("Idempotent pinning pass reported changes");
        }

        Path guardDir = Files.createTempDirectory("csclient-serverlist-guard");
        Path unreadable = guardDir.resolve("servers.dat");
        Files.writeString(unreadable, "legacy-format-content-" + "x".repeat(200));
        Path backup = ServerListPinning.backupUnreadableListFile(unreadable);
        if (backup == null || !Files.isRegularFile(backup)
                || !Files.readString(backup).equals(Files.readString(unreadable))) {
            throw new AssertionError("Unreadable servers.dat was not preserved for recovery");
        }
        Files.writeString(unreadable, "{}");
        if (ServerListPinning.backupUnreadableListFile(unreadable) != null) {
            throw new AssertionError("Trivially empty servers.dat must not trigger a recovery backup");
        }
        if (ServerListPinning.backupUnreadableListFile(guardDir.resolve("missing.dat")) != null) {
            throw new AssertionError("Missing servers.dat must not trigger a recovery backup");
        }

        // Wipe-guard decision: only an empty in-memory list over a non-trivial
        // on-disk file must be refused.
        if (!ServerListPinning.wouldDestroySavedData(0, true, 500L))
            throw new AssertionError("Empty list over a real servers.dat must be refused");
        if (ServerListPinning.wouldDestroySavedData(0, true, 64L))
            throw new AssertionError("Trivial file (empty list on disk) must not be refused");
        if (ServerListPinning.wouldDestroySavedData(3, true, 500L))
            throw new AssertionError("Non-empty list must always be allowed to save");
        if (ServerListPinning.wouldDestroySavedData(0, false, 0L))
            throw new AssertionError("First launch (no file) must not be refused");

        // Replay Mod bridge: absent mod = no-op, unknown screen = graceful null.
        if (com.craftstudio.csclient.common.replay.ReplayModBridge.isLoaded())
            throw new AssertionError("Fake client must not report Replay Mod as installed");
        if (com.craftstudio.csclient.common.replay.ReplayModBridge.createDefaultScreen(null) != null)
            throw new AssertionError("Missing Replay Mod must produce a null screen, not a crash");
        if (com.craftstudio.csclient.common.replay.ReplayModBridge.open(
                (com.craftstudio.csclient.common.ref.game.MinecraftClientRef) null))
            throw new AssertionError("open(null) must fail gracefully");
        System.out.println("Replay Mod bridge + server-list wipe guard smoke OK");

        // Performance: per-player nametag caches rely on these invariants.
        // 1) ModRuntimeGuard fast path: the volatile flag is consulted first.
        Mod guardProbe = ModManager.MODS.get(0);
        boolean originalFlag = guardProbe.quarantined;
        try {
            guardProbe.quarantined = true;
            if (!ModRuntimeGuard.isQuarantined(guardProbe))
                throw new AssertionError("Guard fast path must see the quarantined flag");
        } finally {
            guardProbe.quarantined = originalFlag;
        }
        if (ModRuntimeGuard.isQuarantined(guardProbe) != originalFlag)
            throw new AssertionError("Guard fast path disagrees with the quarantine state");

        // 2) HeartRow records are value-equal for identical inputs, which is what
        //    makes the per-version heart-row caches hit across frames.
        HealthDisplayMod.HeartRow a = HealthDisplayMod.createHeartRow(18.0f, 20.0f, 0f);
        HealthDisplayMod.HeartRow b = HealthDisplayMod.createHeartRow(18.0f, 20.0f, 0f);
        if (!a.equals(b))
            throw new AssertionError("Identical heart rows must be value-equal cache keys");
        System.out.println("Nametag cache invariants OK (guard fast path + heart-row keys)");
    }

    private static void runHudPerformanceSmoke() {
        // 1) Tracker semantics: unchanged content draws once, changes re-draw.
        HudDirtyTracker tracker = new HudDirtyTracker();
        ModLayout layout = new ModLayout(10, 10, 40, 14);
        if (!tracker.dirty("144", 0xFF55E37A, layout))
            throw new AssertionError("First HUD frame must draw");
        if (tracker.dirty("144", 0xFF55E37A, layout))
            throw new AssertionError("Unchanged HUD content reported dirty");
        layout.x.value = 12;
        if (!tracker.dirty("144", 0xFF55E37A, layout))
            throw new AssertionError("Position change not detected");
        layout.x.value = 10;
        if (!tracker.dirty("145", 0xFF55E37A, layout))
            throw new AssertionError("Content change not detected");
        tracker.invalidate();
        if (!tracker.dirty("145", 0xFF55E37A, layout))
            throw new AssertionError("invalidate() did not force a redraw");

        // 2) IntStrings: exact matches, including out-of-table values.
        for (int value : new int[] { 0, 1, 42, 999, 9999, -1, 10_000 }) {
            if (!Integer.toString(value).equals(IntStrings.of(value)))
                throw new AssertionError("IntStrings mismatch for " + value);
        }

        // 3) Width cache: repeated measurement is stable and cached.
        int first = Fonts.getWidth("PING", 2);
        int second = Fonts.getWidth("PING", 2);
        if (first <= 0 || first != second)
            throw new AssertionError("Width cache inconsistent: " + first + " vs " + second);

        // 4) End-to-end frame skip on a real module: 60 static frames of the
        //    Coordinates HUD must not re-submit 60 identical draw passes.
        Mod coords = ModManager.MODS.stream()
                .filter(mod -> mod.getName().equals("Coordinates"))
                .findFirst().orElseThrow();
        coords.setEnabled(true);
        CountingScope counting = new CountingScope();
        for (int frame = 0; frame < 60; frame++) {
            ((HudMod) coords).renderHud(counting);
        }
        coords.setEnabled(false);
        if (counting.draws < 1)
            throw new AssertionError("Static HUD never drew");
        if (counting.draws > 12)
            throw new AssertionError("HUD frame skip ineffective: " + counting.draws
                    + " text draw passes in 60 static frames");
        System.out.println("HUD frame-skip smoke OK (" + counting.draws + "/60 passes drawn)");
    }

    private static final class CountingScope extends NoopScope {
        int draws;

        @Override
        public void drawText(String text, int x, int y, int font, int color) {
            draws++;
        }

        @Override
        public void drawText(float scale, String text, int x, int y, int font, int color) {
            draws++;
        }
    }

    private static void runOcclusionCullingSmoke() {
        Mod perfMod = ModManager.MODS.stream()
                .filter(mod -> mod.getName().equals("Performance Engine")).findFirst().orElseThrow();
        if (!perfMod.isEnabled()) perfMod.setEnabled(true);
        BoolProperty cullPlayers = (BoolProperty) perfMod.getConfig()
                .getProperties().get("Cull Players Behind Blocks");
        if (cullPlayers == null) throw new AssertionError("Player culling option missing");

        UUID hidden = UUID.randomUUID();
        UUID visible = UUID.randomUUID();
        UUID ownPlayer = UUID.randomUUID();

        // Behind the deterministic wall (target x >= 5): culled after the probe.
        if (!EntityOcclusionCulling.shouldSkip(hidden, 20, 64, 0, 10, 64, 0, false, false))
            throw new AssertionError("Occluded entity was not culled");
        // Cached within the 100 ms window: no re-probe, still culled.
        if (!EntityOcclusionCulling.shouldSkip(hidden, 20.1, 64, 0, 10, 64, 0, false, false))
            throw new AssertionError("Cached occlusion state lost");

        // Clear line of sight (target x < 5): never culled.
        if (EntityOcclusionCulling.shouldSkip(visible, 0, 64, 10, 10, 64, 0, false, false))
            throw new AssertionError("Visible entity was culled");

        // Safety margins: close entities and the local player are never culled.
        if (EntityOcclusionCulling.shouldSkip(hidden, 13, 64, 0, 10, 64, 0, false, false))
            throw new AssertionError("Close entity (3 blocks) was culled");
        if (EntityOcclusionCulling.shouldSkip(ownPlayer, 20, 64, 0, 10, 64, 0, false, true))
            throw new AssertionError("Own player was culled");

        // Player culling can be switched off.
        cullPlayers.value = false;
        try {
            UUID otherPlayer = UUID.randomUUID();
            if (EntityOcclusionCulling.shouldSkip(otherPlayer, 20, 64, 0, 10, 64, 0, true, false))
                throw new AssertionError("Player culled while player culling is off");
        } finally {
            cullPlayers.value = true;
        }

        EntityOcclusionCulling.clear();
        System.out.println("Entity occlusion culling smoke OK");
    }

    private static void runPerformanceMetricsSmoke(Path runDirectory) throws Exception {
        long now = System.nanoTime();
        PerformanceEngine.onFrame(now);
        PerformanceEngine.startBenchmark("smoke-test");
        for (int i = 0; i < 240; i++) {
            now += 16_666_667L;
            PerformanceEngine.onFrame(now);
        }
        PerformanceEngine.Metrics metrics = PerformanceEngine.snapshotRecent();
        if (metrics.samples() < 200 || metrics.averageFps() < 59.0 || metrics.averageFps() > 61.0
                || metrics.p99FrameMs() < 16.0 || metrics.p99FrameMs() > 17.5) {
            throw new AssertionError("Performance frame metrics are outside expected bounds: " + metrics);
        }
        Path json = PerformanceEngine.stopBenchmarkAndExport();
        if (json == null || !Files.isRegularFile(json)
                || !Files.readString(json).contains("\"p99_frametime_ms\"")) {
            throw new AssertionError("Benchmark JSON export failed");
        }
        Path csv = json.resolveSibling(json.getFileName().toString().replace(".json", ".csv"));
        if (!Files.isRegularFile(csv) || !Files.readString(csv).startsWith("frame,frametime_ms")) {
            throw new AssertionError("Benchmark CSV export failed");
        }
        if (!json.startsWith(runDirectory.resolve("cs-client-benchmarks"))) {
            throw new AssertionError("Benchmark exported outside the run directory");
        }
    }

    private static void runHudCollisionSmoke(RenderScope scope) {
        List<Mod> hudMods = ModManager.MODS.stream().filter(mod -> mod instanceof HudMod).limit(2).toList();
        if (hudMods.size() != 2) throw new AssertionError("Need two HUD modules for collision test");
        for (Mod mod : ModManager.MODS) mod.setEnabled(false);
        Mod firstMod = hudMods.get(0);
        Mod secondMod = hudMods.get(1);
        firstMod.setEnabled(true);
        secondMod.setEnabled(true);
        ModLayout first = ((HudMod) firstMod).getDimensions();
        ModLayout second = ((HudMod) secondMod).getDimensions();
        first.scale.value = 1f;
        second.scale.value = 1f;
        first.x.value = 24;
        first.y.value = 80;
        second.x.value = 220;
        second.y.value = 80;

        HudEditor editor = new HudEditor();
        editor.render(scope, 0, 0, 0f, 0L);
        double clickX = first.x.value + 2;
        double clickY = first.y.value + 2;
        editor.mouseClicked(clickX, clickY, 0);
        editor.mouseDragged(second.x.value + 2, second.y.value + 2, 0, 0, 0);
        editor.mouseReleased(second.x.value + 2, second.y.value + 2, 0);
        assertNoOverlap(first, second);

        // Place the first widget just left of the second and try to enlarge it into the second.
        first.x.value = Math.max(4, second.x.value - Math.round(first.width * first.scale.value) - 6);
        first.y.value = second.y.value;
        float oldScale = first.scale.value;
        editor.mouseScrolled(first.x.value + 2, first.y.value + 2, 0, 8);
        assertNoOverlap(first, second);
        if (first.scale.value > oldScale + 0.001f) {
            throw new AssertionError("Collision resize unexpectedly increased widget scale");
        }
        firstMod.setEnabled(false);
        secondMod.setEnabled(false);
    }

    private static void assertNoOverlap(ModLayout first, ModLayout second) {
        int aw = Math.max(1, Math.round(first.width * first.scale.value));
        int ah = Math.max(1, Math.round(first.height * first.scale.value));
        int bw = Math.max(1, Math.round(second.width * second.scale.value));
        int bh = Math.max(1, Math.round(second.height * second.scale.value));
        boolean overlap = first.x.value < second.x.value + bw + 4 && first.x.value + aw + 4 > second.x.value
                && first.y.value < second.y.value + bh + 4 && first.y.value + ah + 4 > second.y.value;
        if (overlap) throw new AssertionError("HUD modules overlap after collision operation");
    }

    @FunctionalInterface
    private interface MethodHandler { Object invoke(java.lang.reflect.Method method, Object[] args) throws Throwable; }

    @SuppressWarnings("unchecked")
    private static <T> T proxy(Class<T> type, MethodHandler handler) {
        return (T) Proxy.newProxyInstance(ModuleSmokeTest.class.getClassLoader(), new Class<?>[] { type },
                (proxy, method, args) -> handler.invoke(method, args == null ? new Object[0] : args));
    }

    private static Object defaultValue(Class<?> type) {
        if (type == boolean.class) return false;
        if (type == byte.class) return (byte) 0;
        if (type == short.class) return (short) 0;
        if (type == int.class) return 0;
        if (type == long.class) return 0L;
        if (type == float.class) return 0f;
        if (type == double.class) return 0d;
        if (type == char.class) return '\0';
        if (type == String.class) return "";
        if (List.class.isAssignableFrom(type)) return List.of();
        return null;
    }

    private static List<ItemStackRef> repeated(ItemStackRef item, int count) {
        List<ItemStackRef> result = new ArrayList<>(count);
        for (int i = 0; i < count; i++) result.add(item);
        return result;
    }

    private record FakeIdentifier(String value) implements IdentifierRef {
        @Override public String toString() { return value; }
    }

    private static final class FakeText implements TextRef {
        private final String value;
        FakeText(String value) { this.value = value == null ? "" : value; }
        @Override public TextRef withFont(IdentifierRef font) { return this; }
        @Override public int getWidth() { return value.length() * 9; }
    }

    private record FakeWindow(int width, int height) implements WindowRef {
        FakeWindow() { this(960, 540); }
        @Override public int getWidth() { return width; }
        @Override public int getHeight() { return height; }
        @Override public int getFramebufferWidth() { return width * 2; }
        @Override public int getFramebufferHeight() { return height * 2; }
    }

    private record FakeItem(boolean isEmpty, int getMaxDamage, int getDamage, int getCount,
            String getItemName, boolean isEnchanted) implements ItemStackRef { }

    private static final class FakeEffect implements EffectRef {
        @Override public boolean shouldShowIcon() { return true; }
        @Override public SpriteRef getIcon() { return null; }
        @Override public boolean isInfinite() { return false; }
        @Override public String getInfiniteText() { return "∞"; }
        @Override public int getDurationSeconds() { return 90; }
    }

    private static final class NoopMatrix implements MatrixStackRef {
        @Override public void push() { }
        @Override public void pop() { }
        @Override public void translate(float x, float y) { }
        @Override public void scale(float x, float y) { }
        @Override public void rotate(float angle, float originX, float originY, float originZ) { }
        @Override public void rotate(float angle) { }
    }

    private static class NoopScope implements RenderScope {
        private final MatrixStackRef matrix = new NoopMatrix();
        @Override public MatrixStackRef getMatrixStack() { return matrix; }
        @Override public void setOpacity(float alpha) { }
        @Override public int getColor(int color) { return color; }
        @Override public void drawRectangle(int x, int y, int width, int height, int color) { }
        @Override public void drawRoundedRectangle(int x, int y, int width, int height, int radius, int color) { }
        @Override public void drawBorder(int x, int y, int width, int height, int color) { }
        @Override public void drawRoundedBorder(int x, int y, int width, int height, int radius, int color) { }
        @Override public void fill(int x1, int y1, int x2, int y2, int color) { }
        @Override public void drawText(String text, int x, int y, int font, int color) { }
        @Override public void drawText(float scale, String text, int x, int y, int font, int color) { }
        @Override public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height) { }
        @Override public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height, int color) { }
        @Override public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height,
                int regionWidth, int regionHeight, int textureWidth, int textureHeight) { }
        @Override public void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height,
                int regionWidth, int regionHeight, int textureWidth, int textureHeight, int color) { }
        @Override public void drawSpriteStretched(SpriteRef sprite, int x, int y, int width, int height) { }
        @Override public void drawSpriteStretched(SpriteRef sprite, int x, int y, int width, int height, int color) { }
        @Override public void drawItem(ItemStackRef item, int x, int y) { }
        @Override public void enableScissor(int x1, int y1, int x2, int y2) { }
        @Override public void disableScissor() { }
        @Override public boolean scissorContains(int x, int y) { return true; }
        @Override public int getScaledWindowWidth() { return 960; }
        @Override public int getScaledWindowHeight() { return 540; }
        @Override public void draw() { }
    }
}
