package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Touch-friendly animated SVG icon button used by full-screen CS menus. */
public class IconButton extends Element {
    private final IdentifierRef icon;
    private final Runnable onClick;
    private float hover;

    public IconButton(IdentifierRef icon, Runnable onClick) {
        this.icon = icon;
        this.onClick = onClick;
        dimensions(40, 40);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.22f;
        int fill = blend(0xB014181E, 0xE02B333D, hover);
        int outline = blend(0x406E7883, 0xDDE9EEF2, hover);
        int foreground = blend(0xFFD0D6DC, 0xFFFFFFFF, hover);
        int lift = hover > 0.55f ? -1 : 0;

        scope.drawRoundedRectangle(0, lift, width, height, 11, fill);
        scope.drawRoundedBorder(0, lift, width, height, 11, outline);
        scope.drawTexture(icon, 11, 11 + lift, 0, 0, 18, 18, foreground);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
