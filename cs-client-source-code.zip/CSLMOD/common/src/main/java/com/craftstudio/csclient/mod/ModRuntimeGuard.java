package com.craftstudio.csclient.mod;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.craftstudio.csclient.common.provider.Providers;

/**
 * Last-resort fault isolation: one incompatible module must not crash the entire
 * Minecraft render/tick loop. A failing module is quarantined for the current
 * run and its first failure is logged with the module name and stage.
 */
public final class ModRuntimeGuard {
    private static final Set<String> QUARANTINED = ConcurrentHashMap.newKeySet();

    private ModRuntimeGuard() { }

    /** Hot-path check: a volatile flag read instead of a hash-set lookup. */
    public static boolean isQuarantined(Mod mod) {
        return mod != null && (mod.quarantined || isQuarantined(mod.getName()));
    }

    public static boolean isQuarantined(String moduleName) {
        return moduleName != null && QUARANTINED.contains(moduleName);
    }

    public static boolean run(Mod mod, String stage, Runnable action) {
        if (mod == null || action == null || isQuarantined(mod)) return false;
        try {
            action.run();
            return true;
        } catch (VirtualMachineError fatal) {
            throw fatal;
        } catch (LinkageError | RuntimeException failure) {
            quarantine(mod, stage, failure);
            return false;
        }
    }

    public static void quarantine(Mod mod, String stage, Throwable failure) {
        if (mod == null || failure == null) return;
        mod.quarantined = true;
        if (QUARANTINED.add(mod.getName())) {
            String message = "Disabled failing CS module '" + mod.getName() + "' during " + stage;
            if (Providers.csClient != null) Providers.csClient.logError(message, failure);
            else {
                System.err.println(message);
                failure.printStackTrace();
            }
        }
    }

    public static void clear() {
        QUARANTINED.clear();
    }
}
