package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Small gameplay-visible glass surface shared by CS quick popups. */
public class QuickPopupSurface extends Element {
    private final int accent;

    public QuickPopupSurface() {
        this(Theme.ACCENT.value);
    }

    public QuickPopupSurface(int accent) {
        this.accent = accent;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        scope.drawRoundedBorder(-3, -3, width + 6, height + 6, 9,
                withAlpha(42, accent));
        scope.drawRoundedRectangle(0, 0, width, height, 7, 0xF30D1418);
        scope.drawRoundedBorder(0, 0, width, height, 7,
                withAlpha(172, accent));
        scope.drawRoundedRectangle(13, 13, 3, Math.min(40, Math.max(12, height - 26)), 2,
                withAlpha(225, accent));
    }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }
}
