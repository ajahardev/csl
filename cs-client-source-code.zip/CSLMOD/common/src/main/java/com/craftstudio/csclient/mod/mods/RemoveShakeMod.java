package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/** Client-only hurt-camera intensity; damage, flash and knockback are untouched. */
public class RemoveShakeMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final IntProperty STRENGTH = Property.integer(0);

    public RemoveShakeMod() {
        super(new ModSpec("Remove Shake", "remove_shake")
                        .description("Controls camera tilt when taking damage without changing gameplay")
                        .version("v1.0.0").tags("Visuals", "PvP", "Accessibility"),
                ENABLED.named("Enabled"), STRENGTH.named("Shake Strength"));
    }

    public static boolean isActive() { return ENABLED.value; }
    public static float multiplier() { return Math.max(0, Math.min(100, STRENGTH.value)) / 100f; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
