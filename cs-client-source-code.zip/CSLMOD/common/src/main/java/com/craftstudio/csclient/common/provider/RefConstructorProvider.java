package com.craftstudio.csclient.common.provider;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.render.TextRef;

public interface RefConstructorProvider {
    public IdentifierRef identifier(String namespace, String path);

    public IdentifierRef identifier(String fullPath);

    public TextRef text(String text);
}
