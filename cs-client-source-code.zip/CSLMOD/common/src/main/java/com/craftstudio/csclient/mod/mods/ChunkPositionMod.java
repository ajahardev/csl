package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.ModSpec;

public class ChunkPositionMod extends TextHudMod {
    public ChunkPositionMod() {
        super(new ModSpec("Chunk Position", "chunk").description("Shows the current chunk coordinates")
                .version("v1.0.0").tags("Navigation", "HUD").requires(Providers.feature::player), 104);
    }

    @Override protected String getText() {
        PlayerFeature p = Providers.feature.player();
        return "CHUNK " + Math.floorDiv(p.getX(), 16) + "  " + Math.floorDiv(p.getZ(), 16);
    }
    @Override protected String getDummyText() { return "CHUNK 24  -18"; }
}
