package com.craftstudio.csclient.server;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Version-independent PlantMC pinning logic for the saved server list.
 *
 * The per-version ServerList mixins adapt their ServerInfo/ServerData entries
 * to {@link Entry} and delegate here, so the behaviour can be unit-tested
 * without the Minecraft runtime. The pinning logic only ever touches the exact
 * canonical PlantMC address, the retired first-party address and duplicates of
 * the pinned entry; every user-owned server entry is left untouched.
 */
public final class ServerListPinning {

    /** One saved server entry, as seen by the pinning logic. */
    public interface Entry {
        String name();

        String address();

        /** Applies the canonical pinned name/address/icon to this entry. */
        void pin(String name, String address, byte[] icon);

        /** The version-specific object (ServerInfo/ServerData) this entry wraps. */
        Object nativeEntry();
    }

    private ServerListPinning() { }

    /**
     * Normalizes a freshly loaded server list:
     * <ul>
     *   <li>removes retired first-party addresses and duplicate pinned entries;</li>
     *   <li>ensures exactly one canonical pinned entry at index zero.</li>
     * </ul>
     * User-owned entries are never removed or renamed.
     *
     * @param servers       visible list, adapted
     * @param hidden        hidden list, adapted
     * @param pinnedFactory creates a new pinned entry (it is inserted by this method)
     * @return true if any list was modified
     */
    public static boolean ensurePinned(List<Entry> servers, List<Entry> hidden,
            Supplier<Entry> pinnedFactory) {
        boolean changed = false;
        Entry pinned = null;
        for (Iterator<Entry> iterator = servers.iterator(); iterator.hasNext();) {
            Entry entry = iterator.next();
            if (FeaturedServers.isRetiredFeaturedAddress(entry.address())) {
                iterator.remove();
                changed = true;
            } else if (FeaturedServers.isPlantMcAddress(entry.address())) {
                if (pinned == null) {
                    pinned = entry;
                } else {
                    iterator.remove();
                    changed = true;
                }
            }
        }
        for (Iterator<Entry> iterator = hidden.iterator(); iterator.hasNext();) {
            Entry entry = iterator.next();
            if (FeaturedServers.isRetiredFeaturedAddress(entry.address())
                    || FeaturedServers.isPlantMcAddress(entry.address())) {
                iterator.remove();
                changed = true;
            }
        }
        if (pinned == null) {
            pinned = pinnedFactory.get();
            servers.add(0, pinned);
            changed = true;
        } else if (!FeaturedServers.PLANTMC_LIST_NAME.equals(pinned.name())
                || !FeaturedServers.PLANTMC_ADDRESS.equals(pinned.address())) {
            changed = true;
        }
        pinned.pin(FeaturedServers.PLANTMC_LIST_NAME, FeaturedServers.PLANTMC_ADDRESS,
                FeaturedServers.plantMcIconBytes());
        int index = servers.indexOf(pinned);
        if (index > 0) {
            servers.remove(index);
            servers.add(0, pinned);
            changed = true;
        }
        return changed;
    }

    /**
     * Single decision rule for the server-list wipe guard: a save must be
     * refused when the in-memory list is empty although a non-trivial
     * servers.dat exists on disk (foreign/legacy format, corruption).
     *
     * @return true when writing the list would destroy saved user data
     */
    public static boolean wouldDestroySavedData(int inMemoryEntries, boolean fileExists,
            long fileSizeBytes) {
        return inMemoryEntries == 0 && fileExists && fileSizeBytes > 128L;
    }

    /**
     * If a servers.dat file exists and is non-trivial but nothing was parsed
     * from it, the file is unreadable by this client (legacy format,
     * corruption, ...). Preserve the original file for recovery before any
     * later save can overwrite it.
     *
     * @return the backup path, or null when nothing needed preserving
     */
    public static Path backupUnreadableListFile(Path listFile) {
        if (listFile == null || !Files.isRegularFile(listFile)) return null;
        try {
            // A valid list with zero entries is tiny; anything larger that
            // produced no parsed entries contains content we failed to read.
            if (Files.size(listFile) <= 128L) return null;
            Path backup = listFile.resolveSibling(
                    "servers.dat.recovery-" + System.currentTimeMillis());
            Files.copy(listFile, backup, StandardCopyOption.REPLACE_EXISTING);
            return backup;
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Read/iterate view over a version-specific list that delegates mutations
     * back to the original list.
     */
    public static <T> List<Entry> view(List<T> source, Function<T, Entry> mapper) {
        return new View<>(source, mapper);
    }

    private static final class View<T> extends AbstractList<Entry> {
        private final List<T> source;
        private final Function<T, Entry> mapper;

        private View(List<T> source, Function<T, Entry> mapper) {
            this.source = source;
            this.mapper = mapper;
        }

        @SuppressWarnings("unchecked")
        @Override
        public Entry set(int index, Entry entry) {
            return mapper.apply(source.set(index, (T) entry.nativeEntry()));
        }

        @SuppressWarnings("unchecked")
        @Override
        public void add(int index, Entry entry) {
            source.add(index, (T) entry.nativeEntry());
        }

        @SuppressWarnings("unchecked")
        @Override
        public Entry remove(int index) {
            return mapper.apply(source.remove(index));
        }

        @Override
        public int indexOf(Object o) {
            if (!(o instanceof Entry)) return -1;
            Object nativeEntry = ((Entry) o).nativeEntry();
            for (int i = 0; i < source.size(); i++) {
                if (source.get(i) == nativeEntry) return i;
            }
            return -1;
        }

        @Override
        public Entry get(int index) {
            return mapper.apply(source.get(index));
        }

        @Override
        public int size() {
            return source.size();
        }

        @Override
        public Iterator<Entry> iterator() {
            Iterator<T> delegate = source.iterator();
            return new Iterator<>() {
                @Override
                public boolean hasNext() {
                    return delegate.hasNext();
                }

                @Override
                public Entry next() {
                    return mapper.apply(delegate.next());
                }

                @Override
                public void remove() {
                    delegate.remove();
                }
            };
        }
    }
}
