package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;

/** Rounded lower-right Discord invite card for the CS Client home screen. */
public final class HomeDiscordCard extends Element {
    private final Runnable onClick;
    private float hover;

    public HomeDiscordCard(Runnable onClick) {
        this.onClick = onClick;
        dimensions(254, 78);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.22f;
        if (Math.abs(target - hover) < 0.002f) hover = target;

        int lift = hover > 0.55f ? -1 : 0;
        int fill = blend(0xDE161D28, 0xFF5865F2, hover);
        int outline = blend(0x927A8AAA, 0xFFFFFFFF, hover);
        int detail = blend(0xFFD9E0EA, 0xFFFFFFFF, hover);
        int sub = blend(0xFFAEB8C7, 0xFFE8EBFF, hover);

        scope.drawRoundedRectangle(0, lift, width, height, 7, fill);
        scope.drawRoundedBorder(0, lift, width, height, 7, outline);
        if (hover > 0.02f) {
            scope.drawRoundedBorder(-2, lift - 2, width + 4, height + 4, 9,
                    Theme.withAlpha(Math.round(80 * hover), 0xFF8D9BFF));
        }

        // Official white wordmark is kept unmodified; the card's Blurple surface is separate CS UI chrome.
        int logoWidth = Math.max(92, Math.min(144, width - 74));
        int logoHeight = Math.max(14, Math.round(logoWidth * (32f / 219f)));
        scope.drawTexture(Textures.DISCORD_OFFICIAL, 16, 14 + lift, 0, 0, logoWidth, logoHeight, 0xFFFFFFFF);
        scope.drawText(0.30f, "JOIN OUR COMMUNITY", 17, Math.min(height - 23, 49) + lift,
                Theme.FONT.value, sub);
        String arrow = "↗";
        int arrowWidth = Math.round(Fonts.getWidth(arrow, Theme.FONT.value) * 0.58f);
        scope.drawText(0.58f, arrow, width - arrowWidth - 18 + Math.round(hover * 2f),
                29 + lift, Theme.FONT.value, detail);

        int railWidth = Math.max(22, Math.round((width - 34) * (0.26f + hover * 0.74f)));
        scope.drawRoundedRectangle(17, height - 5 + lift, railWidth, 2, 1,
                Theme.withAlpha(Math.round(130 + hover * 110), 0xFFFFFFFF));
    }

    @Override public void click(int mouseX, int mouseY) { if (onClick != null) onClick.run(); }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
