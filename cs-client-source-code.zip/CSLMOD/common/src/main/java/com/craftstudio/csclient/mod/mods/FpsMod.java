package com.craftstudio.csclient.mod.mods;

import java.util.Arrays;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/** Clean adaptive FPS metric: green when smooth, amber when pressured, red when low. */
public class FpsMod extends Mod implements HudMod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty smoothAnimation = Property.bool(true);
    private static final BoolProperty showGraph = Property.bool(false);
    private static final BoolProperty adaptiveColor = Property.bool(true);
    private static final ColorProperty accentColor = Property.color(0xFF55E37A);
    private static final ModLayout layout = createLayout();

    private final int[] history = new int[8];
    private int historyIndex;
    private long lastSample;
    private float displayedFps = -1f;
    private final com.craftstudio.csclient.mod.HudDirtyTracker dirtyTracker =
            new com.craftstudio.csclient.mod.HudDirtyTracker();

    private static ModLayout createLayout() {
        ModLayout value = new ModLayout(64, 22);
        value.bgColor.value = 0xD912171C;
        value.fgColor.value = 0xFFF4F6F8;
        value.radius.value = 5;
        return value;
    }

    public FpsMod() {
        super(new ModSpec("FPS Display", "fps")
                        .description("Clear frame-rate display with meaningful performance colours")
                        .version("v1.0.0").tags("Performance", "HUD")
                        .requires(Providers.feature::render),
                enabled.named("Enabled"), smoothAnimation.named("Smooth number animation"),
                showGraph.named("Show micro graph"), adaptiveColor.named("Adaptive FPS colour"),
                accentColor.named("High FPS colour"), layout.prop());
        Arrays.fill(history, 120);
    }

    @Override public void renderHud(RenderScope scope) { draw(scope, Providers.feature.render().getFps(), true); }
    @Override public void renderDummy(RenderScope scope) { draw(scope, 144, false); }

    private void draw(RenderScope scope, int fps, boolean live) {
        if (displayedFps < 0f) displayedFps = fps;
        displayedFps = smoothAnimation.value ? displayedFps + (fps - displayedFps) * 0.28f : fps;
        int shown = Math.max(0, Math.round(displayedFps));
        int color = performanceColor(shown);

        long now = System.currentTimeMillis();
        if (live && now - lastSample >= 250L) {
            history[historyIndex++ & 7] = Math.max(1, fps);
            lastSample = now;
        }

        String valueText = com.craftstudio.csclient.util.IntStrings.of(shown);
        // Frame skip for live HUD: unchanged value + colour + position draws
        // nothing. The micro graph updates at 4 Hz, so with it visible the
        // widget keeps redrawing.
        if (live && !showGraph.value
                && !dirtyTracker.dirty(valueText, color, layout)) {
            return;
        }

        HudTextRenderer.drawMetric(scope, layout, "FPS", valueText, "", color,
                HudTextRenderer.MetricKind.PERFORMANCE);
        if (!showGraph.value) return;

        int baseWidth = layout.width;
        layout.width = baseWidth + 27;
        int max = 60;
        for (int sample : history) max = Math.max(max, sample);
        int graphBottom = Math.max(13, layout.height - 4);
        for (int i = 0; i < 8; i++) {
            int sample = history[(historyIndex + i) & 7];
            int bar = Math.max(2, Math.round((sample / (float) max) * 12));
            int alpha = 95 + i * 18;
            scope.drawRectangle(baseWidth + 2 + i * 3, graphBottom - bar, 2, bar,
                    withAlpha(alpha, color));
        }
    }

    private static int performanceColor(int fps) {
        if (!adaptiveColor.value) return accentColor.value;
        if (fps >= 60) return accentColor.value;
        if (fps >= 30) return 0xFFF0BF55;
        return 0xFFF05F68;
    }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
