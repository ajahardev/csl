package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.Fade;
import com.craftstudio.csclient.ui.anim.PopFade;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.ImageTexture;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;
import com.craftstudio.csclient.util.ExternalLinks;

/** Animated explicit confirmation before a fixed Discord/YouTube browser hand-off. */
public final class ExternalLinkConfirmScreen extends CSClientScreen {
    private final CSClientScreen parent;
    private final ExternalLinks.Destination destination;
    private String status = "";

    public ExternalLinkConfirmScreen(CSClientScreen parent, ExternalLinks.Destination destination) {
        super(destination == ExternalLinks.Destination.YOUTUBE ? "Subscribe on YouTube" : "Join Discord");
        this.parent = parent == null ? new TitleMenu() : parent;
        this.destination = destination == null ? ExternalLinks.Destination.DISCORD : destination;
        backgroundBlur = 2;
        backgroundOpacity = 0.48f;
    }

    @Override
    public void ui() {
        int panelWidth = Math.min(468, width - 36);
        int panelHeight = 292;
        int x = (width - panelWidth) / 2;
        int y = Math.max(18, (height - panelHeight) / 2);
        boolean youtube = destination == ExternalLinks.Destination.YOUTUBE;

        draw(new Panel(0xF20D1418).dimensions(panelWidth, panelHeight).position(x, y).animation(pop(0)));
        draw(new Text(youtube ? "SUBSCRIBE ON YOUTUBE?" : "JOIN DISCORD?")
                .scale(0.66f).position(x + 26, y + 22).animation(slide(-8, 28)));
        draw(new Text("ONE MORE CONFIRMATION BEFORE YOUR BROWSER OPENS")
                .scale(0.27f).position(x + 27, y + 49).animation(fade(44)));

        if (youtube) {
            draw(new ImageTexture(Textures.YOUTUBE_OFFICIAL).dimensions(158, 53)
                    .position(x + (panelWidth - 158) / 2, y + 78).animation(pop(60)));
        } else {
            draw(new ImageTexture(Textures.DISCORD_OFFICIAL).dimensions(184, 27)
                    .position(x + (panelWidth - 184) / 2, y + 93).animation(pop(60)));
        }

        draw(new Text(destination.prompt()).scale(0.34f)
                .position(x + 28, y + 151).animation(fade(78)));
        draw(new Text(destination.url()).scale(0.25f)
                .position(x + 28, y + 174).animation(fade(92)));
        if (!status.isBlank()) {
            draw(new Text(status).color(0xFFFF9AA5).scale(0.28f)
                    .position(x + 28, y + 198).animation(fade(0)));
        }

        int gap = 10;
        int buttonWidth = (panelWidth - 52 - gap) / 2;
        draw(new HomeMenuButton(Textures.BACK, "CANCEL", false, this::cancel)
                .dimensions(buttonWidth, 40).position(x + 26, y + panelHeight - 60)
                .animation(slide(-6, 112)));
        draw(new HomeMenuButton(null, destination.title(), true, this::confirm)
                .dimensions(buttonWidth, 40).position(x + 26 + buttonWidth + gap, y + panelHeight - 60)
                .animation(slide(6, 126)));
    }

    private void confirm() {
        if (Providers.csClient.getClient().openExternalUrl(destination.url())) {
            Providers.csClient.getClient().setScreen(parent);
        } else {
            status = "COULD NOT OPEN THE PLATFORM BROWSER.";
            init();
        }
    }

    private void cancel() { Providers.csClient.getClient().setScreen(parent); }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            cancel();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean shouldPause() { return false; }

    private static PopFade pop(int delay) {
        PopFade value = new PopFade(AnimationConfig.mainMenu);
        value.delay = delay;
        return value;
    }

    private static SlideFade slide(int offset, int delay) {
        SlideFade value = new SlideFade(AnimationConfig.mainMenu, offset);
        value.delay = delay;
        return value;
    }

    private static Fade fade(int delay) {
        Fade value = new Fade(AnimationConfig.mainMenu);
        value.delay = delay;
        return value;
    }
}
