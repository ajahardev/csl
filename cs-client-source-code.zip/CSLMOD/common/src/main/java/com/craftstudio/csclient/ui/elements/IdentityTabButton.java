package com.craftstudio.csclient.ui.elements;

import java.util.function.BooleanSupplier;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Feather/Lunar-derived identity tab with a shallow CS outline. */
public class IdentityTabButton extends Element {
    private final IdentifierRef icon;
    private final String label;
    private final BooleanSupplier selected;
    private final BooleanSupplier locked;
    private final Runnable action;
    private float progress;

    public IdentityTabButton(IdentifierRef icon, String label, BooleanSupplier selected,
            BooleanSupplier locked, Runnable action) {
        this.icon = icon;
        this.label = label;
        this.selected = selected;
        this.locked = locked;
        this.action = action;
        dimensions(170, 40);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        boolean isSelected = selected.getAsBoolean();
        boolean isLocked = locked.getAsBoolean();
        float target = isSelected ? 1f : (ctx.isHovering() ? 0.48f : 0f);
        progress += (target - progress) * 0.24f;
        int fill = blend(0xC713181E, Theme.withAlpha(220, Theme.ACCENT.value), progress);
        int fg = isLocked ? Theme.withAlpha(90, Theme.PRIMARY_FG.value)
                : blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, progress);
        scope.drawRoundedRectangle(0, 0, width, height, 6, fill);
        scope.drawRoundedBorder(0, 0, width, height, 6,
                blend(Theme.withAlpha(70, Theme.ACCENT.value), 0xFFF2F5F7, progress));
        scope.drawTexture(isLocked ? com.craftstudio.csclient.ui.resources.Textures.LOCK : icon,
                13, 11, 0, 0, 18, 18, fg);
        scope.drawText(0.45f, label, 42, 15, Theme.FONT.value, fg);
        if (progress > 0.04f) {
            scope.drawRectangle(10, height - 2, Math.round((width - 20) * progress), 1,
                    Theme.withAlpha(Math.round(225 * progress), Theme.ACCENT.value));
        }
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (action != null) action.run();
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
