package com.craftstudio.csclient.ui.components.inputs;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Compact color summary; clicking opens the dedicated, viewport-safe editor. */
public class ColorInput extends Element {
    private final ColorProperty prop;
    private final Runnable openEditor;
    private float hover;

    public ColorInput(ColorProperty prop, Runnable openEditor) {
        this.prop = prop;
        this.openEditor = openEditor;
        dimensions(176, 34);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.22f;
        scope.drawRoundedRectangle(0, 0, width, height, 10,
                hover > 0.15f ? 0xF020272F : 0xE7181D23);
        scope.drawRoundedBorder(0, 0, width, height, 10,
                Theme.withAlpha(70 + Math.round(120 * hover), Theme.ACCENT.value));
        scope.drawRoundedRectangle(7, 6, 34, 22, 7, prop.value);
        scope.drawRoundedBorder(7, 6, 34, 22, 7, 0x88FFFFFF);
        scope.drawText(0.44f, String.format("#%08X", prop.value), 51, 13,
                Theme.FONT.value, Theme.FOREGROUND.value);
        scope.drawText(0.54f, "›", width - 20, 11, Theme.FONT.value,
                Theme.PRIMARY_FG.value);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (openEditor != null) openEditor.run();
    }
}
