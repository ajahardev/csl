package com.craftstudio.csclient.account;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Stores offline/local profiles only. Passwords, Microsoft tokens and launcher
 * credentials are deliberately never read or written by CS Client.
 */
public final class LocalAccountManager {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Pattern VALID_USERNAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
    private static final List<LocalAccount> ACCOUNTS = new ArrayList<>();
    private static File file;

    private LocalAccountManager() {
    }

    public record LocalAccount(String username, UUID uuid, long lastUsed) {
    }

    public static synchronized void initialize(File runDirectory) {
        file = new File(runDirectory, "cs-client-local-accounts.json");
        load();
    }

    public static synchronized List<LocalAccount> getAccounts() {
        return ACCOUNTS.stream()
                .sorted(Comparator.comparingLong(LocalAccount::lastUsed).reversed()
                        .thenComparing(LocalAccount::username, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    public static synchronized boolean isValidUsername(String username) {
        return username != null && VALID_USERNAME.matcher(username.trim()).matches();
    }

    /** True only for UUIDs created/stored by CS's credential-free local manager. */
    public static synchronized boolean isLocalAccount(UUID uuid) {
        return uuid != null && ACCOUNTS.stream().anyMatch(account -> account.uuid().equals(uuid));
    }

    public static synchronized LocalAccount find(UUID uuid) {
        if (uuid == null) return null;
        return ACCOUNTS.stream().filter(account -> account.uuid().equals(uuid)).findFirst().orElse(null);
    }

    public static synchronized String add(String username) {
        String clean = username == null ? "" : username.trim();
        if (!isValidUsername(clean)) {
            return "Use 3–16 letters, numbers, or underscores.";
        }

        boolean exists = ACCOUNTS.stream().anyMatch(account -> account.username().equalsIgnoreCase(clean));
        if (exists) {
            return "That local profile already exists.";
        }

        ACCOUNTS.add(new LocalAccount(clean, offlineUuid(clean), System.currentTimeMillis()));
        save();
        return null;
    }

    public static synchronized void remove(UUID uuid) {
        ACCOUNTS.removeIf(account -> account.uuid().equals(uuid));
        save();
    }

    public static synchronized void markUsed(UUID uuid) {
        for (int i = 0; i < ACCOUNTS.size(); i++) {
            LocalAccount account = ACCOUNTS.get(i);
            if (account.uuid().equals(uuid)) {
                ACCOUNTS.set(i, new LocalAccount(account.username(), account.uuid(), System.currentTimeMillis()));
                save();
                return;
            }
        }
    }

    public static UUID offlineUuid(String username) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Best-effort identification for launcher-provided offline sessions. Different
     * launchers use a canonical OfflinePlayer UUID, a version-3 UUID, an empty
     * token, or a short placeholder token. The token is inspected only in memory
     * for this boolean decision; it is never stored, logged, or transmitted.
     */
    public static boolean isLikelyOfflineLauncherSession(String username, UUID uuid, String accessToken) {
        if (uuid == null || username == null || username.isBlank()) return false;
        String cleanName = username.trim();
        if (isValidUsername(cleanName) && offlineUuid(cleanName).equals(uuid)) return true;
        if (uuid.version() == 3 || uuid.equals(new UUID(0L, 0L))) return true;
        if (accessToken == null) return true;

        String token = accessToken.trim();
        if (token.isBlank()) return true;
        String normalized = token.toLowerCase(Locale.ROOT);
        if (normalized.equals("0") || normalized.equals("-") || normalized.equals("null")
                || normalized.equals("none") || normalized.equals("offline")
                || normalized.equals("invalid") || normalized.equals("unauthenticated")
                || normalized.equals("token") || normalized.equals("access_token")
                || normalized.startsWith("offline:") || normalized.startsWith("offline-")) {
            return true;
        }
        if (token.equalsIgnoreCase(cleanName) || token.equalsIgnoreCase(uuid.toString())
                || token.length() < 20 || token.matches("[0-9a-fA-F]{32}")) {
            return true;
        }
        try {
            UUID.fromString(token);
            return true;
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    private static void load() {
        ACCOUNTS.clear();
        if (file == null || !file.isFile()) {
            return;
        }

        try {
            JsonNode root = MAPPER.readTree(file);
            JsonNode accounts = root == null ? null : root.get("accounts");
            if (accounts == null || !accounts.isArray()) {
                return;
            }

            for (JsonNode node : accounts) {
                String username = node.path("username").asText("").trim();
                String uuidText = node.path("uuid").asText("");
                long lastUsed = node.path("lastUsed").asLong(0L);
                if (!isValidUsername(username)) {
                    continue;
                }
                try {
                    UUID uuid = uuidText.isBlank() ? offlineUuid(username) : UUID.fromString(uuidText);
                    boolean duplicate = ACCOUNTS.stream()
                            .anyMatch(account -> account.username().toLowerCase(Locale.ROOT)
                                    .equals(username.toLowerCase(Locale.ROOT)));
                    if (!duplicate) {
                        ACCOUNTS.add(new LocalAccount(username, uuid, lastUsed));
                    }
                } catch (IllegalArgumentException ignored) {
                    // Skip only the malformed entry; keep the rest of the account list.
                }
            }
        } catch (Exception ignored) {
            // A broken optional profile file must never prevent Minecraft startup.
        }
    }

    private static void save() {
        if (file == null) {
            return;
        }

        try {
            File parent = file.getParentFile();
            if (parent != null) {
                parent.mkdirs();
            }

            ObjectNode root = MAPPER.createObjectNode();
            root.put("version", 1);
            ArrayNode accounts = root.putArray("accounts");
            for (LocalAccount account : ACCOUNTS) {
                ObjectNode node = accounts.addObject();
                node.put("username", account.username());
                node.put("uuid", account.uuid().toString());
                node.put("lastUsed", account.lastUsed());
            }

            Files.writeString(file.toPath(), MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(root));
        } catch (Exception ignored) {
            // Account switching remains usable for this run even if persistence fails.
        }
    }
}
