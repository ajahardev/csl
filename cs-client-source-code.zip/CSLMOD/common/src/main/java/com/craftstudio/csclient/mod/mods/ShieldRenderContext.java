package com.craftstudio.csclient.mod.mods;

/** Render-thread marker used only to distinguish the local first-person shield pass. */
public final class ShieldRenderContext {
    private static final ThreadLocal<Boolean> FIRST_PERSON_SHIELD = ThreadLocal.withInitial(() -> false);

    private ShieldRenderContext() { }

    public static void beginFirstPersonShield(boolean shield) {
        FIRST_PERSON_SHIELD.set(shield);
    }

    public static boolean isFirstPersonShield() {
        return FIRST_PERSON_SHIELD.get();
    }

    public static void endFirstPersonShield() {
        FIRST_PERSON_SHIELD.remove();
    }
}
