package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.FloatProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/** Resource-pack-safe status colours rendered as additional overlays, never replacement textures. */
public final class ShieldStatusesMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty INTERPOLATE = Property.bool(true);
    private static final BoolProperty ITEM_ICON_OUTLINE = Property.bool(true);
    private static final BoolProperty FIRST_PERSON_OVERLAY = Property.bool(true);
    private static final FloatProperty READY_SOON_THRESHOLD = Property.floatProp(0.25f);
    private static final FloatProperty OVERLAY_OPACITY = Property.floatProp(0.34f);
    private static final ColorProperty DISABLED_COLOR = Property.color(0xFFFF3B3B);
    private static final ColorProperty READY_SOON_COLOR = Property.color(0xFFFF9F1C);
    private static final ColorProperty ENABLED_COLOR = Property.color(0xFF43D96B);

    public ShieldStatusesMod() {
        super(new ModSpec("Shield Statuses", "shieldstatus")
                        .description("Shows red, orange and green shield state overlays using Minecraft's exact cooldown progress")
                        .version("v1.0.0").tags("PvP", "Visuals", "Utility"),
                ENABLED.named("Enabled"),
                INTERPOLATE.named("Interpolate Colors"),
                ITEM_ICON_OUTLINE.named("Show Item Icon Outline"),
                FIRST_PERSON_OVERLAY.named("Show First-Person Overlay"),
                READY_SOON_THRESHOLD.named("Ready Soon Threshold"),
                OVERLAY_OPACITY.named("First-Person Overlay Opacity"),
                DISABLED_COLOR.named("Disabled Color"),
                READY_SOON_COLOR.named("Ready Soon Color"),
                ENABLED_COLOR.named("Enabled Color"));
    }

    public static boolean isActive() { return ENABLED.value; }
    public static boolean itemIconOutlineEnabled() { return ENABLED.value && ITEM_ICON_OUTLINE.value; }
    public static boolean firstPersonOverlayEnabled() { return ENABLED.value && FIRST_PERSON_OVERLAY.value; }

    /** Vanilla remaining fraction: 1 at disable start, 0 when usable again. */
    public static int iconColor(float tickDelta) {
        return withAlpha(statusRgb(tickDelta), 0xE8);
    }

    public static int firstPersonColor(float tickDelta) {
        int configuredAlpha = (statusRgb(tickDelta) >>> 24) & 255;
        int alpha = Math.round(clamp(OVERLAY_OPACITY.value, 0.08f, 0.80f) * configuredAlpha);
        return withAlpha(statusRgb(tickDelta), alpha);
    }

    public static int colorForRemaining(float remaining, boolean interpolate) {
        float left = clamp(remaining, 0f, 1f);
        if (left <= 0.001f) return ENABLED_COLOR.value;
        float threshold = clamp(READY_SOON_THRESHOLD.value, 0.05f, 0.50f);
        if (!interpolate) return left <= threshold ? READY_SOON_COLOR.value : DISABLED_COLOR.value;
        float progress = 1f - left;
        float orangeAt = 1f - threshold;
        if (progress <= orangeAt) {
            return lerp(DISABLED_COLOR.value, READY_SOON_COLOR.value, progress / Math.max(0.001f, orangeAt));
        }
        return lerp(READY_SOON_COLOR.value, ENABLED_COLOR.value,
                (progress - orangeAt) / Math.max(0.001f, threshold));
    }

    private static int statusRgb(float tickDelta) {
        float remaining = Providers.feature == null ? 0f
                : Providers.feature.player().getShieldCooldownRemaining(tickDelta);
        return colorForRemaining(remaining, INTERPOLATE.value);
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static int lerp(int from, int to, float amount) {
        float t = clamp(amount, 0f, 1f);
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
