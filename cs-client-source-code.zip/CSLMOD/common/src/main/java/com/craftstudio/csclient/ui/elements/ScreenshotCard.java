package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.screenshot.ScreenshotRepository;
import com.craftstudio.csclient.screenshot.ScreenshotThumbnailCache;
import com.craftstudio.csclient.screenshot.ScreenshotThumbnailCache.Thumbnail;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Touch-sized local screenshot thumbnail card. */
public final class ScreenshotCard extends Element {
    private final ScreenshotRepository.Entry entry;
    private final Runnable action;
    private float hover;

    public ScreenshotCard(ScreenshotRepository.Entry entry, Runnable action) {
        this.entry = entry;
        this.action = action;
        dimensions(250, 158);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.22f;
        int border = hover > 0.15f ? Theme.withAlpha(220, Theme.ACCENT.value) : 0x756C7782;
        scope.drawRoundedRectangle(0, 0, width, height, 8, 0xEC10161C);
        scope.drawRoundedBorder(0, 0, width, height, 8, border);

        int imageHeight = height - 29;
        Thumbnail thumbnail = ScreenshotThumbnailCache.request(entry, width - 8, imageHeight - 8);
        if (thumbnail == null) {
            scope.drawText(0.36f, "LOADING PREVIEW…", 12, imageHeight / 2, Theme.FONT.value, 0xFF8E99A4);
        } else if (thumbnail.failed() || thumbnail.texture() == null) {
            scope.drawText(0.36f, "PREVIEW UNAVAILABLE", 12, imageHeight / 2, Theme.FONT.value, 0xFFFF8B94);
        } else {
            float scale = Math.min((width - 8) / (float) thumbnail.width(),
                    (imageHeight - 8) / (float) thumbnail.height());
            int drawWidth = Math.max(1, Math.round(thumbnail.width() * scale));
            int drawHeight = Math.max(1, Math.round(thumbnail.height() * scale));
            scope.drawTexture(thumbnail.texture(), (width - drawWidth) / 2, (imageHeight - drawHeight) / 2,
                    0, 0, drawWidth, drawHeight);
        }

        scope.drawRectangle(1, imageHeight, width - 2, height - imageHeight - 1, 0xE8182027);
        String name = entry.name().length() > 30 ? entry.name().substring(0, 27) + "…" : entry.name();
        scope.drawText(0.34f, name, 9, imageHeight + 10, Theme.FONT.value, Theme.FOREGROUND.value);
    }

    @Override public void click(int mouseX, int mouseY) { if (action != null) action.run(); }
}
