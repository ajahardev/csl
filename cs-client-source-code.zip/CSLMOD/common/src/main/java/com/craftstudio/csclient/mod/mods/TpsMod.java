package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;

/** Event-driven server TPS metric with healthy/warning/low states. */
public class TpsMod extends Mod implements HudMod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty adaptiveColor = Property.bool(true);
    private static final ModLayout layout = new ModLayout(64, 22);
    private static final int SAMPLE_COUNT = 2;
    private static final double[] samples = new double[SAMPLE_COUNT];

    static { java.util.Arrays.fill(samples, 20.0); }

    private static long lastWorldAge = -1L;
    private static long lastRealTime = -1L;
    private static double currentTps = 20.0;
    private static int sampleIndex;
    private static int samplesFilled = SAMPLE_COUNT;
    private static double lastDrawnTps = -1.0;
    private static String lastTpsText = FastNumberFormatter.fixed(20.0, 1);
    private static final com.craftstudio.csclient.mod.HudDirtyTracker dirtyTracker =
            new com.craftstudio.csclient.mod.HudDirtyTracker();

    public TpsMod() {
        super(new ModSpec("TPS Display", "tps")
                        .description("Shows measured server tick health")
                        .version("v1.0.0").tags("Utility", "HUD"),
                enabled.named("Enabled"),
                adaptiveColor.named("Adaptive TPS Colour"),
                layout.prop());
    }

    public static void onTimePacket(long worldAge) {
        long now = System.currentTimeMillis();
        if (lastWorldAge != -1L && lastRealTime != -1L) {
            long tickDelta = worldAge - lastWorldAge;
            long timeDelta = now - lastRealTime;
            if (timeDelta > 0L && tickDelta > 0L) {
                double sample = Math.min((tickDelta / (double) timeDelta) * 1000.0, 20.0);
                samples[sampleIndex++ % SAMPLE_COUNT] = sample;
                samplesFilled = Math.min(samplesFilled + 1, SAMPLE_COUNT);
                double sum = 0.0;
                for (int i = 0; i < samplesFilled; i++) sum += samples[i];
                currentTps = sum / samplesFilled;
            }
        }
        lastWorldAge = worldAge;
        lastRealTime = now;
    }

    public static void reset() {
        lastWorldAge = lastRealTime = -1L;
        currentTps = 20.0;
        sampleIndex = 0;
        samplesFilled = SAMPLE_COUNT;
        java.util.Arrays.fill(samples, 20.0);
    }

    @Override public void renderHud(RenderScope scope) {
        double tps = currentTps;
        if (tps != lastDrawnTps) {
            lastTpsText = FastNumberFormatter.fixed(tps, 1);
            lastDrawnTps = tps;
        }
        int color = tpsColor(tps);
        // Frame skip: TPS moves slowly, so most frames draw nothing.
        if (!dirtyTracker.dirty(lastTpsText, color, layout)) return;
        HudTextRenderer.drawMetric(scope, layout, "TPS", lastTpsText, "", color,
                HudTextRenderer.MetricKind.SERVER);
    }

    @Override public void renderDummy(RenderScope scope) {
        double tps = 20.0;
        int color = tpsColor(tps);
        HudTextRenderer.drawMetric(scope, layout, "TPS", FastNumberFormatter.fixed(tps, 1), "", color,
                HudTextRenderer.MetricKind.SERVER);
    }

    private static int tpsColor(double tps) {
        return !adaptiveColor.value ? 0xFF55E37A
                : tps >= 18.0 ? 0xFF55E37A : tps >= 14.0 ? 0xFFF0BF55 : 0xFFF05F68;
    }

    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
