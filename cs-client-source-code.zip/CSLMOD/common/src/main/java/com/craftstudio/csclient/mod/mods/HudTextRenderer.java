package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Shared low-allocation typography for genuinely distinct HUD presets. */
public final class HudTextRenderer {
    public enum MetricKind { SIGNAL, PERFORMANCE, SERVER }

    private HudTextRenderer() { }

    public static void draw(RenderScope scope, ModLayout layout, String text) {
        String safe = text == null ? "" : text;
        int style = clampStyle(layout.style.value);
        float scale = switch (style) {
            case 1 -> 0.48f; // Feather: compact and airy
            case 2 -> 0.52f; // Lunar: denser/bolder
            case 3 -> 0.50f; // CS: balanced graphite typography
            default -> 0.50f; // Minecraft
        };
        int lines = lineCount(safe);
        int textWidth = maxLineWidth(safe, layout.font.value);
        int left = switch (style) {
            case 1 -> 8;
            case 2 -> 6;
            case 3 -> 10;
            default -> 3;
        };
        int right = switch (style) {
            case 1 -> 8;
            case 2 -> 6;
            case 3 -> 8;
            default -> 3;
        };
        int lineHeight = style == 0 ? 14 : style == 2 ? 16 : 17;
        layout.width = Math.max(24, (int) Math.ceil(textWidth * scale) + left + right);
        layout.height = Math.max(lineHeight, lineHeight * lines);

        int y = style == 0 ? 2 : style == 2 ? 3 : 4;
        scope.drawText(scale, safe, left, y, layout.font.value, layout.fgColor.value);
    }

    /** Value/label layout used by FPS, Ping and TPS instead of generic text chips. */
    public static void drawMetric(RenderScope scope, ModLayout layout, String label,
            String value, String unit, int qualityColor, MetricKind kind) {
        String safeLabel = label == null ? "" : label.toUpperCase();
        String safeValue = value == null ? "0" : value;
        String safeUnit = unit == null ? "" : unit;
        int style = clampStyle(layout.style.value);
        int font = layout.font.value;

        switch (style) {
            case 0 -> {
                float labelScale = 0.44f;
                float valueScale = 0.52f;
                String prefix = safeLabel + ": ";
                int prefixWidth = Math.round(Fonts.getWidth(prefix, font) * labelScale);
                int valueWidth = Math.round(Fonts.getWidth(safeValue, font) * valueScale);
                int unitWidth = safeUnit.isEmpty() ? 0 : Math.round(Fonts.getWidth(" " + safeUnit, font) * labelScale);
                layout.width = Math.max(34, 5 + prefixWidth + valueWidth + unitWidth);
                layout.height = 15;
                scope.drawText(labelScale, prefix, 2, 3, font, layout.fgColor.value);
                scope.drawText(valueScale, safeValue, 2 + prefixWidth, 2, font, qualityColor);
                if (!safeUnit.isEmpty()) scope.drawText(labelScale, " " + safeUnit,
                        2 + prefixWidth + valueWidth, 3, font, layout.fgColor.value);
            }
            case 1 -> {
                int iconWidth = kind == MetricKind.SIGNAL ? 14 : 9;
                int valueWidth = Math.round(Fonts.getWidth(safeValue, font) * 0.58f);
                int unitWidth = safeUnit.isEmpty() ? 0 : Math.round(Fonts.getWidth(safeUnit, font) * 0.27f) + 3;
                layout.width = Math.max(54, 7 + iconWidth + valueWidth + unitWidth + 8);
                layout.height = 22;
                drawMetricIcon(scope, kind, 5, 5, qualityColor);
                int valueX = 7 + iconWidth;
                scope.drawText(0.58f, safeValue, valueX, 4, font, qualityColor);
                if (!safeUnit.isEmpty()) scope.drawText(0.27f, safeUnit,
                        valueX + valueWidth + 3, 10, font, layout.fgColor.value);
                scope.drawText(0.22f, safeLabel, valueX, 16, font, withAlpha(170, layout.fgColor.value));
            }
            case 2 -> {
                int valueWidth = Math.round(Fonts.getWidth(safeValue, font) * 0.56f);
                int unitWidth = safeUnit.isEmpty() ? 0 : Math.round(Fonts.getWidth(" " + safeUnit, font) * 0.29f);
                int labelWidth = Math.round(Fonts.getWidth(safeLabel, font) * 0.25f);
                layout.width = Math.max(50, Math.max(labelWidth + 12, valueWidth + unitWidth + 12));
                layout.height = 26;
                scope.drawText(0.25f, safeLabel, 6, 4, font, withAlpha(190, layout.fgColor.value));
                scope.drawText(0.56f, safeValue, 6, 11, font, qualityColor);
                if (!safeUnit.isEmpty()) scope.drawText(0.29f, " " + safeUnit,
                        6 + valueWidth, 16, font, layout.fgColor.value);
                scope.drawRectangle(6, 24, Math.max(10, layout.width - 12), 1, withAlpha(175, qualityColor));
            }
            default -> {
                int valueWidth = Math.round(Fonts.getWidth(safeValue, font) * 0.59f);
                int unitWidth = safeUnit.isEmpty() ? 0 : Math.round(Fonts.getWidth(safeUnit, font) * 0.25f) + 3;
                layout.width = Math.max(58, 14 + valueWidth + unitWidth + 8);
                layout.height = 23;
                scope.drawRoundedRectangle(4, 5, 3, 13, 2, qualityColor);
                scope.drawText(0.59f, safeValue, 12, 4, font, qualityColor);
                if (!safeUnit.isEmpty()) scope.drawText(0.25f, safeUnit,
                        12 + valueWidth + 3, 10, font, layout.fgColor.value);
                scope.drawText(0.22f, safeLabel, 12, 17, font, withAlpha(165, layout.fgColor.value));
            }
        }
    }

    private static void drawMetricIcon(RenderScope scope, MetricKind kind, int x, int y, int color) {
        if (kind == MetricKind.SIGNAL) {
            scope.drawRectangle(x, y + 8, 2, 3, withAlpha(120, color));
            scope.drawRectangle(x + 4, y + 5, 2, 6, withAlpha(180, color));
            scope.drawRectangle(x + 8, y + 1, 2, 10, color);
        } else if (kind == MetricKind.PERFORMANCE) {
            scope.drawRectangle(x + 3, y, 3, 6, color);
            scope.drawRectangle(x + 1, y + 5, 5, 3, color);
            scope.drawRectangle(x, y + 7, 3, 5, color);
        } else {
            scope.drawRoundedRectangle(x + 1, y + 3, 8, 8, 4, withAlpha(80, color));
            scope.drawRoundedRectangle(x + 3, y + 5, 4, 4, 2, color);
        }
    }

    private static int lineCount(String text) {
        int count = 1;
        for (int i = 0; i < text.length(); i++) if (text.charAt(i) == '\n') count++;
        return count;
    }

    private static int maxLineWidth(String text, int font) {
        if (text.indexOf('\n') < 0) return Fonts.getWidth(text, font);
        int max = 0, start = 0;
        while (start <= text.length()) {
            int end = text.indexOf('\n', start);
            if (end < 0) end = text.length();
            max = Math.max(max, Fonts.getWidth(text.substring(start, end), font));
            if (end == text.length()) break;
            start = end + 1;
        }
        return max;
    }

    private static int clampStyle(int style) { return Math.max(0, Math.min(3, style)); }
    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }
}
