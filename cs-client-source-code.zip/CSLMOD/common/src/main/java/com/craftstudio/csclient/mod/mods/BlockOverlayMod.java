package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/** Customizes Minecraft's targeted-block outline color and thickness. */
public class BlockOverlayMod extends Mod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final ColorProperty outlineColor = Property.color(0xFFE6E9ED);
    private static final IntProperty lineWidthTenths = Property.integer(18);

    public BlockOverlayMod() {
        super(new ModSpec("Block Overlay", "blockoverlay")
                        .description("Custom block outline color and thickness")
                        .version("v1.0.0").tags("Visuals", "Utility"),
                enabled.named("Enabled"), outlineColor.named("Outline color"),
                lineWidthTenths.named("Line width ×10"));
    }

    public static boolean isActive() { return enabled.value; }
    public static int color() { return outlineColor.value; }
    public static float lineWidth() { return Math.max(0.5f, lineWidthTenths.value / 10.0f); }

    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
