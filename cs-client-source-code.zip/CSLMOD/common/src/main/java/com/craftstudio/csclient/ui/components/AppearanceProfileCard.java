package com.craftstudio.csclient.ui.components;

import java.util.function.Supplier;

import com.craftstudio.csclient.account.LocalSkinManager;
import com.craftstudio.csclient.account.LocalSkinManager.CapeRecord;
import com.craftstudio.csclient.account.LocalSkinManager.SkinRecord;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;
import com.craftstudio.csclient.ui.resources.SkinHeadRenderer;

/**
 * Compact animated identity/appearance summary used only by CS Identity's
 * Skin + Cape page. It makes the active profile state obvious without exposing
 * credential information.
 */
public final class AppearanceProfileCard extends Element {
    private final Supplier<String> username;
    private final Supplier<Boolean> localProfile;
    private final Supplier<Boolean> launcherOffline;
    private final Supplier<SkinRecord> skin;
    private final Supplier<CapeRecord> cape;
    private final Supplier<String> storage;
    private float hover;

    public AppearanceProfileCard(Supplier<String> username, Supplier<Boolean> localProfile,
            Supplier<Boolean> launcherOffline, Supplier<SkinRecord> skin,
            Supplier<CapeRecord> cape, Supplier<String> storage) {
        this.username = username;
        this.localProfile = localProfile;
        this.launcherOffline = launcherOffline;
        this.skin = skin;
        this.cape = cape;
        this.storage = storage;
        dimensions(280, 156);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        boolean local = Boolean.TRUE.equals(localProfile.get());
        boolean offline = Boolean.TRUE.equals(launcherOffline.get());
        boolean eligible = LocalSkinManager.isActiveAppearanceProfile();
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.20f;
        if (Math.abs(target - hover) < 0.002f) hover = target;

        int fill = blend(0xD9141A20, eligible ? 0xE51E2931 : 0xD8231A1E, hover * 0.55f);
        int outline = eligible
                ? blend(Theme.withAlpha(105, Theme.ACCENT.value), Theme.FOREGROUND.value, hover)
                : blend(0x8C80464E, 0xDCE07581, hover);
        scope.drawRoundedRectangle(0, 0, width, height, 7, fill);
        scope.drawRoundedBorder(0, 0, width, height, 7, outline);

        int accent = eligible ? Theme.ACCENT.value : 0xFFE07581;
        scope.drawRoundedRectangle(12, 13, 34, 34, 6, Theme.withAlpha(220, accent));
        if (eligible) SkinHeadRenderer.draw(scope, 14, 15, 30, Theme.ACCENT_FG.value);
        else scope.drawTexture(Textures.LOCK, 21, 22, 0, 0, 16, 16, Theme.FOREGROUND.value);

        String name = safe(username.get(), "PLAYER").toUpperCase();
        scope.drawText(0.47f, trim(name, width - 72, 0.47f), 57, 17,
                Theme.FONT.value, Theme.FOREGROUND.value);
        String state = local ? "CS LOCAL PROFILE"
                : offline ? "LAUNCHER OFFLINE PROFILE"
                        : eligible ? "LAUNCHER PROFILE" : "PROFILE UNAVAILABLE";
        scope.drawText(0.25f, trim(state, width - 72, 0.25f), 57, 38,
                Theme.FONT.value, eligible ? Theme.PRIMARY_FG.value : 0xFFE89AA4);

        SkinRecord skinRecord = skin.get();
        CapeRecord capeRecord = cape.get();
        drawAssetChip(scope, 12, 61, width - 24, "SKIN",
                skinRecord == null ? "ORIGINAL" : "LOCAL READY", Textures.IMAGE,
                skinRecord != null && eligible);
        drawAssetChip(scope, 12, 94, width - 24, "CAPE",
                capeRecord == null ? "ORIGINAL / NONE" : "LOCAL READY", Textures.CAPE,
                capeRecord != null && eligible);

        String path = trim(safe(storage.get(), "profiles"), width - 24, 0.22f);
        scope.drawText(0.22f, path, 12, height - 15, Theme.FONT.value,
                Theme.withAlpha(145, Theme.PRIMARY_FG.value));
    }

    private static void drawAssetChip(RenderScope scope, int x, int y, int width,
            String label, String value, com.craftstudio.csclient.common.ref.asset.IdentifierRef icon,
            boolean active) {
        int fill = active ? Theme.withAlpha(100, Theme.ACCENT.value) : 0x9A171D23;
        int foreground = active ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value;
        scope.drawRoundedRectangle(x, y, width, 26, 5, fill);
        scope.drawTexture(icon, x + 9, y + 7, 0, 0, 12, 12, foreground);
        scope.drawText(0.27f, label, x + 29, y + 9, Theme.FONT.value, foreground);
        int valueWidth = Math.round(Fonts.getWidth(value, Theme.FONT.value) * 0.25f);
        scope.drawText(0.25f, value, x + width - valueWidth - 10, y + 9,
                Theme.FONT.value, active ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);
    }

    private static String safe(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String trim(String value, int maxWidth, float scale) {
        if (Fonts.getWidth(value, Theme.FONT.value) * scale <= maxWidth) return value;
        int end = value.length();
        while (end > 1 && Fonts.getWidth(value.substring(0, end) + "…", Theme.FONT.value) * scale > maxWidth) {
            end--;
        }
        return value.substring(0, Math.max(1, end)) + "…";
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255)
                + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255)
                + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255)
                + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
