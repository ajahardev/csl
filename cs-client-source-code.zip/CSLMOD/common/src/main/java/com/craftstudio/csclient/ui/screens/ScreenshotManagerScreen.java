package com.craftstudio.csclient.ui.screens;

import java.util.List;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.screenshot.ScreenshotRepository;
import com.craftstudio.csclient.screenshot.ScreenshotRepository.Entry;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.Scroll;
import com.craftstudio.csclient.ui.elements.ScreenshotCard;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

/** Local-only gallery for screenshots belonging to the active game directory/profile. */
public final class ScreenshotManagerScreen extends CSClientScreen {
    private static final int PAGE_SIZE = 60;
    private final CSClientScreen parent;
    private int page;

    public ScreenshotManagerScreen(CSClientScreen parent) {
        super("Screenshot Manager");
        this.parent = parent == null ? new TitleMenu() : parent;
        backgroundBlur = 5;
    }

    @Override
    public void ui() {
        List<Entry> entries = ScreenshotRepository.list();
        int panelWidth = Math.min(1000, width - 28);
        int panelHeight = Math.min(510, height - 24);
        int x = (width - panelWidth) / 2;
        int y = (height - panelHeight) / 2;
        draw(new Panel(0xF20E1419).dimensions(panelWidth, panelHeight).position(x, y));
        int pages = Math.max(1, (entries.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(page, pages - 1));
        draw(new IconButton(Textures.BACK, this::goBack).dimensions(38, 38).position(x + 13, y + 13));
        draw(new IconButton(Textures.LEFT, this::previousPage).dimensions(38, 38).position(x + panelWidth - 139, y + 13));
        draw(new IconButton(Textures.RIGHT, this::nextPage).dimensions(38, 38).position(x + panelWidth - 95, y + 13));
        draw(new IconButton(Textures.RESET, this::refresh).dimensions(38, 38).position(x + panelWidth - 51, y + 13));
        draw(new Text("SCREENSHOT MANAGER").scale(0.72f).position(x + 64, y + 13));
        draw(new Text(entries.size() + " PNG FILES  •  PAGE " + (page + 1) + "/" + pages
                + "  •  ACTIVE PROFILE ONLY  •  LOCAL STORAGE")
                .color(Theme.ACCENT.value).scale(0.28f).position(x + 65, y + 42));

        int listY = y + 65;
        Scroll gallery = new Scroll(10);
        gallery.dimensions(panelWidth - 20, panelHeight - 78).position(x + 10, listY);
        draw(gallery);

        if (entries.isEmpty()) {
            gallery.draw(new Text("NO SCREENSHOTS IN THIS PROFILE").scale(0.48f).position(20, 28));
            String folder = ScreenshotRepository.directory().toString();
            if (folder.length() > 100) folder = "…" + folder.substring(folder.length() - 99);
            gallery.draw(new Text(folder).scale(0.28f).position(20, 58));
            return;
        }

        int available = panelWidth - 44;
        int columns = available >= 810 ? 3 : available >= 530 ? 2 : 1;
        int gap = 12;
        int cardWidth = (available - gap * (columns - 1)) / columns;
        int cardHeight = Math.max(126, Math.min(168, Math.round(cardWidth * 0.62f)));
        int start = page * PAGE_SIZE;
        int end = Math.min(entries.size(), start + PAGE_SIZE);
        for (int i = start; i < end; i++) {
            Entry entry = entries.get(i);
            int visibleIndex = i - start;
            int column = visibleIndex % columns;
            int row = visibleIndex / columns;
            ScreenshotCard card = new ScreenshotCard(entry,
                    () -> Providers.csClient.getClient().setScreen(new ScreenshotPreviewScreen(this, entry)));
            gallery.draw(card.dimensions(cardWidth, cardHeight)
                    .position(column * (cardWidth + gap), row * (cardHeight + gap)));
        }
    }

    private void refresh() { init(); }
    private void previousPage() { if (page > 0) { page--; init(); } }
    private void nextPage() {
        int pages = Math.max(1, (ScreenshotRepository.list().size() + PAGE_SIZE - 1) / PAGE_SIZE);
        if (page + 1 < pages) { page++; init(); }
    }
    private void goBack() { Providers.csClient.getClient().setScreen(parent); }

    @Override public boolean shouldPause() { return true; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            goBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
