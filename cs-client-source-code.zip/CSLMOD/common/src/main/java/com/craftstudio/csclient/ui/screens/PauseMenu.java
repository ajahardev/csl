package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef.MinecraftScreen;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.Fade;
import com.craftstudio.csclient.ui.anim.PopFade;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.elements.FeatherStackButton;
import com.craftstudio.csclient.common.replay.ReplayModBridge;
import com.craftstudio.csclient.ui.elements.ImageTexture;
import com.craftstudio.csclient.ui.elements.HomeIconTile;
import com.craftstudio.csclient.ui.elements.ProfileButton;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

/** Feather-structure Escape menu with original CS branding and one accent color. */
public class PauseMenu extends CSClientScreen {
    public PauseMenu() {
        super("CS Client V1 Game Menu");
        backgroundBlur = 3;
        backgroundOpacity = 0.96f;
    }

    @Override
    public void ui() {
        int centerX = width / 2;
        int menuWidth = Math.min(310, width - 72);
        int x = centerX - menuWidth / 2;
        int top = Math.max(18, height / 2 - 211);
        String username = Providers.csClient.getClient().getUsername();
        if (username == null || username.isBlank()) username = "PLAYER";
        boolean hasModMenu = Providers.csClient.getClient().isModLoaded("modmenu");
        boolean friends = Providers.csClient.getClient().supportsNativeFriends();
        boolean localLanAvailable = Providers.csClient.getClient().canOpenNativeWorldHost();
        int loadedMods = Providers.csClient.getClient().getLoadedMods().size();

        // Feather uses a large faint brand silhouette behind a narrow center stack.
        ImageTexture watermark = new ImageTexture(Textures.LOGO);
        watermark.dimensions(300, 300).position(Math.max(18, centerX - 520), height / 2 - 150);
        watermark.opacity = 0.075f;
        watermark.animation(new Fade(AnimationConfig.pauseMenu));
        draw(watermark);

        int profileX = width - 194;
        draw(new ProfileButton(username,
                () -> Providers.csClient.getClient().setScreen(
                        new LocalAccountsScreen(LocalAccountsScreen.Tab.ACCOUNTS, new PauseMenu())))
                .dimensions(176, 38).position(profileX, 18)
                .animation(new SlideFade(AnimationConfig.pauseMenu, 8)));
        int utilityX = profileX - 47;
        if (friends) {
            draw(new HomeIconTile(Textures.FRIENDS,
                    () -> Providers.csClient.getClient().openNativeFriends(new PauseMenu()))
                    .dimensions(38, 38).position(utilityX, 18)
                    .animation(new SlideFade(AnimationConfig.pauseMenu, 7)));
        }

        int lockupWidth = 218;
        int logoX = centerX - lockupWidth / 2;
        draw(new ImageTexture(Textures.LOGO).dimensions(48, 48).position(logoX, top)
                .animation(pop(20)));
        draw(new ImageTexture(Textures.LOGO_TEXT).dimensions(154, 15)
                .position(logoX + 64, top + 10).animation(pop(35)));
        draw(new Text("GAME MENU  •  " + ModManager.MODS.size() + " MODULES")
                .scale(0.25f).position(logoX + 65, top + 34).animation(fade(45)));

        int row = top + 66;
        addButton(x, row, menuWidth, Textures.RESUME, "BACK TO GAME", false, false,
                provider::close, 60);
        row += 50;
        addButton(x, row, menuWidth, Textures.SLIDERS, "CS SETTINGS", true, false,
                () -> Providers.csClient.getClient().setScreen(new ShiftMenu()), 78);
        row += 50;
        // CS Worlds hosting was removed; the slot stays as a disabled teaser.
        int splitGap = 8;
        int splitWidth = (menuWidth - splitGap) / 2;
        draw(new FeatherStackButton(Textures.HOST_WORLD, "CS WORLDS  •  COMING SOON", false, false, null)
                .dimensions(splitWidth, 42).position(x, row).animation(slide(-7, 88)));
        Runnable openLan = localLanAvailable
                ? () -> Providers.csClient.getClient().openNativeWorldHost(new PauseMenu())
                : null;
        draw(new FeatherStackButton(Textures.HOST_WORLD, "OPEN TO LAN", false, false, openLan)
                .dimensions(menuWidth - splitWidth - splitGap, 42)
                .position(x + splitWidth + splitGap, row).animation(slide(7, 90)));
        row += 50;
        addButton(x, row, menuWidth, Textures.MODS_TAB,
                (hasModMenu ? "MOD MENU" : "INSTALLED MODS") + "  •  " + loadedMods,
                false, false, this::openMods, 96);
        row += 50;
        // Replay Mod's default menu, opened exactly as Replay Mod provides it.
        boolean replayMod = ReplayModBridge.isLoaded();
        if (replayMod) {
            addButton(x, row, menuWidth, Textures.IMAGE, "REPLAY MOD", false, false,
                    () -> ReplayModBridge.open(Providers.csClient.getClient()), 105);
            row += 50;
        }
        int replayShift = replayMod ? 9 : 0;
        addButton(x, row, menuWidth, Textures.IMAGE, "SCREENSHOT MANAGER", false, false,
                () -> Providers.csClient.getClient().setScreen(new ScreenshotManagerScreen(new PauseMenu())), 105 + replayShift);
        row += 50;
        addButton(x, row, menuWidth, Textures.SETTINGS, "OPTIONS", false, false,
                () -> Providers.csClient.getClient().setScreen(MinecraftScreen.Options), 114 + replayShift);
        row += 50;
        addButton(x, row, menuWidth, Textures.CLOSE, "DISCONNECT / QUIT TO TITLE", false, true,
                () -> Providers.csClient.getClient().setScreen(MinecraftScreen.Disconnect), 132 + replayShift);

        draw(new Text("ESC  •  BACK TO GAME").scale(0.24f).position(18, height - 18)
                .animation(fade(150)));
        draw(new Text("CS CLIENT V1").scale(0.24f).position(width - 106, height - 18)
                .animation(fade(150)));
    }

    private void openMods() {
        if (Providers.csClient.getClient().isModLoaded("modmenu")) {
            Providers.csClient.getClient().openExternalModMenu();
        } else {
            Providers.csClient.getClient().setScreen(new InstalledModsScreen(new PauseMenu()));
        }
    }

    private void addButton(int x, int y, int width,
            com.craftstudio.csclient.common.ref.asset.IdentifierRef icon, String label,
            boolean primary, boolean danger, Runnable action, int delay) {
        draw(new FeatherStackButton(icon, label, primary, danger, action)
                .dimensions(width, 42).position(x, y).animation(slide(-7, delay)));
    }

    @Override public boolean shouldPause() { return true; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            provider.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private static PopFade pop(int delay) {
        PopFade value = new PopFade(AnimationConfig.pauseMenu);
        value.delay = delay;
        return value;
    }
    private static SlideFade slide(int offset, int delay) {
        SlideFade value = new SlideFade(AnimationConfig.pauseMenu, offset);
        value.delay = delay;
        return value;
    }
    private static Fade fade(int delay) {
        Fade value = new Fade(AnimationConfig.pauseMenu);
        value.delay = delay;
        return value;
    }
}
