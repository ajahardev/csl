package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.WorldFeature.BlockInfo;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Jade/WAILA-inspired basic targeted block information HUD. */
public class BlockInfoMod extends Mod implements HudMod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty SHOW_ID = Property.bool(true);
    private static final BoolProperty SHOW_DETAIL = Property.bool(true);
    private static final ModLayout LAYOUT = new ModLayout(150, 42);

    public BlockInfoMod() {
        super(new ModSpec("Block Information", "blockinfo")
                        .description("Shows the name and basic details of the block under your crosshair")
                        .version("v1.0.0").tags("World", "HUD", "Utility")
                        .requires(Providers.feature::world),
                ENABLED.named("Enabled"), SHOW_ID.named("Show Block ID"),
                SHOW_DETAIL.named("Show Basic Detail"), LAYOUT.prop());
        LAYOUT.bgColor.value = 0xE014181E;
        LAYOUT.radius.value = 8;
    }

    @Override public boolean shouldRenderHud() {
        return Providers.feature.world().hasWorld()
                && !BlockInfo.EMPTY.equals(Providers.feature.world().getTargetBlockInfo());
    }

    @Override public void renderHud(RenderScope scope) {
        draw(scope, Providers.feature.world().getTargetBlockInfo(),
                Providers.feature.world().getTargetBlockIcon());
    }

    @Override public void renderDummy(RenderScope scope) {
        draw(scope, new BlockInfo("DIAMOND ORE", "minecraft:diamond_ore", "Hardness 3.0 • Tool required"), null);
    }

    private void draw(RenderScope scope, BlockInfo info, ItemStackRef icon) {
        String name = info == null ? "NO BLOCK" : info.name();
        String second = SHOW_ID.value ? info.id() : SHOW_DETAIL.value ? info.detail() : "";
        String third = SHOW_ID.value && SHOW_DETAIL.value ? info.detail() : "";
        int copyX = 50;
        int width = Math.max(158, Math.round(Fonts.getWidth(name, LAYOUT.font.value) * 0.52f) + copyX + 14);
        if (!second.isBlank()) width = Math.max(width, Math.round(Fonts.getWidth(second, LAYOUT.font.value) * 0.31f) + copyX + 14);
        if (!third.isBlank()) width = Math.max(width, Math.round(Fonts.getWidth(third, LAYOUT.font.value) * 0.31f) + copyX + 14);
        LAYOUT.width = Math.min(278, width);
        LAYOUT.height = third.isBlank() ? 44 : 57;

        scope.drawRoundedRectangle(9, 9, 32, 32, 7, 0xB51A2027);
        scope.drawRoundedBorder(9, 9, 32, 32, 7, Theme.withAlpha(100, Theme.ACCENT.value));
        if (icon != null && !icon.isEmpty()) {
            scope.drawItem(icon, 17, 17);
        } else {
            scope.drawRectangle(18, 18, 14, 14, 0xFF59636C);
        }
        scope.drawText(0.52f, name, copyX, 9, LAYOUT.font.value, LAYOUT.fgColor.value);
        if (!second.isBlank()) scope.drawText(0.31f, second, copyX, 27, LAYOUT.font.value,
                Theme.withAlpha(165, LAYOUT.fgColor.value));
        if (!third.isBlank()) scope.drawText(0.31f, third, copyX, 41, LAYOUT.font.value,
                Theme.withAlpha(135, LAYOUT.fgColor.value));
    }

    @Override public ModLayout getDimensions() { return LAYOUT; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
