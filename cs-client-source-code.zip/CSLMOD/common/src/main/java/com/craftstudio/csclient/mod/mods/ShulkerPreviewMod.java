package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * Configuration gate for the inventory shulker content tooltip.
 * Shulker container-preview behavior is adapted from KGriffon's MIT-licensed
 * Shulker Preview project; CS rendering/configuration remains version-specific.
 */
public class ShulkerPreviewMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty REQUIRE_SHIFT = Property.bool(false);
    private static final IntProperty SCALE = Property.integer(100);
    private static final SelectProperty POSITION = Property.select(0, "Auto", "Left", "Right");
    private static final SelectProperty STYLE = Property.select(0, "CS Graphite", "Vanilla", "Compact");

    public ShulkerPreviewMod() {
        super(new ModSpec("Shulker Box Preview", "shulkerpreview")
                        .description("Shows shulker contents in a clean inventory hover preview")
                        .version("v1.0.0").tags("Inventory", "Utility"),
                ENABLED.named("Enabled"), REQUIRE_SHIFT.named("Require Shift"),
                SCALE.named("Preview Scale %"), POSITION.named("Preview Position"),
                STYLE.named("Preview Style"));
    }

    public static boolean isActive() { return ENABLED.value; }
    public static boolean requireShift() { return REQUIRE_SHIFT.value; }
    public static float scale() { return Math.max(0.6f, Math.min(1.6f, SCALE.value / 100f)); }
    public static int position() { return POSITION.value; }
    public static int style() { return STYLE.value; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
