package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * Compact lower first-person shield transform; native/resource-pack texture is untouched.
 * The Y offset intentionally leaves the smaller shield on-screen instead of moving it below view.
 */
public class LowShieldMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(false);

    public LowShieldMod() {
        super(new ModSpec("Low Shield", "lowshield")
                        .description("Shows a smaller, lower first-person shield without hiding its texture")
                        .version("v2.2.0").tags("Visuals", "PvP"),
                ENABLED.named("Enabled"));
    }

    public static boolean isActive() { return ENABLED.value; }
    /** Conservative downward shift: compact but still clearly visible in the lower-left view. */
    public static float lowerOffset() { return -0.18f; }
    /** Keep the requested small shield silhouette while retaining readable coverage. */
    public static float fixedScale() { return 0.82f; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
