package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/** Configuration and cross-version formatting for the world-space TNT timer. */
public class TntTimerMod extends Mod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty preciseTenths = Property.bool(true);
    private static final BoolProperty pulseFinalSecond = Property.bool(true);
    private static final IntProperty maxDistance = Property.integer(48);
    private static final ColorProperty safeColor = Property.color(0xFFFFFFFF);
    private static final ColorProperty warningColor = Property.color(0xFFFFB84D);
    private static final ColorProperty dangerColor = Property.color(0xFFFF4658);

    public TntTimerMod() {
        super(new ModSpec("TNT Timer", "tnttimer")
                        .description("Color-coded fuse countdown floating above every primed TNT")
                        .version("v1.0.0").tags("World", "Utility", "Minigames"),
                enabled.named("Enabled"),
                preciseTenths.named("Show tenths of a second"),
                pulseFinalSecond.named("Pulse during final second"),
                maxDistance.named("Maximum render distance"),
                safeColor.named("More than two seconds"),
                warningColor.named("Final two seconds"),
                dangerColor.named("Final second"));
    }

    public static boolean shouldShow(float fuseTicks, double squaredDistance) {
        int distance = Math.max(4, maxDistance.value);
        return enabled.value && fuseTicks > 0f
                && squaredDistance <= distance * (double) distance;
    }

    public static String format(float fuseTicks) {
        float seconds = Math.max(0f, fuseTicks / 20f);
        return preciseTenths.value
                ? FastNumberFormatter.fixed(seconds, 1) + "s"
                : Math.max(1, (int) Math.ceil(seconds)) + "s";
    }

    public static int color(float fuseTicks) {
        float seconds = fuseTicks / 20f;
        int base = seconds <= 1f ? dangerColor.value
                : seconds <= 2f ? warningColor.value : safeColor.value;
        if (seconds <= 1f && pulseFinalSecond.value) {
            float amount = (float) ((Math.sin(System.currentTimeMillis() / 85.0) + 1.0) * 0.16);
            return blend(base, 0xFFFFFFFF, amount);
        }
        return base;
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
