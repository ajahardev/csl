package com.craftstudio.csclient.mod.mods;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * ClockMod displays the real-world time as a HUD element.
 * No engine access is required; {@link LocalTime} is used directly.
 */
public class ClockMod extends Mod implements HudMod {

    private static final BoolProperty enabled = Property.bool(false);
    private static final SelectProperty format = Property.select(0, "24 hour", "12 hour");
    private static final BoolProperty showSeconds = Property.bool(false);
    private static final ModLayout layout = new ModLayout(60, Fonts.getHeight());

    public ClockMod() {
        super(
                new ModSpec("Clock", "clock")
                        .description("Displays the current real-world time")
                        .version("v0.2.0")
                        .tags("Utility"),
                enabled.named("Enabled"),
                format.named("Format"),
                showSeconds.named("Show seconds"),
                layout.prop());
    }

    // ---------------------------------------------------------------
    // HudMod
    // ---------------------------------------------------------------

    @Override
    public void renderHud(RenderScope scope) {
        renderClock(scope);
    }

    @Override
    public void renderDummy(RenderScope scope) {
        renderClock(scope);
    }

    // ---------------------------------------------------------------
    // Rendering
    // ---------------------------------------------------------------

    private void renderClock(RenderScope scope) {
        String text = buildTimeString(LocalTime.now());

        HudTextRenderer.draw(scope, layout, text);
    }

    private String buildTimeString(LocalTime time) {
        return switch (format.value) {
            case 1 -> time.format(showSeconds.value
                    ? DateTimeFormatter.ofPattern("hh:mm:ss a")
                    : DateTimeFormatter.ofPattern("hh:mm a"));
            default -> time.format(showSeconds.value
                    ? DateTimeFormatter.ofPattern("HH:mm:ss")
                    : DateTimeFormatter.ofPattern("HH:mm"));
        };
    }

    // ---------------------------------------------------------------
    // Mod contract
    // ---------------------------------------------------------------

    @Override
    public ModLayout getDimensions() {
        return layout;
    }

    @Override
    public boolean isEnabled() {
        return enabled.value;
    }

    @Override
    public void onEnabled(boolean e) {
        enabled.value = e;
    }
}
