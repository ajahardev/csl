package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.ModSpec;

/** Compact Lunar-style sprint/sneak/ground status chip. */
public class MovementStatusMod extends TextHudMod {
    public MovementStatusMod() {
        super(new ModSpec("Movement Status", "movementstatus")
                .description("Shows sprint, sneak, jump and airborne state")
                .version("v1.0.0").tags("Movement", "HUD")
                .requires(Providers.feature::player), 98);
    }

    @Override
    protected String getText() {
        PlayerFeature player = Providers.feature.player();
        if (!player.hasPlayer()) return "IDLE";
        if (!player.isOnGround()) return "AIRBORNE";
        if (player.isSneaking()) return "SNEAKING";
        if (player.isSprinting()) return "SPRINTING";
        if (player.isJumpPressed()) return "JUMP";
        return "WALKING";
    }

    @Override
    protected String getDummyText() {
        return "SPRINTING";
    }
}
