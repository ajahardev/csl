package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * Client-side fluid visibility controls.
 *
 * <p>When enabled, Water and Lava can be controlled independently. The target
 * mixins only alter first-person fog/overlay rendering; they never change
 * fluid collision, damage, movement, server state, or the actual block model.</p>
 * Water/lava fog behavior is adapted from ExpensiveKoala's MIT-licensed
 * Clear Water project with independent modern FogData/overlay adapters.
 */
public class ClearFluidsMod extends Mod {
    /** Large enough to remove fluid fog while still avoiding non-finite shader values. */
    public static final float CLEAR_FOG_DISTANCE = 4096.0f;

    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty CLEAR_WATER = Property.bool(true);
    private static final BoolProperty CLEAR_LAVA = Property.bool(true);

    public ClearFluidsMod() {
        super(new ModSpec("Clear Fluids", "clearfluids")
                        .description("True inside-water/lava clarity: fog, tint and matching screen overlay")
                        .version("v1.2.0").tags("Visuals", "Utility"),
                ENABLED.named("Enabled"),
                CLEAR_WATER.named("Clear Water"),
                CLEAR_LAVA.named("Clear Lava"));
    }

    /** True only while the user has enabled full underwater clarity. */
    public static boolean shouldClearWater() {
        return ENABLED.value && CLEAR_WATER.value;
    }

    /** True only while the user has enabled full under-lava clarity. */
    public static boolean shouldClearLava() {
        return ENABLED.value && CLEAR_LAVA.value;
    }

    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
