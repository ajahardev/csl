package com.craftstudio.csclient.util;

/**
 * Pre-computed {@code Integer.toString} results for the value range HUD
 * widgets actually display (FPS, ping, TPS counts, ...). Replacing a per-frame
 * allocation with a table lookup keeps the HUD render path allocation-free.
 */
public final class IntStrings {
    private static final String[] TABLE = new String[10_000];

    static {
        for (int i = 0; i < TABLE.length; i++) TABLE[i] = Integer.toString(i);
    }

    private IntStrings() { }

    public static String of(int value) {
        if (value >= 0 && value < TABLE.length) return TABLE[value];
        return Integer.toString(value);
    }
}
