package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/** Compact connection-quality display with readable latency states. */
public class PingMod extends Mod implements HudMod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty adaptiveColor = Property.bool(true);
    private static final ModLayout layout = new ModLayout(62, 22);
    private final com.craftstudio.csclient.mod.HudDirtyTracker dirtyTracker =
            new com.craftstudio.csclient.mod.HudDirtyTracker();

    public PingMod() {
        super(new ModSpec("Ping Display", "ping")
                        .description("Shows real server latency with signal bars and quality colours")
                        .version("v1.0.0").tags("Utility", "HUD")
                        .requires(Providers.feature::network),
                enabled.named("Enabled"),
                adaptiveColor.named("Adaptive Ping Colour"),
                layout.prop());
    }

    @Override public void renderHud(RenderScope scope) {
        int ping = Providers.feature.network().getPing();
        int safe = Math.max(0, ping);
        int color = qualityColor(ping);
        String value = com.craftstudio.csclient.util.IntStrings.of(safe);
        // Frame skip: latency changes at most a few times per second, so in
        // the normal case 50+ of 60 frames draw nothing.
        if (!dirtyTracker.dirty(value, color, layout)) return;
        HudTextRenderer.drawMetric(scope, layout, "PING", value, "ms", color,
                HudTextRenderer.MetricKind.SIGNAL);
    }

    @Override public void renderDummy(RenderScope scope) {
        int ping = 42;
        int safe = Math.max(0, ping);
        int color = qualityColor(ping);
        HudTextRenderer.drawMetric(scope, layout, "PING", Integer.toString(safe), "ms", color,
                HudTextRenderer.MetricKind.SIGNAL);
    }

    private static int qualityColor(int ping) {
        if (!adaptiveColor.value) return 0xFF72D69A;
        if (ping < 0) return 0xFF9AA3AD;
        if (ping <= 80) return 0xFF55E37A;
        if (ping <= 160) return 0xFFF0BF55;
        return 0xFFF05F68;
    }

    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
