package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModRuntimeGuard;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Move-only adapter for Minecraft's exact live server boss-bar renderer. */
public final class BossBarMod extends Mod implements HudMod {
    private static final ModLayout layout = new ModLayout(182, 14);
    private static final BoolProperty MOVED = Property.bool(false);
    private static volatile long nativeBossSeenAtNanos;
    private static volatile int vanillaX;
    private static volatile int vanillaY = 3;

    public BossBarMod() {
        super(new ModSpec("Boss Bar", "bossbar")
                        .description("Moves Minecraft's exact live server boss bars from their vanilla position")
                        .version("v1.0.0").tags("HUD", "Server"),
                layout.nativeHudProp(MOVED));
        layout.renderBackground = false;
        layout.scale.value = 1.0f;
    }

    public static void updateNativeBounds(int width, int height, int defaultX, int defaultY) {
        if (width > 0) layout.width = width;
        if (height > 0) layout.height = height;
        vanillaX = defaultX;
        vanillaY = defaultY;
        if (!MOVED.value) {
            layout.x.value = defaultX;
            layout.y.value = defaultY;
            layout.scale.value = 1.0f;
        }
        nativeBossSeenAtNanos = System.nanoTime();
    }

    public static int targetX() { return layout.x.value; }
    public static int targetY() { return layout.y.value; }

    /** No transformation is applied until the user explicitly drags the native element. */
    public static boolean shouldMoveVanilla() {
        return MOVED.value && !ModRuntimeGuard.isQuarantined("Boss Bar");
    }

    /** Compatibility name: content is never replaced, only the native pose may move. */
    public static boolean shouldReplaceVanilla() { return true; }

    private static boolean nativeBossIsOnThisFrame() {
        long age = System.nanoTime() - nativeBossSeenAtNanos;
        return age >= 0L && age < 1_000_000_000L;
    }

    @Override public boolean shouldRenderHud() { return false; }
    @Override public void renderHud(RenderScope scope) { }

    /** Live editor shows Minecraft's real bars; without server data this is a vanilla-shaped preview. */
    @Override public void renderEditor(RenderScope scope) {
        if (!nativeBossIsOnThisFrame()) renderDummy(scope);
    }

    @Override public void renderDummy(RenderScope scope) {
        String title = "ENDER DRAGON";
        int titleWidth = Math.round(Fonts.getWidth(title, 0) * 0.50f);
        layout.width = 182;
        layout.height = 14;
        scope.drawText(0.50f, title, Math.max(0, (182 - titleWidth) / 2), 0, 0, 0xFFFFFFFF);
        scope.drawRectangle(0, 9, 182, 5, 0xFF32124F);
        scope.drawRectangle(0, 9, 131, 5, 0xFFB94FE8);
    }

    @Override public boolean canScale() { return false; }
    @Override public boolean usesNativeDefaultPosition() { return true; }
    @Override public boolean isUsingNativeDefaultPosition() { return !MOVED.value; }
    @Override public void onLayoutChanged() { MOVED.value = true; }
    @Override public void onLayoutReset() {
        MOVED.value = false;
        layout.x.value = vanillaX;
        layout.y.value = vanillaY;
        layout.scale.value = 1.0f;
    }
    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return true; }
    @Override public boolean isToggleable() { return false; }
    @Override public void onEnabled(boolean ignored) { }
}
