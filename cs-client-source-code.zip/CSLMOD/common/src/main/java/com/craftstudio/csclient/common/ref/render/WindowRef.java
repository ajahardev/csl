package com.craftstudio.csclient.common.ref.render;

public interface WindowRef {
    public int getWidth();

    public int getHeight();

    /**
     * Physical framebuffer width. The default keeps third-party/launcher-modified
     * Window classes safe even if a version-specific bridge is unavailable.
     */
    default int getFramebufferWidth() {
        return getWidth();
    }

    /** Physical framebuffer height; see {@link #getFramebufferWidth()}. */
    default int getFramebufferHeight() {
        return getHeight();
    }
}
