package com.craftstudio.csclient.ui;

public class ElementContext {
    public int mouseX, mouseY;
    public int elementWidth, elementHeight;
    public float elementScale;
    public long elapsed;

    public ElementContext(long elapsed, int mouseX, int mouseY, Element e) {
        float safeScale = e.scale == 0f ? 1f : e.scale;
        this.mouseX = Math.round((mouseX - e.x) / safeScale);
        this.mouseY = Math.round((mouseY - e.y) / safeScale);
        this.elementWidth = e.width;
        this.elementHeight = e.height;
        this.elementScale = safeScale;
        this.elapsed = elapsed;
    }

    public boolean isHovering() {
        return Utils.isHovering(mouseX, mouseY, elementWidth, elementHeight, 1f);
    }

    public boolean isHovering(int x, int y, int width, int height) {
        return Utils.isHovering(mouseX - x, mouseY - y, width, height, 1f);
    }
}
