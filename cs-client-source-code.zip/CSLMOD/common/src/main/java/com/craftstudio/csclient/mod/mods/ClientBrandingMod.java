package com.craftstudio.csclient.mod.mods;

import java.util.UUID;

import com.craftstudio.csclient.branding.ClientBrandingState;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.resources.Textures;

/** Client-brand badge settings; networking/rendering remain version-specific. */
public final class ClientBrandingMod extends Mod {
    public static final char BRAND_GLYPH = '\uE010';
    private static final double MAX_DISTANCE_SQ = 48.0 * 48.0;

    private static final BoolProperty ENABLED = Property.bool(true);
    // Self is locally certain and provides an immediate visual check that the badge asset works.
    private static final BoolProperty SHOW_SELF = Property.bool(true);
    private static final SelectProperty SCALE = Property.select(1, "Small", "Normal", "Large");

    public ClientBrandingMod() {
        super(new ModSpec("CS Client Branding", "branding")
                        .description("Shows the CS logo before confirmed names; remote badges need the same JAR on the Fabric server")
                        .version("v1.0.0").tags("Visuals", "Multiplayer"),
                ENABLED.named("Show CS Client Logo"),
                // New stable key also migrates the old broken OFF default to the repaired ON default.
                SHOW_SELF.named("Show Logo Above Self"),
                SCALE.named("Logo Scale"));
    }

    public static boolean shouldRender(UUID uuid, boolean ownPlayer,
            boolean invisible, double squaredDistance, boolean hasVanillaNametag) {
        if (!ENABLED.value || uuid == null || invisible) return false;
        if (ownPlayer && !SHOW_SELF.value) return false;
        // A local player's vanilla name is normally suppressed because it is the camera entity.
        // The explicit self option is therefore allowed to use the safe fallback label attachment.
        if (!ownPlayer && !hasVanillaNametag) return false;
        if (squaredDistance > MAX_DISTANCE_SQ) return false;
        // The running local player is unquestionably using this client; only remotes need relay proof.
        return ownPlayer || ClientBrandingState.isCsClient(uuid);
    }

    public static boolean showSelf() { return ENABLED.value && SHOW_SELF.value; }
    public static int logoScale() { return Math.max(0, Math.min(2, SCALE.value)); }
    public static String logoGlyph() { return String.valueOf(BRAND_GLYPH); }

    @Override public IdentifierRef getIconTexture() { return Textures.LOGO; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
