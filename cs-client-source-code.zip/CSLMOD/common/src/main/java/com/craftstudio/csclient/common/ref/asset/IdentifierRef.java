package com.craftstudio.csclient.common.ref.asset;

import com.craftstudio.csclient.common.provider.Providers;

public interface IdentifierRef {
    public static IdentifierRef of(String namespace, String path) {
        return Providers.refConstructor.identifier(namespace, path);
    }

    public static IdentifierRef of(String fullPath) {
        return Providers.refConstructor.identifier(fullPath);
    }

    public static IdentifierRef ofClient(String path) {
        return of("csclient", path);
    }

    public static IdentifierRef ofVanilla(String path) {
        return of("minecraft", path);
    }

    @Override
    public String toString();
}
