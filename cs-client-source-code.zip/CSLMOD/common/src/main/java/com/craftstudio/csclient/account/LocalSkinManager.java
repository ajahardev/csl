package com.craftstudio.csclient.account;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.IDN;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import com.craftstudio.csclient.common.provider.Providers;

/** Password/token-free per-local-account skin and cape storage with secure imports. */
public final class LocalSkinManager {
    public static final String CLASSIC = "classic";
    public static final String SLIM = "slim";

    private static final int MAX_TEXTURE_BYTES = 1_048_576;
    private static final int MAX_JSON_BYTES = 131_072;
    private static final int MAX_REDIRECTS = 3;
    private static final Pattern USERNAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
    private static final Set<String> MOJANG_API_HOSTS = Set.of(
            "api.minecraftservices.com", "api.mojang.com", "sessionserver.mojang.com");
    private static final Set<String> MOJANG_TEXTURE_HOSTS = Set.of("textures.minecraft.net");
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .followRedirects(HttpClient.Redirect.NEVER)
            .build();
    private static final Map<UUID, SkinRecord> SKINS = new LinkedHashMap<>();
    private static final Map<UUID, CapeRecord> CAPES = new LinkedHashMap<>();
    private static final AtomicLong OPERATION = new AtomicLong();

    private static Path runDirectory;
    /** Root holding one isolated appearance directory per eligible profile UUID. */
    private static Path appearanceDirectory;
    private static Path metadataFile;
    /** Read-only migration source used by the prior flat-profile layout. */
    private static Path legacyAppearanceDirectory;
    private static Path legacyMetadataFile;
    private static volatile long knownIndexModified;
    private static volatile long nextExternalSyncCheck;

    private LocalSkinManager() { }

    public record SkinRecord(UUID uuid, String model, String sourceType,
            String sourceLabel, long updatedAt) { }

    public record CapeRecord(UUID uuid, String sourceType, String sourceLabel, long updatedAt) { }

    public record SkinResult(boolean success, String message) {
        public static SkinResult ok(String message) { return new SkinResult(true, message); }
        public static SkinResult fail(String message) { return new SkinResult(false, message); }
    }

    public static synchronized void initialize(java.io.File gameDirectory) {
        runDirectory = gameDirectory.toPath().toAbsolutePath().normalize();
        Path config = runDirectory.resolve("config").resolve("cs-client");
        appearanceDirectory = config.resolve("profiles");
        metadataFile = appearanceDirectory.resolve("appearance-index.json");
        legacyAppearanceDirectory = config.resolve("local-skins");
        legacyMetadataFile = legacyAppearanceDirectory.resolve("skins.json");
        load();
        knownIndexModified = modifiedTime(metadataFile);
        nextExternalSyncCheck = 0L;
    }

    /**
     * One-second launcher bridge poll. A launcher can atomically replace the
     * documented appearance index/files; CS reloads and applies them on the
     * client thread without watching the filesystem every frame.
     */
    public static void tickExternalSync() {
        long now = System.currentTimeMillis();
        if (now < nextExternalSyncCheck || metadataFile == null) return;
        nextExternalSyncCheck = now + 1_000L;
        long modified = modifiedTime(metadataFile);
        if (modified <= 0L || modified == knownIndexModified) return;
        synchronized (LocalSkinManager.class) {
            load();
            knownIndexModified = modifiedTime(metadataFile);
        }
        activateForCurrentAccount();
    }

    /** A profile made inside CS's credential-free local account manager. */
    public static boolean isActiveLocalAccount() {
        UUID uuid = Providers.csClient.getClient().getUuid();
        return LocalAccountManager.isLocalAccount(uuid);
    }

    /** Any non-CS profile supplied by the active launcher. */
    public static boolean isActiveLauncherProfile() {
        UUID uuid = Providers.csClient.getClient().getUuid();
        String username = Providers.csClient.getClient().getUsername();
        return uuid != null && username != null && !username.isBlank()
                && !LocalAccountManager.isLocalAccount(uuid);
    }

    /**
     * Best-effort display classification for a launcher-provided offline session.
     * Eligibility does not depend on this heuristic: every active launcher profile
     * can use a local appearance, so launchers with unusual placeholder sessions
     * are never incorrectly locked out.
     */
    public static boolean isActiveLauncherOfflineProfile() {
        return isActiveLauncherProfile()
                && Providers.csClient.getClient().isLauncherOfflineProfile();
    }

    /** CS local profiles and all valid launcher profiles may use local appearance files. */
    public static boolean isActiveAppearanceProfile() {
        return isActiveLocalAccount() || isActiveLauncherProfile();
    }

    /** Safe display-only relative location for the active profile's local files. */
    public static String getActiveProfileStorageLabel() {
        UUID uuid = Providers.csClient.getClient().getUuid();
        return uuid == null ? "profiles" : "profiles/" + uuid + "/appearance";
    }

    public static synchronized boolean hasSavedSkin(UUID uuid) {
        return uuid != null && SKINS.containsKey(uuid) && Files.isRegularFile(skinPath(uuid));
    }

    public static synchronized boolean hasSavedCape(UUID uuid) {
        return uuid != null && CAPES.containsKey(uuid) && Files.isRegularFile(capePath(uuid));
    }

    public static synchronized boolean hasSavedAppearance(UUID uuid) {
        return hasSavedSkin(uuid) || hasSavedCape(uuid);
    }

    public static synchronized SkinRecord getActiveRecord() {
        UUID uuid = Providers.csClient.getClient().getUuid();
        return uuid == null ? null : SKINS.get(uuid);
    }

    public static synchronized CapeRecord getActiveCapeRecord() {
        UUID uuid = Providers.csClient.getClient().getUuid();
        return uuid == null ? null : CAPES.get(uuid);
    }

    public static String getActiveModel() {
        SkinRecord record = getActiveRecord();
        return record == null ? CLASSIC : normalizeModel(record.model());
    }

    /** Must run on Minecraft's client thread. */
    public static void activateForCurrentAccount() {
        UUID uuid = Providers.csClient.getClient().getUuid();
        if (!isActiveAppearanceProfile()) {
            Providers.csClient.getClient().resetLocalSkin();
            return;
        }
        Appearance appearance = appearance(uuid);
        if (appearance.skin() == null && appearance.cape() == null) {
            Providers.csClient.getClient().resetLocalSkin();
            return;
        }
        if (!Providers.csClient.getClient().applyLocalAppearance(
                appearance.skin(), appearance.cape(), appearance.model())) {
            Providers.csClient.getClient().resetLocalSkin();
        }
    }

    /** Copies the public Mojang skin and, when present, its official CAPE texture. */
    public static CompletableFuture<SkinResult> applyFromUsername(String rawUsername) {
        String username = rawUsername == null ? "" : rawUsername.trim();
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        if (!USERNAME.matcher(username).matches()) {
            return CompletableFuture.completedFuture(SkinResult.fail("Use a valid 3–16 character Minecraft username."));
        }
        UUID account = Providers.csClient.getClient().getUuid();
        long operation = OPERATION.incrementAndGet();
        return CompletableFuture.supplyAsync(() -> {
            try {
                String id = resolveJavaProfileId(username);
                if (!id.matches("[0-9a-fA-F]{32}")) {
                    return SkinResult.fail("No Minecraft Java profile was found for that username.");
                }

                URI sessionUri = URI.create("https://sessionserver.mojang.com/session/minecraft/profile/" + id);
                JsonNode session = MAPPER.readTree(requestBytes(sessionUri, MAX_JSON_BYTES, MOJANG_API_HOSTS));
                String textureValue = "";
                for (JsonNode property : session.path("properties")) {
                    if (property.path("name").asText("").equals("textures")) {
                        textureValue = property.path("value").asText("");
                        break;
                    }
                }
                if (textureValue.isBlank() || textureValue.length() > 100_000) {
                    return SkinResult.fail("No public skin is available for that username.");
                }
                byte[] decoded = Base64.getDecoder().decode(textureValue);
                if (decoded.length > MAX_JSON_BYTES) return SkinResult.fail("Mojang texture metadata was too large.");
                JsonNode textures = MAPPER.readTree(decoded).path("textures");
                JsonNode skin = textures.path("SKIN");
                String skinUrl = skin.path("url").asText("");
                if (skinUrl.isBlank()) return SkinResult.fail("No public skin is available for that username.");
                String model = skin.path("metadata").path("model").asText("").equalsIgnoreCase(SLIM)
                        ? SLIM : CLASSIC;
                byte[] skinPng = requestBytes(URI.create(skinUrl), MAX_TEXTURE_BYTES, MOJANG_TEXTURE_HOSTS);

                String capeUrl = textures.path("CAPE").path("url").asText("");
                byte[] capePng = capeUrl.isBlank() ? null
                        : requestBytes(URI.create(capeUrl), MAX_TEXTURE_BYTES, MOJANG_TEXTURE_HOSTS);
                return commitUsername(operation, account, skinPng, capePng, model, username);
            } catch (Exception ignored) {
                return SkinResult.fail("Could not fetch that player's public skin/cape.");
            }
        });
    }

    /** Modern lookup first; legacy Mojang is a compatibility fallback for launcher/network variance. */
    private static String resolveJavaProfileId(String username) {
        String encoded = URLEncoder.encode(username, StandardCharsets.UTF_8);
        String[] endpoints = {
                "https://api.minecraftservices.com/minecraft/profile/lookup/name/" + encoded,
                "https://api.mojang.com/users/profiles/minecraft/" + encoded
        };
        for (String endpoint : endpoints) {
            try {
                JsonNode profile = MAPPER.readTree(requestBytes(
                        URI.create(endpoint), MAX_JSON_BYTES, MOJANG_API_HOSTS));
                String id = profile == null ? "" : profile.path("id").asText("");
                if (id.matches("[0-9a-fA-F]{32}")) return id;
            } catch (Exception ignored) {
                // Try the other official public lookup endpoint.
            }
        }
        return "";
    }

    public static CompletableFuture<SkinResult> applyFromUrl(String rawUrl, String model) {
        String url = rawUrl == null ? "" : rawUrl.trim();
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        if (url.isBlank() || url.length() > 768) {
            return CompletableFuture.completedFuture(SkinResult.fail("Enter a direct HTTP(S) skin PNG URL."));
        }
        UUID account = Providers.csClient.getClient().getUuid();
        long operation = OPERATION.incrementAndGet();
        return CompletableFuture.supplyAsync(() -> {
            try {
                URI uri = URI.create(url);
                byte[] png = requestBytes(uri, MAX_TEXTURE_BYTES, null);
                return commitSkin(operation, account, png, normalizeModel(model), "url", safeHostLabel(uri),
                        "Applied the URL skin locally.");
            } catch (SecurityException security) {
                return SkinResult.fail(security.getMessage());
            } catch (Exception ignored) {
                return SkinResult.fail("Could not download a valid skin PNG from that URL.");
            }
        });
    }

    public static CompletableFuture<SkinResult> applyFromFile(Path path, String model) {
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        UUID account = Providers.csClient.getClient().getUuid();
        long operation = OPERATION.incrementAndGet();
        return CompletableFuture.supplyAsync(() -> {
            try {
                Path safe = validateSelectedFile(path, "skin");
                byte[] png = Files.readAllBytes(safe);
                return commitSkin(operation, account, png, normalizeModel(model), "file",
                        safe.getFileName().toString(), "Imported the selected skin PNG.");
            } catch (IllegalArgumentException invalid) {
                return SkinResult.fail(invalid.getMessage());
            } catch (Exception ignored) {
                return SkinResult.fail("Could not read the selected skin PNG.");
            }
        });
    }

    public static CompletableFuture<SkinResult> applyCapeFromFile(Path path) {
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        UUID account = Providers.csClient.getClient().getUuid();
        long operation = OPERATION.incrementAndGet();
        return CompletableFuture.supplyAsync(() -> {
            try {
                Path safe = validateSelectedFile(path, "cape");
                byte[] png = Files.readAllBytes(safe);
                return commitCape(operation, account, png, "file", safe.getFileName().toString(),
                        "Imported the selected 64×32 cape PNG locally.");
            } catch (IllegalArgumentException invalid) {
                return SkinResult.fail(invalid.getMessage());
            } catch (Exception ignored) {
                return SkinResult.fail("Could not read the selected cape PNG.");
            }
        });
    }

    public static CompletableFuture<SkinResult> setActiveModel(String model) {
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        UUID uuid = Providers.csClient.getClient().getUuid();
        SkinRecord updated;
        synchronized (LocalSkinManager.class) {
            SkinRecord current = SKINS.get(uuid);
            if (current == null || !Files.isRegularFile(skinPath(uuid))) {
                return CompletableFuture.completedFuture(SkinResult.fail("Apply a local skin before changing its model."));
            }
            updated = new SkinRecord(uuid, normalizeModel(model), current.sourceType(),
                    current.sourceLabel(), System.currentTimeMillis());
            SKINS.put(uuid, updated);
            save();
        }
        return activateAsync(uuid).thenApply(success -> success
                ? SkinResult.ok("Model changed to " + updated.model() + ".")
                : SkinResult.fail("Could not refresh the local appearance."));
    }

    public static CompletableFuture<SkinResult> resetActiveSkin() {
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        UUID uuid = Providers.csClient.getClient().getUuid();
        OPERATION.incrementAndGet();
        synchronized (LocalSkinManager.class) {
            SKINS.remove(uuid);
            delete(skinPath(uuid));
            save();
        }
        return activateAsync(uuid).thenApply(success -> SkinResult.ok(
                hasSavedCape(uuid) ? "Restored the session skin; local cape remains active."
                        : "Restored the original session skin."));
    }

    public static CompletableFuture<SkinResult> resetActiveCape() {
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        UUID uuid = Providers.csClient.getClient().getUuid();
        OPERATION.incrementAndGet();
        synchronized (LocalSkinManager.class) {
            CAPES.remove(uuid);
            delete(capePath(uuid));
            save();
        }
        return activateAsync(uuid).thenApply(success -> SkinResult.ok("Restored the original session cape."));
    }

    public static CompletableFuture<SkinResult> resetActiveAppearance() {
        SkinResult eligibility = eligibility();
        if (!eligibility.success()) return CompletableFuture.completedFuture(eligibility);
        UUID uuid = Providers.csClient.getClient().getUuid();
        OPERATION.incrementAndGet();
        synchronized (LocalSkinManager.class) {
            SKINS.remove(uuid);
            CAPES.remove(uuid);
            delete(skinPath(uuid));
            delete(capePath(uuid));
            save();
        }
        CompletableFuture<SkinResult> result = new CompletableFuture<>();
        Providers.csClient.getClient().executeOnThread(() -> {
            Providers.csClient.getClient().resetLocalSkin();
            result.complete(SkinResult.ok("Restored the original session skin and cape."));
        });
        return result;
    }

    public static synchronized void remove(UUID uuid) {
        if (uuid == null) return;
        SKINS.remove(uuid);
        CAPES.remove(uuid);
        delete(skinPath(uuid));
        delete(capePath(uuid));
        save();
    }

    private static SkinResult eligibility() {
        return isActiveAppearanceProfile()
                ? SkinResult.ok("Ready")
                : SkinResult.fail("A valid CS local or launcher profile is required for local skin/cape files.");
    }

    private static SkinResult commitSkin(long operation, UUID account, byte[] input, String model,
            String sourceType, String sourceLabel, String successMessage) {
        try {
            ensureCurrent(operation, account);
            byte[] canonical = validateAndCanonicalize(input, 64, 64, "Skin");
            Files.createDirectories(profileAppearanceDirectory(account));
            atomicWrite(skinPath(account), canonical);
            SkinRecord record = new SkinRecord(account, normalizeModel(model), sourceType,
                    sanitizeLabel(sourceLabel, "local skin"), System.currentTimeMillis());
            synchronized (LocalSkinManager.class) {
                SKINS.put(account, record);
                save();
            }
            return activateAsync(account).join() ? SkinResult.ok(successMessage)
                    : SkinResult.fail("The skin was saved but could not be rendered.");
        } catch (IllegalArgumentException invalid) {
            return SkinResult.fail(invalid.getMessage());
        } catch (Exception ignored) {
            return SkinResult.fail("Could not save the local skin safely.");
        }
    }

    private static SkinResult commitCape(long operation, UUID account, byte[] input,
            String sourceType, String sourceLabel, String successMessage) {
        try {
            ensureCurrent(operation, account);
            byte[] canonical = validateAndCanonicalize(input, 64, 32, "Cape");
            Files.createDirectories(profileAppearanceDirectory(account));
            atomicWrite(capePath(account), canonical);
            CapeRecord record = new CapeRecord(account, sourceType,
                    sanitizeLabel(sourceLabel, "local cape"), System.currentTimeMillis());
            synchronized (LocalSkinManager.class) {
                CAPES.put(account, record);
                save();
            }
            return activateAsync(account).join() ? SkinResult.ok(successMessage)
                    : SkinResult.fail("The cape was saved but could not be rendered.");
        } catch (IllegalArgumentException invalid) {
            return SkinResult.fail(invalid.getMessage());
        } catch (Exception ignored) {
            return SkinResult.fail("Could not save the local cape safely.");
        }
    }

    private static SkinResult commitUsername(long operation, UUID account, byte[] skinInput,
            byte[] capeInput, String model, String username) {
        try {
            ensureCurrent(operation, account);
            byte[] canonicalSkin = validateAndCanonicalize(skinInput, 64, 64, "Skin");
            byte[] canonicalCape = capeInput == null ? null
                    : validateAndCanonicalize(capeInput, 64, 32, "Cape");
            Files.createDirectories(profileAppearanceDirectory(account));
            atomicWrite(skinPath(account), canonicalSkin);
            if (canonicalCape != null) atomicWrite(capePath(account), canonicalCape);
            else delete(capePath(account));

            long now = System.currentTimeMillis();
            synchronized (LocalSkinManager.class) {
                SKINS.put(account, new SkinRecord(account, normalizeModel(model), "player",
                        sanitizeLabel(username, "Mojang player"), now));
                if (canonicalCape != null) {
                    CAPES.put(account, new CapeRecord(account, "official-player",
                            sanitizeLabel(username, "Mojang player"), now));
                } else {
                    CAPES.remove(account);
                }
                save();
            }
            boolean applied = activateAsync(account).join();
            if (!applied) return SkinResult.fail("The Mojang appearance was saved but could not be rendered.");
            return canonicalCape == null
                    ? SkinResult.ok("Applied " + username + "'s skin locally; no official cape was active.")
                    : SkinResult.ok("Applied " + username + "'s skin and official cape locally.");
        } catch (IllegalArgumentException invalid) {
            return SkinResult.fail(invalid.getMessage());
        } catch (Exception ignored) {
            return SkinResult.fail("Could not save the Mojang skin/cape safely.");
        }
    }

    private static void ensureCurrent(long operation, UUID account) {
        if (operation != OPERATION.get() || account == null
                || !account.equals(Providers.csClient.getClient().getUuid())
                || !isActiveAppearanceProfile()) {
            throw new IllegalArgumentException("The active appearance profile changed before loading finished.");
        }
    }

    private static CompletableFuture<Boolean> activateAsync(UUID uuid) {
        CompletableFuture<Boolean> result = new CompletableFuture<>();
        Appearance appearance = appearance(uuid);
        Providers.csClient.getClient().executeOnThread(() -> {
            if (!uuid.equals(Providers.csClient.getClient().getUuid()) || !isActiveAppearanceProfile()) {
                result.complete(false);
                return;
            }
            if (appearance.skin() == null && appearance.cape() == null) {
                Providers.csClient.getClient().resetLocalSkin();
                result.complete(true);
                return;
            }
            result.complete(Providers.csClient.getClient().applyLocalAppearance(
                    appearance.skin(), appearance.cape(), appearance.model()));
        });
        return result;
    }

    private static synchronized Appearance appearance(UUID uuid) {
        SkinRecord skin = SKINS.get(uuid);
        CapeRecord cape = CAPES.get(uuid);
        Path skinFile = skin != null && Files.isRegularFile(skinPath(uuid)) ? skinPath(uuid) : null;
        Path capeFile = cape != null && Files.isRegularFile(capePath(uuid)) ? capePath(uuid) : null;
        return new Appearance(skinFile, capeFile, skin == null ? CLASSIC : normalizeModel(skin.model()));
    }

    private record Appearance(Path skin, Path cape, String model) { }

    private static Path validateSelectedFile(Path selected, String kind) throws IOException {
        if (selected == null) throw new IllegalArgumentException("No " + kind + " PNG was selected.");
        Path path = selected.toAbsolutePath().normalize();
        if (Files.isSymbolicLink(path) || !Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) {
            throw new IllegalArgumentException("The selected " + kind + " file does not exist.");
        }
        if (!path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png")) {
            throw new IllegalArgumentException("The selected file must end in .png.");
        }
        long size = Files.size(path);
        if (size <= 0 || size > MAX_TEXTURE_BYTES) {
            throw new IllegalArgumentException("The PNG must be smaller than 1 MB.");
        }
        return path;
    }

    private static byte[] validateAndCanonicalize(byte[] input, int width, int height, String label)
            throws IOException {
        if (input == null || input.length < 24 || input.length > MAX_TEXTURE_BYTES
                || input[0] != (byte) 0x89 || input[1] != 0x50 || input[2] != 0x4E || input[3] != 0x47) {
            throw new IllegalArgumentException(label + " data must be a valid PNG smaller than 1 MB.");
        }
        int declaredWidth = ((input[16] & 255) << 24) | ((input[17] & 255) << 16)
                | ((input[18] & 255) << 8) | (input[19] & 255);
        int declaredHeight = ((input[20] & 255) << 24) | ((input[21] & 255) << 16)
                | ((input[22] & 255) << 8) | (input[23] & 255);
        if (declaredWidth != width || declaredHeight != height) {
            throw new IllegalArgumentException(label + " PNG dimensions must be exactly " + width + "×" + height + ".");
        }
        BufferedImage source = ImageIO.read(new ByteArrayInputStream(input));
        if (source == null || source.getWidth() != width || source.getHeight() != height) {
            throw new IllegalArgumentException(label + " PNG dimensions must be exactly " + width + "×" + height + ".");
        }
        BufferedImage canonical = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = canonical.createGraphics();
        graphics.drawImage(source, 0, 0, null);
        graphics.dispose();
        ByteArrayOutputStream output = new ByteArrayOutputStream(32_768);
        if (!ImageIO.write(canonical, "PNG", output)) throw new IOException("PNG encoder unavailable");
        return output.toByteArray();
    }

    private static void atomicWrite(Path destination, byte[] data) throws IOException {
        Path temporary = destination.resolveSibling(destination.getFileName() + ".tmp");
        Files.write(temporary, data);
        try {
            Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static byte[] requestBytes(URI initial, int limit, Set<String> allowedHosts) throws Exception {
        URI current = initial;
        for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
            validateUri(current, allowedHosts);
            HttpRequest request = HttpRequest.newBuilder(current)
                    .timeout(Duration.ofSeconds(10))
                    .header("User-Agent", "CS-Client/LocalAppearance")
                    .header("Accept", "image/png, application/json;q=0.9, */*;q=0.1")
                    .GET().build();
            HttpResponse<InputStream> response = HTTP.send(request, HttpResponse.BodyHandlers.ofInputStream());
            int status = response.statusCode();
            if (status >= 300 && status <= 399) {
                try (InputStream ignored = response.body()) {
                    String location = response.headers().firstValue("location").orElse("");
                    if (location.isBlank() || redirect == MAX_REDIRECTS) throw new IOException("redirect rejected");
                    current = current.resolve(location);
                    continue;
                }
            }
            if (status < 200 || status >= 300) {
                try (InputStream ignored = response.body()) { }
                throw new IOException("HTTP " + status);
            }
            try (InputStream body = response.body()) {
                return readLimited(body, limit);
            }
        }
        throw new IOException("too many redirects");
    }

    private static byte[] readLimited(InputStream input, int limit) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream(Math.min(limit, 65_536));
        byte[] buffer = new byte[8_192];
        int total = 0;
        int read;
        while ((read = input.read(buffer)) >= 0) {
            total += read;
            if (total > limit) throw new IOException("response too large");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private static void validateUri(URI uri, Set<String> allowedHosts) throws Exception {
        if (uri == null || uri.toString().length() > 1_024 || uri.getUserInfo() != null || uri.getFragment() != null) {
            throw new SecurityException("That URL format is not allowed.");
        }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (!scheme.equals("https") && !scheme.equals("http")) {
            throw new SecurityException("Only direct HTTP(S) texture URLs are allowed.");
        }
        int port = uri.getPort();
        if (port != -1 && port != 80 && port != 443) {
            throw new SecurityException("Only standard HTTP(S) ports are allowed.");
        }
        String host = uri.getHost();
        if (host == null || host.isBlank()) throw new SecurityException("The texture URL needs a public host.");
        host = IDN.toASCII(host).toLowerCase(Locale.ROOT);
        if (allowedHosts != null && !allowedHosts.contains(host)) {
            throw new SecurityException("The texture service redirected to an untrusted host.");
        }
        if (host.equals("localhost") || host.endsWith(".localhost") || host.endsWith(".local")) {
            throw new SecurityException("Private or local network texture URLs are blocked.");
        }
        for (InetAddress address : InetAddress.getAllByName(host)) {
            if (isPrivateOrReserved(address)) {
                throw new SecurityException("Private or local network texture URLs are blocked.");
            }
        }
    }

    private static boolean isPrivateOrReserved(InetAddress address) {
        if (address.isAnyLocalAddress() || address.isLoopbackAddress() || address.isLinkLocalAddress()
                || address.isSiteLocalAddress() || address.isMulticastAddress()) return true;
        byte[] b = address.getAddress();
        if (b.length == 4) {
            int a = b[0] & 255, c = b[1] & 255;
            return a == 0 || a == 10 || a == 127 || a >= 224
                    || (a == 100 && c >= 64 && c <= 127)
                    || (a == 169 && c == 254)
                    || (a == 172 && c >= 16 && c <= 31)
                    || (a == 192 && (c == 0 || c == 168))
                    || (a == 198 && (c == 18 || c == 19 || c == 51))
                    || (a == 203 && c == 0);
        }
        if (address instanceof Inet6Address) {
            int first = b[0] & 255, second = b[1] & 255;
            return (first & 0xFE) == 0xFC || (first == 0x20 && second == 0x01
                    && (b[2] & 255) == 0x0D && (b[3] & 255) == 0xB8);
        }
        return true;
    }

    private static String normalizeModel(String model) {
        return model != null && model.equalsIgnoreCase(SLIM) ? SLIM : CLASSIC;
    }

    private static String safeHostLabel(URI uri) {
        String host = uri.getHost();
        return host == null ? "direct URL" : host.toLowerCase(Locale.ROOT);
    }

    private static String sanitizeLabel(String value, String fallback) {
        String clean = value == null ? fallback : value.replaceAll("[\\r\\n\\t]", " ").trim();
        if (clean.isBlank()) clean = fallback;
        return clean.length() > 96 ? clean.substring(0, 96) : clean;
    }

    private static Path profileAppearanceDirectory(UUID uuid) {
        return appearanceDirectory.resolve(uuid.toString()).resolve("appearance");
    }

    private static Path skinPath(UUID uuid) { return profileAppearanceDirectory(uuid).resolve("skin.png"); }
    private static Path capePath(UUID uuid) { return profileAppearanceDirectory(uuid).resolve("cape.png"); }
    private static Path legacySkinPath(UUID uuid) { return legacyAppearanceDirectory.resolve(uuid + ".png"); }
    private static Path legacyCapePath(UUID uuid) { return legacyAppearanceDirectory.resolve(uuid + ".cape.png"); }
    private static void delete(Path path) { try { Files.deleteIfExists(path); } catch (IOException ignored) { } }
    private static long modifiedTime(Path path) {
        try { return path != null && Files.isRegularFile(path) ? Files.getLastModifiedTime(path).toMillis() : 0L; }
        catch (IOException ignored) { return 0L; }
    }

    private static synchronized void load() {
        SKINS.clear();
        CAPES.clear();
        loadIndex(metadataFile);
        migrateLegacyLayout();
    }

    private static void loadIndex(Path index) {
        if (index == null || !Files.isRegularFile(index, LinkOption.NOFOLLOW_LINKS)) return;
        try {
            JsonNode root = MAPPER.readTree(index.toFile());
            for (JsonNode node : root.path("skins")) {
                UUID uuid = UUID.fromString(node.path("uuid").asText(""));
                String model = normalizeModel(node.path("model").asText(CLASSIC));
                String type = sanitizeLabel(node.path("sourceType").asText("file"), "file");
                String label = sanitizeLabel(node.path("sourceLabel").asText("local skin"), "local skin");
                long updated = node.path("updatedAt").asLong(0L);
                if (Files.isRegularFile(skinPath(uuid), LinkOption.NOFOLLOW_LINKS)) {
                    SKINS.put(uuid, new SkinRecord(uuid, model, type, label, updated));
                }
            }
            for (JsonNode node : root.path("capes")) {
                UUID uuid = UUID.fromString(node.path("uuid").asText(""));
                String type = sanitizeLabel(node.path("sourceType").asText("file"), "file");
                String label = sanitizeLabel(node.path("sourceLabel").asText("local cape"), "local cape");
                long updated = node.path("updatedAt").asLong(0L);
                if (Files.isRegularFile(capePath(uuid), LinkOption.NOFOLLOW_LINKS)) {
                    CAPES.put(uuid, new CapeRecord(uuid, type, label, updated));
                }
            }
        } catch (Exception ignored) {
            // Optional appearance metadata must never block client startup.
        }
    }

    /** Migrates the prior flat local-skins files once into isolated per-profile folders. */
    private static void migrateLegacyLayout() {
        if (legacyMetadataFile == null || !Files.isRegularFile(legacyMetadataFile, LinkOption.NOFOLLOW_LINKS)) return;
        boolean migrated = false;
        try {
            JsonNode root = MAPPER.readTree(legacyMetadataFile.toFile());
            for (JsonNode node : root.path("skins")) {
                UUID uuid = UUID.fromString(node.path("uuid").asText(""));
                Path old = legacySkinPath(uuid);
                if (!Files.isRegularFile(old, LinkOption.NOFOLLOW_LINKS)) continue;
                Path target = skinPath(uuid);
                if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) {
                    Files.createDirectories(profileAppearanceDirectory(uuid));
                    Files.copy(old, target, StandardCopyOption.REPLACE_EXISTING);
                }
                if (!SKINS.containsKey(uuid) && Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) {
                    SKINS.put(uuid, new SkinRecord(uuid,
                            normalizeModel(node.path("model").asText(CLASSIC)),
                            sanitizeLabel(node.path("sourceType").asText("file"), "file"),
                            sanitizeLabel(node.path("sourceLabel").asText("local skin"), "local skin"),
                            node.path("updatedAt").asLong(0L)));
                }
                migrated = true;
            }
            for (JsonNode node : root.path("capes")) {
                UUID uuid = UUID.fromString(node.path("uuid").asText(""));
                Path old = legacyCapePath(uuid);
                if (!Files.isRegularFile(old, LinkOption.NOFOLLOW_LINKS)) continue;
                Path target = capePath(uuid);
                if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) {
                    Files.createDirectories(profileAppearanceDirectory(uuid));
                    Files.copy(old, target, StandardCopyOption.REPLACE_EXISTING);
                }
                if (!CAPES.containsKey(uuid) && Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) {
                    CAPES.put(uuid, new CapeRecord(uuid,
                            sanitizeLabel(node.path("sourceType").asText("file"), "file"),
                            sanitizeLabel(node.path("sourceLabel").asText("local cape"), "local cape"),
                            node.path("updatedAt").asLong(0L)));
                }
                migrated = true;
            }
            if (migrated) save();
        } catch (Exception ignored) {
            // Keep legacy files intact if a migration entry is malformed.
        }
    }

    private static synchronized void save() {
        if (metadataFile == null) return;
        try {
            Files.createDirectories(appearanceDirectory);
            ObjectNode root = MAPPER.createObjectNode();
            root.put("version", 3);
            ArrayNode skins = root.putArray("skins");
            for (SkinRecord record : SKINS.values()) {
                ObjectNode node = skins.addObject();
                node.put("uuid", record.uuid().toString());
                node.put("model", record.model());
                node.put("sourceType", record.sourceType());
                node.put("sourceLabel", record.sourceLabel());
                node.put("updatedAt", record.updatedAt());
            }
            ArrayNode capes = root.putArray("capes");
            for (CapeRecord record : CAPES.values()) {
                ObjectNode node = capes.addObject();
                node.put("uuid", record.uuid().toString());
                node.put("sourceType", record.sourceType());
                node.put("sourceLabel", record.sourceLabel());
                node.put("updatedAt", record.updatedAt());
            }
            Path temporary = metadataFile.resolveSibling("appearance-index.json.tmp");
            Files.writeString(temporary, MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(root));
            try {
                Files.move(temporary, metadataFile, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, metadataFile, StandardCopyOption.REPLACE_EXISTING);
            }
            knownIndexModified = modifiedTime(metadataFile);
        } catch (Exception ignored) {
            // Appearance remains active for this run even if optional metadata persistence fails.
        }
    }
}
