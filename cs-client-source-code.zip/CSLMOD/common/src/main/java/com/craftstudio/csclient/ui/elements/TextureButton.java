package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

public class TextureButton extends Element {
    IdentifierRef sprite;
    private Runnable onClick;
    static int padding = 14;

    public TextureButton(IdentifierRef sprite, Runnable onClick) {
        this.sprite = sprite;
        this.onClick = onClick;
    }

    @Override
    public void render(RenderScope renderScope, ElementContext ctx) {
        renderScope.drawRoundedRectangle(0, 0, width, height, Theme.WIDGET_RADIUS.value,
                ctx.isHovering() ? Theme.ACCENT.value : Theme.PRIMARY.value);

        int texWidth = width - padding;
        int texHeight = height - padding;

        renderScope.drawTexture(sprite, padding / 2, padding / 2, 0, 0, texWidth, texHeight,
                ctx.isHovering() ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) {
            onClick.run();
        }
    }
}
