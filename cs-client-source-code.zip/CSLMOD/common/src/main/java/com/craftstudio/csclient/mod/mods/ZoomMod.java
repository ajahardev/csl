package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.FloatProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/** Smooth, scroll-adjustable FOV zoom without modifying Minecraft video settings. */
public final class ZoomMod extends Mod {
    private static final float MIN_ZOOM = 1.25f;
    private static final float MAX_ZOOM = 50.0f;

    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty toggle = Property.bool(false);
    private static final BoolProperty smoothZoom = Property.bool(true);
    private static final BoolProperty scrollAdjust = Property.bool(true);
    public static final KeybindingProperty zoomKey = Property.keybinding(GLFWProvider.GLFW_KEY_C);
    public static final FloatProperty zoomLevel = Property.floatProp(3.0f);
    private static final FloatProperty scrollStep = Property.floatProp(0.20f);
    public static final IntProperty zoomInDuration = Property.integer(180);
    public static final IntProperty zoomOutDuration = Property.integer(220);

    public static volatile boolean isZooming;
    private static volatile float currentZoom = 1.0f;
    private static long lastFrameNanos;

    public ZoomMod() {
        super(new ModSpec("Zoom", "zoom")
                        .description("Smooth camera zoom with mouse-wheel magnification control")
                        .tags("Camera", "Utility").version("v1.0.0"),
                enabled.named("Enabled"),
                toggle.named("Toggle Zoom"),
                zoomKey.named("Zoom Keybinding"),
                zoomLevel.named("Default Zoom Level"),
                scrollAdjust.named("Mouse Wheel Zoom"),
                scrollStep.named("Mouse Wheel Step"),
                smoothZoom.named("Smooth Zoom"),
                zoomInDuration.named("Zoom In Duration"),
                zoomOutDuration.named("Zoom Out Duration"));
    }

    @Override
    public void tick() {
        if (toggle.value) {
            if (zoomKey.wasKeyPressed()) isZooming = !isZooming;
        } else {
            isZooming = zoomKey.isKeyPressed();
        }
    }

    /** Consumes wheel movement only while actively zooming, leaving normal hotbar scrolling untouched. */
    public static boolean handleMouseWheel(double verticalAmount) {
        if (!enabled.value || !isZooming || !scrollAdjust.value || verticalAmount == 0.0) return false;
        double amount = Math.max(-4.0, Math.min(4.0, verticalAmount));
        float step = Math.max(0.02f, Math.min(1.0f, scrollStep.value));
        double factor = Math.pow(1.0 + step, amount);
        zoomLevel.value = clampZoom((float) (clampZoom(zoomLevel.value) * factor));
        return true;
    }

    @Override
    public void onEnabled(boolean value) {
        enabled.value = value;
        if (!value) {
            isZooming = false;
            currentZoom = 1.0f;
            lastFrameNanos = 0L;
        }
    }

    @Override public boolean isEnabled() { return enabled.value; }

    public static boolean shouldZoom() {
        return enabled.value && (isZooming || currentZoom > 1.001f);
    }

    /** Render-frame interpolation prevents tick-rate stepping and scroll-wheel jumps. */
    public static float getZoomLevel() {
        float target = isZooming ? clampZoom(zoomLevel.value) : 1.0f;
        long now = System.nanoTime();
        long previous = lastFrameNanos;
        lastFrameNanos = now;
        if (!smoothZoom.value) {
            currentZoom = target;
            return currentZoom;
        }
        if (previous == 0L) return currentZoom;

        float seconds = Math.max(0.0f, Math.min(0.05f, (now - previous) / 1_000_000_000.0f));
        int durationMs = isZooming ? zoomInDuration.value : zoomOutDuration.value;
        float duration = Math.max(0.04f, Math.min(2.0f, durationMs / 1000.0f));
        // 4.6 time constants reaches roughly 99% at the configured duration.
        float blend = 1.0f - (float) Math.exp(-4.6f * seconds / duration);
        currentZoom += (target - currentZoom) * blend;
        if (Math.abs(target - currentZoom) < 0.001f) currentZoom = target;
        return Math.max(1.0f, currentZoom);
    }

    public static float configuredZoomLevel() { return clampZoom(zoomLevel.value); }

    private static float clampZoom(float value) {
        return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, value));
    }
}
