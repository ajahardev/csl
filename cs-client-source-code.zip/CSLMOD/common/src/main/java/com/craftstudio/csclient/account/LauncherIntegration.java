package com.craftstudio.csclient.account;

import com.craftstudio.csclient.config.Config;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Stable, credential-free contract a mobile launcher can consume.
 *
 * Publishing is merge-safe: an existing {@code client-request.json} is read
 * first and every value the launcher (or a previous session) already saved is
 * preserved. Defaults are only written when no saved value exists, so
 * initialization can never clear a saved server IP or frame-rate preference.
 */
public final class LauncherIntegration {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private LauncherIntegration() { }

    public static Path bridgeFile(java.io.File gameDirectory) {
        return gameDirectory.toPath().toAbsolutePath().normalize()
                .resolve("config").resolve("cs-client").resolve("launcher-bridge")
                .resolve("client-request.json");
    }

    public static void publishCapabilities(java.io.File gameDirectory) {
        if (gameDirectory == null) return;
        try {
            Path directory = bridgeFile(gameDirectory).getParent();
            Files.createDirectories(directory);
            Path target = bridgeFile(gameDirectory);
            Path temporary = directory.resolve("client-request.json.tmp");

            // Start from whatever is already saved on disk.
            ObjectNode json = null;
            if (Files.isRegularFile(target)) {
                try {
                    JsonNode existing = MAPPER.readTree(Files.readString(target, StandardCharsets.UTF_8));
                    if (existing != null && existing.isObject()) json = (ObjectNode) existing;
                } catch (IOException corrupted) {
                    json = null;
                }
                if (json == null) {
                    // Keep the unreadable file for recovery instead of destroying it.
                    try {
                        Files.move(target, directory.resolve("client-request.json.bad"),
                                StandardCopyOption.REPLACE_EXISTING);
                    } catch (IOException ignored) { }
                }
            }
            if (json == null) json = MAPPER.createObjectNode();

            // Client-owned capability fields: always current.
            json.put("protocol", 1);
            json.put("productVersion", "V1");
            json.put("preferredDisplayMode", "MAX_SUPPORTED_REFRESH_RATE");
            json.put("nativePngPicker", true);
            json.put("appearanceIndex", "../profiles/appearance-index.json");
            json.put("appearanceSync", "BIDIRECTIONAL_ATOMIC");

            // Saved server IP: the client's saved value wins; otherwise the
            // already-saved value is kept untouched. Never a forced default.
            String clientSavedIp = Config.savedServerIp();
            if (!clientSavedIp.isEmpty()) {
                json.put("serverIp", clientSavedIp);
            } else if (!json.path("serverIp").asText("").trim().isEmpty()) {
                // Preserve the value saved by the launcher / a previous session.
            } else {
                json.put("serverIp", "");
            }

            // Saved frame-rate preference: keep any saved non-zero value; the
            // default 0 (max supported refresh) only applies when nothing is saved.
            int savedFrameRate = json.path("preferredFrameRate").asInt(0);
            json.put("preferredFrameRate", savedFrameRate > 0 ? savedFrameRate : 0);

            String out = MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(json) + "\n";
            Files.writeString(temporary, out, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ignored) {
            // Launcher integration is optional and must never block client startup.
        }
    }
}
