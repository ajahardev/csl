package com.craftstudio.csclient.ui.components.inputs;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

public abstract class Input extends Element {
    String text = "";
    public int cursorPosition = 0;
    private float focusProgress;

    public abstract void checkReset();
    public abstract void backspace();
    public boolean validateBackspace() { return true; }

    @Override
    public boolean acceptsTextInput() {
        return true;
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        boolean shortcut = (modifiers & (GLFWProvider.GLFW_MOD_CONTROL | GLFWProvider.GLFW_MOD_SUPER)) != 0;
        if (shortcut && keyCode == GLFWProvider.GLFW_KEY_V) {
            String clipboard = Providers.csClient.getClient().getClipboardText();
            if (clipboard != null) {
                for (int i = 0; i < clipboard.length(); i++) charTyped(clipboard.charAt(i));
            }
        } else if (keyCode == GLFWProvider.GLFW_KEY_BACKSPACE) {
            if (cursorPosition > 0 && validateBackspace()) {
                text = text.substring(0, cursorPosition - 1) + text.substring(cursorPosition);
                cursorPosition--;
                backspace();
            }
        } else if (keyCode == GLFWProvider.GLFW_KEY_LEFT && cursorPosition > 0) {
            cursorPosition--;
        } else if (keyCode == GLFWProvider.GLFW_KEY_RIGHT && cursorPosition < text.length()) {
            cursorPosition++;
        } else if (keyCode == GLFWProvider.GLFW_KEY_HOME) {
            cursorPosition = 0;
        } else if (keyCode == GLFWProvider.GLFW_KEY_END) {
            cursorPosition = text.length();
        } else if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE || keyCode == GLFWProvider.GLFW_KEY_ENTER) {
            // Commit: persist the current value so a relaunch never loses it.
            com.craftstudio.csclient.config.ConfigManager.save();
            focused = false;
        }
    }

    @Override
    public void click(int mouseX, int mouseY) {
        int scrollOffset = getScrollOffset();
        String visibleText = text.substring(scrollOffset);
        int newCursorPos = scrollOffset;
        for (int i = 0; i < visibleText.length(); i++) {
            float textWidth = Fonts.getWidth(visibleText.substring(0, i + 1), Theme.FONT.value) * 0.52f;
            if (textWidth > mouseX - 10) break;
            newCursorPos++;
        }
        cursorPosition = newCursorPos;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        checkReset();
        float target = focused ? 1f : (ctx.isHovering() ? 0.4f : 0f);
        focusProgress += (target - focusProgress) * 0.23f;
        scope.drawRoundedRectangle(0, 0, width, height, 10, 0xEB181D23);
        scope.drawRoundedBorder(0, 0, width, height, 10,
                Theme.withAlpha(65 + Math.round(160 * focusProgress), Theme.ACCENT.value));

        int scrollOffset = getScrollOffset();
        String visibleText = getVisibleText(scrollOffset);
        scope.drawText(0.52f, visibleText, 10, 11, Theme.FONT.value, Theme.FOREGROUND.value);

        if (focused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
            int safeCursor = Math.max(scrollOffset, Math.min(cursorPosition, text.length()));
            int cursorX = 10 + (int) (Fonts.getWidth(text.substring(scrollOffset, safeCursor), Theme.FONT.value) * 0.52f);
            scope.drawRectangle(cursorX, 7, 1, height - 14, Theme.ACCENT.value);
        }
    }

    protected int getScrollOffset() {
        if (text.isEmpty()) return 0;
        int offset = 0;
        int maxWidth = width - 20;
        while (offset < cursorPosition) {
            String visibleText = text.substring(offset, cursorPosition);
            if (Fonts.getWidth(visibleText, Theme.FONT.value) * 0.52f > maxWidth) offset++;
            else break;
        }
        return offset;
    }

    protected String getVisibleText(int scrollOffset) {
        String visibleText = text.substring(scrollOffset);
        for (int i = 1; i <= visibleText.length(); i++) {
            if (Fonts.getWidth(visibleText.substring(0, i), Theme.FONT.value) * 0.52f > width - 20) {
                return visibleText.substring(0, i - 1);
            }
        }
        return visibleText;
    }
}
