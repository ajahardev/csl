package com.craftstudio.csclient.ui.components.inputs;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Large animated switch with a 52x28 touch target. */
public class Toggle extends Element {
    private final BoolProperty prop;
    private float progress;

    public Toggle(BoolProperty prop) {
        this.prop = prop;
        this.width = 52;
        this.height = 28;
        this.progress = prop.value ? 1f : 0f;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = prop.value ? 1f : 0f;
        progress += (target - progress) * 0.24f;
        int track = blend(0xFF2A3139, Theme.ACCENT.value, progress);
        if (ctx.isHovering()) track = blend(track, 0xFFFFFFFF, 0.10f);
        scope.drawRoundedRectangle(0, 0, width, height, 14, track);
        int knobX = 4 + Math.round(progress * 24f);
        scope.drawRoundedRectangle(knobX, 4, 20, 20, 10,
                blend(0xFF98A0A8, Theme.ACCENT_FG.value, progress));
    }

    @Override
    public void click(int mouseX, int mouseY) {
        prop.value = !prop.value;
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
