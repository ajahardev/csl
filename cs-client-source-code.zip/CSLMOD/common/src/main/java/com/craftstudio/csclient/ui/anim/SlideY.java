package com.craftstudio.csclient.ui.anim;

import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.ui.Element;

public class SlideY extends Animation {
    int offset = 20;
    double startY;

    public SlideY(AnimationConfig config) {
        super(config);
    }

    public SlideY(AnimationConfig config, int offset) {
        super(config);
        this.offset = offset;
    }

    public SlideY(int duration) {
        super(duration);
    }

    public SlideY(int duration, int offset) {
        super(duration);
        this.offset = offset;
    }

    @Override
    public void init(Element element) {
        startY = element.y - offset;
        element.y = (int) startY;
    }

    @Override
    public void tick(double progress, Element element) {
        double currentY = startY + offset * progress;
        element.y = (int) currentY;
    }
}
