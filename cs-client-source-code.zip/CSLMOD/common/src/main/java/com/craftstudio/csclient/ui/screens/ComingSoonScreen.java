package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.Fade;
import com.craftstudio.csclient.ui.anim.PopFade;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.ImageTexture;
import com.craftstudio.csclient.ui.elements.QuickPopupSurface;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

/** Offline-only Store placeholder; no account, purchase or network service exists. */
public class ComingSoonScreen extends CSClientScreen {
    private final CSClientScreen parent;

    public ComingSoonScreen(CSClientScreen parent) {
        super("CS Client V1 Store — Coming Soon");
        this.parent = parent == null ? new TitleMenu() : parent;
        backgroundBlur = 1;
        backgroundOpacity = 0.34f;
    }

    @Override
    public void ui() {
        int panelWidth = Math.min(354, width - 30);
        int panelHeight = 224;
        int x = (width - panelWidth) / 2;
        int y = Math.max(14, (height - panelHeight) / 2);
        int accent = Theme.ACCENT.value;

        draw(new QuickPopupSurface(accent).dimensions(panelWidth, panelHeight).position(x, y)
                .animation(pop(0)));
        draw(new ImageTexture(Textures.STORE).dimensions(40, 40).position(x + 28, y + 24)
                .animation(pop(35)));
        draw(new Text("CS CLIENT V1 STORE").scale(0.72f).position(x + 82, y + 25)
                .animation(slide(-7, 45)));
        draw(new Text("COMING SOON").color(accent).scale(0.32f).position(x + 83, y + 53)
                .animation(fade(60)));

        draw(new Text("A new CS experience is being prepared.").scale(0.38f)
                .position(x + 28, y + 92).animation(slide(-5, 80)));
        draw(new Text("For now this is an offline preview only:").scale(0.29f)
                .position(x + 28, y + 117).animation(fade(95)));
        draw(new Text("NO LOGIN  •  NO PAYMENT  •  NO REMOTE STORE").color(accent).scale(0.28f).position(x + 28, y + 140).animation(fade(110)));

        draw(new HomeMenuButton(Textures.BACK, "BACK TO HOME", false, this::goBack)
                .dimensions(panelWidth - 56, 38).position(x + 28, y + 170)
                .animation(slide(8, 125)));
    }

    private void goBack() { Providers.csClient.getClient().setScreen(parent); }
    @Override public boolean shouldPause() { return false; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            goBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private static PopFade pop(int delay) {
        PopFade value = new PopFade(AnimationConfig.mainMenu);
        value.delay = delay;
        return value;
    }
    private static SlideFade slide(int offset, int delay) {
        SlideFade value = new SlideFade(AnimationConfig.mainMenu, offset);
        value.delay = delay;
        return value;
    }
    private static Fade fade(int delay) {
        Fade value = new Fade(AnimationConfig.mainMenu);
        value.delay = delay;
        return value;
    }
}
