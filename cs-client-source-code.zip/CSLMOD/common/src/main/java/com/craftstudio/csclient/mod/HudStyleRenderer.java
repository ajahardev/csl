package com.craftstudio.csclient.mod;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.RenderScope;

/** Distinct, low-cost HUD shells for each public style preset. */
public final class HudStyleRenderer {
    private HudStyleRenderer() { }

    public static void drawBackground(RenderScope scope, ModLayout layout) {
        if (scope == null || layout == null || !layout.renderBackground) return;
        int width = Math.max(1, layout.width);
        int height = Math.max(1, layout.height);
        int style = Math.max(0, Math.min(3, layout.style.value));
        if (!layout.background.value) {
            drawUnbackedStyle(scope, layout, width, height, style);
            return;
        }
        switch (style) {
            case 0 -> drawMinecraft(scope, layout, width, height);
            case 1 -> drawFeather(scope, layout, width, height);
            case 2 -> drawLunar(scope, layout, width, height);
            default -> drawCs(scope, layout, width, height);
        }
    }

    private static void drawMinecraft(RenderScope scope, ModLayout layout, int width, int height) {
        // Vanilla HUD language: square translucent backdrop and a crisp lower edge.
        scope.drawRectangle(0, 0, width, height, (layout.bgColor.value & 0x00FFFFFF) | 0x90000000);
        scope.drawRectangle(0, height - 1, width, 1, 0x78000000);
    }

    private static void drawFeather(RenderScope scope, ModLayout layout, int width, int height) {
        // Feather-inspired compact glass: restrained radius, hairline border, slim activity rail.
        int radius = Math.max(3, Math.min(5, layout.radius.value));
        scope.drawRoundedRectangle(0, 1, width, Math.max(1, height - 1), radius,
                (layout.bgColor.value & 0x00FFFFFF) | 0xD0000000);
        scope.drawRoundedBorder(0, 1, width, Math.max(1, height - 1), radius, 0x4C9CA6AF);
        scope.drawRoundedRectangle(2, 4, 2, Math.max(3, height - 8), 1,
                withAlpha(190, layout.fgColor.value));
    }

    private static void drawLunar(RenderScope scope, ModLayout layout, int width, int height) {
        // Lunar-like dense dark plate with cool outline and a grounded shadow.
        int radius = Math.max(2, Math.min(4, layout.radius.value));
        scope.drawRoundedRectangle(1, 2, Math.max(1, width - 2), Math.max(1, height - 2), radius,
                (layout.bgColor.value & 0x00FFFFFF) | 0xE3000000);
        scope.drawRoundedBorder(1, 1, Math.max(1, width - 2), Math.max(1, height - 2), radius,
                0x665C6875);
        scope.drawRectangle(4, height - 1, Math.max(1, width - 8), 1, 0x785FA8FF);
    }

    private static void drawCs(RenderScope scope, ModLayout layout, int width, int height) {
        // CS Graphite: deeper surface, accent corner rail and quiet top highlight.
        int radius = Math.max(6, layout.radius.value);
        scope.drawRoundedRectangle(0, 0, width, height, radius,
                (layout.bgColor.value & 0x00FFFFFF) | 0xEA000000);
        scope.drawRoundedBorder(0, 0, width, height, radius,
                withAlpha(120, Theme.ACCENT.value));
        scope.drawRectangle(7, 1, Math.max(1, width - 14), 1, 0x4CFFFFFF);
        scope.drawRoundedRectangle(3, 4, 3, Math.max(3, height - 8), 2,
                withAlpha(220, Theme.ACCENT.value));
    }

    private static void drawUnbackedStyle(RenderScope scope, ModLayout layout,
            int width, int height, int style) {
        switch (style) {
            case 1 -> scope.drawRoundedRectangle(1, 3, 2, Math.max(4, height - 6), 1,
                    withAlpha(180, layout.fgColor.value));
            case 2 -> {
                scope.drawRectangle(0, 0, Math.min(8, width), 1, 0xA05FA8FF);
                scope.drawRectangle(0, 0, 1, Math.min(7, height), 0xA05FA8FF);
            }
            case 3 -> scope.drawRoundedRectangle(2, Math.max(2, height / 2 - 2), 4, 4, 2,
                    Theme.ACCENT.value);
            default -> { /* Minecraft stays completely unframed. */ }
        }
    }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }
}
