package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * Visual-only enhanced controller for Minecraft's real debug hitbox renderer.
 * It never alters an entity's collision box, combat reach, damage, packets, or
 * server-side targeting. Unlike a bare F3+B toggle, it can filter which entity
 * classes receive vanilla body/eye/look-direction debug visuals.
 */
public class HitboxMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty ONLY_ATTACKABLE = Property.bool(false);
    private static final BoolProperty SHOW_PLAYERS = Property.bool(true);
    private static final BoolProperty SHOW_HOSTILE = Property.bool(true);
    private static final BoolProperty SHOW_PASSIVE = Property.bool(true);
    private static final BoolProperty SHOW_OTHER_MOBS = Property.bool(true);
    private static final IntProperty MAX_DISTANCE = Property.integer(32);

    private boolean previousDebugState;
    private boolean capturedDebugState;

    public HitboxMod() {
        super(new ModSpec("Hitbox", "hitbox")
                        .description("Filtered visual hitboxes with vanilla eye/look-direction guides")
                        .version("v2.0.0").tags("PvP", "Visuals", "Utility")
                        .requires(Providers.feature::player, Providers.feature::entity),
                ENABLED.named("Enabled"),
                ONLY_ATTACKABLE.named("Only while target is in attack range"),
                SHOW_PLAYERS.named("Show players"),
                SHOW_HOSTILE.named("Show hostile mobs"),
                SHOW_PASSIVE.named("Show passive mobs"),
                SHOW_OTHER_MOBS.named("Show neutral and boss mobs"),
                MAX_DISTANCE.named("Maximum visual distance"));
    }

    @Override
    public void tick() {
        if (!ENABLED.value) return;
        boolean visible = !ONLY_ATTACKABLE.value
                || (Providers.feature.entity().isTargetingLivingEntity()
                    && Providers.feature.entity().getTargetDistance() <= attackRange());
        if (Providers.feature.player().areHitboxesEnabled() != visible) {
            Providers.feature.player().setHitboxesEnabled(visible);
        }
    }

    /** Category predicates are consumed only by target-specific visual renderer mixins. */
    public static boolean isActive() { return ENABLED.value; }
    public static boolean showPlayers() { return SHOW_PLAYERS.value; }
    public static boolean showHostile() { return SHOW_HOSTILE.value; }
    public static boolean showPassive() { return SHOW_PASSIVE.value; }
    public static boolean showOtherMobs() { return SHOW_OTHER_MOBS.value; }
    public static int maxDistance() { return Math.max(4, Math.min(128, MAX_DISTANCE.value)); }
    private static double attackRange() { return 3.25; }

    @Override public boolean isEnabled() { return ENABLED.value; }

    @Override
    public void onEnabled(boolean enabled) {
        if (enabled) {
            previousDebugState = Providers.feature.player().areHitboxesEnabled();
            capturedDebugState = true;
            ENABLED.value = true;
            Providers.feature.player().setHitboxesEnabled(!ONLY_ATTACKABLE.value);
            return;
        }

        ENABLED.value = false;
        if (capturedDebugState) {
            Providers.feature.player().setHitboxesEnabled(previousDebugState);
            capturedDebugState = false;
        }
    }
}
