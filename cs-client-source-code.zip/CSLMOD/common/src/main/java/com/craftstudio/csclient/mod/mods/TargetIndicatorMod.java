package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.ModSpec;

public class TargetIndicatorMod extends TextHudMod {
    public TargetIndicatorMod() {
        super(new ModSpec("Target Indicator", "target").description("Shows when the crosshair is over a living entity")
                .version("v1.0.0").tags("PvP", "HUD").requires(Providers.feature::entity), 92);
    }

    @Override protected String getText() {
        return Providers.feature.entity().isTargetingLivingEntity() ? "● TARGET LOCK" : "○ NO TARGET";
    }
    @Override protected String getDummyText() { return "● TARGET LOCK"; }
}
