package com.craftstudio.csclient.ui;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;

/**
 * Lightweight CS reload composition shared by both active Minecraft targets.
 * Only packaged PNGs and primitive quads are submitted while resources reload:
 * no GIFs, rotation, dynamic SVG generation, or early custom-font work.
 */
public final class LoadingVisuals {
    public static final float FADE_OUT_MILLIS = 620f;
    public static final float FADE_IN_MILLIS = 420f;

    private LoadingVisuals() {
    }

    public static void render(RenderScope scope, int width, int height,
            float progress, int alpha, long now) {
        float safeProgress = Math.max(0f, Math.min(1f, progress));
        int centerX = width / 2;
        int centerY = height / 2 - Math.max(8, height / 28);
        int white = forceAlpha(alpha, 0xFFF3F5F7);
        int muted = forceAlpha(Math.round(alpha * 0.34f), 0xFFD4D9DE);
        int faint = forceAlpha(Math.round(alpha * 0.12f), 0xFFFFFFFF);
        int accent = forceAlpha(alpha, Theme.ACCENT.value);

        // Open canvas with restrained framing; no containing dashboard panel.
        int edgeBand = Math.max(1, height / 10);
        scope.drawRectangle(0, 0, width, edgeBand,
                forceAlpha(Math.round(alpha * 0.10f), 0xFF000000));
        scope.drawRectangle(0, height - edgeBand, width, edgeBand,
                forceAlpha(Math.round(alpha * 0.14f), 0xFF000000));
        scope.drawRectangle(0, centerY, width, 1, faint);

        int logoSize = clamp(Math.min(width, height) / 6, 56, 86);
        int logoX = centerX - logoSize / 2;
        int logoY = centerY - logoSize - 24;
        float breathe = (float) ((Math.sin(now / 540.0) + 1.0) * 0.5);
        int bracketAlpha = Math.round(alpha * (0.19f + breathe * 0.15f));
        int bracket = forceAlpha(bracketAlpha, Theme.ACCENT.value);
        int bracketGap = 10;
        int bracketLength = Math.max(10, logoSize / 5);

        // Four tiny corner brackets provide motion without moving the brand mark.
        int left = logoX - bracketGap;
        int top = logoY - bracketGap;
        int right = logoX + logoSize + bracketGap;
        int bottom = logoY + logoSize + bracketGap;
        scope.drawRectangle(left, top, bracketLength, 1, bracket);
        scope.drawRectangle(left, top, 1, bracketLength, bracket);
        scope.drawRectangle(right - bracketLength, top, bracketLength, 1, bracket);
        scope.drawRectangle(right - 1, top, 1, bracketLength, bracket);
        scope.drawRectangle(left, bottom - 1, bracketLength, 1, bracket);
        scope.drawRectangle(left, bottom - bracketLength, 1, bracketLength, bracket);
        scope.drawRectangle(right - bracketLength, bottom - 1, bracketLength, 1, bracket);
        scope.drawRectangle(right - 1, bottom - bracketLength, 1, bracketLength, bracket);

        // Stable packaged bitmaps remain available during resource reconstruction.
        scope.drawTexture(Textures.LOGO, logoX, logoY, 0, 0, logoSize, logoSize, white);
        int wordWidth = Math.min(218, Math.max(132, width - 120));
        int wordHeight = Math.max(13, Math.round(wordWidth * (60f / 606f)));
        int wordX = centerX - wordWidth / 2;
        int wordY = logoY + logoSize + 15;
        scope.drawTexture(Textures.LOGO_TEXT_BIG, wordX, wordY, 0, 0, wordWidth, wordHeight, white);

        int sideLineWidth = Math.max(18, Math.min(70, (width - wordWidth) / 5));
        int sideLineY = wordY + wordHeight / 2;
        scope.drawRectangle(wordX - sideLineWidth - 14, sideLineY, sideLineWidth, 1, muted);
        scope.drawRectangle(wordX + wordWidth + 14, sideLineY, sideLineWidth, 1, muted);

        // Actual smoothed Minecraft resource-reload progress, never a fake timer.
        int trackWidth = Math.min(370, Math.max(150, width - 92));
        int trackX = centerX - trackWidth / 2;
        int trackY = wordY + wordHeight + Math.max(30, height / 16);
        int trackOutline = forceAlpha(Math.round(alpha * 0.42f), 0xFFFFFFFF);
        scope.drawRectangle(trackX, trackY, trackWidth, 1, trackOutline);
        scope.drawRectangle(trackX, trackY + 5, trackWidth, 1, trackOutline);
        scope.drawRectangle(trackX, trackY, 1, 6, trackOutline);
        scope.drawRectangle(trackX + trackWidth - 1, trackY, 1, 6, trackOutline);

        int innerWidth = Math.max(0, trackWidth - 4);
        int fillWidth = Math.round(innerWidth * safeProgress);
        if (fillWidth > 0) {
            int fillX = trackX + 2;
            scope.drawRectangle(fillX, trackY + 2, fillWidth, 2, accent);

            // A clipped scanner glides only over the completed part of the bar.
            int scannerWidth = Math.min(22, fillWidth);
            int travel = Math.max(1, fillWidth + scannerWidth);
            int scannerOffset = (int) ((now / 12L) % travel) - scannerWidth;
            int scannerX = Math.max(fillX, fillX + scannerOffset);
            int scannerEnd = Math.min(fillX + fillWidth, fillX + scannerOffset + scannerWidth);
            if (scannerEnd > scannerX) {
                scope.drawRectangle(scannerX, trackY + 2, scannerEnd - scannerX, 2,
                        forceAlpha(Math.round(alpha * 0.72f), 0xFFFFFFFF));
            }

            int headX = fillX + fillWidth - 1;
            scope.drawRectangle(headX, trackY - 1, 2, 8, white);
        }

        // Four stage marks remain readable even before fonts are safe to submit.
        for (int i = 0; i < 4; i++) {
            float threshold = (i + 1) / 4f;
            int x = trackX + Math.round(trackWidth * threshold) - 1;
            int color = safeProgress >= threshold ? accent : muted;
            scope.drawRectangle(x, trackY + 12, 2, 2, color);
        }

        // Custom fonts are intentionally delayed until the resource reload is done.
        if (safeProgress >= 0.995f) {
            String ready = "CS CLIENT V1  •  READY";
            float scale = 0.36f;
            int textWidth = Math.round(Fonts.getWidth(ready, Theme.FONT.value) * scale);
            scope.drawText(scale, ready, centerX - textWidth / 2, trackY + 24,
                    Theme.FONT.value, white);
        }
    }

    private static int forceAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (clamp(alpha, 0, 255) << 24);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
