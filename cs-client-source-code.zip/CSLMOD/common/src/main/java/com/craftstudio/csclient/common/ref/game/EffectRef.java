package com.craftstudio.csclient.common.ref.game;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;

public interface EffectRef {
    /** Safe default for launcher- or mapping-modified effect instances. */
    default boolean shouldShowIcon() { return true; }

    SpriteRef getIcon();

    default IdentifierRef getIconId() {
        return null;
    }

    default boolean isInfinite() { return false; }

    String getInfiniteText();

    int getDurationSeconds();
}
