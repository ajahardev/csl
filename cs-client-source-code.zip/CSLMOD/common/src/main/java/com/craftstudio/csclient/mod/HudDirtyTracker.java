package com.craftstudio.csclient.mod;

/**
 * Per-module frame-skip state for HUD widgets.
 *
 * The biggest client-side FPS cost is redrawing static HUD content every
 * frame (text measurement, string layout and GPU render-state submission).
 * A widget that shows the same value, colour and position does not need to
 * be re-submitted. Each widget keeps one of these trackers; when the content
 * is unchanged since the last drawn frame the whole draw pass is skipped.
 *
 * This only reduces work CS itself schedules — it never touches Minecraft
 * settings, world rendering or any external state.
 */
public final class HudDirtyTracker {
    private String lastContent;
    private int lastColor;
    private int lastX;
    private int lastY;
    private float lastScale;

    /**
     * @param content the exact text/content that would be drawn
     * @param color   the exact colour that would be used
     * @param layout  current position/scale
     * @return true when this frame must be drawn, false when the previous
     *         frame already drew identical content at the same place
     */
    public boolean dirty(String content, int color, ModLayout layout) {
        int x = layout.x.value;
        int y = layout.y.value;
        float scale = layout.scale.value;
        if (content == lastContent || (content != null && content.equals(lastContent))) {
            if (color == lastColor && x == lastX && y == lastY && scale == lastScale) {
                return false;
            }
        }
        lastContent = content;
        lastColor = color;
        lastX = x;
        lastY = y;
        lastScale = scale;
        return true;
    }

    /** Forces the next frame to draw (layout edits, style changes, ...). */
    public void invalidate() {
        lastContent = null;
    }
}
