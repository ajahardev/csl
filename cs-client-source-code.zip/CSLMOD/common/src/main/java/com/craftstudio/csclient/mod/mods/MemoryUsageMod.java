package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.ModSpec;

public class MemoryUsageMod extends TextHudMod {
    private static final BoolProperty showMaximum = Property.bool(false);

    public MemoryUsageMod() {
        super(new ModSpec("Memory Usage", "memory").description("Displays Java heap memory usage")
                        .version("v1.0.0").tags("Performance", "HUD"),
                98, showMaximum.named("Show Maximum"));
    }

    @Override protected String getText() {
        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) / 1_048_576L;
        long max = rt.maxMemory() / 1_048_576L;
        return showMaximum.value ? used + " / " + max + " MB" : used + " MB RAM";
    }
    @Override protected String getDummyText() { return showMaximum.value ? "824 / 2048 MB" : "824 MB RAM"; }
}
