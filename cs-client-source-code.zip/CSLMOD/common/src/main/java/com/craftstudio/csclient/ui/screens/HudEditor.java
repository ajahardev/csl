package com.craftstudio.csclient.ui.screens;

import java.util.ArrayList;
import java.util.List;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.render.MatrixStackRef;
import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.mod.ModRuntimeGuard;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;

/**
 * Direct-manipulation HUD editor inspired by Lunar and Feather clients.
 * Drag a widget to move it and drag its lower-right handle to resize it.
 *
 * <p>The normal editor intentionally remains a precise, utility-first canvas.
 * The {@link ShiftMenu} quick-overlay mode adds a lightweight entrance, hover,
 * drag, snap and exit motion system without changing the separate Modules page.
 * All quick-overlay motion is transform/opacity based: no particles, per-frame
 * collections, or dynamically generated textures are used.</p>
 */
public class HudEditor extends CSClientScreen {
    private static final float MIN_SCALE = 0.35f;
    private static final float MAX_SCALE = 3.0f;
    private static final int HANDLE_SIZE = 12;
    private static final int SNAP_DISTANCE = 7;
    private static final int COLLISION_GAP = 4;

    // The sequence is deliberately short so Right Shift stays responsive on Pojav/mobile launchers.
    private static final long OVERLAY_INTRO_MILLIS = 460L;
    private static final long OVERLAY_OUTRO_MILLIS = 190L;
    private static final long WIDGET_INTRO_MILLIS = 340L;
    private static final long WIDGET_STAGGER_MILLIS = 32L;
    private static final long LOGO_DELAY_MILLIS = 68L;
    private static final long SETTINGS_DELAY_MILLIS = 158L;
    private static final long FOOTER_DELAY_MILLIS = 286L;

    private enum ExitTarget {
        NONE,
        GAMEPLAY,
        MODULES
    }

    /** Per-widget visual state; owned by Entry so render does not allocate maps every frame. */
    private static final class Motion {
        float hover;
        float active;
        float dragging;
        float snapPulse;
    }

    private static final class Entry {
        final Mod mod;
        final HudMod hud;
        final Motion motion = new Motion();

        Entry(Mod mod, HudMod hud) {
            this.mod = mod;
            this.hud = hud;
        }
    }

    private final List<Entry> entries = new ArrayList<>();
    private final boolean shiftOverlay;
    private Entry selected;
    private Entry dragging;
    private boolean resizing;
    private int dragOffsetX;
    private int dragOffsetY;
    private int viewportWidth = 960;
    private int viewportHeight = 540;
    private String presetStatus = "6 COLOR PRESETS  •  REVERSIBLE";

    // Quick Right Shift overlay motion state. Normal HudEditor deliberately does not use it.
    private float settingsHover;
    private float settingsClickPulse;
    private long lastAnimationElapsed = -1L;
    private long exitStartedAt = -1L;
    private float exitStartVisibility = 1f;
    private ExitTarget exitTarget = ExitTarget.NONE;
    private boolean exitCommitted;

    public HudEditor() {
        this(false);
    }

    protected HudEditor(boolean shiftOverlay) {
        super(shiftOverlay ? "CS Client V1 HUD Layout" : "CS Client V1 HUD Editor");
        this.shiftOverlay = shiftOverlay;
        if (shiftOverlay) {
            backgroundBlur = 2;
            // Render() raises this smoothly on the first frames instead of flashing the dim layer.
            backgroundOpacity = 0f;
        }
        refreshEntries(true);
    }

    private void refreshEntries(boolean placeUnpositioned) {
        entries.clear();
        int unplaced = 0;
        for (Mod mod : ModManager.ENABLED_MODS) {
            if (!(mod instanceof HudMod hud)) continue;
            ModLayout layout = hud.getDimensions();
            if (placeUnpositioned && !hud.usesNativeDefaultPosition()
                    && layout.x.value == 0 && layout.y.value == 0) {
                layout.x.value = 16 + (unplaced % 4) * 100;
                layout.y.value = 40 + (unplaced / 4) * 21;
                unplaced++;
            }
            entries.add(new Entry(mod, hud));
        }
        resolveExistingCollisions();
        selected = null;
        dragging = null;
        resizing = false;
    }

    @Override
    public void ui() {
        // HUD widgets are rendered directly in render() so their coordinates match gameplay.
    }

    @Override
    public void render(RenderScope scope, int mouseX, int mouseY, float delta, long elapsed) {
        viewportWidth = scope.getScaledWindowWidth();
        viewportHeight = scope.getScaledWindowHeight();
        // CSClientScreenFabric now supplies native GUI coordinates consistently
        // for both rendering and input; no legacy 2× correction is needed.
        int pointerX = mouseX;
        int pointerY = mouseY;

        if (!shiftOverlay) {
            renderFullEditor(scope, pointerX, pointerY);
            return;
        }

        float frameSeconds = advanceAnimationClock(elapsed);
        float visibility = overlayVisibility(elapsed);
        // CSClientScreenFabric samples this on its next frame, creating a smooth backdrop fade.
        backgroundOpacity = 0.62f * visibility;

        renderShiftOverlay(scope, pointerX, pointerY, elapsed, frameSeconds, visibility);
        finishShiftExitIfReady(elapsed);
    }

    /** Keeps the standalone/full HUD Editor visually and behaviorally separate from RShift. */
    private void renderFullEditor(RenderScope scope, int pointerX, int pointerY) {
        scope.drawBorder(4, 4, viewportWidth - 8, viewportHeight - 8,
                Theme.withAlpha(75, Theme.ACCENT.value));
        scope.drawRectangle(viewportWidth / 2, 4, 1, viewportHeight - 8,
                Theme.withAlpha(35, Theme.ACCENT.value));
        scope.drawRectangle(4, viewportHeight / 2, viewportWidth - 8, 1,
                Theme.withAlpha(35, Theme.ACCENT.value));

        if (entries.isEmpty()) {
            String message = "ENABLE A HUD MODULE FIRST, THEN RETURN HERE";
            scope.drawText(0.6f, message,
                    (viewportWidth - (int) (Fonts.getWidth(message, Theme.FONT.value) * 0.6f)) / 2,
                    viewportHeight / 2, Theme.FONT.value, Theme.PRIMARY_FG.value);
        } else {
            for (Entry entry : entries) renderStaticEntry(scope, entry, pointerX, pointerY);
        }
        drawToolbar(scope);
    }

    /** Original full-editor drawing path, intentionally free of quick-overlay animation transforms. */
    private void renderStaticEntry(RenderScope scope, Entry entry, int pointerX, int pointerY) {
        ModLayout layout = entry.hud.getDimensions();
        if (!entry.hud.isUsingNativeDefaultPosition()) clampLayout(layout);
        boolean hovered = isInside(pointerX, pointerY, layout);
        boolean active = entry == selected || entry == dragging;

        MatrixStackRef matrices = scope.getMatrixStack();
        ModRuntimeGuard.run(entry.mod, "HUD editor render", () -> {
            matrices.push();
            try {
                matrices.translate(layout.x.value, layout.y.value);
                matrices.scale(layout.scale.value, layout.scale.value);
                entry.hud.renderBackground(scope);
                entry.hud.renderEditor(scope);
            } finally {
                matrices.pop();
            }
        });

        int boxWidth = scaledWidth(layout);
        int boxHeight = scaledHeight(layout);
        int borderColor = active ? Theme.ACCENT.value
                : hovered ? Theme.FOREGROUND.value : Theme.withAlpha(105, Theme.PRIMARY_FG.value);
        scope.drawBorder(layout.x.value, layout.y.value, boxWidth, boxHeight, borderColor);

        if (active || hovered) drawWidgetChrome(scope, entry, layout, boxWidth, boxHeight, active);
    }

    /** Right Shift's world-visible animated HUD layout overlay. */
    private void renderShiftOverlay(RenderScope scope, int pointerX, int pointerY, long elapsed,
            float frameSeconds, float visibility) {
        if (entries.isEmpty()) {
            drawShiftEmptyState(scope, elapsed, visibility);
        } else {
            for (int index = 0; index < entries.size(); index++) {
                renderShiftEntry(scope, entries.get(index), index, pointerX, pointerY,
                        elapsed, frameSeconds, visibility);
            }
        }

        drawShiftCenter(scope, pointerX, pointerY, elapsed, frameSeconds, visibility);
        drawShiftFooter(scope, elapsed, visibility);
        scope.setOpacity(1f);
    }

    private void drawShiftEmptyState(RenderScope scope, long elapsed, float visibility) {
        float reveal = easeOutCubic(stage(elapsed, LOGO_DELAY_MILLIS, 300L));
        String message = "ENABLE A HUD MODULE FIRST, THEN RETURN HERE";
        scope.setOpacity(visibility * reveal);
        scope.drawText(0.6f, message,
                (viewportWidth - (int) (Fonts.getWidth(message, Theme.FONT.value) * 0.6f)) / 2,
                viewportHeight / 2 - 126, Theme.FONT.value, Theme.PRIMARY_FG.value);
        scope.setOpacity(1f);
    }

    /**
     * Each active widget arrives in a short stagger, then has frame-rate-independent hover/drag feedback.
     * The actual configured layout coordinates are never changed by animation transforms.
     */
    private void renderShiftEntry(RenderScope scope, Entry entry, int index, int pointerX, int pointerY,
            long elapsed, float frameSeconds, float visibility) {
        ModLayout layout = entry.hud.getDimensions();
        if (!entry.hud.isUsingNativeDefaultPosition()) clampLayout(layout);
        boolean hovered = isInside(pointerX, pointerY, layout);
        boolean active = entry == selected || entry == dragging;
        updateMotion(entry.motion, hovered, active, entry == dragging, frameSeconds);

        long delay = 30L + Math.min(index, 8) * WIDGET_STAGGER_MILLIS;
        float arrival = easeOutBack(stage(elapsed, delay, WIDGET_INTRO_MILLIS));
        float entryAlpha = easeOutCubic(stage(elapsed, delay, WIDGET_INTRO_MILLIS));
        float visualAlpha = visibility * entryAlpha;
        if (visualAlpha <= 0.002f) return;

        int boxWidth = scaledWidth(layout);
        int boxHeight = scaledHeight(layout);
        Motion motion = entry.motion;
        float focus = Math.max(motion.hover, motion.active);
        float introScale = 0.90f + 0.10f * arrival;
        float closeScale = 0.94f + 0.06f * visibility;
        float interactionScale = 1f + motion.active * 0.010f + motion.dragging * 0.014f;
        float visualScale = introScale * closeScale * interactionScale;
        float entryDrop = (1f - entryAlpha) * (10f + Math.min(index, 4) * 2f);
        float lift = entryDrop - motion.hover * 0.8f - motion.dragging * 2.2f;

        int idleBorder = Theme.withAlpha(108, Theme.PRIMARY_FG.value);
        int hoveredBorder = blend(idleBorder, Theme.FOREGROUND.value, motion.hover);
        int borderColor = blend(hoveredBorder, Theme.ACCENT.value, motion.active);

        scope.setOpacity(visualAlpha);
        MatrixStackRef matrices = scope.getMatrixStack();
        matrices.push();
        matrices.translate(layout.x.value + boxWidth / 2f, layout.y.value + boxHeight / 2f + lift);
        matrices.scale(visualScale, visualScale);
        matrices.translate(-boxWidth / 2f, -boxHeight / 2f);

        // Render widget contents at their saved HUD scale inside the presentation transform.
        ModRuntimeGuard.run(entry.mod, "quick HUD editor render", () -> {
            matrices.push();
            try {
                matrices.scale(layout.scale.value, layout.scale.value);
                entry.hud.renderBackground(scope);
                entry.hud.renderEditor(scope);
            } finally {
                matrices.pop();
            }
        });

        scope.drawRoundedBorder(0, 0, boxWidth, boxHeight, 5, borderColor);
        if (focus > 0.015f || motion.snapPulse > 0.015f) {
            float aura = Math.max(focus, motion.snapPulse);
            scope.drawRoundedBorder(-2, -2, boxWidth + 4, boxHeight + 4, 7,
                    Theme.withAlpha(Math.round(28 + aura * 84), Theme.ACCENT.value));
            drawShiftWidgetChrome(scope, entry, layout, boxWidth, boxHeight, focus, motion, elapsed);
        }
        matrices.pop();
        scope.setOpacity(1f);
    }

    private void updateMotion(Motion motion, boolean hovered, boolean active, boolean isDragging,
            float frameSeconds) {
        motion.hover = approach(motion.hover, hovered ? 1f : 0f, frameSeconds, 19f);
        motion.active = approach(motion.active, active ? 1f : 0f, frameSeconds, 15f);
        motion.dragging = approach(motion.dragging, isDragging ? 1f : 0f, frameSeconds, 20f);
        motion.snapPulse = Math.max(0f, motion.snapPulse - frameSeconds * 2.8f);
    }

    /** Local-coordinate chrome for the animated quick overlay only. */
    private void drawShiftWidgetChrome(RenderScope scope, Entry entry, ModLayout layout, int boxWidth,
            int boxHeight, float focus, Motion motion, long elapsed) {
        float reveal = clamp01(focus * 1.65f + motion.snapPulse * 0.45f);
        String label = entry.hud.canScale()
                ? entry.mod.getName() + "  " + Math.round(layout.scale.value * 100) + "%"
                : entry.mod.getName() + "  MOVE ONLY";
        int labelWidth = (int) (Fonts.getWidth(label, Theme.FONT.value) * 0.38f) + 10;
        int labelY = layout.y.value >= 19 ? -15 : boxHeight + 2;
        int labelFill = blend(Theme.PRIMARY.value, Theme.ACCENT.value, motion.active);
        int labelForeground = blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, motion.active);
        scope.drawRoundedRectangle(0, labelY, labelWidth, 13, 4,
                Theme.withAlpha(reveal, labelFill));
        scope.drawText(0.38f, label, 5, labelY + 4, Theme.FONT.value,
                Theme.withAlpha(reveal, labelForeground));
        if (!entry.hud.canScale()) return;

        float pulse = (float) ((Math.sin(elapsed / 105.0 + entry.mod.getName().hashCode()) + 1.0) * 0.5);
        int grow = focus > 0.36f ? 1 : 0;
        int handleSize = HANDLE_SIZE + grow * 2;
        int handleX = boxWidth - HANDLE_SIZE / 2 - grow;
        int handleY = boxHeight - HANDLE_SIZE / 2 - grow;
        int handleColor = blend(Theme.withAlpha(180, Theme.ACCENT.value), Theme.ACCENT.value,
                Math.max(motion.active, motion.dragging));
        scope.drawRoundedRectangle(handleX, handleY, handleSize, handleSize, 3, handleColor);
        int innerAlpha = Math.round(180 + pulse * 75 * reveal);
        scope.drawRectangle(handleX + 3, handleY + 3, handleSize - 6, 1,
                Theme.withAlpha(innerAlpha, Theme.ACCENT_FG.value));
        scope.drawRectangle(handleX + 3, handleY + 6, handleSize - 6, 1,
                Theme.withAlpha(innerAlpha, Theme.ACCENT_FG.value));
    }

    /** Center contains the original CS lockup and exactly one action: CS SETTINGS. */
    private void drawShiftCenter(RenderScope scope, int pointerX, int pointerY, long elapsed,
            float frameSeconds, float visibility) {
        int centerX = viewportWidth / 2;
        int centerY = viewportHeight / 2;
        int buttonY = centerY - 6;
        boolean hoveringSettings = !isShiftExiting()
                && pointerX >= centerX - 100 && pointerX <= centerX + 100
                && pointerY >= buttonY && pointerY <= buttonY + 38;
        settingsHover = approach(settingsHover, hoveringSettings ? 1f : 0f, frameSeconds, 18f);
        settingsClickPulse = Math.max(0f, settingsClickPulse - frameSeconds * 3.7f);

        float logoReveal = easeOutBack(stage(elapsed, LOGO_DELAY_MILLIS, 360L));
        float logoAlpha = visibility * easeOutCubic(stage(elapsed, LOGO_DELAY_MILLIS, 320L));
        drawCenterLockup(scope, centerX, centerY, logoReveal, logoAlpha, elapsed);

        float settingsReveal = easeOutBack(stage(elapsed, SETTINGS_DELAY_MILLIS, 320L));
        float settingsAlpha = visibility * easeOutCubic(stage(elapsed, SETTINGS_DELAY_MILLIS, 280L));
        drawSettingsAction(scope, centerX, buttonY, settingsReveal, settingsAlpha, elapsed);
    }

    private void drawCenterLockup(RenderScope scope, int centerX, int centerY, float reveal,
            float opacity, long elapsed) {
        if (opacity <= 0.002f) return;
        float scale = 0.86f + 0.14f * reveal;
        float drop = (1f - clamp01(reveal)) * 11f;
        float breathe = (float) ((Math.sin(elapsed / 520.0) + 1.0) * 0.5);
        int lockupX = centerX - 104;
        int lockupY = centerY - 74;

        scope.setOpacity(opacity);
        // Four tiny animated brackets make the brand landing feel intentional without adding a new control.
        int bracket = Theme.withAlpha(Math.round(42 + breathe * 48), Theme.ACCENT.value);
        scope.drawRectangle(lockupX - 9, lockupY + 3, 7, 1, bracket);
        scope.drawRectangle(lockupX - 9, lockupY + 3, 1, 7, bracket);
        scope.drawRectangle(lockupX + 210, lockupY + 3, 7, 1, bracket);
        scope.drawRectangle(lockupX + 216, lockupY + 3, 1, 7, bracket);

        MatrixStackRef matrices = scope.getMatrixStack();
        matrices.push();
        matrices.translate(centerX, centerY - 49 + drop);
        matrices.scale(scale, scale);
        matrices.translate(-104, -25);
        scope.drawTexture(Textures.LOGO, 0, 0, 0, 0, 46, 46);
        scope.drawTexture(Textures.LOGO_TEXT, 60, 9, 0, 0, 148, 15);
        scope.drawText(0.25f, "HUD LAYOUT  •  DRAG + SCROLL TO RESIZE",
                61, 32, Theme.FONT.value, Theme.PRIMARY_FG.value);
        matrices.pop();
        scope.setOpacity(1f);
    }

    private void drawSettingsAction(RenderScope scope, int centerX, int buttonY, float reveal,
            float opacity, long elapsed) {
        if (opacity <= 0.002f) return;
        float hover = Math.max(settingsHover, settingsClickPulse * 0.72f);
        float scale = (0.89f + 0.11f * reveal) * (1f + settingsHover * 0.024f);
        float drop = (1f - clamp01(reveal)) * 9f - settingsHover;
        float breathe = (float) ((Math.sin(elapsed / 440.0) + 1.0) * 0.5);
        int fill = blend(0xEC11171C, Theme.ACCENT.value, settingsHover);
        int outline = blend(Theme.withAlpha(175, Theme.ACCENT.value), 0xFFFFFFFF, settingsHover);
        int foreground = blend(Theme.FOREGROUND.value, Theme.ACCENT_FG.value, settingsHover);

        scope.setOpacity(opacity);
        MatrixStackRef matrices = scope.getMatrixStack();
        matrices.push();
        matrices.translate(centerX, buttonY + 19 + drop);
        matrices.scale(scale, scale);
        matrices.translate(-100, -19);

        scope.drawRoundedRectangle(0, 0, 200, 38, 6, fill);
        scope.drawRoundedBorder(0, 0, 200, 38, 6, outline);
        // A muted idle rail and a stronger hover halo provide feedback without a distracting loop.
        int idleRailWidth = Math.round(38 + breathe * 22);
        scope.drawRectangle((200 - idleRailWidth) / 2, 35, idleRailWidth, 1,
                Theme.withAlpha(Math.round(68 + breathe * 44), Theme.ACCENT.value));
        if (hover > 0.01f) {
            scope.drawRoundedBorder(-3, -3, 206, 44, 8,
                    Theme.withAlpha(Math.round(42 + hover * 84), Theme.ACCENT.value));
            int railWidth = Math.round((70 + 92 * hover) * clamp01(reveal));
            scope.drawRectangle((200 - railWidth) / 2, 35, railWidth, 2,
                    Theme.withAlpha(Math.round(190 * hover),
                            settingsHover > 0.5f ? Theme.ACCENT_FG.value : Theme.ACCENT.value));
        }

        int textWidth = Math.round(Fonts.getWidth("CS SETTINGS", Theme.FONT.value) * 0.46f);
        int groupWidth = 18 + 12 + textWidth;
        int groupX = (200 - groupWidth) / 2 + Math.round(settingsHover * 2f);
        int iconY = 10 - (settingsHover > 0.66f ? 1 : 0);
        scope.drawTexture(Textures.SLIDERS, groupX, iconY, 0, 0, 18, 18, foreground);
        scope.drawText(0.46f, "CS SETTINGS", groupX + 30, 14 - (settingsHover > 0.66f ? 1 : 0),
                Theme.FONT.value, foreground);
        matrices.pop();
        scope.setOpacity(1f);
    }

    /** Bottom hints fade in from opposite directions; they remain hints, not extra center controls. */
    private void drawShiftFooter(RenderScope scope, long elapsed, float visibility) {
        float reveal = easeOutCubic(stage(elapsed, FOOTER_DELAY_MILLIS, 210L));
        float opacity = visibility * reveal;
        if (opacity <= 0.002f) return;
        String close = "RSHIFT / ESC  •  CLOSE";
        String resize = "SCROLL ON WIDGET  •  RESIZE";
        float pulse = (float) ((Math.sin(elapsed / 650.0) + 1.0) * 0.5);
        scope.setOpacity(opacity);
        scope.drawRoundedRectangle(14, viewportHeight - 17, 3, 3, 3,
                Theme.withAlpha(Math.round(130 + pulse * 95), Theme.ACCENT.value));
        scope.drawText(0.24f, close, 22, viewportHeight - 16,
                Theme.FONT.value, Theme.PRIMARY_FG.value);
        int resizeWidth = Math.round(Fonts.getWidth(resize, Theme.FONT.value) * 0.24f);
        scope.drawText(0.24f, resize, viewportWidth - resizeWidth - 14, viewportHeight - 16,
                Theme.FONT.value, Theme.PRIMARY_FG.value);
        scope.setOpacity(1f);
    }

    private boolean isSettingsButton(double mouseX, double mouseY) {
        int centerX = viewportWidth / 2;
        int centerY = viewportHeight / 2;
        return mouseX >= centerX - 100 && mouseX <= centerX + 100
                && mouseY >= centerY - 6 && mouseY <= centerY + 32;
    }

    private void drawToolbar(RenderScope scope) {
        scope.drawRoundedRectangle(8, 8, viewportWidth - 16, 30, 7, 0xF015181D);
        scope.drawBorder(8, 8, viewportWidth - 16, 30, Theme.withAlpha(75, Theme.ACCENT.value));
        scope.drawText(0.40f, "HUD EDITOR  •  " + presetStatus,
                16, 19, Theme.FONT.value, Theme.PRIMARY_FG.value);

        int x = presetStartX();
        x = drawPresetButton(scope, x, "PRESETS", 76, true);
        drawPresetButton(scope, x, "UNDO", 54, HudPresetManager.canUndo());

        int actionY = viewportHeight - 31;
        if (selected != null) {
            scope.drawRoundedRectangle(viewportWidth - 112, actionY, 48, 22, 5, Theme.PRIMARY.value);
            scope.drawText(0.38f, "RESET", viewportWidth - 100, actionY + 8,
                    Theme.FONT.value, Theme.PRIMARY_FG.value);
        }
        scope.drawRoundedRectangle(viewportWidth - 60, actionY, 50, 22, 5, Theme.ACCENT.value);
        scope.drawText(0.40f, "DONE", viewportWidth - 47, actionY + 8,
                Theme.FONT.value, Theme.ACCENT_FG.value);
    }

    private int presetStartX() {
        return viewportWidth - (76 + 54 + 5) - 16;
    }

    private int drawPresetButton(RenderScope scope, int x, String label, int width, boolean emphasized) {
        int color = emphasized ? Theme.withAlpha(205, Theme.ACCENT.value) : Theme.PRIMARY.value;
        scope.drawRoundedRectangle(x, 12, width, 22, 5, color);
        scope.drawBorder(x, 12, width, 22, Theme.withAlpha(100, Theme.ACCENT.value));
        int textWidth = Math.round(Fonts.getWidth(label, Theme.FONT.value) * 0.34f);
        scope.drawText(0.34f, label, x + (width - textWidth) / 2, 20,
                Theme.FONT.value, emphasized ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);
        return x + width + 5;
    }

    /** Original full-editor widget chrome. Quick mode uses drawShiftWidgetChrome instead. */
    private void drawWidgetChrome(RenderScope scope, Entry entry, ModLayout layout, int boxWidth, int boxHeight,
            boolean active) {
        String label = entry.hud.canScale()
                ? entry.mod.getName() + "  " + Math.round(layout.scale.value * 100) + "%"
                : entry.mod.getName() + "  MOVE ONLY";
        int labelWidth = (int) (Fonts.getWidth(label, Theme.FONT.value) * 0.38f) + 10;
        int labelY = layout.y.value >= 19 ? layout.y.value - 15 : layout.y.value + boxHeight + 2;
        scope.drawRoundedRectangle(layout.x.value, labelY, labelWidth, 13, 4,
                active ? Theme.ACCENT.value : Theme.PRIMARY.value);
        scope.drawText(0.38f, label, layout.x.value + 5, labelY + 4, Theme.FONT.value,
                active ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);
        if (!entry.hud.canScale()) return;

        int handleX = layout.x.value + boxWidth - HANDLE_SIZE / 2;
        int handleY = layout.y.value + boxHeight - HANDLE_SIZE / 2;
        scope.drawRoundedRectangle(handleX, handleY, HANDLE_SIZE, HANDLE_SIZE, 3, Theme.ACCENT.value);
        scope.drawRectangle(handleX + 3, handleY + 3, HANDLE_SIZE - 6, 1, Theme.ACCENT_FG.value);
        scope.drawRectangle(handleX + 3, handleY + 6, HANDLE_SIZE - 6, 1, Theme.ACCENT_FG.value);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (shiftOverlay) {
            if (isShiftExiting()) return true;
            if (button == 0 && isSettingsButton(mouseX, mouseY)) {
                settingsClickPulse = 1f;
                beginShiftExit(ExitTarget.MODULES);
                return true;
            }
        }
        if (!shiftOverlay && button == 0 && mouseY >= 12 && mouseY <= 34) {
            int x = presetStartX();
            if (mouseX >= x && mouseX <= x + 76) {
                Providers.csClient.getClient().setScreen(new HudPresetPopup(new HudEditor()));
                return true;
            }
            x += 81;
            if (mouseX >= x && mouseX <= x + 54) {
                boolean restored = HudPresetManager.restoreLast();
                presetStatus = restored ? "RESTORED PREVIOUS HUD" : "NOTHING TO UNDO";
                if (restored) refreshEntries(false);
                return true;
            }
        }
        int actionY = viewportHeight - 31;
        if (!shiftOverlay && button == 0 && mouseY >= actionY && mouseY <= actionY + 22) {
            if (mouseX >= viewportWidth - 60) {
                exitEditor();
                return true;
            }
            if (selected != null && mouseX >= viewportWidth - 112 && mouseX <= viewportWidth - 64) {
                resetLayout(selected);
                ConfigManager.save();
                return true;
            }
        }

        for (int i = entries.size() - 1; i >= 0; i--) {
            Entry entry = entries.get(i);
            ModLayout layout = entry.hud.getDimensions();
            boolean resizeHandle = entry.hud.canScale() && isResizeHandle(mouseX, mouseY, layout);
            if (!isInside(mouseX, mouseY, layout) && !resizeHandle) continue;

            selected = entry;
            if (button == 1) {
                resetLayout(entry);
                entry.motion.snapPulse = 1f;
                ConfigManager.save();
                return true;
            }
            if (button == 0) {
                dragging = entry;
                resizing = entry.hud.canScale() && isResizeHandle(mouseX, mouseY, layout);
                dragOffsetX = (int) mouseX - layout.x.value;
                dragOffsetY = (int) mouseY - layout.y.value;
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (shiftOverlay && isShiftExiting()) return true;
        if (dragging == null || button != 0) return true;
        ModLayout layout = dragging.hud.getDimensions();

        if (resizing) {
            float scaleX = ((float) mouseX - layout.x.value) / Math.max(1, layout.width);
            float scaleY = ((float) mouseY - layout.y.value) / Math.max(1, layout.height);
            float candidate = clamp(Math.max(scaleX, scaleY), MIN_SCALE, MAX_SCALE);
            if (!tryResizeWithoutOverlap(dragging, candidate)) dragging.motion.snapPulse = 1f;
        } else {
            int nextX = (int) mouseX - dragOffsetX;
            int nextY = (int) mouseY - dragOffsetY;
            int width = scaledWidth(layout);
            int height = scaledHeight(layout);
            int snappedX = snap(nextX, 4, viewportWidth / 2 - width / 2, viewportWidth - width - 4);
            int snappedY = snap(nextY, 4, viewportHeight / 2 - height / 2,
                    viewportHeight - height - 4);
            if (snappedX != nextX || snappedY != nextY) dragging.motion.snapPulse = 1f;
            if (!tryMoveWithoutOverlap(dragging, snappedX, snappedY)) dragging.motion.snapPulse = 1f;
        }
        clampLayout(layout);
        return true;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && dragging != null) ConfigManager.save();
        dragging = null;
        resizing = false;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (shiftOverlay && isShiftExiting()) return true;
        Entry target = findAt(mouseX, mouseY);
        if (target != null) {
            selected = target;
            if (!target.hud.canScale()) return true;
            ModLayout layout = target.hud.getDimensions();
            float candidate = clamp(layout.scale.value + (float) verticalAmount * 0.06f,
                    MIN_SCALE, MAX_SCALE);
            if (tryResizeWithoutOverlap(target, candidate)) target.motion.snapPulse = 0.72f;
            else target.motion.snapPulse = 1f;
            clampLayout(layout);
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (shiftOverlay) {
            if (isShiftExiting()) return true;
            if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE || keyCode == GLFWProvider.GLFW_KEY_RIGHT_SHIFT) {
                beginShiftExit(ExitTarget.GAMEPLAY);
                return true;
            }
        }
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            exitEditor();
            return true;
        }
        if (selected == null) return false;

        ModLayout layout = selected.hud.getDimensions();
        int step = (modifiers & GLFWProvider.GLFW_MOD_SHIFT) != 0 ? 10 : 1;
        switch (keyCode) {
            case GLFWProvider.GLFW_KEY_LEFT -> tryMoveWithoutOverlap(selected, layout.x.value - step, layout.y.value);
            case GLFWProvider.GLFW_KEY_RIGHT -> tryMoveWithoutOverlap(selected, layout.x.value + step, layout.y.value);
            case GLFWProvider.GLFW_KEY_UP -> tryMoveWithoutOverlap(selected, layout.x.value, layout.y.value - step);
            case GLFWProvider.GLFW_KEY_DOWN -> tryMoveWithoutOverlap(selected, layout.x.value, layout.y.value + step);
            case GLFWProvider.GLFW_KEY_EQUAL -> {
                if (selected.hud.canScale()) tryResizeWithoutOverlap(selected,
                        clamp(layout.scale.value + 0.05f, MIN_SCALE, MAX_SCALE));
            }
            case GLFWProvider.GLFW_KEY_MINUS -> {
                if (selected.hud.canScale()) tryResizeWithoutOverlap(selected,
                        clamp(layout.scale.value - 0.05f, MIN_SCALE, MAX_SCALE));
            }
            case GLFWProvider.GLFW_KEY_BACKSPACE -> {
                resetLayout(selected);
                selected.motion.snapPulse = 1f;
            }
            default -> {
                return false;
            }
        }
        clampLayout(layout);
        return true;
    }

    private Entry findAt(double x, double y) {
        for (int i = entries.size() - 1; i >= 0; i--) {
            Entry entry = entries.get(i);
            if (isInside(x, y, entry.hud.getDimensions())) return entry;
        }
        return null;
    }

    private void clampLayout(ModLayout layout) {
        layout.scale.value = clamp(layout.scale.value, MIN_SCALE, MAX_SCALE);
        int width = scaledWidth(layout);
        int height = scaledHeight(layout);
        layout.x.value = Math.max(4, Math.min(layout.x.value, Math.max(4, viewportWidth - width - 4)));
        layout.y.value = Math.max(4, Math.min(layout.y.value, Math.max(4, viewportHeight - height - 4)));
    }

    /** Prevents HUD widgets from entering each other's scaled bounds while dragging. */
    private boolean tryMoveWithoutOverlap(Entry moving, int desiredX, int desiredY) {
        ModLayout layout = moving.hud.getDimensions();
        int width = scaledWidth(layout);
        int height = scaledHeight(layout);
        int oldX = layout.x.value;
        int oldY = layout.y.value;
        int x = Math.max(4, Math.min(desiredX, Math.max(4, viewportWidth - width - 4)));
        int y = Math.max(4, Math.min(desiredY, Math.max(4, viewportHeight - height - 4)));

        if (isPlacementFree(moving, x, y, layout.scale.value)) {
            layout.x.value = x;
            layout.y.value = y;
            moving.hud.onLayoutChanged();
            return true;
        }
        // Slide along the collision edge instead of sticking on diagonal movement.
        if (x != oldX && isPlacementFree(moving, x, oldY, layout.scale.value)) {
            layout.x.value = x;
            moving.hud.onLayoutChanged();
            return true;
        }
        if (y != oldY && isPlacementFree(moving, oldX, y, layout.scale.value)) {
            layout.y.value = y;
            moving.hud.onLayoutChanged();
            return true;
        }
        moving.motion.snapPulse = 1f;
        return false;
    }

    /** Rejects a resize that would overlap another HUD widget or leave the viewport. */
    private boolean tryResizeWithoutOverlap(Entry moving, float desiredScale) {
        if (!moving.hud.canScale()) return false;
        ModLayout layout = moving.hud.getDimensions();
        float scale = clamp(desiredScale, MIN_SCALE, MAX_SCALE);
        if (!isPlacementFree(moving, layout.x.value, layout.y.value, scale)) {
            moving.motion.snapPulse = 1f;
            return false;
        }
        layout.scale.value = scale;
        return true;
    }

    private boolean isPlacementFree(Entry moving, int x, int y, float scale) {
        ModLayout layout = moving.hud.getDimensions();
        int width = scaledWidth(layout, scale);
        int height = scaledHeight(layout, scale);
        if (x < 4 || y < 4 || x + width > viewportWidth - 4 || y + height > viewportHeight - 4) return false;
        for (Entry other : entries) {
            if (other == moving) continue;
            ModLayout otherLayout = other.hud.getDimensions();
            if (rectanglesOverlap(x, y, width, height,
                    otherLayout.x.value, otherLayout.y.value,
                    scaledWidth(otherLayout), scaledHeight(otherLayout), COLLISION_GAP)) return false;
        }
        return true;
    }

    /** Separates old/preset positions once so collision rules start from a valid layout. */
    private void resolveExistingCollisions() {
        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            ModLayout layout = entry.hud.getDimensions();
            if (entry.hud.isUsingNativeDefaultPosition()) continue;
            clampLayout(layout);
            boolean collides = false;
            for (int j = 0; j < i; j++) {
                ModLayout other = entries.get(j).hud.getDimensions();
                if (rectanglesOverlap(layout.x.value, layout.y.value, scaledWidth(layout), scaledHeight(layout),
                        other.x.value, other.y.value, scaledWidth(other), scaledHeight(other), COLLISION_GAP)) {
                    collides = true;
                    break;
                }
            }
            if (!collides) continue;
            int[] free = findFreePosition(entry, layout.scale.value, 12, 40);
            if (free != null) {
                layout.x.value = free[0];
                layout.y.value = free[1];
            }
        }
    }

    private void resetLayout(Entry entry) {
        if (entry.hud.usesNativeDefaultPosition()) {
            entry.hud.onLayoutReset();
            return;
        }
        int[] free = findFreePosition(entry, 1.0f, 12, 40);
        if (free == null) return;
        ModLayout layout = entry.hud.getDimensions();
        layout.scale.value = 1.0f;
        layout.x.value = free[0];
        layout.y.value = free[1];
    }

    private int[] findFreePosition(Entry moving, float scale, int preferredX, int preferredY) {
        if (isPlacementFree(moving, preferredX, preferredY, scale)) return new int[] { preferredX, preferredY };
        ModLayout layout = moving.hud.getDimensions();
        int width = scaledWidth(layout, scale);
        int height = scaledHeight(layout, scale);
        int maxX = viewportWidth - width - 4;
        int maxY = viewportHeight - height - 4;
        for (int y = 40; y <= maxY; y += 8) {
            for (int x = 4; x <= maxX; x += 8) {
                if (isPlacementFree(moving, x, y, scale)) return new int[] { x, y };
            }
        }
        for (int y = 4; y < Math.min(40, maxY + 1); y += 8) {
            for (int x = 4; x <= maxX; x += 8) {
                if (isPlacementFree(moving, x, y, scale)) return new int[] { x, y };
            }
        }
        return null;
    }

    private static boolean rectanglesOverlap(int ax, int ay, int aw, int ah,
            int bx, int by, int bw, int bh, int gap) {
        return ax < bx + bw + gap && ax + aw + gap > bx
                && ay < by + bh + gap && ay + ah + gap > by;
    }

    private static int scaledWidth(ModLayout layout) {
        return scaledWidth(layout, layout.scale.value);
    }

    private static int scaledWidth(ModLayout layout, float scale) {
        return Math.max(1, Math.round(layout.width * scale));
    }

    private static int scaledHeight(ModLayout layout) {
        return scaledHeight(layout, layout.scale.value);
    }

    private static int scaledHeight(ModLayout layout, float scale) {
        return Math.max(1, Math.round(layout.height * scale));
    }

    private static boolean isInside(double mouseX, double mouseY, ModLayout layout) {
        return mouseX >= layout.x.value && mouseX <= layout.x.value + scaledWidth(layout)
                && mouseY >= layout.y.value && mouseY <= layout.y.value + scaledHeight(layout);
    }

    private static boolean isResizeHandle(double mouseX, double mouseY, ModLayout layout) {
        double right = layout.x.value + scaledWidth(layout);
        double bottom = layout.y.value + scaledHeight(layout);
        return Math.abs(mouseX - right) <= HANDLE_SIZE && Math.abs(mouseY - bottom) <= HANDLE_SIZE;
    }

    private void exitEditor() {
        if (shiftOverlay) {
            beginShiftExit(ExitTarget.GAMEPLAY);
            return;
        }
        ConfigManager.save();
        if (Providers.feature.player().hasPlayer()) {
            Providers.csClient.getClient().setScreen(new PauseMenu());
        } else {
            provider.close();
        }
    }

    private boolean isShiftExiting() {
        return exitTarget != ExitTarget.NONE;
    }

    /** Starts a quick reverse fade before switching screens or returning to gameplay. */
    private void beginShiftExit(ExitTarget target) {
        if (!shiftOverlay || isShiftExiting()) return;
        exitTarget = target;
        exitStartedAt = Math.max(0L, lastAnimationElapsed);
        exitStartVisibility = openingVisibility(exitStartedAt);
        dragging = null;
        resizing = false;
    }

    private void finishShiftExitIfReady(long elapsed) {
        if (!isShiftExiting() || exitCommitted || elapsed - exitStartedAt < OVERLAY_OUTRO_MILLIS) return;
        exitCommitted = true;
        ConfigManager.save();
        if (exitTarget == ExitTarget.MODULES) {
            Providers.csClient.getClient().setScreen(new ModMenu());
        } else {
            provider.close();
        }
    }

    private float overlayVisibility(long elapsed) {
        if (!isShiftExiting()) return openingVisibility(elapsed);
        float exit = easeInCubic(stage(elapsed, exitStartedAt, OVERLAY_OUTRO_MILLIS));
        return exitStartVisibility * (1f - exit);
    }

    private float openingVisibility(long elapsed) {
        return easeOutCubic(stage(elapsed, 0L, OVERLAY_INTRO_MILLIS));
    }

    private float advanceAnimationClock(long elapsed) {
        if (lastAnimationElapsed < 0L || elapsed < lastAnimationElapsed) {
            lastAnimationElapsed = elapsed;
            return 1f / 60f;
        }
        float seconds = clamp((elapsed - lastAnimationElapsed) / 1000f, 0.001f, 0.050f);
        lastAnimationElapsed = elapsed;
        return seconds;
    }

    private static int snap(int value, int start, int center, int end) {
        if (Math.abs(value - start) <= SNAP_DISTANCE) return start;
        if (Math.abs(value - center) <= SNAP_DISTANCE) return center;
        if (Math.abs(value - end) <= SNAP_DISTANCE) return end;
        return value;
    }

    private static float stage(long elapsed, long delay, long duration) {
        if (duration <= 0L) return elapsed >= delay ? 1f : 0f;
        return clamp01((elapsed - delay) / (float) duration);
    }

    private static float easeOutCubic(float value) {
        float t = clamp01(value) - 1f;
        return t * t * t + 1f;
    }

    private static float easeInCubic(float value) {
        float t = clamp01(value);
        return t * t * t;
    }

    /** A small, restrained overshoot for opening cards and the central lockup. */
    private static float easeOutBack(float value) {
        float t = clamp01(value) - 1f;
        float c1 = 1.25f;
        float c3 = c1 + 1f;
        return 1f + c3 * t * t * t + c1 * t * t;
    }

    private static float approach(float current, float target, float frameSeconds, float response) {
        float amount = 1f - (float) Math.exp(-response * Math.max(0f, frameSeconds));
        return current + (target - current) * amount;
    }

    private static int blend(int from, int to, float amount) {
        float t = clamp01(amount);
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static float clamp01(float value) {
        return Math.max(0f, Math.min(1f, value));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    public boolean shouldPause() {
        return !shiftOverlay;
    }

    @Override
    public void onClose() {
        ConfigManager.save();
    }
}
