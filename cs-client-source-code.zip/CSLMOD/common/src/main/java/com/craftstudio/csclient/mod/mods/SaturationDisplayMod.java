package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.ModSpec;

/** Feather-style food and hidden saturation statistics. */
public class SaturationDisplayMod extends TextHudMod {
    private static final BoolProperty showFood = Property.bool(true);

    public SaturationDisplayMod() {
        super(new ModSpec("Saturation", "saturation")
                        .description("Shows food and hidden saturation values")
                        .version("v1.0.0").tags("HUD", "Utility")
                        .requires(Providers.feature::player),
                104, showFood.named("Show food level"));
    }

    @Override protected String getText() {
        PlayerFeature p = Providers.feature.player();
        String saturation = "SAT " + FastNumberFormatter.fixed(p.getSaturationLevel(), 1);
        return showFood.value ? "FOOD " + p.getFoodLevel() + "  •  " + saturation : saturation;
    }

    @Override protected String getDummyText() { return "FOOD 20  •  SAT 5.0"; }
}
