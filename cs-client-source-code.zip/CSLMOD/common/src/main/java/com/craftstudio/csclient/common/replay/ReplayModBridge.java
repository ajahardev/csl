package com.craftstudio.csclient.common.replay;

import java.lang.reflect.Constructor;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;

/**
 * Minimal integration for Replay Mod's own UI.
 *
 * CS Client replaces the vanilla title/pause screens, so Replay Mod's native
 * button injections (which target those screens) never run. This bridge
 * restores the default behaviour without replacing anything: it opens
 * Replay Mod's own default screen class, exactly as Replay Mod intends.
 * No custom menu, no restyling. When Replay Mod is absent everything here
 * is a cheap no-op.
 */
public final class ReplayModBridge {
    /** Default replay screens across Replay Mod major versions. */
    private static final String[] SCREEN_CLASSES = {
            "com.replaymod.ui.screen.ReplayScreen",
            "com.replaymod.screen.ReplayScreen",
    };

    private ReplayModBridge() { }

    /** True when Replay Mod is installed in this client. */
    public static boolean isLoaded() {
        try {
            return Providers.csClient != null
                    && Providers.csClient.getClient().isModLoaded("replaymod");
        } catch (Throwable ignored) {
            return false;
        }
    }

    /**
     * Opens Replay Mod's default screen (its own class, unmodified).
     *
     * @return true when the screen was handed to the client
     */
    public static boolean open(MinecraftClientRef client) {
        if (client == null || !isLoaded()) return false;
        Object screen = createDefaultScreen(client.currentScreen());
        if (screen == null) {
            if (Providers.csClient != null) {
                Providers.csClient.logError("Replay Mod is installed but its default "
                        + "screen could not be created (version mismatch?)");
            }
            return false;
        }
        boolean opened = client.openNativeScreen(screen);
        if (!opened && Providers.csClient != null) {
            Providers.csClient.logError("Replay Mod default screen could not be displayed");
        }
        return opened;
    }

    /**
     * Reflectively constructs Replay Mod's own default screen.
     *
     * @param parent the current screen, so back-navigation returns where the
     *               user was (null is tolerated by Replay Mod)
     * @return the screen instance, or null when no compatible class exists
     */
    public static Object createDefaultScreen(Object parent) {
        for (String className : SCREEN_CLASSES) {
            try {
                Class<?> type = Class.forName(className);
                for (Constructor<?> constructor : type.getConstructors()) {
                    Class<?>[] params = constructor.getParameterTypes();
                    if (params.length == 1 && params[0].isInstance(parent)) {
                        return constructor.newInstance(parent);
                    }
                }
                for (Constructor<?> constructor : type.getConstructors()) {
                    if (constructor.getParameterCount() == 0) {
                        return constructor.newInstance();
                    }
                }
            } catch (Throwable ignored) {
                // Try the next known screen class.
            }
        }
        return null;
    }
}
