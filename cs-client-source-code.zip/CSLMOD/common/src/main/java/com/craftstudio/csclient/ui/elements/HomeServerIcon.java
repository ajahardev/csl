package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;

/**
 * Icon-only Home server rail item. The default state deliberately contains no
 * label, IP, card surface, invented player count, or remote status.
 */
public final class HomeServerIcon extends Element {
    private final FeaturedServers.Slot slot;
    private final Runnable onClick;
    private float hover;

    public HomeServerIcon(FeaturedServers.Slot slot, Runnable onClick) {
        this.slot = slot;
        this.onClick = onClick;
        dimensions(44, 44); // Touch-friendly invisible hit area; logo remains compact.
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.25f;
        if (Math.abs(target - hover) < 0.002f) hover = target;

        boolean joinable = slot.joinable();
        int logoSize = Math.max(22, Math.min(34, height - 10)) + (hover > 0.68f ? 1 : 0);
        int logoX = (width - logoSize) / 2;
        int logoY = (height - logoSize) / 2 - (hover > 0.58f ? 1 : 0);
        int accent = joinable ? 0xFFFF6B32 : 0xFFB9C3CD;

        // Only hover reveals a tiny original-CS halo; idle remains logo-only.
        if (hover > 0.02f) {
            int pad = 3;
            scope.drawRoundedRectangle(logoX - pad, logoY - pad, logoSize + pad * 2,
                    logoSize + pad * 2, 7, withAlpha(Math.round(24 + 62 * hover), 0xFF0B1017));
            scope.drawRoundedBorder(logoX - pad, logoY - pad, logoSize + pad * 2,
                    logoSize + pad * 2, 7, withAlpha(Math.round(85 + 120 * hover), accent));
        }

        scope.drawTexture(joinable ? Textures.PLANTMC_SERVER : Textures.SERVER_SLOT,
                logoX, logoY, 0, 0, logoSize, logoSize,
                joinable ? 0xFFFFFFFF : withAlpha(214, 0xFFE9EEF2));

        // Green means the requested explicit-join PlantMC slot. Muted gray means a
        // local Coming Soon slot, avoiding a false online-server claim.
        int dot = Math.max(7, Math.round(8 + hover));
        int dotX = logoX + logoSize - dot + 2;
        int dotY = logoY + logoSize - dot + 2;
        scope.drawRoundedRectangle(dotX - 1, dotY - 1, dot + 2, dot + 2, (dot + 2) / 2,
                0xD90A0E14);
        scope.drawRoundedRectangle(dotX, dotY, dot, dot, dot / 2,
                joinable ? 0xFF4BE06D : 0xFF7D8995);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }
}
