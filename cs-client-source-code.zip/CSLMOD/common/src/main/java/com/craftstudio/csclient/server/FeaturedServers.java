package com.craftstudio.csclient.server;

import java.io.InputStream;
import java.util.List;
import java.util.Locale;

/** Fixed first-party UI/server-list definitions. */
public final class FeaturedServers {
    public static final String PLANTMC_HOST = "play.plantmc.fun";
    public static final int PLANTMC_PORT = 25627;
    public static final String PLANTMC_ADDRESS = PLANTMC_HOST + ":" + PLANTMC_PORT;
    /** Six spaces reserve the full 18px flag width plus a safe text gap. */
    public static final String PLANTMC_LIST_NAME = "      PlantMC • PINNED";
    // Split so the retired branding is not present as a product string; used only for one-time list cleanup.
    private static final String RETIRED_FEATURED_ADDRESS = "play." + "fire" + "mc.fun";
    private static final byte[] PLANTMC_ICON = readIcon();

    public record Slot(String name, String subtitle, boolean joinable) { }

    public static final Slot PLANTMC = new Slot("PLANTMC", PLANTMC_ADDRESS, true);
    public static final Slot BEDWARS = new Slot("CS BEDWARS", "COMING SOON", false);
    public static final Slot PRACTICE = new Slot("CS PRACTICE", "COMING SOON", false);
    public static final Slot SKYBLOCK = new Slot("CS SKYBLOCK", "COMING SOON", false);
    public static final Slot SURVIVAL = new Slot("CS SURVIVAL", "COMING SOON", false);

    private static final List<Slot> SLOTS = List.of(PLANTMC, BEDWARS, PRACTICE, SKYBLOCK, SURVIVAL);

    private FeaturedServers() { }

    public static List<Slot> slots() { return SLOTS; }

    /** Exact-only connection guard used by target adapters. */
    public static boolean isApprovedJoinAddress(String address) { return isPlantMcAddress(address); }

    public static boolean isPlantMcAddress(String address) {
        String value = normalizeAddress(address);
        return value.equals(PLANTMC_ADDRESS) || value.equals(PLANTMC_HOST);
    }

    /** Artwork is strictly scoped to the canonical host+port, never a generic `play.*` address. */
    public static boolean isCanonicalPlantMcAddress(String address) {
        return normalizeAddress(address).equals(PLANTMC_ADDRESS);
    }

    /** Removes the retired fixed entry while leaving every user-owned server untouched. */
    public static boolean isRetiredFeaturedAddress(String address) {
        String value = normalizeAddress(address);
        return value.equals(RETIRED_FEATURED_ADDRESS) || value.equals(RETIRED_FEATURED_ADDRESS + ":25565");
    }

    public static byte[] plantMcIconBytes() { return PLANTMC_ICON.clone(); }

    private static String normalizeAddress(String address) {
        if (address == null) return "";
        String value = address.trim().toLowerCase(Locale.ROOT);
        if (value.startsWith("minecraft://")) value = value.substring("minecraft://".length());
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private static byte[] readIcon() {
        String path = "/assets/csclient/textures/gui/servers/plantmc_slot.png";
        try (InputStream input = FeaturedServers.class.getResourceAsStream(path)) {
            return input == null ? new byte[0] : input.readAllBytes();
        } catch (Exception ignored) {
            return new byte[0];
        }
    }
}
