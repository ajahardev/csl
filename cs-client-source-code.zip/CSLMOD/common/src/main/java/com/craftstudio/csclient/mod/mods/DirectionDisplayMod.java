package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.ModSpec;

public class DirectionDisplayMod extends TextHudMod {
    public DirectionDisplayMod() {
        super(new ModSpec("Direction Display", "direction").description("Shows compass direction and yaw")
                .version("v1.0.0").tags("Navigation", "HUD").requires(Providers.feature::player), 92);
    }

    private static String direction(float yaw) {
        float normalized = (yaw % 360.0f + 360.0f) % 360.0f;
        String[] names = { "S", "SW", "W", "NW", "N", "NE", "E", "SE" };
        return names[Math.round(normalized / 45.0f) & 7];
    }

    @Override protected String getText() {
        float yaw = Providers.feature.player().getYaw();
        return direction(yaw) + "  " + Math.round(yaw) + "°";
    }
    @Override protected String getDummyText() { return "NE  135°"; }
}
