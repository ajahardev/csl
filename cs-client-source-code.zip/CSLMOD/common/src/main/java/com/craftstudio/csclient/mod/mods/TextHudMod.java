package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.NamedProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudDirtyTracker;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Shared compact dark HUD implementation used by CS Client utility modules. */
public abstract class TextHudMod extends Mod implements HudMod {
    private final BoolProperty enabled;
    protected final ModLayout layout;
    private String cachedText;
    private long nextTextUpdate;
    private final HudDirtyTracker dirtyTracker = new HudDirtyTracker();

    protected TextHudMod(ModSpec spec, int initialWidth, NamedProperty... extraProperties) {
        this(spec, Property.bool(false), createLayout(initialWidth), extraProperties);
    }

    private TextHudMod(ModSpec spec, BoolProperty enabled, ModLayout layout, NamedProperty[] extraProperties) {
        super(spec, combine(enabled, layout, extraProperties));
        this.enabled = enabled;
        this.layout = layout;
    }

    private static ModLayout createLayout(int width) {
        ModLayout layout = new ModLayout(width, Fonts.getHeight());
        layout.bgColor.value = 0xD914171B;
        layout.fgColor.value = 0xFFF0F2F4;
        layout.radius.value = 6;
        layout.font.value = 2;
        return layout;
    }

    private static NamedProperty[] combine(BoolProperty enabled, ModLayout layout, NamedProperty[] extras) {
        NamedProperty[] result = new NamedProperty[extras.length + 2];
        result[0] = enabled.named("Enabled");
        System.arraycopy(extras, 0, result, 1, extras.length);
        result[result.length - 1] = layout.prop();
        return result;
    }

    protected abstract String getText();

    protected abstract String getDummyText();

    @Override
    public void renderHud(RenderScope scope) {
        int interval = PerformanceBoostMod.hudRefreshIntervalMs();
        long now = System.currentTimeMillis();
        if (cachedText == null || interval == 0 || now >= nextTextUpdate) {
            cachedText = getText();
            nextTextUpdate = now + interval;
        }
        // Frame skip: unchanged text + colour + position means the previous
        // frame already drew exactly this — resubmitting only costs GPU/CPU.
        if (!dirtyTracker.dirty(cachedText, layout.fgColor.value, layout)) return;
        drawText(scope, cachedText);
    }

    @Override
    public void renderDummy(RenderScope scope) {
        drawText(scope, getDummyText());
    }

    protected void drawText(RenderScope scope, String text) {
        HudTextRenderer.draw(scope, layout, text);
    }

    @Override
    public ModLayout getDimensions() {
        return layout;
    }

    @Override
    public boolean isEnabled() {
        return enabled.value;
    }

    @Override
    public void onEnabled(boolean value) {
        enabled.value = value;
    }
}
