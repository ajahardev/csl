package com.craftstudio.csclient.ui.resources;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.ui.RenderScope;

/** Draws the active effective Minecraft skin face plus its hat/second layer. */
public final class SkinHeadRenderer {
    private SkinHeadRenderer() { }

    public static void draw(RenderScope scope, int x, int y, int size, int fallbackTint) {
        IdentifierRef skin = Providers.csClient == null ? null
                : Providers.csClient.getClient().getActiveSkinTexture();
        if (skin == null) {
            int icon = Math.max(12, Math.round(size * 0.55f));
            scope.drawTexture(Textures.PROFILE, x + (size - icon) / 2, y + (size - icon) / 2,
                    0, 0, icon, icon, fallbackTint);
            return;
        }
        // Base face (8,8→16,16) and hat layer (40,8→48,16) from a 64×64 skin.
        scope.drawTexture(skin, x, y, 8, 8, size, size, 8, 8, 64, 64);
        scope.drawTexture(skin, x, y, 40, 8, size, size, 8, 8, 64, 64);
    }
}
