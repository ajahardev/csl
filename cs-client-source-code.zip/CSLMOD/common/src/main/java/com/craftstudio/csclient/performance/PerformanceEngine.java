package com.craftstudio.csclient.performance;

import java.io.IOException;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import com.craftstudio.csclient.common.provider.Providers;

/**
 * CS-owned measurement and adaptive scheduling engine. It never reads, writes,
 * or owns Minecraft/renderer graphics settings.
 */
public final class PerformanceEngine {
    public static final int PROFILE_LOW = 0;
    public static final int PROFILE_BALANCED = 1;
    public static final int PROFILE_HIGH = 2;

    private static final int RECENT_CAPACITY = 16_384;
    private static final int BENCHMARK_CAPACITY = 131_072;
    private static final long[] RECENT_FRAME_NANOS = new long[RECENT_CAPACITY];
    private static final long[] BENCHMARK_FRAME_NANOS = new long[BENCHMARK_CAPACITY];
    private static final long MAX_VALID_FRAME_NANOS = 2_000_000_000L;
    private static final DateTimeFormatter FILE_TIME = DateTimeFormatter
            .ofPattern("uuuuMMdd-HHmmss", Locale.ROOT).withZone(ZoneOffset.UTC);

    private static volatile long frameSequence;
    private static volatile long lastFrameAt;
    private static volatile int effectiveProfile = PROFILE_BALANCED;
    private static volatile boolean benchmarkActive;
    private static volatile boolean benchmarkFull;
    private static volatile int benchmarkCount;
    private static volatile long benchmarkStartedAt;
    private static volatile long benchmarkGcCountStart;
    private static volatile long benchmarkGcTimeStart;
    private static volatile String benchmarkLabel = "benchmark";

    private static long lastAdaptiveCheck;
    private static long lastProfileChange;
    private static int slowWindows;
    private static int fastWindows;

    private PerformanceEngine() { }

    /** Called exactly once from the actual HUD render-frame path. No allocations. */
    public static void onFrame(long nowNanos) {
        long previous = lastFrameAt;
        lastFrameAt = nowNanos;
        if (previous == 0L) return;
        long duration = nowNanos - previous;
        if (duration <= 0L || duration > MAX_VALID_FRAME_NANOS) return;

        long sequence = frameSequence;
        RECENT_FRAME_NANOS[(int) (sequence & (RECENT_CAPACITY - 1))] = duration;
        frameSequence = sequence + 1;

        if (benchmarkActive) {
            int index = benchmarkCount;
            if (index < BENCHMARK_CAPACITY) {
                BENCHMARK_FRAME_NANOS[index] = duration;
                benchmarkCount = index + 1;
            } else {
                benchmarkFull = true;
            }
        }
    }

    /** Client-tick control; profile changes affect only CS-owned algorithms. */
    public static void tick(boolean enabled, boolean adaptive, int configuredProfile,
            int targetFps, int benchmarkDurationSeconds) {
        int configured = clampProfile(configuredProfile);
        if (!enabled) {
            effectiveProfile = PROFILE_LOW;
        } else if (!adaptive) {
            effectiveProfile = configured;
            slowWindows = fastWindows = 0;
        } else {
            updateAdaptiveProfile(configured, Math.max(30, Math.min(360, targetFps)));
        }

        if (benchmarkActive) {
            long elapsed = System.nanoTime() - benchmarkStartedAt;
            long duration = Math.max(10, Math.min(900, benchmarkDurationSeconds)) * 1_000_000_000L;
            if (elapsed >= duration || benchmarkFull) stopBenchmarkAndExport();
        }
    }

    private static void updateAdaptiveProfile(int configured, int targetFps) {
        long now = System.nanoTime();
        if (effectiveProfile < PROFILE_LOW || effectiveProfile > PROFILE_HIGH) effectiveProfile = configured;
        if (lastAdaptiveCheck == 0L) {
            effectiveProfile = configured;
            lastAdaptiveCheck = now;
            lastProfileChange = now;
            return;
        }
        if (now - lastAdaptiveCheck < 5_000_000_000L) return;
        lastAdaptiveCheck = now;

        // A bounded window (≈17 s at 60 FPS) is statistically sufficient for
        // p95/p99 profile decisions; it also keeps this periodic sample cheap
        // instead of copying and sorting the whole 16 k ring every 5 seconds.
        Metrics metrics = snapshotRecent(1_024);
        if (metrics.samples() < 120) return;
        double frameBudgetMs = 1000.0 / targetFps;
        if (metrics.p99FrameMs() > frameBudgetMs * 1.35) {
            slowWindows++;
            fastWindows = 0;
        } else if (metrics.p95FrameMs() < frameBudgetMs * 0.85
                && metrics.p99FrameMs() < frameBudgetMs * 1.10) {
            fastWindows++;
            slowWindows = 0;
        } else {
            slowWindows = fastWindows = 0;
        }

        // Hysteresis avoids profile oscillation and therefore avoids self-created stutter.
        if (now - lastProfileChange < 20_000_000_000L) return;
        if (slowWindows >= 3 && effectiveProfile < PROFILE_HIGH) {
            effectiveProfile++;
            slowWindows = fastWindows = 0;
            lastProfileChange = now;
        } else if (fastWindows >= 6 && effectiveProfile > PROFILE_LOW) {
            effectiveProfile--;
            slowWindows = fastWindows = 0;
            lastProfileChange = now;
        }
    }

    public static int effectiveProfile() { return effectiveProfile; }

    /** Monotonic HUD render-frame counter (drives per-frame budgets). */
    public static long frameId() { return frameSequence; }

    public static int hudRefreshIntervalMs() {
        return switch (effectiveProfile) {
            case PROFILE_HIGH -> 100;
            case PROFILE_BALANCED -> 50;
            default -> 33;
        };
    }

    public static int minimapSampleIntervalMs() {
        return switch (effectiveProfile) {
            case PROFILE_HIGH -> 1_000;
            case PROFILE_BALANCED -> 700;
            default -> 500;
        };
    }

    public static synchronized void toggleBenchmark(String label) {
        if (benchmarkActive) stopBenchmarkAndExport();
        else startBenchmark(label);
    }

    public static synchronized void startBenchmark(String label) {
        Arrays.fill(BENCHMARK_FRAME_NANOS, 0L);
        benchmarkCount = 0;
        benchmarkFull = false;
        benchmarkLabel = sanitizeLabel(label);
        benchmarkStartedAt = System.nanoTime();
        long[] gc = gcTotals();
        benchmarkGcCountStart = gc[0];
        benchmarkGcTimeStart = gc[1];
        benchmarkActive = true;
        logInfo("Started CS benchmark '" + benchmarkLabel + "'");
    }

    public static synchronized Path stopBenchmarkAndExport() {
        if (!benchmarkActive && benchmarkCount == 0) return null;
        benchmarkActive = false;
        int count = benchmarkCount;
        long[] samples = Arrays.copyOf(BENCHMARK_FRAME_NANOS, count);
        Metrics metrics = calculate(samples, count);
        long[] gc = gcTotals();
        long gcCount = Math.max(0L, gc[0] - benchmarkGcCountStart);
        long gcTime = Math.max(0L, gc[1] - benchmarkGcTimeStart);

        try {
            Path runDirectory = Providers.csClient.getClient().getRunDirectory().toPath();
            Path directory = runDirectory.resolve("cs-client-benchmarks");
            Files.createDirectories(directory);
            String base = FILE_TIME.format(Instant.now()) + "-" + benchmarkLabel;
            Path csv = directory.resolve(base + ".csv");
            Path json = directory.resolve(base + ".json");
            writeCsv(csv, samples);
            writeJson(json, metrics, gcCount, gcTime);
            benchmarkCount = 0;
            benchmarkFull = false;
            logInfo("Saved CS benchmark: " + json.toAbsolutePath());
            return json;
        } catch (Exception error) {
            logError("Unable to export CS benchmark", error);
            return null;
        }
    }

    public static boolean isBenchmarkActive() { return benchmarkActive; }

    public static Metrics snapshotRecent() {
        return snapshotRecent(RECENT_CAPACITY);
    }

    public static Metrics snapshotRecent(int maxSamples) {
        long sequence = frameSequence;
        int count = (int) Math.min(Math.min(sequence, RECENT_CAPACITY),
                Math.max(1, maxSamples));
        if (count <= 0) return Metrics.EMPTY;
        long start = sequence - count;
        long[] copy = new long[count];
        for (int i = 0; i < count; i++) {
            copy[i] = RECENT_FRAME_NANOS[(int) ((start + i) & (RECENT_CAPACITY - 1))];
        }
        return calculate(copy, count);
    }

    static Metrics calculate(long[] source, int count) {
        if (source == null || count <= 0) return Metrics.EMPTY;
        int usable = Math.min(count, source.length);
        long[] sorted = Arrays.copyOf(source, usable);
        long sum = 0L;
        int valid = 0;
        for (int i = 0; i < usable; i++) {
            long value = sorted[i];
            if (value <= 0L || value > MAX_VALID_FRAME_NANOS) continue;
            sorted[valid++] = value;
            sum += value;
        }
        if (valid == 0) return Metrics.EMPTY;
        sorted = Arrays.copyOf(sorted, valid);
        Arrays.sort(sorted);
        double averageNanos = sum / (double) valid;
        long heapUsed = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        return new Metrics(valid,
                1_000_000_000.0 / averageNanos,
                averageNanos / 1_000_000.0,
                percentile(sorted, 0.95) / 1_000_000.0,
                percentile(sorted, 0.99) / 1_000_000.0,
                percentile(sorted, 0.999) / 1_000_000.0,
                sorted[sorted.length - 1] / 1_000_000.0,
                heapUsed / (1024L * 1024L),
                effectiveProfile);
    }

    private static long percentile(long[] sorted, double percentile) {
        int index = (int) Math.ceil(percentile * sorted.length) - 1;
        return sorted[Math.max(0, Math.min(sorted.length - 1, index))];
    }

    private static void writeCsv(Path path, long[] samples) throws IOException {
        StringBuilder output = new StringBuilder(Math.max(128, samples.length * 18));
        output.append("frame,frametime_ms\n");
        for (int i = 0; i < samples.length; i++) {
            output.append(i).append(',').append(String.format(Locale.ROOT, "%.6f", samples[i] / 1_000_000.0)).append('\n');
        }
        Files.writeString(path, output, StandardCharsets.UTF_8);
    }

    private static void writeJson(Path path, Metrics metrics, long gcCount, long gcTimeMs) throws IOException {
        String rendererMods = detectedRendererMods();
        String json = "{\n"
                + "  \"label\": \"" + escapeJson(benchmarkLabel) + "\",\n"
                + "  \"samples\": " + metrics.samples() + ",\n"
                + formatJson("average_fps", metrics.averageFps())
                + formatJson("average_frametime_ms", metrics.averageFrameMs())
                + formatJson("p95_frametime_ms", metrics.p95FrameMs())
                + formatJson("p99_frametime_ms", metrics.p99FrameMs())
                + formatJson("p999_frametime_ms", metrics.p999FrameMs())
                + formatJson("one_percent_low_fps", metrics.onePercentLowFps())
                + formatJson("point_one_percent_low_fps", metrics.pointOnePercentLowFps())
                + formatJson("worst_frametime_ms", metrics.worstFrameMs())
                + formatJson("process_cpu_load_percent", processCpuLoadPercent())
                + "  \"heap_used_mib\": " + metrics.heapUsedMiB() + ",\n"
                + "  \"gc_count\": " + gcCount + ",\n"
                + "  \"gc_pause_ms\": " + gcTimeMs + ",\n"
                + "  \"effective_profile\": \"" + profileName(metrics.profile()) + "\",\n"
                + "  \"java_version\": \"" + escapeJson(System.getProperty("java.version", "unknown")) + "\",\n"
                + "  \"os_arch\": \"" + escapeJson(System.getProperty("os.arch", "unknown")) + "\",\n"
                + "  \"renderer_mods\": \"" + escapeJson(rendererMods) + "\"\n"
                + "}\n";
        Files.writeString(path, json, StandardCharsets.UTF_8);
    }

    private static String formatJson(String name, double value) {
        return "  \"" + name + "\": " + String.format(Locale.ROOT, "%.6f", value) + ",\n";
    }

    private static double processCpuLoadPercent() {
        try {
            Object bean = ManagementFactory.getOperatingSystemMXBean();
            Object value = bean.getClass().getMethod("getProcessCpuLoad").invoke(bean);
            if (value instanceof Number number) {
                double load = number.doubleValue();
                if (load >= 0.0) return load * 100.0;
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) { }
        return -1.0;
    }

    private static long[] gcTotals() {
        long count = 0L, time = 0L;
        try {
            List<GarbageCollectorMXBean> collectors = ManagementFactory.getGarbageCollectorMXBeans();
            for (GarbageCollectorMXBean collector : collectors) {
                if (collector.getCollectionCount() > 0) count += collector.getCollectionCount();
                if (collector.getCollectionTime() > 0) time += collector.getCollectionTime();
            }
        } catch (Throwable ignored) { }
        return new long[] { count, time };
    }

    private static String detectedRendererMods() {
        if (Providers.csClient == null || Providers.csClient.getClient() == null) return "unknown";
        StringBuilder result = new StringBuilder();
        String[] ids = { "sodium", "embeddium", "rubidium", "canvas", "vulkanmod", "immediatelyfast",
                "entityculling", "moreculling", "lithium", "ferritecore", "modernfix", "c2me", "noisium" };
        for (String id : ids) {
            if (Providers.csClient.getClient().isModLoaded(id)) {
                if (!result.isEmpty()) result.append(',');
                result.append(id);
            }
        }
        return result.isEmpty() ? "none-detected" : result.toString();
    }

    private static int clampProfile(int profile) { return Math.max(PROFILE_LOW, Math.min(PROFILE_HIGH, profile)); }
    private static String profileName(int profile) {
        return switch (profile) {
            case PROFILE_HIGH -> "HIGH PERFORMANCE";
            case PROFILE_BALANCED -> "BALANCED";
            default -> "LOW";
        };
    }

    private static String sanitizeLabel(String value) {
        String clean = value == null ? "benchmark" : value.trim().replaceAll("[^A-Za-z0-9._-]+", "-");
        if (clean.isBlank()) clean = "benchmark";
        return clean.length() > 48 ? clean.substring(0, 48) : clean;
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private static void logInfo(String message) {
        if (Providers.csClient != null) Providers.csClient.logInfo(message);
    }

    private static void logError(String message, Throwable error) {
        if (Providers.csClient != null) Providers.csClient.logError(message, error);
    }

    public record Metrics(int samples, double averageFps, double averageFrameMs,
            double p95FrameMs, double p99FrameMs, double p999FrameMs,
            double worstFrameMs, long heapUsedMiB, int profile) {
        public static final Metrics EMPTY = new Metrics(0, 0, 0, 0, 0, 0, 0, 0, PROFILE_LOW);
        public double onePercentLowFps() { return p99FrameMs <= 0 ? 0 : 1000.0 / p99FrameMs; }
        public double pointOnePercentLowFps() { return p999FrameMs <= 0 ? 0 : 1000.0 / p999FrameMs; }
    }
}
