package com.craftstudio.csclient.ui.screens;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModManager;

/** Six researched, reversible HUD-only presets; gameplay modules are untouched. */
public final class HudPresetManager {
    public enum Preset { PVP, BEDWARS, SURVIVAL, STREAM, PERFORMANCE, MINIMAL }

    public record LayoutState(int x, int y, float scale) { }
    public record Snapshot(Map<Mod, Boolean> enabled, Map<HudMod, LayoutState> layouts) { }

    private static final Set<String> PVP = Set.of(
            "FPS Display", "Ping Display", "Keystrokes", "CPS Display",
            "Armor Display", "Status Effects", "Combo Counter", "Reach Display");
    private static final Set<String> BEDWARS = Set.of(
            "FPS Display", "Ping Display", "Keystrokes", "CPS Display",
            "Armor Display", "Item Counter", "Combo Counter", "Reach Display");
    private static final Set<String> SURVIVAL = Set.of(
            "FPS Display", "Coordinates", "Direction Display", "Day Counter",
            "Armor Display", "Status Effects", "Minimap", "Clock");
    private static final Set<String> STREAM = Set.of(
            "FPS Display", "CPS Display", "Keystrokes", "Armor Display",
            "Status Effects", "Clock", "Coordinates", "Server Address");
    private static final Set<String> PERFORMANCE = Set.of(
            "FPS Display", "Ping Display", "TPS Display", "Memory Usage", "Connection Status");
    private static final Set<String> MINIMAL = Set.of("FPS Display", "Ping Display");

    private static Snapshot lastSnapshot;

    private HudPresetManager() { }

    public static Snapshot capture() {
        Map<Mod, Boolean> enabled = new IdentityHashMap<>();
        Map<HudMod, LayoutState> layouts = new IdentityHashMap<>();
        for (Mod mod : ModManager.MODS) {
            if (!(mod instanceof HudMod hud)) continue;
            enabled.put(mod, mod.isEnabled());
            ModLayout layout = hud.getDimensions();
            layouts.put(hud, new LayoutState(layout.x.value, layout.y.value, layout.scale.value));
        }
        return new Snapshot(enabled, layouts);
    }

    public static synchronized Snapshot apply(Preset preset, int width, int height) {
        Snapshot before = capture();
        Set<String> selected = selected(preset);
        for (Mod mod : ModManager.MODS) {
            if (!(mod instanceof HudMod) || !mod.isToggleable()) continue;
            boolean enabled = selected.contains(mod.getName());
            if (mod.isEnabled() != enabled) mod.setEnabled(enabled);
        }
        for (Mod mod : ModManager.MODS) {
            if (!(mod instanceof HudMod hud) || !selected.contains(mod.getName())) continue;
            place(preset, mod.getName(), hud.getDimensions(), width, height);
        }
        ModManager.updateEnabledModules();
        ConfigManager.save();
        lastSnapshot = before;
        return before;
    }

    public static synchronized boolean canUndo() {
        return lastSnapshot != null;
    }

    public static synchronized boolean restoreLast() {
        if (lastSnapshot == null) return false;
        Snapshot snapshot = lastSnapshot;
        lastSnapshot = null;
        restoreInternal(snapshot);
        return true;
    }

    public static synchronized void restore(Snapshot snapshot) {
        if (snapshot == null) return;
        if (snapshot == lastSnapshot) lastSnapshot = null;
        restoreInternal(snapshot);
    }

    private static void restoreInternal(Snapshot snapshot) {
        snapshot.enabled().forEach((mod, enabled) -> {
            if (mod.isToggleable() && mod.isEnabled() != enabled) mod.setEnabled(enabled);
        });
        snapshot.layouts().forEach((hud, state) -> {
            ModLayout layout = hud.getDimensions();
            layout.x.value = state.x();
            layout.y.value = state.y();
            layout.scale.value = state.scale();
        });
        ModManager.updateEnabledModules();
        ConfigManager.save();
    }

    private static Set<String> selected(Preset preset) {
        return switch (preset) {
            case PVP -> PVP;
            case BEDWARS -> BEDWARS;
            case SURVIVAL -> SURVIVAL;
            case STREAM -> STREAM;
            case PERFORMANCE -> PERFORMANCE;
            case MINIMAL -> MINIMAL;
        };
    }

    private static void place(Preset preset, String name, ModLayout layout, int width, int height) {
        float scale = preset == Preset.MINIMAL ? 0.78f : 0.86f;
        int x = 12;
        int y = 42;
        switch (preset) {
            case PVP -> {
                switch (name) {
                    case "FPS Display" -> { x = 12; y = 42; scale = 0.82f; }
                    case "Ping Display" -> { x = 12; y = 68; scale = 0.82f; }
                    case "Keystrokes" -> { x = 12; y = height - 170; scale = 0.92f; }
                    case "CPS Display" -> { x = 142; y = height - 82; scale = 0.86f; }
                    case "Armor Display" -> { x = width - 205; y = height - 82; scale = 0.90f; }
                    case "Status Effects" -> { x = width - 235; y = 46; scale = 0.84f; }
                    case "Combo Counter" -> { x = width / 2 - 205; y = height - 88; scale = 0.84f; }
                    case "Reach Display" -> { x = width / 2 + 122; y = height - 88; scale = 0.84f; }
                }
            }
            case BEDWARS -> {
                switch (name) {
                    case "FPS Display" -> { x = 12; y = 42; scale = 0.82f; }
                    case "Ping Display" -> { x = 12; y = 68; scale = 0.82f; }
                    case "Keystrokes" -> { x = 12; y = height - 170; scale = 0.92f; }
                    case "CPS Display" -> { x = 142; y = height - 82; scale = 0.86f; }
                    case "Armor Display" -> { x = width - 205; y = height - 82; scale = 0.90f; }
                    case "Item Counter" -> { x = width - 195; y = 46; scale = 0.84f; }
                    case "Combo Counter" -> { x = width / 2 - 205; y = height - 88; scale = 0.84f; }
                    case "Reach Display" -> { x = width / 2 + 122; y = height - 88; scale = 0.84f; }
                }
            }
            case SURVIVAL -> {
                switch (name) {
                    case "FPS Display" -> { x = 12; y = 42; scale = 0.82f; }
                    case "Coordinates" -> { x = 12; y = 72; scale = 0.86f; }
                    case "Direction Display" -> { x = width / 2 - 66; y = 42; scale = 0.84f; }
                    case "Day Counter" -> { x = 12; y = 104; scale = 0.80f; }
                    case "Clock" -> { x = width - 126; y = 42; scale = 0.80f; }
                    case "Minimap" -> { x = width - 180; y = 78; scale = 0.78f; }
                    case "Status Effects" -> { x = width - 238; y = 222; scale = 0.84f; }
                    case "Armor Display" -> { x = width - 205; y = height - 82; scale = 0.90f; }
                }
            }
            case STREAM -> {
                switch (name) {
                    case "FPS Display" -> { x = 16; y = 44; scale = 0.82f; }
                    case "Coordinates" -> { x = 16; y = 76; scale = 0.84f; }
                    case "Keystrokes" -> { x = 16; y = height - 205; scale = 0.92f; }
                    case "CPS Display" -> { x = 16; y = height - 84; scale = 0.86f; }
                    case "Clock" -> { x = width - 122; y = 42; scale = 0.80f; }
                    case "Status Effects" -> { x = width - 238; y = 78; scale = 0.84f; }
                    case "Armor Display" -> { x = width - 205; y = height - 82; scale = 0.90f; }
                    case "Server Address" -> { x = width / 2 - 90; y = 42; scale = 0.80f; }
                }
            }
            case PERFORMANCE -> {
                switch (name) {
                    case "FPS Display" -> { x = 12; y = 42; scale = 0.78f; }
                    case "Ping Display" -> { x = 12; y = 68; scale = 0.78f; }
                    case "TPS Display" -> { x = 12; y = 94; scale = 0.78f; }
                    case "Memory Usage" -> { x = 12; y = 120; scale = 0.78f; }
                    case "Connection Status" -> { x = 12; y = 146; scale = 0.78f; }
                }
            }
            case MINIMAL -> {
                if (name.equals("FPS Display")) { x = 12; y = 42; }
                else if (name.equals("Ping Display")) { x = 12; y = 64; }
            }
        }
        layout.scale.value = scale;
        int scaledWidth = Math.max(1, Math.round(layout.width * scale));
        int scaledHeight = Math.max(1, Math.round(layout.height * scale));
        layout.x.value = Math.max(4, Math.min(x, Math.max(4, width - scaledWidth - 4)));
        layout.y.value = Math.max(36, Math.min(y, Math.max(36, height - scaledHeight - 4)));
    }
}
