package com.craftstudio.csclient.common.feature;

import com.craftstudio.csclient.common.ref.game.ItemStackRef;

/** Cross-version world and targeted-block information. */
public interface WorldFeature {
    boolean hasWorld();
    long getWorldAge();

    default long getDay() {
        return getWorldAge() / 24_000L;
    }

    record BlockInfo(String name, String id, String detail) {
        public static final BlockInfo EMPTY = new BlockInfo("NO BLOCK", "minecraft:air", "Aim at a block");
    }

    /** Basic client-visible information for the block under the crosshair. */
    default BlockInfo getTargetBlockInfo() { return BlockInfo.EMPTY; }

    /** Actual Minecraft item/block icon for the targeted block. */
    default ItemStackRef getTargetBlockIcon() { return null; }

    /** Whether the player is under a substantial roof and cave mapping should be used. */
    default boolean isUnderground() { return false; }

    /** Local block break progress from 0 to 1. */
    default float getBlockBreakProgress() { return 0f; }

    /**
     * True when nothing opaque blocks the straight line from (x0,y0,z0) to
     * (x1,y1,z1). Used by entity occlusion culling. The default is "clear"
     * so an unimplemented adapter never hides entities (fail-open).
     */
    default boolean isLineOfSightClear(double x0, double y0, double z0,
            double x1, double y1, double z1) { return true; }


    /**
     * Lightweight top-surface colors around the player. Implementations sample
     * only this requested grid and may cache it between calls.
     */
    default int[] getMinimapColors(int cells, int blocksPerCell) {
        return new int[Math.max(1, cells * cells)];
    }
}
