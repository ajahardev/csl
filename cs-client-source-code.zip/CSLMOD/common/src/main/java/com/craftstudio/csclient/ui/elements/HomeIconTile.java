package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Compact shallow-corner utility tile for Home's floating navigation rails. */
public class HomeIconTile extends Element {
    private final IdentifierRef icon;
    private final Runnable onClick;
    private float hover;

    public HomeIconTile(IdentifierRef icon, Runnable onClick) {
        this.icon = icon;
        this.onClick = onClick;
        dimensions(38, 38);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.25f;
        int lift = hover > 0.55f ? -1 : 0;
        int fill = blend(0x7A11171D, 0xE42A343E, hover);
        int outline = blend(0x657C8792, 0xFFF3F6F8, hover);
        scope.drawRoundedRectangle(0, lift, width, height, 6, fill);
        scope.drawRoundedBorder(0, lift, width, height, 6, outline);
        int iconSize = 16 + (hover > 0.65f ? 1 : 0);
        scope.drawTexture(icon, (width - iconSize) / 2, (height - iconSize) / 2 + lift,
                0, 0, iconSize, iconSize,
                hover > 0.45f ? Theme.FOREGROUND.value : Theme.PRIMARY_FG.value);
        if (hover > 0.03f) {
            scope.drawRectangle(8, height - 2, Math.round((width - 16) * hover), 1,
                    Theme.withAlpha(Math.round(220 * hover), Theme.ACCENT.value));
        }
    }

    @Override public void click(int mouseX, int mouseY) { if (onClick != null) onClick.run(); }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
