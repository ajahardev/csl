package com.craftstudio.csclient.ui.screens;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.screenshot.ScreenshotRepository.Entry;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.elements.FeatherStackButton;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.ScreenshotPreviewImage;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

public final class ScreenshotPreviewScreen extends CSClientScreen {
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd  HH:mm:ss");
    private final CSClientScreen parent;
    private final Entry entry;

    public ScreenshotPreviewScreen(CSClientScreen parent, Entry entry) {
        super("Screenshot Preview");
        this.parent = parent == null ? new ScreenshotManagerScreen(new TitleMenu()) : parent;
        this.entry = entry;
        backgroundBlur = 5;
    }

    @Override
    public void ui() {
        int panelWidth = Math.min(1040, width - 28);
        int panelHeight = Math.min(520, height - 22);
        int x = (width - panelWidth) / 2;
        int y = (height - panelHeight) / 2;
        draw(new Panel(0xF20E1419).dimensions(panelWidth, panelHeight).position(x, y));
        draw(new IconButton(Textures.BACK, this::goBack).dimensions(38, 38).position(x + 13, y + 13));
        draw(new Text("SCREENSHOT PREVIEW").scale(0.70f).position(x + 64, y + 13));
        String displayName = entry.name().length() > 72 ? entry.name().substring(0, 69) + "…" : entry.name();
        draw(new Text(displayName).color(Theme.ACCENT.value).scale(0.30f).position(x + 65, y + 42));

        int sideWidth = Math.min(250, Math.max(190, panelWidth / 4));
        int imageWidth = panelWidth - sideWidth - 34;
        int imageHeight = panelHeight - 84;
        draw(new ScreenshotPreviewImage(entry).dimensions(imageWidth, imageHeight)
                .position(x + 14, y + 68));

        int sx = x + imageWidth + 24;
        int buttonWidth = sideWidth - 20;
        String date = DATE.format(Instant.ofEpochMilli(entry.modifiedMillis()).atZone(ZoneId.systemDefault()));
        draw(new Text("PROFILE FILE").scale(0.29f).position(sx, y + 82));
        draw(new Text(date).scale(0.31f).position(sx, y + 106));
        draw(new Text(formatBytes(entry.bytes())).scale(0.31f).position(sx, y + 130));
        draw(new Text("Local PNG only").color(Theme.ACCENT.value).scale(0.28f).position(sx, y + 154));

        draw(new FeatherStackButton(Textures.FILE, "COPY FILE PATH", false, false,
                () -> Providers.csClient.getClient().setClipboardText(entry.path().toString()))
                .dimensions(buttonWidth, 46).position(sx, y + 205));
        draw(new FeatherStackButton(Textures.TRASH, "DELETE SCREENSHOT", false, true,
                () -> Providers.csClient.getClient().setScreen(new ScreenshotDeleteConfirmScreen(parent, entry)))
                .dimensions(buttonWidth, 46).position(sx, y + 263));
        draw(new Text("No upload or sharing service").scale(0.25f).position(sx, y + panelHeight - 36));
    }

    private static String formatBytes(long bytes) {
        if (bytes >= 1024L * 1024L) return String.format(java.util.Locale.ROOT, "%.2f MiB", bytes / 1048576.0);
        return String.format(java.util.Locale.ROOT, "%.1f KiB", bytes / 1024.0);
    }

    private void goBack() { Providers.csClient.getClient().setScreen(parent); }
    @Override public boolean shouldPause() { return true; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            goBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
