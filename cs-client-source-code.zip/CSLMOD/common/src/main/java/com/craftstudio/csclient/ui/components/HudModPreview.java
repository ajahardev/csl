package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

public class HudModPreview extends Element {
    HudMod feature;

    public HudModPreview(HudMod feature) {
        this.feature = feature;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        ModLayout layout = feature.getDimensions();

        // Use the exact same shell path as gameplay; previews no longer force a fake background.
        feature.renderBackground(scope);
        feature.renderEditor(scope);
    }
}
