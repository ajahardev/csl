package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.ModSpec;

public class StopwatchMod extends TextHudMod {
    private static final KeybindingProperty startPauseKey = Property.keybinding(GLFWProvider.GLFW_KEY_P);
    private static final KeybindingProperty resetKey = Property.keybinding(GLFWProvider.GLFW_KEY_O);
    private boolean running;
    private long startedAt;
    private long accumulated;

    public StopwatchMod() {
        super(new ModSpec("Stopwatch", "stopwatch").description("Key-controlled gameplay stopwatch")
                        .version("v1.0.0").tags("Utility", "HUD"),
                106,
                startPauseKey.named("Start / Pause Key"),
                resetKey.named("Reset Key"));
    }

    @Override public void tick() {
        long now = System.currentTimeMillis();
        if (startPauseKey.wasKeyPressed()) {
            if (running) accumulated += now - startedAt;
            else startedAt = now;
            running = !running;
        }
        if (resetKey.wasKeyPressed()) {
            accumulated = 0L;
            startedAt = now;
        }
    }

    private long elapsed() { return accumulated + (running ? System.currentTimeMillis() - startedAt : 0L); }
    private static String format(long millis) {
        long totalTenths = millis / 100L;
        long minutes = totalTenths / 600;
        long seconds = (totalTenths / 10) % 60;
        return FastNumberFormatter.twoDigits(minutes) + ":" + FastNumberFormatter.twoDigits(seconds)
                + "." + (totalTenths % 10);
    }
    @Override protected String getText() { return (running ? "▶ " : "Ⅱ ") + format(elapsed()); }
    @Override protected String getDummyText() { return "▶ 03:42.7"; }
}
