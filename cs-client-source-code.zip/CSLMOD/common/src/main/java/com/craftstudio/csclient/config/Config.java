package com.craftstudio.csclient.config;

import java.io.File;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.StringProperty;
import com.craftstudio.csclient.ui.resources.Textures;

public class Config {
    public static ConfigManager config;

    public static final BoolProperty realisticLogo = Property.bool(false);
    public static final BoolProperty csTitleScreen = Property.bool(true);
    public static final BoolProperty stagger = Property.bool(true);

    /**
     * User-saved server address. Blank means "no saved server"; the default is
     * only applied while no saved value exists, and initialization never
     * overwrites a previously saved address.
     */
    public static final StringProperty serverIp = Property.string("");

    public static IdentifierRef getLogo() {
        return realisticLogo.value ? Textures.REALISTIC_LOGO : Textures.LOGO;
    }

    /** Trimmed saved server address, or "" when nothing was saved. */
    public static String savedServerIp() {
        String value = serverIp.value;
        return value == null ? "" : value.trim();
    }

    /**
     * Persists a user-chosen server address immediately. A blank address
     * simply clears the saved value; it is never replaced by a default.
     */
    public static void setServerIp(String address) {
        String clean = address == null ? "" : address.trim();
        if (clean.length() > 80) clean = clean.substring(0, 80);
        serverIp.value = clean;
        ConfigManager.save();
    }

    public static void init() {
        File configFile = new File(Providers.csClient.getClient().getRunDirectory(), "cs-client.json");
        // Stable on-disk namespace: keep existing user configuration readable across V1.
        config = new ConfigManager(configFile, "CS Client");

        config.property("Realistic logo", realisticLogo);
        config.property("CS Client title screen", csTitleScreen);
        config.property("Stagger animations", stagger);
        config.property("Server IP", serverIp);

        Theme.init(config);
        AnimationConfig.init(config);
    }
}
