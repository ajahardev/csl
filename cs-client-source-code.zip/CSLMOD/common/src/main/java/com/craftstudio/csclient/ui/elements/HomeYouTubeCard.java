package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;

/** Rounded Home card that prompts before opening the fixed Craft Studio YouTube channel. */
public final class HomeYouTubeCard extends Element {
    private final Runnable onClick;
    private float hover;

    public HomeYouTubeCard(Runnable onClick) {
        this.onClick = onClick;
        dimensions(220, 68);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.22f;
        if (Math.abs(target - hover) < 0.002f) hover = target;

        int lift = hover > 0.55f ? -1 : 0;
        int fill = blend(0xDE161D22, 0xF228121C, hover);
        int outline = blend(0x927A808A, 0xFFFFFFFF, hover);
        int detail = blend(0xFFD9E0EA, 0xFFFFFFFF, hover);
        int sub = blend(0xFFAEB8C7, 0xFFFFD8DD, hover);
        scope.drawRoundedRectangle(0, lift, width, height, 7, fill);
        scope.drawRoundedBorder(0, lift, width, height, 7, outline);
        if (hover > 0.02f) {
            scope.drawRoundedBorder(-2, lift - 2, width + 4, height + 4, 9,
                    Theme.withAlpha(Math.round(80 * hover), 0xFFFF5368));
        }

        // Official YouTube PNG is drawn with no tint or transformation.
        int logoWidth = Math.max(90, Math.min(126, width - 70));
        int logoHeight = Math.max(30, Math.round(logoWidth * (573f / 1705f)));
        scope.drawTexture(Textures.YOUTUBE_OFFICIAL, 15, 12 + lift, 0, 0, logoWidth, logoHeight);
        scope.drawText(0.30f, "SUBSCRIBE FOR UPDATES", 16,
                Math.min(height - 20, 47) + lift, Theme.FONT.value, sub);
        String arrow = "↗";
        int arrowWidth = Math.round(Fonts.getWidth(arrow, Theme.FONT.value) * 0.58f);
        scope.drawText(0.58f, arrow, width - arrowWidth - 17 + Math.round(hover * 2f),
                25 + lift, Theme.FONT.value, detail);
        int railWidth = Math.max(22, Math.round((width - 32) * (0.26f + hover * 0.74f)));
        scope.drawRoundedRectangle(16, height - 5 + lift, railWidth, 2, 1,
                Theme.withAlpha(Math.round(130 + hover * 110), 0xFFFF5368));
    }

    @Override public void click(int mouseX, int mouseY) { if (onClick != null) onClick.run(); }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
