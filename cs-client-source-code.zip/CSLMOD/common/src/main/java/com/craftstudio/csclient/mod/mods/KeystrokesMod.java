package com.craftstudio.csclient.mod.mods;

import java.util.ArrayDeque;
import java.util.Deque;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Research-driven Lunar/Feather keystrokes with spring press/fade animation. */
public class KeystrokesMod extends Mod implements HudMod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty showMouse = Property.bool(true);
    private static final BoolProperty showSpace = Property.bool(true);
    private static final BoolProperty showCps = Property.bool(true);
    private static final BoolProperty useArrows = Property.bool(false);
    private static final BoolProperty border = Property.bool(true);
    private static final BoolProperty animateColor = Property.bool(true);
    private static final SelectProperty keyStyle = Property.select(0,
            "Lunar Glass", "Feather Flat", "Minimal Outline");
    private static final IntProperty boxSize = Property.integer(22);
    private static final ColorProperty borderColor = Property.color(0x808F969F);
    private static final ColorProperty clickBg = Property.color(0xDDE7EBF0);
    private static final ColorProperty clickFg = Property.color(0xFF111419);
    private static final ModLayout layout = new ModLayout(70, 92);
    private static final int GAP = 3;

    private static final class KeyAnim {
        float value;
        float velocity;
        void update(boolean down) {
            float target = down ? 1f : 0f;
            velocity += (target - value) * 0.40f;
            velocity *= 0.61f;
            value = Math.max(0, Math.min(1.08f, value + velocity));
            if (Math.abs(target - value) < 0.003f && Math.abs(velocity) < 0.003f) {
                value = target;
                velocity = 0;
            }
        }
    }

    private final KeyAnim w = new KeyAnim(), a = new KeyAnim(), s = new KeyAnim(), d = new KeyAnim();
    private final KeyAnim lmb = new KeyAnim(), rmb = new KeyAnim(), space = new KeyAnim();
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean lastLeft, lastRight;

    public KeystrokesMod() {
        super(new ModSpec("Keystrokes", "keystrokes")
                        .description("Lunar/Feather WASD with CPS, borders and smooth press animation")
                        .version("v0.4.0").tags("Utility", "HUD")
                        .requires(Providers.feature::player),
                enabled.named("Enabled"), showMouse.named("Show mouse buttons"),
                showSpace.named("Show spacebar"), showCps.named("Show mouse CPS"),
                useArrows.named("Use arrow symbols"), border.named("Key borders"),
                animateColor.named("Animate pressed colors"), keyStyle.named("Key design"),
                boxSize.named("Box size"), borderColor.named("Border color"),
                clickFg.named("Pressed text"), clickBg.named("Pressed background"), layout.prop());
        layout.renderBackground = false;
    }

    @Override
    public void tick() {
        PlayerFeature p = Providers.feature.player();
        boolean left = p.isAttackPressed();
        boolean right = p.isUsePressed();
        w.update(p.isForwardPressed()); a.update(p.isLeftPressed());
        s.update(p.isBackPressed()); d.update(p.isRightPressed());
        lmb.update(left); rmb.update(right); space.update(p.isJumpPressed());

        long now = System.currentTimeMillis();
        if (left && !lastLeft) leftClicks.addLast(now);
        if (right && !lastRight) rightClicks.addLast(now);
        lastLeft = left; lastRight = right;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) rightClicks.removeFirst();
        refreshDimensions();
    }

    @Override public void renderHud(RenderScope scope) { render(scope, true); }
    @Override public void renderDummy(RenderScope scope) { render(scope, false); }

    private void render(RenderScope scope, boolean live) {
        int size = clampedSize();
        int gridWidth = size * 3 + GAP * 2;
        int y = 0;
        renderKey(scope, live ? w.value : 0, useArrows.value ? "↑" : "W", size + GAP, y, size, size);
        y += size + GAP;
        renderKey(scope, live ? a.value : 0, useArrows.value ? "←" : "A", 0, y, size, size);
        renderKey(scope, live ? s.value : 0, useArrows.value ? "↓" : "S", size + GAP, y, size, size);
        renderKey(scope, live ? d.value : 0, useArrows.value ? "→" : "D", (size + GAP) * 2, y, size, size);
        y += size + GAP;

        if (showMouse.value) {
            int mouseWidth = (gridWidth - GAP) / 2;
            renderMouse(scope, live ? lmb.value : 0, "LMB", live ? leftClicks.size() : 8,
                    0, y, mouseWidth, size);
            renderMouse(scope, live ? rmb.value : 0, "RMB", live ? rightClicks.size() : 5,
                    mouseWidth + GAP, y, mouseWidth, size);
            y += size + GAP;
        }
        if (showSpace.value) {
            int spaceHeight = Math.max(10, size / 2);
            renderSpace(scope, live ? space.value : 0, 0, y, gridWidth, spaceHeight);
        }
    }

    private void renderKey(RenderScope scope, float progress, String label, int x, int y, int width, int height) {
        Box box = drawBox(scope, progress, x, y, width, height);
        float scale = label.length() == 1 ? 0.52f : 0.38f;
        int textWidth = Math.round(Fonts.getWidth(label, layout.font.value) * scale);
        int fg = animateColor.value ? blend(layout.fgColor.value, clickFg.value, progress) : layout.fgColor.value;
        scope.drawText(scale, label, box.x + (box.w - textWidth) / 2,
                box.y + (box.h - 9) / 2, layout.font.value, fg);
    }

    private void renderMouse(RenderScope scope, float progress, String label, int cps,
            int x, int y, int width, int height) {
        Box box = drawBox(scope, progress, x, y, width, height);
        int fg = animateColor.value ? blend(layout.fgColor.value, clickFg.value, progress) : layout.fgColor.value;
        if (showCps.value) {
            int labelWidth = Math.round(Fonts.getWidth(label, layout.font.value) * 0.34f);
            String cpsText = cps + " CPS";
            int cpsWidth = Math.round(Fonts.getWidth(cpsText, layout.font.value) * 0.27f);
            scope.drawText(0.34f, label, box.x + (box.w - labelWidth) / 2, box.y + 3, layout.font.value, fg);
            scope.drawText(0.27f, cpsText, box.x + (box.w - cpsWidth) / 2, box.y + 13, layout.font.value, fg);
        } else {
            int textWidth = Math.round(Fonts.getWidth(label, layout.font.value) * 0.36f);
            scope.drawText(0.36f, label, box.x + (box.w - textWidth) / 2,
                    box.y + (box.h - 8) / 2, layout.font.value, fg);
        }
    }

    private void renderSpace(RenderScope scope, float progress, int x, int y, int width, int height) {
        Box box = drawBox(scope, progress, x, y, width, height);
        int fg = animateColor.value ? blend(layout.fgColor.value, clickFg.value, progress) : layout.fgColor.value;
        int lineWidth = Math.round(box.w * (0.38f + Math.min(1f, progress) * 0.18f));
        scope.drawRoundedRectangle(box.x + (box.w - lineWidth) / 2, box.y + box.h / 2,
                lineWidth, 2, 1, fg);
    }

    private Box drawBox(RenderScope scope, float progress, int x, int y, int width, int height) {
        int inset = Math.round(Math.min(1f, progress));
        Box b = new Box(x + inset, y + inset, width - inset * 2, height - inset * 2);
        int normalBg = layout.effectiveBackgroundColor();
        int bg = animateColor.value ? blend(normalBg, clickBg.value, progress) : (progress > 0.5f ? clickBg.value : normalBg);
        int radius = keyStyle.value == 0 ? 5 : keyStyle.value == 1 ? 2 : 1;

        if (layout.background.value && keyStyle.value != 2) {
            scope.drawRoundedRectangle(b.x, b.y, b.w, b.h, radius, bg);
        }
        if (border.value || keyStyle.value == 2) {
            int bc = animateColor.value ? blend(borderColor.value, 0xFFE8ECF1, progress) : borderColor.value;
            scope.drawBorder(b.x, b.y, b.w, b.h, bc);
        }
        if (progress > 0.015f && keyStyle.value == 0) {
            int alpha = Math.min(130, Math.round(progress * 130));
            scope.drawRoundedRectangle(b.x + 3, b.y + 3, Math.max(2, b.w - 6), Math.max(2, b.h - 6),
                    Math.max(1, radius - 2), (alpha << 24) | (clickBg.value & 0x00FFFFFF));
        }
        return b;
    }

    private void refreshDimensions() {
        int size = clampedSize();
        layout.width = size * 3 + GAP * 2;
        layout.height = size * 2 + GAP;
        if (showMouse.value) layout.height += size + GAP;
        if (showSpace.value) layout.height += Math.max(10, size / 2) + GAP;
    }

    private static int clampedSize() { return Math.max(16, Math.min(32, boxSize.value)); }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0, Math.min(1, amount));
        int a = lerp((from >>> 24) & 255, (to >>> 24) & 255, t);
        int r = lerp((from >>> 16) & 255, (to >>> 16) & 255, t);
        int g = lerp((from >>> 8) & 255, (to >>> 8) & 255, t);
        int b = lerp(from & 255, to & 255, t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    private static int lerp(int a, int b, float t) { return Math.round(a + (b - a) * t); }
    private record Box(int x, int y, int w, int h) { }

    /** Preserve the existing WASD shell exactly while other HUDs use the new style system. */
    @Override public void renderBackground(RenderScope scope) {
        if (layout.shouldRenderBackground()) {
            scope.drawRoundedRectangle(0, 0, layout.width, layout.height,
                    layout.effectiveRadius(), layout.effectiveBackgroundColor());
        }
    }

    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
