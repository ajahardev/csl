package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

public class Text extends Element {
    private final String text;
    private Integer color;

    public Text(String text) {
        this.text = text;
        width = Fonts.getWidth(text, Theme.FONT.value);
        height = Fonts.getHeight();
    }

    public Text color(int color) {
        this.color = color;
        return this;
    }

    @Override
    public void render(RenderScope renderScope, ElementContext ctx) {
        renderScope.drawText(this.text, 0, 0, Theme.FONT.value,
                color == null ? Theme.FOREGROUND.value : color);
    }
}
