package com.craftstudio.csclient.mod.mods;

import java.awt.image.BufferedImage;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/** Cached low-resolution terrain minimap; samples update at most four times per second. */
public class MinimapMod extends Mod implements HudMod {
    private static final int CELLS = 33;
    private static final IdentifierRef LIVE_MAP = IdentifierRef.ofClient("textures/gui/minimap/live_map");
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty CIRCULAR = Property.bool(false);
    private static final BoolProperty SHOW_DIRECTION = Property.bool(true);
    private static final BoolProperty ROTATE_WITH_PLAYER = Property.bool(true);
    private static final IntProperty SIZE = Property.integer(128);
    private static final IntProperty ZOOM = Property.integer(2);
    private static final ModLayout LAYOUT = new ModLayout(128, 128);

    private int[] colors = new int[CELLS * CELLS];
    private long nextSample;
    private boolean textureReady;

    public MinimapMod() {
        super(new ModSpec("Minimap", "minimap")
                        .description("Lightweight cached terrain map with size, shape and zoom controls")
                        .version("v1.0.0").tags("Navigation", "HUD", "World")
                        .requires(Providers.feature::world),
                ENABLED.named("Enabled"), SIZE.named("Map Size"), ZOOM.named("Map Zoom"),
                CIRCULAR.named("Circular Shape"), SHOW_DIRECTION.named("Show Direction Marker"),
                ROTATE_WITH_PLAYER.named("Rotate With Player"), LAYOUT.prop());
        LAYOUT.background.value = false;
    }

    @Override
    public void tick() {
        if (!ENABLED.value || !Providers.feature.world().hasWorld()) return;
        long now = System.currentTimeMillis();
        if (now < nextSample) return;
        nextSample = now + PerformanceBoostMod.minimapSampleIntervalMs();
        int zoom = Math.max(1, Math.min(6, ZOOM.value));
        colors = Providers.feature.world().getMinimapColors(CELLS, zoom);
        uploadMapTexture(colors);
    }

    private void uploadMapTexture(int[] samples) {
        BufferedImage image = new BufferedImage(CELLS, CELLS, BufferedImage.TYPE_INT_ARGB);
        int radius = CELLS / 2;
        for (int y = 0; y < CELLS; y++) for (int x = 0; x < CELLS; x++) {
            int color = samples != null && y * CELLS + x < samples.length
                    ? samples[y * CELLS + x] : 0xFF151A20;
            if (CIRCULAR.value) {
                int dx = x - radius, dy = y - radius;
                if (dx * dx + dy * dy > radius * radius) color = 0x00000000;
            }
            image.setRGB(x, y, color);
        }
        Providers.csClient.registerBufferedImageTexture(LIVE_MAP, image);
        textureReady = true;
    }

    @Override public void renderHud(RenderScope scope) { draw(scope, colors, Providers.feature.player().getYaw(), true); }

    @Override public void renderDummy(RenderScope scope) {
        int[] dummy = new int[CELLS * CELLS];
        for (int y = 0; y < CELLS; y++) for (int x = 0; x < CELLS; x++) {
            int dx = x - CELLS / 2, dy = y - CELLS / 2;
            dummy[y * CELLS + x] = Math.abs(dx) < 2 ? 0xFF4D86B8
                    : (dx + dy) % 5 == 0 ? 0xFF87945B : 0xFF4F7C45;
        }
        draw(scope, dummy, -35f, false);
    }

    private void draw(RenderScope scope, int[] samples, float yaw, boolean live) {
        int size = Math.max(88, Math.min(196, SIZE.value));
        LAYOUT.width = size;
        LAYOUT.height = size + 15;
        int cell = Math.max(1, (size - 8) / CELLS);
        int mapSize = cell * CELLS;
        int start = (size - mapSize) / 2;
        int radius = CELLS / 2;

        scope.drawRoundedRectangle(0, 0, size, size, CIRCULAR.value ? size / 2 : 10, 0xE00A0E12);
        scope.getMatrixStack().push();
        if (ROTATE_WITH_PLAYER.value) {
            scope.getMatrixStack().translate(size / 2f, size / 2f);
            scope.getMatrixStack().rotate(-yaw);
            scope.getMatrixStack().translate(-size / 2f, -size / 2f);
        }
        if (live && textureReady) {
            scope.drawTexture(LIVE_MAP, start, start, 0, 0, mapSize, mapSize);
        } else {
            for (int gy = 0; gy < CELLS; gy++) {
                for (int gx = 0; gx < CELLS; gx++) {
                    int dx = gx - radius, dy = gy - radius;
                    if (CIRCULAR.value && dx * dx + dy * dy > radius * radius) continue;
                    int index = gy * CELLS + gx;
                    int color = samples != null && index < samples.length && samples[index] != 0
                            ? samples[index] : 0xFF22282E;
                    scope.drawRectangle(start + gx * cell, start + gy * cell, cell + 1, cell + 1, color);
                }
            }
        }
        scope.getMatrixStack().pop();
        scope.drawRoundedBorder(0, 0, size, size, CIRCULAR.value ? size / 2 : 10,
                Theme.withAlpha(185, Theme.ACCENT.value));
        if (SHOW_DIRECTION.value) {
            int cx = size / 2, cy = size / 2;
            // Player arrow remains fixed while terrain rotates, like common PvP minimaps.
            scope.drawRectangle(cx - 2, cy - 1, 5, 4, 0xFFFFFFFF);
            scope.drawRectangle(cx - 1, cy - 6, 3, 7, Theme.ACCENT.value);
        }
        if (!ROTATE_WITH_PLAYER.value) {
            scope.drawText(0.32f, "N", size / 2 - 3, 5, LAYOUT.font.value, 0xFFFFFFFF);
        }
        String mode = Providers.feature.world().isUnderground() ? "CAVE" : "SURFACE";
        scope.drawText(0.28f, mode + "  •  Z" + Math.max(1, Math.min(6, ZOOM.value)),
                7, size - 12, LAYOUT.font.value, Theme.withAlpha(210, 0xFFFFFFFF));
        String coords = Providers.feature.player().getX() + ", "
                + Providers.feature.player().getY() + ", " + Providers.feature.player().getZ();
        scope.drawText(0.32f, coords, 6, size + 5, LAYOUT.font.value,
                Theme.withAlpha(220, 0xFFFFFFFF));
    }

    @Override public ModLayout getDimensions() { return LAYOUT; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
