package com.craftstudio.csclient.server;

import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;

/** Draws the local PlantMC banner and India flag behind the native server row. */
public final class PlantMcServerDecoration {
    private static final int BANNER_WIDTH = 1009;
    private static final int BANNER_HEIGHT = 202;

    private PlantMcServerDecoration() { }

    public static void render(RenderScope scope, int x, int y, int width, int height, boolean hovered) {
        if (scope == null || width < 40 || height < 16) return;
        scope.enableScissor(x, y, x + width, y + height);
        try {
            drawCover(scope, x, y, width, height);
            // Keep vanilla server name/MOTD/player text readable without hiding the artwork.
            scope.drawRectangle(x, y, width, height, hovered ? 0x26000000 : 0x46000000);
            scope.drawRectangle(x, y, width, 1, hovered ? 0xFFE3473E : 0xA8A51F1B);
            scope.drawRectangle(x, y + height - 1, width, 1, hovered ? 0xFFE3473E : 0xA8A51F1B);

            // Matches the established country-flag placement immediately before the server name.
            int flagX = x + 35;
            int flagY = y + 2;
            scope.drawRectangle(flagX - 1, flagY - 1, 20, 14, 0xD00A0D11);
            scope.drawTexture(Textures.INDIA_FLAG, flagX, flagY, 0, 0, 18, 12);
        } finally {
            scope.disableScissor();
        }
    }

    /** Center-crop cover scaling keeps a responsive row filled without stretching the supplied art. */
    private static void drawCover(RenderScope scope, int x, int y, int width, int height) {
        float targetAspect = width / (float) height;
        float sourceAspect = BANNER_WIDTH / (float) BANNER_HEIGHT;
        if (targetAspect > sourceAspect) {
            int cropHeight = Math.max(1, Math.round(BANNER_WIDTH / targetAspect));
            int cropY = Math.max(0, (BANNER_HEIGHT - cropHeight) / 2);
            scope.drawTexture(Textures.PLANTMC_BANNER, x, y, 0, cropY, width, height,
                    BANNER_WIDTH, cropHeight, BANNER_WIDTH, BANNER_HEIGHT);
        } else {
            int cropWidth = Math.max(1, Math.round(BANNER_HEIGHT * targetAspect));
            int cropX = Math.max(0, (BANNER_WIDTH - cropWidth) / 2);
            scope.drawTexture(Textures.PLANTMC_BANNER, x, y, cropX, 0, width, height,
                    cropWidth, BANNER_HEIGHT, BANNER_WIDTH, BANNER_HEIGHT);
        }
    }
}
