package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.WorldFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/**
 * DayCounterMod shows how many in-game days have elapsed.
 * Day count is derived from the world age via {@link WorldFeature}.
 */
public class DayCounterMod extends Mod implements HudMod {

    private static final BoolProperty enabled = Property.bool(false);
    private static final ModLayout layout = new ModLayout(40, 18);

    public DayCounterMod() {
        super(
                new ModSpec("Day Counter", "day")
                        .description("Displays the number of in-game days elapsed")
                        .version("v0.2.0")
                        .tags("Utility")
                        .requires(Providers.feature::world),
                enabled.named("Enabled"),
                layout.prop());
    }

    // ---------------------------------------------------------------
    // HudMod
    // ---------------------------------------------------------------

    @Override
    public void renderHud(RenderScope scope) {
        renderDay(Providers.feature.world().getDay(), scope);
    }

    @Override
    public void renderDummy(RenderScope scope) {
        renderDay(271L, scope);
    }

    // ---------------------------------------------------------------
    // Rendering
    // ---------------------------------------------------------------

    private void renderDay(long day, RenderScope scope) {
        String text = "DAY  " + day;

        HudTextRenderer.draw(scope, layout, text);
    }

    // ---------------------------------------------------------------
    // Mod contract
    // ---------------------------------------------------------------

    @Override
    public ModLayout getDimensions() {
        return layout;
    }

    @Override
    public boolean isEnabled() {
        return enabled.value;
    }

    @Override
    public void onEnabled(boolean e) {
        enabled.value = e;
    }
}
