package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.SkinHeadRenderer;

/** Live active-profile face, including the skin's second/head layer. */
public final class ActiveSkinHead extends Element {
    public ActiveSkinHead() { dimensions(32, 32); }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        SkinHeadRenderer.draw(scope, 0, 0, Math.min(width, height), Theme.FOREGROUND.value);
    }
}
