package com.craftstudio.csclient.ui.elements;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Live async skin-import status without rebuilding focused text fields. */
public class SkinStatusBadge extends Element {
    private final Supplier<String> message;
    private final BooleanSupplier busy;
    private final BooleanSupplier success;

    public SkinStatusBadge(Supplier<String> message, BooleanSupplier busy, BooleanSupplier success) {
        this.message = message;
        this.busy = busy;
        this.success = success;
        dimensions(420, 34);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        boolean loading = busy.getAsBoolean();
        int color = loading ? 0xFFFFC66D : success.getAsBoolean() ? 0xFF77D99A : 0xFFFF8F9D;
        scope.drawRoundedRectangle(0, 0, width, height, 6, Theme.withAlpha(38, color));
        scope.drawRoundedBorder(0, 0, width, height, 6, Theme.withAlpha(145, color));
        scope.drawRoundedRectangle(11, 14, 6, 6, 3, color);
        String value = message.get();
        if (value == null || value.isBlank()) value = "Ready for a local skin.";
        value = ellipsize(value, width - 35, 0.34f);
        scope.drawText(0.34f, value, 26, 13, Theme.FONT.value, color);
    }

    private static String ellipsize(String text, int maxWidth, float scale) {
        if (Fonts.getWidth(text, Theme.FONT.value) * scale <= maxWidth) return text;
        int end = text.length();
        while (end > 1 && Fonts.getWidth(text.substring(0, end) + "…", Theme.FONT.value) * scale > maxWidth) end--;
        return text.substring(0, Math.max(1, end)) + "…";
    }
}
