package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Compact icon-first action used by the Right-Shift, preset and pause popups. */
public class QuickActionTile extends Element {
    private final IdentifierRef icon;
    private final String title;
    private final String subtitle;
    private final int accent;
    private final Runnable action;
    private float hover;

    public QuickActionTile(IdentifierRef icon, String title, String subtitle, int accent, Runnable action) {
        this.icon = icon;
        this.title = title == null ? "" : title;
        this.subtitle = subtitle == null ? "" : subtitle;
        this.accent = accent;
        this.action = action;
        dimensions(142, 58);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.24f;
        if (Math.abs(target - hover) < 0.002f) hover = target;

        int lift = hover > 0.56f ? -1 : 0;
        int fill = blend(0xDE11181D, withAlpha(228, darken(accent, 0.77f)), hover * 0.46f);
        int outline = blend(0x78677470, withAlpha(240, accent), hover);
        int foreground = blend(0xFFE1E7E4, 0xFFFFFFFF, hover);
        scope.drawRoundedRectangle(0, lift, width, height, 6, fill);
        scope.drawRoundedBorder(0, lift, width, height, 6, outline);

        int iconBox = Math.min(34, height - 18);
        int iconY = (height - iconBox) / 2 + lift;
        scope.drawRoundedRectangle(10, iconY, iconBox, iconBox, 6,
                blend(withAlpha(55, accent), withAlpha(105, accent), hover));
        scope.drawRoundedBorder(10, iconY, iconBox, iconBox, 6,
                withAlpha(125 + Math.round(100 * hover), accent));
        if (icon != null) {
            int iconSize = 17 + (hover > 0.65f ? 1 : 0);
            scope.drawTexture(icon, 10 + (iconBox - iconSize) / 2,
                    iconY + (iconBox - iconSize) / 2, 0, 0, iconSize, iconSize,
                    hover > 0.28f ? 0xFFFFFFFF : accent);
        }

        int copyX = 54 + Math.round(hover * 2f);
        int copyWidth = Math.max(24, width - copyX - 8);
        String shownTitle = ellipsize(title, copyWidth, 0.43f);
        scope.drawText(0.43f, shownTitle, copyX, subtitle.isBlank() ? height / 2 - 5 + lift : 15 + lift,
                Theme.FONT.value, foreground);
        if (!subtitle.isBlank()) {
            scope.drawText(0.25f, ellipsize(subtitle, copyWidth, 0.25f), copyX, 34 + lift,
                    Theme.FONT.value, withAlpha(180, foreground));
        }

        if (hover > 0.02f) {
            int rail = Math.max(2, Math.round((width - 20) * hover));
            scope.drawRoundedRectangle(10, height - 2 + lift, rail, 1, 1,
                    withAlpha(Math.round(230 * hover), accent));
        }
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (action != null) action.run();
    }

    private static String ellipsize(String text, int maxWidth, float scale) {
        if (Fonts.getWidth(text, Theme.FONT.value) * scale <= maxWidth) return text;
        int end = text.length();
        while (end > 1 && Fonts.getWidth(text.substring(0, end) + "…", Theme.FONT.value) * scale > maxWidth) end--;
        return text.substring(0, Math.max(1, end)) + "…";
    }

    private static int darken(int color, float factor) {
        int r = Math.round(((color >>> 16) & 255) * factor);
        int g = Math.round(((color >>> 8) & 255) * factor);
        int b = Math.round((color & 255) * factor);
        return (color & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
