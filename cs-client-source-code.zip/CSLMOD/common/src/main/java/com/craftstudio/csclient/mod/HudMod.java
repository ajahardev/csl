package com.craftstudio.csclient.mod;

import com.craftstudio.csclient.ui.RenderScope;

public interface HudMod {
    public ModLayout getDimensions();

    /** Draws the selected shell consistently in gameplay, settings preview and HUD Layout. */
    default void renderBackground(RenderScope scope) {
        HudStyleRenderer.drawBackground(scope, getDimensions());
    }

    /** Native adapters such as Scoreboard may be movable but intentionally not resizable. */
    default boolean canScale() { return true; }

    /** Native HUD adapters start at Minecraft's exact position until the user drags them. */
    default boolean usesNativeDefaultPosition() { return false; }
    default boolean isUsingNativeDefaultPosition() { return false; }
    default void onLayoutChanged() { }
    default void onLayoutReset() { }

    public void renderDummy(RenderScope scope);

    /** Settings/HUD previews use the module's real renderer with deterministic representative data. */
    default void renderEditor(RenderScope scope) { renderDummy(scope); }

    public void renderHud(RenderScope scope);

    /** Whether this widget currently has live content to display. */
    default boolean shouldRenderHud() { return true; }
}
