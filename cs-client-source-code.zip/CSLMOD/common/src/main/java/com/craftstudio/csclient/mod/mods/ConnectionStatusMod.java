package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.NetworkFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.ModSpec;

public class ConnectionStatusMod extends TextHudMod {
    public ConnectionStatusMod() {
        super(new ModSpec("Connection Status", "connection").description("Shows connection state and latency")
                .version("v1.0.0").tags("Network", "HUD").requires(Providers.feature::network), 112);
    }

    @Override protected String getText() {
        NetworkFeature network = Providers.feature.network();
        if (!network.hasNetwork()) return "○ OFFLINE";
        int ping = network.getPing();
        return "● ONLINE" + (ping >= 0 ? "  " + ping + " MS" : "");
    }
    @Override protected String getDummyText() { return "● ONLINE  42 MS"; }
}
