package com.craftstudio.csclient.ui.screens;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.FloatProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.NamespaceProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.config.property.StringProperty;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.mods.ScoreboardMod;
import com.craftstudio.csclient.mod.mods.BossBarMod;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.components.HudModPreview;
import com.craftstudio.csclient.ui.components.ModulePreviewSurface;
import com.craftstudio.csclient.ui.components.ModuleSettingRow;
import com.craftstudio.csclient.ui.components.ModuleStateToggle;
import com.craftstudio.csclient.ui.components.SettingSurface;
import com.craftstudio.csclient.ui.components.inputs.ColorInput;
import com.craftstudio.csclient.ui.components.inputs.FloatInput;
import com.craftstudio.csclient.ui.components.inputs.IntInput;
import com.craftstudio.csclient.ui.components.inputs.KeybindingSelector;
import com.craftstudio.csclient.ui.components.inputs.Select;
import com.craftstudio.csclient.ui.components.inputs.StringInput;
import com.craftstudio.csclient.ui.components.inputs.Toggle;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.ImageTexture;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.Scroll;
import com.craftstudio.csclient.ui.elements.SettingsNavButton;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.elements.TextFieldElement;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;

/** Two-pane client-grade settings studio with search and live module context. */
public class ConfigEditor extends CSClientScreen {
    private final ConfigManager config;
    private final HudMod hudMod;
    private final Mod mod;
    private String activeSection = "GENERAL";
    private String query = "";
    private Scroll settingsScroll;
    private Map<String, Property> visibleProperties;
    private int settingsWidth;

    public ConfigEditor(ConfigManager config) {
        this(config, null, null);
    }

    public ConfigEditor(ConfigManager config, HudMod hudMod) {
        this(config, hudMod, null);
    }

    public ConfigEditor(Mod mod) {
        this(mod.getConfig(), mod instanceof HudMod h ? h : null, mod);
    }

    private ConfigEditor(ConfigManager config, HudMod hudMod, Mod mod) {
        super("CS Client V1 Settings Studio");
        this.config = config;
        this.hudMod = hudMod;
        this.mod = mod;
    }

    /** Allows platform adapters to retain the title panorama behind module-only settings. */
    public boolean isModuleEditor() {
        return mod != null;
    }

    @Override
    public void ui() {
        backgroundBlur = 7;
        // Individual modules use the researched context + dense options layout;
        // Client-wide settings keep their separate sectioned Studio navigation.
        if (mod != null) {
            drawResearchedModuleEditor();
            return;
        }
        int studioWidth = Math.min(1080, width - 28);
        int studioX = (width - studioWidth) / 2;
        int top = 18;
        boolean compact = studioWidth < 820;

        draw(new IconButton(Textures.BACK, provider::close).position(studioX, top));
        draw(new Text(mod == null ? "CLIENT STUDIO" : "MODULE STUDIO")
                .scale(0.92f).position(studioX + 56, top + 2));
        draw(new Text(mod == null
                ? "APPEARANCE  •  BEHAVIOR  •  MOTION"
                : "LIVE PREVIEW  •  MODULE OPTIONS  •  HUD CONTROL")
                .scale(0.33f).position(studioX + 57, top + 32));

        int contentY = 76;
        int contentHeight = Math.max(250, height - contentY - 18);
        int gap = 12;

        int navWidth = compact ? 176 : 224;
        int rightX = studioX + navWidth + gap;
        int rightWidth = studioWidth - navWidth - gap;
        drawClientNavigation(studioX, contentY, navWidth, contentHeight);
        visibleProperties = clientSectionProperties();
        drawSettingsPane(rightX, contentY, rightWidth, contentHeight,
                sectionTitle(), sectionSubtitle());
    }

    private void drawResearchedModuleEditor() {
        int workspaceWidth = Math.min(1040, width - 28);
        int workspaceX = (width - workspaceWidth) / 2;
        int top = 16;
        int headerHeight = 66;
        boolean compact = workspaceWidth < 820;

        // Feather-style module identity bar with Lunar's explicit searchable context.
        draw(new Panel(0xED10151A).dimensions(workspaceWidth, headerHeight).position(workspaceX, top));
        draw(new IconButton(Textures.BACK, provider::close).position(workspaceX + 10, top + 13));
        draw(new Panel(0xE51D242B).dimensions(42, 42).position(workspaceX + 56, top + 11));
        draw(new ImageTexture(mod.getIconTexture()).dimensions(22, 22).position(workspaceX + 66, top + 21));

        int copyX = workspaceX + 112;
        int copyWidth = workspaceWidth - 112 - 142;
        draw(new Text(ellipsize(mod.getName().toUpperCase(), copyWidth, 0.72f))
                .scale(0.72f).position(copyX, top + 8));
        draw(new Text(moduleMeta()).scale(0.29f).position(copyX + 1, top + 34));
        draw(new Text(ellipsize(mod.getDescription(), copyWidth, 0.29f))
                .scale(0.29f).position(copyX + 1, top + 49));
        if (mod.isToggleable()) {
            draw(new ModuleStateToggle(mod).position(workspaceX + workspaceWidth - 124, top + 14));
        } else {
            draw(new Panel(Theme.withAlpha(165, Theme.ACCENT.value)).dimensions(112, 38)
                    .position(workspaceX + workspaceWidth - 124, top + 14));
            draw(new Text("AUTO HUD").scale(0.39f)
                    .position(workspaceX + workspaceWidth - 101, top + 29));
        }

        int contentY = top + headerHeight + 10;
        int contentHeight = Math.max(230, height - contentY - 16);
        int gap = 10;

        if (compact) {
            int contextHeight = hudMod == null ? 96 : 118;
            drawCompactModuleContext(workspaceX, contentY, workspaceWidth, contextHeight);
            drawModuleSettingsWorkspace(workspaceX, contentY + contextHeight + gap,
                    workspaceWidth, contentHeight - contextHeight - gap);
        } else {
            int contextWidth = 264;
            drawModuleContextRail(workspaceX, contentY, contextWidth, contentHeight);
            drawModuleSettingsWorkspace(workspaceX + contextWidth + gap, contentY,
                    workspaceWidth - contextWidth - gap, contentHeight);
        }
    }

    private void drawModuleContextRail(int x, int y, int width, int height) {
        draw(new Panel(0xE710151B).dimensions(width, height).position(x, y));
        draw(new Text("MODULE CONTEXT").scale(0.36f).position(x + 14, y + 14));
        draw(new Text(hudMod == null ? "REAL-TIME FEATURE" : "LIVE OUTPUT")
                .scale(0.28f).position(x + width - 94, y + 15));

        int surfaceX = x + 14;
        int surfaceY = y + 40;
        int surfaceWidth = width - 28;
        int surfaceHeight = Math.min(hudMod == null ? 170 : 218,
                Math.max(108, height - (hudMod == null ? 126 : 174)));
        draw(new ModulePreviewSurface(hudMod == null ? "FEATURE MODULE" : "LIVE HUD PREVIEW")
                .dimensions(surfaceWidth, surfaceHeight).position(surfaceX, surfaceY));

        if (hudMod != null) {
            drawHudPreview(surfaceX, surfaceY, surfaceWidth, surfaceHeight);
        } else {
            int iconSize = Math.min(64, Math.max(42, surfaceHeight - 88));
            draw(new ImageTexture(mod.getIconTexture()).dimensions(iconSize, iconSize)
                    .position(surfaceX + (surfaceWidth - iconSize) / 2,
                            surfaceY + (surfaceHeight - iconSize) / 2 + 7));
        }

        int infoY = surfaceY + surfaceHeight + 15;
        draw(new Text("TYPE").scale(0.28f).position(x + 16, infoY));
        draw(new Text(hudMod == null ? "GAME FEATURE" : "HUD MODULE")
                .scale(0.36f).position(x + 16, infoY + 15));
        draw(new Text("OPTIONS").scale(0.28f).position(x + 16, infoY + 42));
        draw(new Text(propertyCount(config.getProperties()) + " COMPLETE SETTINGS")
                .scale(0.36f).position(x + 16, infoY + 57));

        if (hudMod != null) {
            draw(new HomeMenuButton(Textures.HUD_ICON, "EDIT HUD", false,
                    () -> Providers.csClient.getClient().setScreen(new HudEditor()))
                    .dimensions(width - 28, 38).position(x + 14, y + height - 52));
        } else {
            draw(new Text("CHANGES APPLY IMMEDIATELY").scale(0.29f)
                    .position(x + 16, y + height - 27));
        }
    }

    private void drawCompactModuleContext(int x, int y, int width, int height) {
        draw(new Panel(0xE710151B).dimensions(width, height).position(x, y));
        int surfaceWidth = Math.min(300, Math.max(190, width / 2 - 18));
        int surfaceX = x + 10;
        int surfaceY = y + 10;
        int surfaceHeight = height - 20;
        draw(new ModulePreviewSurface(hudMod == null ? "FEATURE MODULE" : "LIVE HUD PREVIEW")
                .dimensions(surfaceWidth, surfaceHeight).position(surfaceX, surfaceY));

        if (hudMod != null) {
            drawHudPreview(surfaceX, surfaceY, surfaceWidth, surfaceHeight);
        } else {
            int iconSize = Math.min(46, Math.max(30, surfaceHeight - 42));
            draw(new ImageTexture(mod.getIconTexture()).dimensions(iconSize, iconSize)
                    .position(surfaceX + (surfaceWidth - iconSize) / 2,
                            surfaceY + (surfaceHeight - iconSize) / 2 + 6));
        }

        int rightX = surfaceX + surfaceWidth + 12;
        int rightWidth = x + width - rightX - 12;
        draw(new Text(hudMod == null ? "REAL-TIME FEATURE" : "HUD MODULE")
                .scale(0.40f).position(rightX, y + 16));
        draw(new Text(moduleMeta()).scale(0.28f).position(rightX, y + 38));
        draw(new Text(propertyCount(config.getProperties()) + " SETTINGS  •  SAVED LIVE")
                .scale(0.28f).position(rightX, y + 55));
        if (hudMod != null) {
            draw(new HomeMenuButton(Textures.HUD_ICON, "EDIT HUD", false,
                    () -> Providers.csClient.getClient().setScreen(new HudEditor()))
                    .dimensions(rightWidth, 34).position(rightX, y + height - 44));
        }
    }

    private void drawModuleSettingsWorkspace(int x, int y, int width, int height) {
        draw(new Panel(0xE710151B).dimensions(width, height).position(x, y));
        draw(new Text("MODULE OPTIONS").scale(0.59f).position(x + 14, y + 13));
        draw(new Text(propertyCount(config.getProperties()) + " SETTINGS  •  ALL CONTROLS RETAINED")
                .scale(0.28f).position(x + 15, y + 40));

        int searchWidth = Math.min(240, Math.max(176, width / 3));
        TextFieldElement search = new TextFieldElement("Search module settings", 40,
                c -> Character.isLetterOrDigit(c) || Character.isWhitespace(c) || c == '-' || c == '_',
                value -> {
                    query = value;
                    populateSettings();
                }, null, Textures.SEARCH);
        search.dimensions(searchWidth, 36).position(x + width - searchWidth - 12, y + 12);
        if (!query.isBlank()) search.setValue(query);
        draw(search);

        visibleProperties = config.getProperties();
        settingsWidth = width - 36;
        settingsScroll = new Scroll(10);
        settingsScroll.dimensions(width - 16, Math.max(130, height - 70)).position(x + 8, y + 62);
        draw(settingsScroll);
        populateSettings();
    }

    private void drawHudPreview(int x, int y, int width, int height) {
        if (hudMod == null) return;
        ModLayout layout = hudMod.getDimensions();
        int baseWidth = Math.max(30, layout.width);
        int baseHeight = Math.max(17, layout.height);
        float preferred = Math.max(0.45f, Math.min(1.05f, layout.scale.value));
        float fitX = Math.max(0.20f, (width - 22f) / baseWidth);
        float fitY = Math.max(0.20f, (height - 38f) / baseHeight);
        float scale = Math.max(0.20f, Math.min(preferred, Math.min(fitX, fitY)));
        int previewWidth = Math.round(baseWidth * scale);
        int previewHeight = Math.round(baseHeight * scale);
        draw(new HudModPreview(hudMod).dimensions(baseWidth, baseHeight).scale(scale)
                .position(x + (width - previewWidth) / 2,
                        y + 22 + (height - 22 - previewHeight) / 2));
    }

    private String moduleMeta() {
        String category = mod.getTags().length == 0 ? "UTILITY" : mod.getTags()[0].toUpperCase(Locale.ROOT);
        String version = mod.getVersion() == null || mod.getVersion().isBlank() ? "BUILT-IN" : mod.getVersion();
        return category + "  •  " + version + "  •  CS MODULE";
    }

    private int propertyCount(Map<String, Property> properties) {
        int count = 0;
        for (Map.Entry<String, Property> entry : properties.entrySet()) {
            String name = entry.getKey();
            if (hudMod != null && (name.equalsIgnoreCase("X") || name.equalsIgnoreCase("Y"))) continue;
            if ((mod instanceof ScoreboardMod || mod instanceof BossBarMod) && name.equalsIgnoreCase("In-Game Display")) continue;
            Property property = entry.getValue();
            count += property instanceof NamespaceProperty namespace ? propertyCount(namespace.value) : 1;
        }
        return count;
    }

    private void drawClientNavigation(int x, int y, int width, int height) {
        draw(new Panel(0xE010151B).dimensions(width, height).position(x, y));
        draw(new Text("SECTIONS").scale(0.35f).position(x + 16, y + 17));

        int buttonY = y + 43;
        addNav(x + 8, buttonY, width - 16, Textures.SLIDERS, "GENERAL", "GENERAL");
        addNav(x + 8, buttonY + 54, width - 16, Textures.PALETTE, "APPEARANCE", "APPEARANCE");
        addNav(x + 8, buttonY + 108, width - 16, Textures.SPARK, "MOTION", "MOTION");

        int cardY = y + height - 126;
        draw(new Panel(0xC9181D23).dimensions(width - 16, 110).position(x + 8, cardY));
        draw(new ImageTexture(Config.getLogo()).dimensions(34, 34).position(x + 20, cardY + 14));
        draw(new Text("CS CLIENT V1").scale(0.54f).position(x + 66, cardY + 16));
        draw(new Text("SETTINGS STUDIO").scale(0.31f).position(x + 67, cardY + 39));
        draw(new Text("GRAPHITE UI").scale(0.31f).position(x + 20, cardY + 67));
        draw(new Panel(Theme.ACCENT.value).dimensions(26, 8).position(x + 20, cardY + 88));
        draw(new Panel(Theme.PRIMARY.value).dimensions(26, 8).position(x + 52, cardY + 88));
        draw(new Panel(Theme.FOREGROUND.value).dimensions(26, 8).position(x + 84, cardY + 88));
    }

    private void addNav(int x, int y, int width, IdentifierRef icon, String label, String id) {
        SettingsNavButton button = new SettingsNavButton(icon, label,
                () -> activeSection.equals(id), () -> {
                    activeSection = id;
                    init();
                });
        button.dimensions(width, 46).position(x, y);
        draw(button);
    }

    private void drawSettingsPane(int x, int y, int width, int height, String title, String subtitle) {
        draw(new Panel(0xE010151B).dimensions(width, height).position(x, y));
        draw(new Text(title).scale(0.68f).position(x + 16, y + 17));
        draw(new Text(ellipsize(subtitle, width - 320, 0.32f)).scale(0.32f).position(x + 17, y + 44));

        int searchWidth = Math.min(270, Math.max(170, width / 3));
        TextFieldElement search = new TextFieldElement("Search this section", 40,
                c -> Character.isLetterOrDigit(c) || Character.isWhitespace(c) || c == '-' || c == '_',
                value -> {
                    query = value;
                    populateSettings();
                }, null, Textures.SEARCH);
        search.dimensions(searchWidth, 36).position(x + width - searchWidth - 14, y + 14);
        if (!query.isBlank()) search.setValue(query);
        draw(search);

        settingsWidth = width - 24;
        settingsScroll = new Scroll(10);
        settingsScroll.dimensions(width - 16, Math.max(140, height - 76)).position(x + 8, y + 68);
        draw(settingsScroll);
        populateSettings();
    }

    private void populateSettings() {
        if (settingsScroll == null || visibleProperties == null) return;
        settingsScroll.clearChildren();
        List<SettingRow> rows = new ArrayList<>();
        flatten(visibleProperties, rows);
        String needle = query.trim().toLowerCase(Locale.ROOT);
        if (!needle.isEmpty()) {
            rows.removeIf(row -> !row.section && !row.name.toLowerCase(Locale.ROOT).contains(needle)
                    && !hintFor(row.name, row.property).toLowerCase(Locale.ROOT).contains(needle));
        }

        int y = 0;
        List<ControlPlacement> controls = new ArrayList<>();
        for (SettingRow row : rows) {
            if (row.section) {
                if (!needle.isEmpty()) continue;
                int sectionHeight = mod == null ? 38 : 32;
                settingsScroll.draw(new Text(row.name.toUpperCase()).scale(mod == null ? 0.37f : 0.33f)
                        .position(5, y + (mod == null ? 11 : 9)));
                settingsScroll.draw(new Panel(Theme.withAlpha(62, Theme.ACCENT.value))
                        .dimensions(Math.max(30, settingsWidth - (mod == null ? 190 : 150)), 1)
                        .position(mod == null ? 165 : 128, y + (mod == null ? 17 : 14)));
                y += sectionHeight;
                continue;
            }

            Element control = controlFor(row.name, row.property);
            int rowHeight = mod == null ? 64 : 56;
            if (mod == null) {
                SettingSurface surface = new SettingSurface(row.name, hintFor(row.name, row.property),
                        iconFor(row.property));
                surface.dimensions(settingsWidth, rowHeight).position(0, y)
                        .animation(new SlideFade(AnimationConfig.modMenu, -8));
                settingsScroll.draw(surface);
            } else {
                int reserved = control == null ? 54 : control.width + 28;
                ModuleSettingRow surface = new ModuleSettingRow(row.name, hintFor(row.name, row.property),
                        iconFor(row.property), reserved);
                surface.dimensions(settingsWidth, rowHeight).position(0, y)
                        .animation(new SlideFade(AnimationConfig.modMenu, -6));
                settingsScroll.draw(surface);
            }

            if (control != null) {
                int controlX = settingsWidth - control.width - 12;
                int controlY = y + (rowHeight - control.height) / 2;
                controls.add(new ControlPlacement(control, controlX, controlY));
            }
            y += mod == null ? 72 : 62;
        }

        for (ControlPlacement placement : controls) {
            placement.control.position(placement.x, placement.y);
            settingsScroll.draw(placement.control);
        }
        if (y == 0) {
            String empty = (mod instanceof ScoreboardMod || mod instanceof BossBarMod)
                    ? "MOVE THE LIVE SERVER HUD IN RIGHT SHIFT → HUD LAYOUT"
                    : "NO SETTINGS MATCH THIS SEARCH";
            settingsScroll.draw(new Text(empty).scale(0.40f).position(18, 24));
            y = 70;
        }
        settingsScroll.draw(new Panel(0x0012161C).dimensions(1, Math.max(1, y)).position(0, 0));
    }

    private Map<String, Property> clientSectionProperties() {
        Map<String, Property> result = new LinkedHashMap<>();
        for (Map.Entry<String, Property> entry : config.getProperties().entrySet()) {
            if (activeSection.equals("GENERAL") && !(entry.getValue() instanceof NamespaceProperty)) {
                result.put(entry.getKey(), entry.getValue());
            } else if (entry.getValue() instanceof NamespaceProperty namespace) {
                String name = entry.getKey().toLowerCase(Locale.ROOT);
                if (activeSection.equals("APPEARANCE") && (name.contains("dark grey") || name.contains("theme"))) {
                    // Global colors now live only in the dedicated Home Theme Studio.
                    // Keep typography/radii here and preserve every module-specific color control.
                    namespace.value.forEach((propertyName, property) -> {
                        if (!(property instanceof ColorProperty)) result.put(propertyName, property);
                    });
                } else if (activeSection.equals("MOTION") && name.contains("animation")) {
                    result.putAll(namespace.value);
                }
            }
        }
        return result;
    }

    private String sectionTitle() {
        return switch (activeSection) {
            case "APPEARANCE" -> "APPEARANCE";
            case "MOTION" -> "MOTION & TRANSITIONS";
            default -> "GENERAL";
        };
    }

    private String sectionSubtitle() {
        return switch (activeSection) {
            case "APPEARANCE" -> "Typography and shape controls. Global colors live in Home's Theme Studio.";
            case "MOTION" -> "Control screen timing, stagger, and animation curves.";
            default -> "Core CS Client V1 behavior and Home presentation.";
        };
    }

    private void flatten(Map<String, Property> properties, List<SettingRow> rows) {
        for (Map.Entry<String, Property> entry : properties.entrySet()) {
            String name = entry.getKey();
            // X/Y remain persisted internally but movement belongs only to Right Shift → HUD Layout.
            if (hudMod != null && (name.equalsIgnoreCase("X") || name.equalsIgnoreCase("Y"))) continue;
            // The native Scoreboard has no cosmetic/settings controls: it is move-only.
            if ((mod instanceof ScoreboardMod || mod instanceof BossBarMod) && name.equalsIgnoreCase("In-Game Display")) continue;
            if (entry.getValue() instanceof NamespaceProperty namespace) {
                rows.add(new SettingRow(name, entry.getValue(), true));
                flatten(namespace.value, rows);
            } else {
                rows.add(new SettingRow(name, entry.getValue(), false));
            }
        }
    }

    private Element controlFor(String name, Property property) {
        if (property instanceof BoolProperty value) return new Toggle(value);
        if (property instanceof ColorProperty value) {
            return new ColorInput(value,
                    () -> Providers.csClient.getClient().setScreen(new ColorPickerScreen(value, this, name)));
        }
        if (property instanceof IntProperty value) return new IntInput(value);
        if (property instanceof FloatProperty value) return new FloatInput(value);
        if (property instanceof SelectProperty value) return new Select(value);
        if (property instanceof KeybindingProperty value) return new KeybindingSelector(value);
        if (property instanceof StringProperty value) return new StringInput(value);
        return null;
    }

    private IdentifierRef iconFor(Property property) {
        if (property instanceof BoolProperty) return Textures.TOGGLE;
        if (property instanceof ColorProperty) return Textures.PALETTE;
        if (property instanceof KeybindingProperty) return Textures.KEY;
        if (property instanceof SelectProperty) return Textures.CHOICE;
        if (property instanceof IntProperty || property instanceof FloatProperty) return Textures.HASH;
        return Textures.SLIDERS;
    }

    private String hintFor(String name, Property property) {
        if (property instanceof BoolProperty) return name.equalsIgnoreCase("Enabled")
                ? "Controls whether this module is active." : "Enable or disable this behavior.";
        if (property instanceof ColorProperty) return "Open Color Studio for alpha, hex, and presets.";
        if (property instanceof KeybindingProperty) return "Click the control, then press a key. Backspace clears it.";
        if (property instanceof SelectProperty) return "Choose between the available client styles or modes.";
        if (property instanceof IntProperty || property instanceof FloatProperty) return "Enter a precise numeric value.";
        return "Edit this client value.";
    }

    private static String ellipsize(String text, int maxWidth, float scale) {
        if (text == null || maxWidth <= 20) return text == null ? "" : text;
        if (Fonts.getWidth(text, Theme.FONT.value) * scale <= maxWidth) return text;
        int end = text.length();
        while (end > 1 && Fonts.getWidth(text.substring(0, end) + "…", Theme.FONT.value) * scale > maxWidth) end--;
        return text.substring(0, Math.max(1, end)) + "…";
    }

    private record SettingRow(String name, Property property, boolean section) {
    }

    private record ControlPlacement(Element control, int x, int y) {
    }
}
