package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Shallow-rounded Lunar/Feather-style centered menu action. */
public class HomeMenuButton extends Element {
    private final IdentifierRef icon;
    private final String label;
    private final Runnable onClick;
    private final boolean primary;
    private float hover;

    public HomeMenuButton(IdentifierRef icon, String label, boolean primary, Runnable onClick) {
        this.icon = icon;
        this.label = label;
        this.primary = primary;
        this.onClick = onClick;
        dimensions(330, 42);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.24f;
        if (Math.abs(target - hover) < 0.002f) hover = target;
        int expand = hover > 0.08f ? Math.max(1, Math.round(hover * 2f)) : 0;
        int radius = 5 + (hover > 0.72f ? 1 : 0);
        boolean danger = label.contains("QUIT");
        int idleFill = danger ? 0x5A2A1015 : primary ? 0x8A141B22 : 0x6310161C;
        int fill = blend(idleFill, danger ? 0xDD7E2632 : 0xE128323C, hover);
        int outline = blend(danger ? 0x8DBE5360 : primary ? 0xB08E99A4 : 0x66808A94,
                danger ? 0xFFFF8F9D : 0xFFF5F7F9, hover);
        int foreground = blend(danger ? 0xFFFF8A98 : 0xFFD7DCE1, 0xFFFFFFFF, hover);

        scope.drawRoundedRectangle(-expand, -expand, width + expand * 2, height + expand * 2,
                radius, fill);
        scope.drawRoundedBorder(-expand, -expand, width + expand * 2, height + expand * 2,
                radius, outline);
        if (hover > 0.02f) {
            scope.drawRoundedBorder(-expand - 2, -expand - 2, width + expand * 2 + 4,
                    height + expand * 2 + 4, radius + 2,
                    withAlpha(Math.round(65 * hover), Theme.ACCENT.value));
        }

        float textScale = 0.52f;
        int textWidth = Math.round(Fonts.getWidth(label, Theme.FONT.value) * textScale);
        int groupWidth = textWidth + (icon == null ? 0 : 25);
        int groupX = (width - groupWidth) / 2 + Math.round(hover * 2f);
        if (icon != null) {
            int iconSize = 15 + (hover > 0.68f ? 1 : 0);
            scope.drawTexture(icon, groupX, (height - iconSize) / 2, 0, 0, iconSize, iconSize, foreground);
            groupX += 25;
        }
        scope.drawText(textScale, label, groupX, height / 2 - 5 - (hover > 0.65f ? 1 : 0),
                Theme.FONT.value, foreground);

        int lineWidth = Math.max(1, Math.round((width - 26) * hover));
        if (lineWidth > 1) {
            scope.drawRectangle((width - lineWidth) / 2, height - 2, lineWidth, 1,
                    withAlpha(Math.round(230 * hover), Theme.ACCENT.value));
        }
    }

    @Override public void click(int mouseX, int mouseY) { if (onClick != null) onClick.run(); }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
