package com.craftstudio.csclient.ui.components.inputs;

import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.ui.resources.Fonts;

public class IntInput extends Input {
    public IntProperty prop;

    public IntInput(IntProperty prop) {
        this.width = 140;
        this.height = 30;
        this.prop = prop;
        this.text = String.valueOf(prop.value);
    }

    @Override
    public void charTyped(char chr) {
        if ((Character.isDigit(chr) || chr == '.' || (chr == '-' && cursorPosition == 0)) && text.length() < 10) {
            if (text.equals("0") && cursorPosition == 1) {
                text = "" + chr;
                try {
                    prop.value = Integer.parseInt(text);
                    // Persist immediately so the changed value survives relaunches.
                    ConfigManager.save();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                text = text.substring(0, cursorPosition) +
                        chr +
                        text.substring(cursorPosition);

                try {
                    prop.value = text.isEmpty() ? 0 : Integer.parseInt(text);
                    cursorPosition++;
                    // Persist immediately so the changed value survives relaunches.
                    ConfigManager.save();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void backspace() {
        try {
            if (text.length() == 0) {
                text = "0";
                cursorPosition = 1;
            }
            prop.value = Integer.parseInt(text);
            ConfigManager.save();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void checkReset() {
        if (prop.isReset) {
            this.text = String.valueOf(prop.value);
            this.cursorPosition = 0;
            prop.isReset = false;
        }
    }
}
