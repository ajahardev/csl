package com.craftstudio.csclient.util;

import java.net.URI;

/** Fixed, allowlisted public links opened only from explicit CS UI confirmation clicks. */
public final class ExternalLinks {
    public static final String DISCORD_INVITE = "https://discord.gg/ve2KMjmMWE";
    public static final String YOUTUBE_CHANNEL = "https://youtube.com/@craft-studio-official";

    public enum Destination {
        DISCORD("JOIN DISCORD", "Open Discord to join the CS Client V1 community?", DISCORD_INVITE),
        YOUTUBE("SUBSCRIBE ON YOUTUBE", "Open YouTube to subscribe to Craft Studio Official?", YOUTUBE_CHANNEL);

        private final String title;
        private final String prompt;
        private final String url;

        Destination(String title, String prompt, String url) {
            this.title = title;
            this.prompt = prompt;
            this.url = url;
        }

        public String title() { return title; }
        public String prompt() { return prompt; }
        public String url() { return url; }
    }

    private ExternalLinks() { }

    public static boolean isApprovedExternalLink(String raw) {
        return isApprovedDiscordInvite(raw) || isApprovedYouTubeChannel(raw);
    }

    /** No arbitrary URL opening: accepts only the configured HTTPS Discord invite. */
    public static boolean isApprovedDiscordInvite(String raw) {
        if (!DISCORD_INVITE.equals(raw)) return false;
        try {
            URI uri = URI.create(raw);
            return "https".equalsIgnoreCase(uri.getScheme())
                    && "discord.gg".equalsIgnoreCase(uri.getHost())
                    && "/ve2KMjmMWE".equals(uri.getPath())
                    && uri.getQuery() == null && uri.getFragment() == null;
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    /** No arbitrary URL opening: accepts only the configured HTTPS YouTube channel URL. */
    public static boolean isApprovedYouTubeChannel(String raw) {
        if (!YOUTUBE_CHANNEL.equals(raw)) return false;
        try {
            URI uri = URI.create(raw);
            return "https".equalsIgnoreCase(uri.getScheme())
                    && "youtube.com".equalsIgnoreCase(uri.getHost())
                    && "/@craft-studio-official".equals(uri.getPath())
                    && uri.getQuery() == null && uri.getFragment() == null;
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }
}
