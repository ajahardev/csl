package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Lightweight grid stage for a module's real HUD preview or feature identity. */
public class ModulePreviewSurface extends Element {
    private final String label;

    public ModulePreviewSurface(String label) {
        this.label = label;
        dimensions(230, 190);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        scope.drawRoundedRectangle(0, 0, width, height, 7, 0xD30A0E12);
        for (int x = 12; x < width - 8; x += 24) {
            scope.drawRectangle(x, 8, 1, Math.max(1, height - 16),
                    Theme.withAlpha(16, Theme.PRIMARY_FG.value));
        }
        for (int y = 12; y < height - 8; y += 24) {
            scope.drawRectangle(8, y, Math.max(1, width - 16), 1,
                    Theme.withAlpha(16, Theme.PRIMARY_FG.value));
        }

        int cx = width / 2;
        int cy = height / 2;
        scope.drawRectangle(cx - 10, cy, 21, 1, Theme.withAlpha(35, Theme.ACCENT.value));
        scope.drawRectangle(cx, cy - 10, 1, 21, Theme.withAlpha(35, Theme.ACCENT.value));
        scope.drawRoundedBorder(0, 0, width, height, 7,
                Theme.withAlpha(ctx.isHovering() ? 155 : 80, Theme.ACCENT.value));

        scope.drawRoundedRectangle(10, 9, 5, 5, 2, Theme.ACCENT.value);
        scope.drawText(0.29f, label, 22, 10, Theme.FONT.value,
                Theme.withAlpha(175, Theme.PRIMARY_FG.value));
    }
}
