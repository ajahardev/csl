package com.craftstudio.csclient.util;

/** Small fixed-decimal formatter that avoids creating java.util.Formatter per HUD frame. */
public final class FastNumberFormatter {
    private FastNumberFormatter() { }

    public static String fixed(double value, int decimals) {
        if (!Double.isFinite(value)) return "0";
        int digits = Math.max(0, Math.min(3, decimals));
        long factor = switch (digits) {
            case 1 -> 10L;
            case 2 -> 100L;
            case 3 -> 1_000L;
            default -> 1L;
        };
        long scaled = Math.round(value * factor);
        boolean negative = scaled < 0;
        long absolute = Math.abs(scaled);
        long whole = absolute / factor;
        if (digits == 0) return (negative ? "-" : "") + whole;
        long fraction = absolute % factor;
        String raw = Long.toString(fraction);
        StringBuilder result = new StringBuilder(negative ? digits + 4 : digits + 3);
        if (negative) result.append('-');
        result.append(whole).append('.');
        for (int i = raw.length(); i < digits; i++) result.append('0');
        return result.append(raw).toString();
    }

    public static String twoDigits(long value) {
        long positive = Math.max(0, value);
        return positive < 10 ? "0" + positive : Long.toString(positive);
    }
}
