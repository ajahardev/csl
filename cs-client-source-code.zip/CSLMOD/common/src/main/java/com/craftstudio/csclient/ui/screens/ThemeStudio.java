package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.Scroll;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.elements.ThemeColorCard;
import com.craftstudio.csclient.ui.elements.ThemeLivePreview;
import com.craftstudio.csclient.ui.elements.ThemePresetCard;
import com.craftstudio.csclient.ui.resources.Textures;

/** Dedicated global palette editor opened directly by Home's palette button. */
public class ThemeStudio extends CSClientScreen {
    private static final Palette[] PALETTES = {
            new Palette("CS GRAPHITE", "ORIGINAL SILVER", new int[] {
                    0xFF0B0D10, 0xFFF0F2F4, 0xFF181B20, 0xFFD4D8DD, 0xFF9AA1AA, 0xFF0B0D10, 0xFF707780
            }),
            new Palette("ARCTIC", "CLEAN BLUE", new int[] {
                    0xFF09111A, 0xFFF2F8FC, 0xFF152431, 0xFFC7D8E5, 0xFF63B3ED, 0xFF07131D, 0xFF557B94
            }),
            new Palette("EMBER", "WARM ORANGE", new int[] {
                    0xFF120D0D, 0xFFF7F1ED, 0xFF251A18, 0xFFE0CCC5, 0xFFF08A5D, 0xFF1C0D08, 0xFF8B675A
            }),
            new Palette("AMETHYST", "SOFT VIOLET", new int[] {
                    0xFF100D17, 0xFFF5F1FA, 0xFF211A2D, 0xFFD9CDE7, 0xFFB58BE0, 0xFF150B20, 0xFF78658D
            }),
            new Palette("FOREST", "COOL GREEN", new int[] {
                    0xFF0A100E, 0xFFF0F7F4, 0xFF17241F, 0xFFC9DDD4, 0xFF67C99A, 0xFF07170F, 0xFF567D69
            })
    };

    private static final Token[] TOKENS = {
            new Token("BACKGROUND", "Main client canvas and deep surfaces.", Theme.BACKGROUND),
            new Token("FOREGROUND", "Primary headings and high-contrast copy.", Theme.FOREGROUND),
            new Token("PRIMARY SURFACE", "Cards, buttons, fields, and control tracks.", Theme.PRIMARY),
            new Token("SURFACE TEXT", "Secondary text and idle icon color.", Theme.PRIMARY_FG),
            new Token("ACCENT", "Selected, enabled, progress, and hover state.", Theme.ACCENT),
            new Token("ACCENT TEXT", "Text and icons placed on the accent.", Theme.ACCENT_FG),
            new Token("SCROLLBAR", "Scroll position and secondary progress.", Theme.SCROLL)
    };

    public ThemeStudio() {
        super("CS Client V1 Theme Studio");
    }

    @Override
    public void ui() {
        backgroundBlur = 6;
        int panelWidth = Math.min(980, width - 36);
        int panelX = (width - panelWidth) / 2;
        int innerWidth = panelWidth - 20;

        draw(new IconButton(Textures.BACK, this::saveAndBack).position(panelX + 2, 20));
        draw(new Text("CLIENT THEME").scale(0.92f).position(panelX + 58, 22));
        draw(new Text("GLOBAL COLOR STUDIO  •  EVERY CS SCREEN UPDATES LIVE")
                .scale(0.34f).position(panelX + 59, 51));

        HomeMenuButton reset = new HomeMenuButton(Textures.RESET, "RESET COLORS", false,
                () -> applyPalette(PALETTES[0]));
        reset.dimensions(166, 36).position(panelX + panelWidth - 166, 25);
        draw(reset);

        int scrollY = 78;
        Scroll scroll = new Scroll(10);
        scroll.dimensions(panelWidth, Math.max(240, height - scrollY - 18)).position(panelX, scrollY);
        draw(scroll);

        int y = 0;
        scroll.draw(new Text("LIVE PREVIEW").scale(0.40f).position(2, y));
        y += 22;
        scroll.draw(new ThemeLivePreview().dimensions(innerWidth, 112).position(0, y));
        y += 134;

        scroll.draw(new Text("QUICK THEMES").scale(0.40f).position(2, y));
        scroll.draw(new Text("ONE TAP CHANGES THE COMPLETE CLIENT PALETTE")
                .scale(0.29f).position(Math.max(130, innerWidth - 286), y + 2));
        y += 22;

        int presetGap = 10;
        int presetColumns = innerWidth >= 850 ? 5 : innerWidth >= 520 ? 3 : 2;
        int presetWidth = (innerWidth - presetGap * (presetColumns - 1)) / presetColumns;
        for (int i = 0; i < PALETTES.length; i++) {
            Palette palette = PALETTES[i];
            int col = i % presetColumns;
            int row = i / presetColumns;
            ThemePresetCard card = new ThemePresetCard(palette.name, palette.hint, palette.colors,
                    () -> applyPalette(palette));
            card.dimensions(presetWidth, 82).position(col * (presetWidth + presetGap), y + row * 92);
            scroll.draw(card);
        }
        int presetRows = (PALETTES.length + presetColumns - 1) / presetColumns;
        y += presetRows * 92 + 10;

        scroll.draw(new Text("CUSTOM COLOR TOKENS").scale(0.40f).position(2, y));
        scroll.draw(new Text("TAP ANY SWATCH FOR HSV, ALPHA, PRESETS, AND HEX")
                .scale(0.29f).position(Math.max(170, innerWidth - 345), y + 2));
        y += 22;

        int colorGap = 10;
        int colorColumns = innerWidth >= 690 ? 2 : 1;
        int colorWidth = (innerWidth - colorGap * (colorColumns - 1)) / colorColumns;
        for (int i = 0; i < TOKENS.length; i++) {
            Token token = TOKENS[i];
            int col = i % colorColumns;
            int row = i / colorColumns;
            ThemeColorCard card = new ThemeColorCard(token.name, token.description, token.property,
                    () -> openColor(token));
            card.dimensions(colorWidth, 68).position(col * (colorWidth + colorGap), y + row * 78);
            scroll.draw(card);
        }
        int colorRows = (TOKENS.length + colorColumns - 1) / colorColumns;
        y += colorRows * 78 + 8;
        scroll.draw(new Text("Palette changes are local, credential-free, and saved in cs-client.json.")
                .scale(0.30f).position(2, y));
    }

    private void openColor(Token token) {
        Providers.csClient.getClient().setScreen(new ColorPickerScreen(token.property, this, token.name));
    }

    private void applyPalette(Palette palette) {
        int[] c = palette.colors;
        Theme.BACKGROUND.value = c[0];
        Theme.FOREGROUND.value = c[1];
        Theme.PRIMARY.value = c[2];
        Theme.PRIMARY_FG.value = c[3];
        Theme.ACCENT.value = c[4];
        Theme.ACCENT_FG.value = c[5];
        Theme.SCROLL.value = c[6];
        ConfigManager.save();
    }

    private void saveAndBack() {
        ConfigManager.save();
        Providers.csClient.getClient().setScreen(new TitleMenu());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            saveAndBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private record Palette(String name, String hint, int[] colors) {
    }

    private record Token(String name, String description, ColorProperty property) {
    }
}
