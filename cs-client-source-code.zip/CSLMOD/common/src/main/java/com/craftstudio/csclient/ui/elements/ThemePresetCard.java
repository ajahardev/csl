package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** One-tap full-client palette preset with a live five-token preview. */
public class ThemePresetCard extends Element {
    private final String name;
    private final String hint;
    private final int[] colors;
    private final Runnable onClick;
    private float hover;

    public ThemePresetCard(String name, String hint, int[] colors, Runnable onClick) {
        this.name = name;
        this.hint = hint;
        this.colors = colors;
        this.onClick = onClick;
        dimensions(164, 82);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.24f;
        boolean selected = matchesCurrentTheme();
        int lift = hover > 0.55f ? -1 : 0;
        int fill = blend(0xD013181E, 0xF01C242D, hover);
        int outline = selected ? Theme.ACCENT.value : blend(0x436A7580, 0xD9E7EBEF, hover);

        scope.drawRoundedRectangle(0, lift, width, height, 7, fill);
        scope.drawRoundedBorder(0, lift, width, height, 7, outline);
        if (selected) scope.drawRectangle(10, height - 3 + lift, width - 20, 2, Theme.ACCENT.value);

        int swatchX = 11;
        int swatchY = 11 + lift;
        int swatchWidth = Math.max(13, (width - 28) / 5);
        for (int i = 0; i < 5; i++) {
            int x = swatchX + i * swatchWidth;
            int w = i == 4 ? width - 11 - x : swatchWidth - 2;
            scope.drawRoundedRectangle(x, swatchY, w, 16, 4, colors[i]);
            scope.drawRoundedBorder(x, swatchY, w, 16, 4, 0x42FFFFFF);
        }

        scope.drawText(0.50f, name, 11, 39 + lift, Theme.FONT.value, Theme.FOREGROUND.value);
        scope.drawText(0.30f, selected ? "ACTIVE PALETTE" : hint, 11, 61 + lift,
                Theme.FONT.value, selected ? Theme.ACCENT.value : Theme.withAlpha(145, Theme.PRIMARY_FG.value));
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private boolean matchesCurrentTheme() {
        return colors.length >= 7
                && Theme.BACKGROUND.value == colors[0]
                && Theme.FOREGROUND.value == colors[1]
                && Theme.PRIMARY.value == colors[2]
                && Theme.PRIMARY_FG.value == colors[3]
                && Theme.ACCENT.value == colors[4]
                && Theme.ACCENT_FG.value == colors[5]
                && Theme.SCROLL.value == colors[6];
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
