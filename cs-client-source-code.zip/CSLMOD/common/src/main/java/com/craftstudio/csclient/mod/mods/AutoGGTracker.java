package com.craftstudio.csclient.mod.mods;

import java.util.Locale;
import java.util.regex.Pattern;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;

/**
 * Local, anchored Auto GG detector. It intentionally has no downloaded trigger
 * lists and does not match broad words such as WINNER inside ordinary chat.
 * Supported-network result markers are adapted from ModLabs' MIT-licensed
 * AutoGG project, with CS delay, sanitization, and duplicate guards.
 */
public final class AutoGGTracker {
    private static final long DUPLICATE_GUARD_MS = 12_000L;

    private static final Pattern[] GAME_END_PATTERNS = {
            Pattern.compile("^VICTORY!?$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^GAME OVER!?$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^GAME (?:WON|LOST)!?$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^YOU (?:WIN|WON)!?$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^WINNER:\\s+.{1,48}$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^(?:1ST PLACE|#1)(?:\\s*[-:]\\s*.{1,64})?$", Pattern.CASE_INSENSITIVE)
    };

    /** Anchored to known end-of-match result lines; evaluated only for server system messages. */
    private static final String[] GAME_END_MARKERS = {
            "your overall winstreak:", "1st place -", "1st killer -", " - damage dealt -",
            "winning team -", "winners:", "winning team:", " won the game!",
            "top seeker:", "last team standing!", "winner #1 (", "top survivors",
            "sumo duel -", "most wool placed -", "the winning team is",
            "the match has ended!", "match results"
    };

    private static long pendingAtMs;
    private static long lastTriggerAtMs = Long.MIN_VALUE;

    private AutoGGTracker() { }

    /** Called by target-specific chat HUD hooks on Minecraft's client thread. */
    public static synchronized void onIncomingMessage(String rawMessage) {
        if (!AutoGGMod.isActive() || rawMessage == null || !isAllowedServer()) return;

        String message = normalize(rawMessage);
        if (!isAnchoredGameEnd(message)) return;

        long now = System.currentTimeMillis();
        if (pendingAtMs != 0L || elapsedSince(now, lastTriggerAtMs) < DUPLICATE_GUARD_MS) return;

        lastTriggerAtMs = now;
        pendingAtMs = now + AutoGGMod.delaySeconds() * 1_000L;
    }

    /** Runs from the normal enabled-module client tick; no background thread is created. */
    public static synchronized void tick() {
        if (pendingAtMs == 0L) return;
        if (!AutoGGMod.isActive()) {
            pendingAtMs = 0L;
            return;
        }

        long now = System.currentTimeMillis();
        if (now < pendingAtMs) return;
        pendingAtMs = 0L;

        if (!isAllowedServer()) return;
        MinecraftClientRef client = Providers.csClient == null ? null : Providers.csClient.getClient();
        if (client != null) client.sendChatMessage(AutoGGMod.safeMessage());
    }

    public static synchronized void cancelPending() {
        pendingAtMs = 0L;
    }

    public static boolean isAnchoredGameEnd(String message) {
        if (message == null || message.isEmpty() || message.length() > 160) return false;
        for (Pattern pattern : GAME_END_PATTERNS) {
            if (pattern.matcher(message).matches()) return true;
        }
        String normalized = message.toLowerCase(Locale.ROOT);
        for (String marker : GAME_END_MARKERS) {
            if (normalized.contains(marker)) return true;
        }
        return false;
    }

    private static boolean isAllowedServer() {
        if (!AutoGGMod.isHypixelOnly()) return true;
        MinecraftClientRef client = Providers.csClient == null ? null : Providers.csClient.getClient();
        return client != null && isSupportedNetworkAddress(client.getCurrentServerAddress());
    }

    static boolean isHypixelAddress(String address) {
        String host = normalizeHost(address);
        return host.equals("hypixel.net") || host.endsWith(".hypixel.net");
    }

    public static boolean isSupportedNetworkAddress(String address) {
        String host = normalizeHost(address);
        return host.equals("hypixel.net") || host.endsWith(".hypixel.net")
                || host.equals("bedwarspractice.club") || host.endsWith(".bedwarspractice.club")
                || host.equals("pvp.land") || host.endsWith(".pvp.land")
                || host.equals("minemen.club") || host.endsWith(".minemen.club")
                || host.equals("mineplex.com") || host.endsWith(".mineplex.com");
    }

    private static String normalizeHost(String address) {
        if (address == null) return "";
        String host = address.trim().toLowerCase(Locale.ROOT);
        int scheme = host.indexOf("://");
        if (scheme >= 0) host = host.substring(scheme + 3);
        int slash = host.indexOf('/');
        if (slash >= 0) host = host.substring(0, slash);
        int colon = host.lastIndexOf(':');
        if (colon > 0 && host.indexOf(':') == colon) host = host.substring(0, colon);
        return host;
    }

    private static String normalize(String message) {
        return message.replace('\r', ' ').replace('\n', ' ').trim().replaceAll("\\s+", " ");
    }

    private static long elapsedSince(long now, long then) {
        if (then == Long.MIN_VALUE || now < then) return Long.MAX_VALUE;
        return now - then;
    }
}
