package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/**
 * CoordinatesMod displays the player's current XYZ position as a
 * HUD element with multiple configurable display formats.
 */
public class CoordinatesMod extends Mod implements HudMod {

    private static final BoolProperty enabled = Property.bool(false);
    private static final SelectProperty displayMethod = Property.select(0,
            "Flat",
            "Flat annotated",
            "Newline",
            "Newline annotated");
    private static final ModLayout layout = new ModLayout(40, 18);
    private String cachedText;
    private long nextTextUpdate;
    private final com.craftstudio.csclient.mod.HudDirtyTracker dirtyTracker =
            new com.craftstudio.csclient.mod.HudDirtyTracker();

    public CoordinatesMod() {
        super(
                new ModSpec("Coordinates", "coords")
                        .description("Displays your current coordinates")
                        .version("v0.2.0")
                        .tags("Utility")
                        .requires(Providers.feature::player),
                enabled.named("Enabled"),
                displayMethod.named("Display Method"),
                layout.prop());
    }

    // ---------------------------------------------------------------
    // HudMod
    // ---------------------------------------------------------------

    @Override
    public void renderHud(RenderScope scope) {
        int interval = PerformanceBoostMod.hudRefreshIntervalMs();
        long now = System.currentTimeMillis();
        if (cachedText == null || interval == 0 || now >= nextTextUpdate) {
            cachedText = formatCoords(
                    Providers.feature.player().getX(),
                    Providers.feature.player().getY(),
                    Providers.feature.player().getZ());
            nextTextUpdate = now + interval;
        }
        // Frame skip: standing still means the coordinate text, colour and
        // position are unchanged — the previous frame already drew it.
        if (!dirtyTracker.dirty(cachedText, layout.fgColor.value, layout)) return;
        HudTextRenderer.draw(scope, layout, cachedText);
    }

    @Override
    public void renderDummy(RenderScope scope) {
        HudTextRenderer.draw(scope, layout, formatCoords(532, 69, 253));
    }

    // ---------------------------------------------------------------
    // Rendering
    // ---------------------------------------------------------------

    private String formatCoords(int x, int y, int z) {
        return switch (displayMethod.value) {
            case 1 -> "X: " + x + " Y: " + y + " Z: " + z;
            case 2 -> x + "\n" + y + "\n" + z;
            case 3 -> "X: " + x + "\nY: " + y + "\nZ: " + z;
            default -> x + " " + y + " " + z;
        };
    }

    // ---------------------------------------------------------------
    // Mod contract
    // ---------------------------------------------------------------

    @Override
    public ModLayout getDimensions() {
        return layout;
    }

    @Override
    public boolean isEnabled() {
        return enabled.value;
    }

    @Override
    public void onEnabled(boolean e) {
        enabled.value = e;
    }
}
