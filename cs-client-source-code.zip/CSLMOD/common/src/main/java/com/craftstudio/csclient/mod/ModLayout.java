package com.craftstudio.csclient.mod;

import java.util.Map;

import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.FloatProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.NamedProperty;

public class ModLayout {
    public IntProperty x = Property.integer(0);
    public IntProperty y = Property.integer(0);
    public FloatProperty scale = Property.floatProp(1.0f);
    // Feather/Lunar-style compact graphite chip defaults.
    public ColorProperty bgColor = Property.color(0xD914171B);
    public ColorProperty fgColor = Property.color(0xFFF0F2F4);
    public IntProperty radius = Property.integer(6);
    public SelectProperty font = Property.font(2);
    /** HUD shells are opt-in: clean text/metrics render without a panel by default. */
    public BoolProperty background = Property.bool(false);
    public SelectProperty style = Property.select(1,
            "Minecraft", "Feather Compact", "Lunar", "CS Graphite");
    public boolean renderBackground = true;

    public int width = 0;
    public int height = 0;

    public NamedProperty prop() {
        return Property.namespace(Map.of(
                "X", x,
                "Y", y,
                "Scale", scale,
                // New key intentionally drops the old always-ON default from existing V1 configs.
                "Show Background", background,
                "HUD Style", style,
                "Background Color", bgColor,
                "Foreground Color", fgColor,
                "Corner Radius", radius,
                "Font", font)).named("In-Game Display");
    }

    /** Hidden persistence for native adapters; movement is exposed only in HUD Layout. */
    public NamedProperty nativeHudProp(BoolProperty moved) {
        return Property.namespace(Map.of(
                "X", x,
                "Y", y,
                "Moved From Vanilla Position", moved)).named("In-Game Display");
    }

    public NamedProperty nativeHudProp() {
        return Property.namespace(Map.of("X", x, "Y", y)).named("In-Game Display");
    }

    public boolean shouldRenderBackground() {
        return renderBackground && background.value;
    }

    public int effectiveRadius() {
        return switch (style.value) {
            case 0 -> 0; // Minecraft
            case 2 -> Math.min(4, radius.value); // Lunar
            case 3 -> Math.max(6, radius.value); // CS Graphite
            default -> radius.value; // Feather Compact
        };
    }

    public int effectiveBackgroundColor() {
        return switch (style.value) {
            case 0 -> (bgColor.value & 0x00FFFFFF) | 0x90000000;
            case 2 -> (bgColor.value & 0x00FFFFFF) | 0xC4000000;
            case 3 -> (bgColor.value & 0x00FFFFFF) | 0xEA000000;
            default -> bgColor.value;
        };
    }

    public ModLayout() {
    }

    public ModLayout(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public ModLayout(int x, int y, int width, int height) {
        this.x.value = x;
        this.y.value = y;
        this.width = width;
        this.height = height;
    }

    public ModLayout(int x, int y, int width, int height, float scale) {
        this.x.value = x;
        this.y.value = y;
        this.scale.value = scale;
        this.width = width;
        this.height = height;
    }
}
