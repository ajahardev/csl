package com.craftstudio.csclient.ui.screens;

import java.awt.Color;
import java.util.function.IntConsumer;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.elements.Button;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.elements.TextFieldElement;
import com.craftstudio.csclient.ui.resources.Textures;

/** Dedicated color editor that is never clipped by a settings scroll viewport. */
public class ColorPickerScreen extends CSClientScreen {
    private final ColorProperty property;
    private final CSClientScreen parent;
    private final String settingName;
    private final int originalColor;
    private ColorCanvas canvas;
    private TextFieldElement hexField;
    private boolean syncingHex;

    public ColorPickerScreen(ColorProperty property, CSClientScreen parent, String settingName) {
        super("Color Editor");
        this.property = property;
        this.parent = parent;
        this.settingName = settingName;
        this.originalColor = property.value;
    }

    @Override
    public void ui() {
        backgroundBlur = 7;
        int panelWidth = Math.min(760, width - 32);
        int panelHeight = Math.min(456, height - 28);
        int panelX = (width - panelWidth) / 2;
        int panelY = (height - panelHeight) / 2;

        draw(new Panel(0xF0101419).dimensions(panelWidth, panelHeight).position(panelX, panelY));
        draw(new IconButton(Textures.BACK, this::applyAndBack).position(panelX + 16, panelY + 15));
        draw(new Text("COLOR STUDIO").scale(0.84f).position(panelX + 70, panelY + 18));
        draw(new Text(settingName.toUpperCase() + "  •  LIVE PREVIEW")
                .scale(0.34f).position(panelX + 71, panelY + 48));

        canvas = new ColorCanvas(property, this::syncHex);
        canvas.dimensions(panelWidth - 32, panelHeight - 126).position(panelX + 16, panelY + 72);
        draw(canvas);

        hexField = new TextFieldElement("#AARRGGBB", 9,
                c -> c == '#' || Character.digit(c, 16) >= 0,
                this::applyHex, this::applyAndBack, null);
        hexField.dimensions(176, 36).position(panelX + panelWidth - 192, panelY + 17);
        syncingHex = true;
        hexField.setValue(String.format("#%08X", property.value));
        syncingHex = false;
        draw(hexField);

        int buttonY = panelY + panelHeight - 45;
        draw(new Button("RESET", this::resetColor).dimensions(112, 34).position(panelX + 16, buttonY));
        draw(new Button("CANCEL", this::cancelAndBack).dimensions(124, 34)
                .position(panelX + panelWidth - 266, buttonY));
        draw(new Button("APPLY", this::applyAndBack).dimensions(124, 34)
                .position(panelX + panelWidth - 130, buttonY));
    }

    private void applyHex(String text) {
        if (syncingHex || text == null) return;
        String clean = text.trim();
        if (clean.length() != 7 && clean.length() != 9) return;
        try {
            property.value = ColorProperty.parseHexToInt(clean);
            if (canvas != null) canvas.syncFromColor();
        } catch (IllegalArgumentException ignored) {
        }
    }

    private void syncHex(int color) {
        if (hexField == null || hexField.focused) return;
        syncingHex = true;
        hexField.setValue(String.format("#%08X", color));
        syncingHex = false;
    }

    private void resetColor() {
        property.value = property.defaultValue;
        if (canvas != null) canvas.syncFromColor();
        syncHex(property.value);
    }

    private void applyAndBack() {
        ConfigManager.save();
        Providers.csClient.getClient().setScreen(parent);
    }

    private void cancelAndBack() {
        property.value = originalColor;
        Providers.csClient.getClient().setScreen(parent);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            applyAndBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private static final class ColorCanvas extends Element {
        private static final int SV_X = 14;
        private static final int SV_Y = 16;
        private static final int HUE_GAP = 16;
        private static final int HUE_W = 24;
        private static final int ALPHA_H = 14;
        private static final int[] PRESETS = {
                0xFFFFFFFF, 0xFF9AA1AA, 0xFF181B20, 0xFF0B0D10,
                0xFFFF5F6D, 0xFFFFA94D, 0xFFFFD43B, 0xFF69DB7C,
                0xFF38D9A9, 0xFF4DABF7, 0xFF748FFC, 0xFFDA77F2
        };

        private final ColorProperty property;
        private final IntConsumer onChange;
        private float hue;
        private float saturation;
        private float value;
        private float alpha;
        private int dragMode;

        private ColorCanvas(ColorProperty property, IntConsumer onChange) {
            this.property = property;
            this.onChange = onChange;
            syncFromColor();
        }

        @Override
        public void render(RenderScope scope, ElementContext ctx) {
            int svWidth = Math.max(260, width - 250);
            int svHeight = Math.max(150, height - 82);
            int hueX = SV_X + svWidth + HUE_GAP;
            int presetX = hueX + HUE_W + 28;
            int baseHue = 0xFF000000 | (Color.HSBtoRGB(hue, 1f, 1f) & 0xFFFFFF);

            scope.drawRoundedRectangle(SV_X - 5, SV_Y - 5, svWidth + 10, svHeight + 10, 11, 0xE8171C22);
            scope.drawRectangle(SV_X, SV_Y, svWidth, svHeight, baseHue);
            scope.drawTexture(Textures.PICKER_SV_WHITE, SV_X, SV_Y, 0, 0, svWidth, svHeight);
            scope.drawTexture(Textures.PICKER_SV_BLACK, SV_X, SV_Y, 0, 0, svWidth, svHeight);

            int markerX = SV_X + Math.round(saturation * svWidth);
            int markerY = SV_Y + Math.round((1f - value) * svHeight);
            scope.drawBorder(markerX - 5, markerY - 5, 10, 10, 0xFF000000);
            scope.drawBorder(markerX - 4, markerY - 4, 8, 8, 0xFFFFFFFF);

            scope.drawRoundedRectangle(hueX - 4, SV_Y - 4, HUE_W + 8, svHeight + 8, 8, 0xE8171C22);
            scope.drawTexture(Textures.PICKER_HUE, hueX, SV_Y, 0, 0, HUE_W, svHeight);
            int hueY = SV_Y + Math.round(hue * svHeight);
            scope.drawRectangle(hueX - 4, hueY - 2, HUE_W + 8, 4, 0xFFFFFFFF);
            scope.drawRectangle(hueX - 3, hueY - 1, HUE_W + 6, 2, 0xFF0B0D10);

            int alphaY = SV_Y + svHeight + 20;
            scope.drawTexture(Textures.PICKER_CHECKER, SV_X, alphaY, 0, 0, svWidth, ALPHA_H);
            int rgb = 0xFF000000 | (property.value & 0xFFFFFF);
            scope.drawTexture(Textures.PICKER_ALPHA, SV_X, alphaY, 0, 0, svWidth, ALPHA_H, rgb);
            int alphaX = SV_X + Math.round(alpha * svWidth);
            scope.drawRectangle(alphaX - 2, alphaY - 3, 4, ALPHA_H + 6, 0xFFFFFFFF);
            scope.drawRectangle(alphaX - 1, alphaY - 2, 2, ALPHA_H + 4, 0xFF0B0D10);

            scope.drawText(0.36f, "SATURATION / VALUE", SV_X, 1, Theme.FONT.value,
                    Theme.withAlpha(165, Theme.PRIMARY_FG.value));
            scope.drawText(0.36f, "ALPHA", SV_X, alphaY + 24, Theme.FONT.value,
                    Theme.withAlpha(165, Theme.PRIMARY_FG.value));
            scope.drawText(0.36f, "PRESETS", presetX, 1, Theme.FONT.value,
                    Theme.withAlpha(165, Theme.PRIMARY_FG.value));

            int swatch = 34;
            int gap = 10;
            int presetColumns = width < 600 ? 2 : 3;
            int presetCount = width < 600 ? 8 : PRESETS.length;
            for (int i = 0; i < presetCount; i++) {
                int x = presetX + (i % presetColumns) * (swatch + gap);
                int y = SV_Y + (i / presetColumns) * (swatch + gap);
                scope.drawRoundedRectangle(x, y, swatch, swatch, 9, PRESETS[i]);
                scope.drawRoundedBorder(x, y, swatch, swatch, 9,
                        (property.value & 0xFFFFFF) == (PRESETS[i] & 0xFFFFFF) ? 0xFFFFFFFF : 0x55FFFFFF);
            }

            int presetRows = (presetCount + presetColumns - 1) / presetColumns;
            int previewY = SV_Y + presetRows * (swatch + gap) + 8;
            int previewWidth = presetColumns * swatch + (presetColumns - 1) * gap;
            if (previewY + 42 <= height) {
                scope.drawRoundedRectangle(presetX, previewY, previewWidth, 42, 11, property.value);
                scope.drawRoundedBorder(presetX, previewY, previewWidth, 42, 11, 0x77FFFFFF);
            }
        }

        @Override
        public void mouseClicked(double mouseX, double mouseY, int button) {
            if (button != 0) return;
            dragMode = hitMode(mouseX, mouseY);
            updateFromPointer(mouseX, mouseY);
        }

        @Override
        public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
            if (button == 0 && dragMode != 0) updateFromPointer(mouseX, mouseY);
        }

        @Override
        public void mouseReleased(double mouseX, double mouseY, int button) {
            dragMode = 0;
        }

        @Override
        public void click(int mouseX, int mouseY) {
            int svWidth = Math.max(260, width - 250);
            int svHeight = Math.max(150, height - 82);
            int hueX = SV_X + svWidth + HUE_GAP;
            int presetX = hueX + HUE_W + 28;
            int swatch = 34;
            int gap = 10;
            int presetColumns = width < 600 ? 2 : 3;
            int presetCount = width < 600 ? 8 : PRESETS.length;
            for (int i = 0; i < presetCount; i++) {
                int x = presetX + (i % presetColumns) * (swatch + gap);
                int y = SV_Y + (i / presetColumns) * (swatch + gap);
                if (mouseX >= x && mouseX <= x + swatch && mouseY >= y && mouseY <= y + swatch) {
                    property.value = PRESETS[i];
                    syncFromColor();
                    changed();
                    return;
                }
            }
        }

        private int hitMode(double mouseX, double mouseY) {
            int svWidth = Math.max(260, width - 250);
            int svHeight = Math.max(150, height - 82);
            int hueX = SV_X + svWidth + HUE_GAP;
            int alphaY = SV_Y + svHeight + 20;
            if (mouseX >= SV_X && mouseX <= SV_X + svWidth && mouseY >= SV_Y && mouseY <= SV_Y + svHeight) return 1;
            if (mouseX >= hueX - 5 && mouseX <= hueX + HUE_W + 5 && mouseY >= SV_Y && mouseY <= SV_Y + svHeight) return 2;
            if (mouseX >= SV_X && mouseX <= SV_X + svWidth && mouseY >= alphaY - 5 && mouseY <= alphaY + ALPHA_H + 5) return 3;
            return 0;
        }

        private void updateFromPointer(double mouseX, double mouseY) {
            int svWidth = Math.max(260, width - 250);
            int svHeight = Math.max(150, height - 82);
            int alphaY = SV_Y + svHeight + 20;
            if (dragMode == 1) {
                saturation = clamp((float) ((mouseX - SV_X) / svWidth));
                value = 1f - clamp((float) ((mouseY - SV_Y) / svHeight));
            } else if (dragMode == 2) {
                hue = clamp((float) ((mouseY - SV_Y) / svHeight));
            } else if (dragMode == 3) {
                alpha = clamp((float) ((mouseX - SV_X) / svWidth));
            } else return;
            int rgb = Color.HSBtoRGB(hue, saturation, value) & 0xFFFFFF;
            property.value = (Math.round(alpha * 255f) << 24) | rgb;
            changed();
        }

        private void syncFromColor() {
            int color = property.value;
            float[] hsb = Color.RGBtoHSB((color >> 16) & 255, (color >> 8) & 255, color & 255, null);
            hue = hsb[0];
            saturation = hsb[1];
            value = hsb[2];
            alpha = ((color >>> 24) & 255) / 255f;
        }

        private void changed() {
            if (onChange != null) onChange.accept(property.value);
        }

        private static float clamp(float value) {
            return Math.max(0f, Math.min(1f, value));
        }
    }
}
