package com.craftstudio.csclient.ui;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.common.ref.render.MatrixStackRef;
import com.craftstudio.csclient.ui.resources.SvgTexture;

public interface RenderScope {

    // ----------------------------
    // Matrix & Transform
    // ----------------------------
    MatrixStackRef getMatrixStack();

    // ----------------------------
    // Color & Opacity
    // ----------------------------
    void setOpacity(float alpha);

    int getColor(int color);

    // ----------------------------
    // Shapes
    // ----------------------------
    void drawRectangle(int x, int y, int width, int height, int color);

    default void drawRoundedRectangle(int x, int y, int width, int height, int radius, int color) {
        if (color == 0 || width < 1 || height < 1) return;
        IdentifierRef texture = SvgTexture.getRoundedShape(width, height, radius, false);
        if (texture != null) drawTexture(texture, x, y, 0, 0, width, height, color);
    }

    void drawBorder(int x, int y, int width, int height, int color);

    /** Cached SVG ring: rounded outline without painting over the transparent interior. */
    default void drawRoundedBorder(int x, int y, int width, int height, int radius, int color) {
        if (color == 0 || width < 3 || height < 3) return;
        IdentifierRef texture = SvgTexture.getRoundedShape(width, height, radius, true);
        if (texture != null) drawTexture(texture, x, y, 0, 0, width, height, color);
    }

    void fill(int x1, int y1, int x2, int y2, int color);

    // ----------------------------
    // Text
    // ----------------------------
    void drawText(String text, int x, int y, int font, int color);

    void drawText(float scale, String text, int x, int y, int font, int color);

    // ----------------------------
    // Textures & Sprites
    // ----------------------------
    void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height);

    void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height, int color);

    void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height,
            int regionWidth, int regionHeight, int textureWidth, int textureHeight);

    void drawTexture(IdentifierRef sprite, int x, int y, float u, float v, int width, int height,
            int regionWidth, int regionHeight, int textureWidth, int textureHeight, int color);

    void drawSpriteStretched(SpriteRef sprite, int x, int y, int width, int height);

    void drawSpriteStretched(SpriteRef sprite, int x, int y, int width, int height, int color);

    // ----------------------------
    // Items
    // ----------------------------
    void drawItem(ItemStackRef item, int x, int y);

    // ----------------------------
    // Scissor / Clipping
    // ----------------------------
    void enableScissor(int x1, int y1, int x2, int y2);

    void disableScissor();

    boolean scissorContains(int x, int y);

    // ----------------------------
    // Window Info / Draw
    // ----------------------------
    int getScaledWindowWidth();

    int getScaledWindowHeight();

    void draw();
}