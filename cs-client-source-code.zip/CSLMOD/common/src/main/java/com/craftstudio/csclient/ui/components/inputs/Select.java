package com.craftstudio.csclient.ui.components.inputs;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.Utils;
import com.craftstudio.csclient.ui.resources.Fonts;

public class Select extends Element {
    private final SelectProperty prop;
    private float hover;

    public Select(SelectProperty prop) {
        this.prop = prop;
        this.width = 190;
        this.height = 30;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.2f;
        scope.drawRoundedRectangle(0, 0, width, height, 10,
                hover > 0.2f ? 0xF020272F : 0xE7181D23);
        scope.drawRoundedBorder(0, 0, width, height, 10,
                Theme.withAlpha(80 + Math.round(100 * hover), Theme.ACCENT.value));
        scope.drawRoundedRectangle(3, 3, 31, 24, 8, Theme.withAlpha(150, Theme.PRIMARY.value));
        scope.drawRoundedRectangle(width - 34, 3, 31, 24, 8, Theme.withAlpha(150, Theme.PRIMARY.value));
        scope.drawText(0.64f, "‹", 14, 8, Theme.FONT.value, Theme.PRIMARY_FG.value);
        scope.drawText(0.64f, "›", width - 23, 8, Theme.FONT.value, Theme.PRIMARY_FG.value);

        String text = prop.getSelection();
        float scale = 0.48f;
        scope.drawText(scale, text,
                (width - (int) (Fonts.getWidth(text, Theme.FONT.value) * scale)) / 2,
                11, Theme.FONT.value, Theme.FOREGROUND.value);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (Utils.isHovering(mouseX - (width - 36), mouseY, 36, height, 1f)) prop.next();
        else if (Utils.isHovering(mouseX, mouseY, 36, height, 1f)) prop.prev();
    }
}
