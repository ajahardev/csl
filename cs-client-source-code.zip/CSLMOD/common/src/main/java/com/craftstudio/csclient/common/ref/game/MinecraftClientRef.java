package com.craftstudio.csclient.common.ref.game;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.UUID;
import java.util.List;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.render.WindowRef;
import com.craftstudio.csclient.ui.CSClientScreen;

public interface MinecraftClientRef {
    record LoadedModInfo(String id, String name, String version) { }

    enum MinecraftScreen {
        SelectWorld,
        Multiplayer,
        Options,
        Disconnect
    }

    File getRunDirectory();
    InputStream getResource(IdentifierRef identifier);
    WindowRef getWindow();
    void setScreen(CSClientScreen screen);
    void setScreen(MinecraftScreen screen);
    UUID getUuid();
    String getUsername();

    /**
     * Best-effort display classification for launcher-provided offline profiles.
     * Local appearance eligibility does not depend on this heuristic, and no
     * credential content is stored, logged, or transmitted.
     */
    default boolean isLauncherOfflineProfile() { return false; }

    void onClientStopping(Runnable handler);
    void scheduleStop();
    void executeOnThread(Runnable runnable);

    default String getClipboardText() { return ""; }
    default void setClipboardText(String text) { }

    /** Registers validated local skin/cape PNGs on Minecraft's render thread. Null keeps that part original. */
    default boolean applyLocalAppearance(Path skinPng, Path capePng, String model) { return false; }
    default boolean applyLocalSkin(Path png, String model) { return applyLocalAppearance(png, null, model); }
    default void resetLocalSkin() { }

    /** Current effective body texture, including a CS local override, for profile-head UI. */
    default IdentifierRef getActiveSkinTexture() { return null; }

    /** Opens the platform-native PNG chooser asynchronously. Null means cancel/unavailable. */
    default boolean openNativePngPicker(String title, java.util.function.Consumer<Path> result) { return false; }

    /** Opens only an allowlisted external HTTPS link after an explicit UI click. */
    default boolean openExternalUrl(String url) { return false; }

    /**
     * Explicitly joins the one hard-coded Home featured-server slot. Target
     * adapters validate the exact address; no arbitrary server field, list,
     * ping, or background connection is exposed by common UI.
     */
    default boolean joinFeaturedServer() { return false; }

    /** Sends a normal player chat message; command strings are rejected by callers. */
    default boolean sendChatMessage(String message) { return false; }

    /** Current multiplayer address only; blank for title screen and local worlds. */
    default String getCurrentServerAddress() { return ""; }

    /** Switches to a password-free local profile while on the title screen. */
    default boolean switchLocalAccount(String username, UUID uuid) { return false; }

    default boolean isModLoaded(String modId) { return false; }

    /** Mod Menu's own displayed count, respecting its library/child preferences. */
    default String getExternalModCount() { return ""; }

    /** Opens the optional Mod Menu screen while preserving the current parent. */
    default void openExternalModMenu() { }

    /** The currently displayed screen (any vanilla/mod screen object). */
    default Object currentScreen() { return null; }

    /**
     * Displays an arbitrary vanilla/mod screen object as-is (e.g. Replay
     * Mod's native menu). CS does not wrap or restyle it.
     */
    default boolean openNativeScreen(Object screen) { return false; }

    /** Fallback list shown when the optional Mod Menu mod is absent. */
    default List<LoadedModInfo> getLoadedMods() { return List.of(); }

    /** Minecraft-native Friends UI where the target provides it. */
    default boolean supportsNativeFriends() { return false; }
    default boolean openNativeFriends(CSClientScreen parent) { return false; }

    /**
     * Opens the target's vanilla integrated-world LAN screen. LAN stays purely
     * local; no internet relay/world-hosting system is bundled any more.
     */
    default boolean canOpenNativeWorldHost() { return false; }
    default boolean openNativeWorldHost(CSClientScreen parent) { return false; }

    String getPlayerListEntry(UUID uuid);
    UUID getPlayerListEntryUUID(String name);
}
