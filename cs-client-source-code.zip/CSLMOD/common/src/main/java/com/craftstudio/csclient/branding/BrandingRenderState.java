package com.craftstudio.csclient.branding;

/** Tiny render-state bridge; no network/cache lookup is performed during submission. */
public interface BrandingRenderState {
    boolean csclient$showBrandLogo();
    void csclient$setShowBrandLogo(boolean show);
}
