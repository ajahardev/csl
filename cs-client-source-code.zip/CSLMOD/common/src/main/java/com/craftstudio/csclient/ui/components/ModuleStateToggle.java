package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Compact header-level module state control with a large touch target. */
public class ModuleStateToggle extends Element {
    private final Mod mod;
    private float progress;
    private float hover;

    public ModuleStateToggle(Mod mod) {
        this.mod = mod;
        this.progress = mod.isEnabled() ? 1f : 0f;
        dimensions(112, 38);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = mod.isEnabled() ? 1f : 0f;
        progress += (target - progress) * 0.24f;
        float hoverTarget = ctx.isHovering() ? 1f : 0f;
        hover += (hoverTarget - hover) * 0.24f;

        int fill = blend(0xE4161B21, Theme.ACCENT.value, progress);
        int outline = blend(Theme.withAlpha(95, Theme.PRIMARY_FG.value), 0xFFF4F6F8, hover);
        int foreground = blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, progress);
        scope.drawRoundedRectangle(0, 0, width, height, 6, fill);
        scope.drawRoundedBorder(0, 0, width, height, 6, outline);

        scope.drawText(0.39f, mod.isEnabled() ? "ENABLED" : "DISABLED", 10, 15,
                Theme.FONT.value, foreground);

        int trackX = width - 38;
        scope.drawRoundedRectangle(trackX, 10, 28, 18, 6,
                blend(0xFF303841, Theme.withAlpha(180, Theme.ACCENT_FG.value), progress));
        int knobX = trackX + 3 + Math.round(progress * 10f);
        scope.drawRoundedRectangle(knobX, 13, 12, 12, 4,
                blend(0xFF9AA2AB, Theme.ACCENT_FG.value, progress));

        if (hover > 0.03f) {
            scope.drawRectangle(10, height - 2, Math.round((width - 20) * hover), 1,
                    Theme.withAlpha(Math.round(220 * hover), Theme.ACCENT.value));
        }
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (mod.isToggleable()) mod.setEnabled(!mod.isEnabled());
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
