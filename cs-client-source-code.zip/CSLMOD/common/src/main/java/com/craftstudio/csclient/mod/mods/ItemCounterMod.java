package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Selected-item inventory counter with a live item icon. */
public class ItemCounterMod extends Mod implements HudMod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty showName = Property.bool(false);
    private static final ModLayout layout = new ModLayout(74, 22);

    public ItemCounterMod() {
        super(new ModSpec("Item Counter", "itemcounter")
                        .description("Counts the selected item across your inventory")
                        .version("v1.0.0").tags("HUD", "Utility")
                        .requires(Providers.feature::player),
                enabled.named("Enabled"), showName.named("Show item name"), layout.prop());
    }

    @Override public boolean shouldRenderHud() { return !Providers.feature.player().getMainHand().isEmpty(); }

    @Override public void renderHud(RenderScope scope) {
        draw(scope, Providers.feature.player().getMainHand(),
                Providers.feature.player().getSelectedItemTotalCount());
    }

    @Override public void renderDummy(RenderScope scope) {
        draw(scope, Providers.feature.player().getDummyMainHand(), 64);
    }

    private void draw(RenderScope scope, ItemStackRef stack, int count) {
        if (!stack.isEmpty()) scope.drawItem(stack, 4, 3);
        String text = showName.value ? stack.getItemName() + "  ×" + count : "ITEMS  ×" + count;
        scope.drawText(0.48f, text, 25, 6, layout.font.value, layout.fgColor.value);
        layout.width = Math.max(68, 31 + (int) (Fonts.getWidth(text, layout.font.value) * 0.48f));
        layout.height = 22;
    }

    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
