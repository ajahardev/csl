package com.craftstudio.csclient.screenshot;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import com.craftstudio.csclient.common.provider.Providers;

/** Sandboxed access to only the active profile's direct screenshots directory. */
public final class ScreenshotRepository {
    public static final int MAX_VISIBLE = 5000;
    public static final long MAX_IMAGE_BYTES = 64L * 1024L * 1024L;

    public record Entry(Path path, String name, long modifiedMillis, long bytes) { }

    private ScreenshotRepository() { }

    public static Path directory() {
        return Providers.csClient.getClient().getRunDirectory().toPath().toAbsolutePath().normalize()
                .resolve("screenshots").normalize();
    }

    public static List<Entry> list() {
        Path directory = directory();
        try {
            Files.createDirectories(directory);
            try (Stream<Path> stream = Files.list(directory)) {
                return stream.filter(ScreenshotRepository::isSafePng)
                        .map(path -> {
                            try {
                                return new Entry(path.toAbsolutePath().normalize(), path.getFileName().toString(),
                                        Files.getLastModifiedTime(path, LinkOption.NOFOLLOW_LINKS).toMillis(),
                                        Files.size(path));
                            } catch (IOException ignored) {
                                return null;
                            }
                        })
                        .filter(entry -> entry != null && entry.bytes() > 0 && entry.bytes() <= MAX_IMAGE_BYTES)
                        .sorted(Comparator.comparingLong(Entry::modifiedMillis).reversed()
                                .thenComparing(Entry::name, String.CASE_INSENSITIVE_ORDER))
                        .limit(MAX_VISIBLE)
                        .toList();
            }
        } catch (IOException error) {
            if (Providers.csClient != null) Providers.csClient.logError("Unable to list profile screenshots", error);
            return List.of();
        }
    }

    public static boolean delete(Path path) {
        if (!isSafePng(path)) return false;
        try {
            return Files.deleteIfExists(path.toAbsolutePath().normalize());
        } catch (IOException error) {
            if (Providers.csClient != null) Providers.csClient.logError("Unable to delete screenshot", error);
            return false;
        }
    }

    public static boolean isSafePng(Path path) {
        if (path == null) return false;
        try {
            Path normalized = path.toAbsolutePath().normalize();
            Path root = directory();
            if (!normalized.getParent().equals(root)
                    || !normalized.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png")) {
                return false;
            }
            return Files.isRegularFile(normalized, LinkOption.NOFOLLOW_LINKS)
                    && !Files.isSymbolicLink(normalized);
        } catch (RuntimeException ignored) {
            return false;
        }
    }
}
