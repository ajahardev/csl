package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** A genuinely translucent rounded glass surface with a rounded outline. */
public class GlassPanel extends Element {
    private final int fill;
    private final int outline;
    private final int radius;

    public GlassPanel(int fill, int outline, int radius) {
        this.fill = fill;
        this.outline = outline;
        this.radius = radius;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        scope.drawRoundedRectangle(0, 0, width, height, radius, fill);
        scope.drawRoundedBorder(0, 0, width, height, radius, outline);
    }
}
