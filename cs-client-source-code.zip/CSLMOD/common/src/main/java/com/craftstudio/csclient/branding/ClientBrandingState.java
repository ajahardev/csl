package com.craftstudio.csclient.branding;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Immutable-snapshot capability cache; render reads perform no allocation. */
public final class ClientBrandingState {
    public static final int PROTOCOL_VERSION = 1;

    public enum Capability { UNKNOWN, CS_CLIENT, NON_CS_CLIENT }

    private static volatile Map<UUID, Capability> capabilities = Map.of();
    private static volatile boolean bridgeAvailable;

    private ClientBrandingState() { }

    public static Capability capability(UUID uuid) {
        if (uuid == null) return Capability.UNKNOWN;
        return capabilities.getOrDefault(uuid, Capability.UNKNOWN);
    }

    public static boolean isCsClient(UUID uuid) { return capability(uuid) == Capability.CS_CLIENT; }
    public static boolean isBridgeAvailable() { return bridgeAvailable; }

    public static synchronized void setBridgeAvailable(boolean available) {
        bridgeAvailable = available;
        if (!available) capabilities = Map.of();
    }

    public static synchronized void update(UUID uuid, boolean csClient) {
        if (uuid == null) return;
        Map<UUID, Capability> next = new HashMap<>(capabilities);
        next.put(uuid, csClient ? Capability.CS_CLIENT : Capability.NON_CS_CLIENT);
        capabilities = Map.copyOf(next);
    }

    public static synchronized void remove(UUID uuid) {
        if (uuid == null || !capabilities.containsKey(uuid)) return;
        Map<UUID, Capability> next = new HashMap<>(capabilities);
        next.remove(uuid);
        capabilities = Map.copyOf(next);
    }

    public static synchronized void clear() {
        capabilities = Map.of();
        bridgeAvailable = false;
    }

    public static int cachedPlayers() { return capabilities.size(); }
}
