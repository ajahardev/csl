package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.HudDirtyTracker;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/**
 * Feather/Lunar-style armor status HUD.
 *
 * Shows the real equipped pieces (helmet, chestplate, leggings, boots) with
 * vanilla-accurate item icons, colour-coded durability and a low-durability
 * alert. Optional main-hand and offhand slots let PvP players keep their
 * weapon and shield state visible without opening the inventory.
 */
public class ArmorDisplayMod extends Mod implements HudMod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty SHOW_MAIN_HAND = Property.bool(false);
    private static final BoolProperty SHOW_OFFHAND = Property.bool(false);
    private static final SelectProperty DURABILITY_MODE = Property.select(0,
            "Bar", "Numeric", "Percentage", "Off");
    private static final BoolProperty SHOW_EMPTY = Property.bool(true);
    private static final BoolProperty LOW_ALERT = Property.bool(true);
    private static final IntProperty SPACING = Property.integer(4);
    private static final SelectProperty ORIENTATION = Property.select(0, "Horizontal", "Vertical");
    private static final ModLayout LAYOUT = createLayout();

    private static final int SLOT = 22;
    private static final String[] ARMOR_LABELS = { "H", "C", "L", "B" };

    private final HudDirtyTracker dirtyTracker = new HudDirtyTracker();

    public ArmorDisplayMod() {
        super(new ModSpec("Armor Display", "armor")
                        .description("Feather/Lunar-style armor status with durability, offhand and main hand")
                        .version("v5.0.0").tags("Utility", "HUD", "PvP")
                        .requires(Providers.feature::player),
                ENABLED.named("Enabled"),
                SHOW_MAIN_HAND.named("Show Main Hand"),
                SHOW_OFFHAND.named("Show Offhand"),
                DURABILITY_MODE.named("Durability Display"),
                SHOW_EMPTY.named("Show Empty Slots"),
                LOW_ALERT.named("Low Durability Alert"),
                SPACING.named("Slot Spacing"),
                ORIENTATION.named("Layout Direction"),
                LAYOUT.prop());
    }

    private static ModLayout createLayout() {
        ModLayout layout = new ModLayout(120, 32);
        layout.bgColor.value = 0xB90B0F13;
        layout.radius.value = 7;
        return layout;
    }

    @Override public void renderHud(RenderScope scope) {
        PlayerFeature p = Providers.feature.player();
        draw(scope, p.getMainHand(), p.getHelmet(), p.getChestplate(), p.getLeggings(),
                p.getBoots(), p.getOffHand());
    }

    @Override public void renderDummy(RenderScope scope) {
        PlayerFeature p = Providers.feature.player();
        draw(scope, p.getDummyMainHand(), p.getDummyHelmet(), p.getDummyChestplate(),
                p.getDummyLeggings(), p.getDummyBoots(), p.getDummyOffHand());
    }

    @Override public void renderEditor(RenderScope scope) {
        if (Providers.feature.player().hasPlayer()) renderHud(scope);
        else renderDummy(scope);
    }

    private void draw(RenderScope scope, ItemStackRef hand, ItemStackRef helmet,
            ItemStackRef chest, ItemStackRef legs, ItemStackRef boots, ItemStackRef offhand) {
        boolean showMain = SHOW_MAIN_HAND.value;
        boolean showOff = SHOW_OFFHAND.value;
        int count = 4 + (showMain ? 1 : 0) + (showOff ? 1 : 0);
        int spacing = Math.max(0, Math.min(16, SPACING.value));
        boolean vertical = ORIENTATION.value == 1;
        LAYOUT.width = vertical ? 32 : 8 + count * SLOT + (count - 1) * spacing;
        LAYOUT.height = vertical ? 8 + count * SLOT + (count - 1) * spacing : 32;

        // One compact content key per frame: item identity + damage of every
        // visible slot. Unchanged gear + unchanged alert state skips the pass.
        StringBuilder key = new StringBuilder(64);
        key.append(showMain ? 'm' : '-').append(showOff ? 'o' : '-')
           .append(DURABILITY_MODE.value).append('|');
        key.append(slotKey(hand)).append(slotKey(helmet)).append(slotKey(chest))
           .append(slotKey(legs)).append(slotKey(boots)).append(slotKey(offhand));
        boolean alertOn = LOW_ALERT.value && anyLowDurability(hand, helmet, chest, legs, boots, offhand);
        key.append(alertOn ? "!a" : "!n");
        if (alertOn) {
            // The low-durability "!" pulses, so it animates every frame while active.
            dirtyTracker.invalidate();
        } else if (!dirtyTracker.dirty(key.toString(), LAYOUT.fgColor.value, LAYOUT)) {
            return;
        }

        int index = 0;
        if (showMain) index = drawSlot(scope, hand, "M", index, vertical, spacing) + 1;
        ItemStackRef[] pieces = { helmet, chest, legs, boots };
        for (int i = 0; i < pieces.length; i++) {
            index = drawSlot(scope, pieces[i], ARMOR_LABELS[i], index, vertical, spacing) + 1;
        }
        if (showOff) drawSlot(scope, offhand, "O", index, vertical, spacing);
    }

    private static String slotKey(ItemStackRef stack) {
        if (stack == null || stack.isEmpty()) return "0";
        return stack.getItemName() + "/" + stack.getDamage();
    }

    private static boolean anyLowDurability(ItemStackRef... stacks) {
        for (ItemStackRef stack : stacks) {
            if (stack != null && !stack.isEmpty() && isLow(stack)) return true;
        }
        return false;
    }

    private static boolean isLow(ItemStackRef stack) {
        int max = stack.getMaxDamage();
        if (max <= 0) return false;
        int remaining = max - stack.getDamage();
        return remaining <= 10 || remaining * 100 <= max * 5;
    }

    /** Draws one slot; returns its index. */
    private int drawSlot(RenderScope scope, ItemStackRef stack, String label,
            int index, boolean vertical, int spacing) {
        int x = 5 + (vertical ? 0 : index * (SLOT + spacing));
        int y = 5 + (vertical ? index * (SLOT + spacing) : 0);
        boolean empty = stack == null || stack.isEmpty();
        if (empty && !SHOW_EMPTY.value) return index;

        scope.drawRoundedRectangle(x, y, 20, 20, 5, empty ? 0x9610161C : 0xB91A2027);
        scope.drawRoundedBorder(x, y, 20, 20, 5, empty ? 0x446F7881 : 0x779AA1AA);
        if (!empty) {
            scope.drawItem(stack, x + 2, y + 2);
        } else {
            scope.drawText(0.38f, label, x + 7, y + 8,
                    LAYOUT.font.value, com.craftstudio.csclient.config.Theme.withAlpha(100,
                            com.craftstudio.csclient.config.Theme.PRIMARY_FG.value));
        }

        if (!empty && DURABILITY_MODE.value != 3 && stack.getMaxDamage() > 0) {
            int max = stack.getMaxDamage();
            int remaining = Math.max(0, max - stack.getDamage());
            float left = remaining / (float) max;
            int color = durabilityColor(left);
            switch (DURABILITY_MODE.value) {
                case 1 -> scope.drawText(0.30f, remaining + "/" + max, x + 1, y + 16,
                        LAYOUT.font.value, color);
                case 2 -> scope.drawText(0.30f, Math.round(left * 100) + "%", x + 1, y + 16,
                        LAYOUT.font.value, color);
                default -> {
                    scope.drawRectangle(x + 2, y + 17, 16, 3, 0xCC1A1D22);
                    scope.drawRectangle(x + 2, y + 17, Math.round(16 * left), 3, color);
                }
            }
        }

        if (LOW_ALERT.value && !empty && isLow(stack)) {
            // Pulsing alert; the frame-skip key already includes alert state,
            // so the pulse only re-draws this small marker.
            float pulse = 0.55f + 0.45f * (float) Math.sin(System.currentTimeMillis() / 220.0);
            int alpha = Math.round(160 + 95 * pulse);
            scope.drawText(0.5f, "!", x + 14, y - 5, LAYOUT.font.value,
                    (alpha << 24) | 0xFF5F68);
        }
        return index;
    }

    private static int durabilityColor(float left) {
        if (left > 0.5f) return 0xFF55E37A;
        if (left > 0.25f) return 0xFFF0BF55;
        return 0xFFFF5F68;
    }

    @Override public ModLayout getDimensions() { return LAYOUT; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
