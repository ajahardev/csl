package com.craftstudio.csclient.ui.elements;

import java.util.function.BooleanSupplier;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Compact animated category filter inspired by modern client tab chips. */
public class FilterChip extends Element {
    private final String label;
    private final BooleanSupplier active;
    private final Runnable onClick;
    private float progress;

    public FilterChip(String label, BooleanSupplier active, Runnable onClick) {
        this.label = label;
        this.active = active;
        this.onClick = onClick;
        dimensions(Math.max(66, Fonts.getWidth(label, Theme.FONT.value) + 28), 30);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = active.getAsBoolean() ? 1f : (ctx.isHovering() ? 0.52f : 0f);
        progress += (target - progress) * 0.24f;
        int fill = blend(0xA512161C, Theme.withAlpha(220, Theme.ACCENT.value), progress);
        int outline = blend(0x305F6974, 0xFFE9EDF1, progress);
        int foreground = blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, Math.max(0f, progress - 0.35f) / 0.65f);

        scope.drawRoundedRectangle(0, 0, width, height, 10, fill);
        scope.drawRoundedBorder(0, 0, width, height, 10, outline);
        scope.drawText(0.50f, label, (width - (int) (Fonts.getWidth(label, Theme.FONT.value) * 0.50f)) / 2,
                10, Theme.FONT.value, foreground);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
