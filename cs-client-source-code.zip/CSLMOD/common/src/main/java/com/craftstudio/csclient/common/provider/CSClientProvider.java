package com.craftstudio.csclient.common.provider;

import java.awt.image.BufferedImage;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;

public interface CSClientProvider {
    MinecraftClientRef getClient();
    void logInfo(String message);
    void logError(String message);
    void logError(String message, Throwable throwable);
    void registerBufferedImageTexture(IdentifierRef identifier, BufferedImage image);
}
