package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;

/** Vanilla-behaviour attack-strength indicator without a fake ATTACK percentage box. */
public class AttackCooldownMod extends Mod implements HudMod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final SelectProperty indicatorStyle = Property.select(0,
            "Vanilla Sword", "Crosshair Meter", "Minimal Sword");
    private static final BoolProperty hideWhenReady = Property.bool(true);
    private static final BoolProperty readyTargetCue = Property.bool(true);
    private static final BoolProperty smoothVisuals = Property.bool(true);
    private static final ColorProperty chargingColor = Property.color(0xFFDCE1E7);
    private static final ColorProperty readyColor = Property.color(0xFFFFFFFF);
    private static final ModLayout layout = new ModLayout(30, 28);
    private float animatedProgress = -1f;

    public AttackCooldownMod() {
        super(new ModSpec("Attack Indicator", "attackcooldown")
                        .description("Vanilla attack-strength sword fill with target-ready cue")
                        .version("v2.0.0").tags("PvP", "HUD"),
                enabled.named("Enabled"),
                indicatorStyle.named("Indicator style"),
                hideWhenReady.named("Hide at full charge"),
                readyTargetCue.named("Show ready cue on a target"),
                smoothVisuals.named("Smooth visual recharge"),
                chargingColor.named("Charging color"),
                readyColor.named("Ready color"), layout.prop());
    }

    @Override
    public boolean shouldRenderHud() {
        float progress = Providers.feature.player().getAttackCooldown();
        boolean targetReady = readyTargetCue.value && progress >= 0.995f
                && Providers.feature.entity().isTargetingLivingEntity();
        return !hideWhenReady.value || progress < 0.995f || targetReady;
    }

    @Override public void renderHud(RenderScope scope) {
        draw(scope, Providers.feature.player().getAttackCooldown(),
                Providers.feature.entity().isTargetingLivingEntity());
    }

    @Override public void renderDummy(RenderScope scope) { draw(scope, 0.62f, false); }

    private void draw(RenderScope scope, float raw, boolean targeting) {
        float target = clamp(raw);
        if (animatedProgress < 0f) animatedProgress = target;
        animatedProgress = smoothVisuals.value
                ? animatedProgress + (target - animatedProgress) * 0.42f
                : target;
        float progress = clamp(animatedProgress);
        boolean ready = target >= 0.995f;
        int color = ready ? readyColor.value : chargingColor.value;

        if (indicatorStyle.value == 1) {
            drawCrosshairMeter(scope, progress, color, ready && targeting);
            return;
        }

        int iconSize = indicatorStyle.value == 2 ? 16 : 22;
        layout.width = readyTargetCue.value ? iconSize + 12 : iconSize + 4;
        layout.height = iconSize + 4;
        int x = 2;
        int y = 2;
        int emptyColor = indicatorStyle.value == 2 ? 0x40343A42 : 0x6A303740;

        // Vanilla's hotbar indicator is a sword silhouette filled bottom-to-top.
        scope.drawTexture(Textures.getModIcon("attackcooldown"), x, y, 0, 0,
                iconSize, iconSize, emptyColor);
        int filled = Math.max(1, Math.round(iconSize * progress));
        scope.enableScissor(x, y + iconSize - filled, x + iconSize, y + iconSize);
        scope.drawTexture(Textures.getModIcon("attackcooldown"), x, y, 0, 0,
                iconSize, iconSize, color);
        scope.disableScissor();

        if (readyTargetCue.value && ready && targeting) {
            drawReadyPlus(scope, x + iconSize + 4, y + iconSize / 2, readyColor.value);
        }
    }

    private void drawCrosshairMeter(RenderScope scope, float progress, int color, boolean targetReady) {
        layout.width = 54;
        layout.height = 12;
        scope.drawRoundedRectangle(2, 4, 44, 4, 2, 0x78303840);
        int fill = Math.max(1, Math.round(44 * progress));
        scope.drawRoundedRectangle(2, 4, fill, 4, 2, color);
        if (targetReady) drawReadyPlus(scope, 50, 6, readyColor.value);
    }

    private void drawReadyPlus(RenderScope scope, int centerX, int centerY, int color) {
        scope.drawRectangle(centerX - 1, centerY - 4, 2, 8, color);
        scope.drawRectangle(centerX - 4, centerY - 1, 8, 2, color);
    }

    private static float clamp(float value) { return Math.max(0f, Math.min(1f, value)); }

    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
