package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.ModSpec;

public class DistanceTrackerMod extends TextHudMod {
    private static final KeybindingProperty resetKey = Property.keybinding(GLFWProvider.GLFW_KEY_K);
    private double distance;

    public DistanceTrackerMod() {
        super(new ModSpec("Distance Tracker", "distance").description("Tracks horizontal distance travelled")
                        .version("v1.0.0").tags("Navigation", "HUD").requires(Providers.feature::player),
                110, resetKey.named("Reset Distance Key"));
    }

    @Override public void tick() {
        PlayerFeature.Velocity v = Providers.feature.player().getVelocity();
        distance += Math.sqrt(v.x * v.x + v.z * v.z);
        if (resetKey.wasKeyPressed()) distance = 0.0;
    }
    @Override protected String getText() { return FastNumberFormatter.fixed(distance, 1) + " BLOCKS"; }
    @Override protected String getDummyText() { return "1248.6 BLOCKS"; }
}
