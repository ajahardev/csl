package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Touch-sized semantic theme token. Opens the full Color Studio on click. */
public class ThemeColorCard extends Element {
    private final String name;
    private final String description;
    private final ColorProperty property;
    private final Runnable onClick;
    private float hover;

    public ThemeColorCard(String name, String description, ColorProperty property, Runnable onClick) {
        this.name = name;
        this.description = description;
        this.property = property;
        this.onClick = onClick;
        dimensions(420, 68);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.23f;
        int fill = blend(0xD213181E, 0xF01D252E, hover);
        int outline = blend(0x3D69747F, 0xD6EDF1F4, hover);
        int lift = hover > 0.62f ? -1 : 0;

        scope.drawRoundedRectangle(0, lift, width, height, 7, fill);
        scope.drawRoundedBorder(0, lift, width, height, 7, outline);
        scope.drawRoundedRectangle(12, 12 + lift, 44, 44, 6, property.value);
        scope.drawRoundedBorder(12, 12 + lift, 44, 44, 6, 0x82FFFFFF);

        scope.drawText(0.52f, name, 68, 15 + lift, Theme.FONT.value, Theme.FOREGROUND.value);
        scope.drawText(0.30f, description, 68, 38 + lift, Theme.FONT.value,
                Theme.withAlpha(150, Theme.PRIMARY_FG.value));
        String hex = String.format("#%08X", property.value);
        int hexX = Math.max(190, width - 120);
        scope.drawText(0.36f, hex, hexX, 17 + lift, Theme.FONT.value, Theme.PRIMARY_FG.value);
        scope.drawText(0.60f, "›", width - 22, 34 + lift, Theme.FONT.value,
                hover > 0.45f ? Theme.FOREGROUND.value : Theme.PRIMARY_FG.value);

        if (hover > 0.03f) {
            scope.drawRectangle(68, height - 3 + lift, Math.round((width - 90) * hover), 1,
                    Theme.withAlpha(Math.round(220 * hover), Theme.ACCENT.value));
        }
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
