package com.craftstudio.csclient.ui.elements;

import java.util.function.Consumer;
import java.util.function.Predicate;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Keyboard-friendly text field with optional SVG leading icon and submit action. */
public class TextFieldElement extends Element {
    private final String placeholder;
    private final int maxLength;
    private final Predicate<Character> characterFilter;
    private final Consumer<String> onChange;
    private final Runnable onSubmit;
    private final IdentifierRef icon;
    private final StringBuilder value = new StringBuilder();
    private int cursor;
    private int renderStart;
    private float focusProgress;

    public TextFieldElement(String placeholder, int maxLength, Predicate<Character> characterFilter,
            Consumer<String> onChange, Runnable onSubmit, IdentifierRef icon) {
        this.placeholder = placeholder;
        this.maxLength = maxLength;
        this.characterFilter = characterFilter == null ? c -> true : characterFilter;
        this.onChange = onChange;
        this.onSubmit = onSubmit;
        this.icon = icon;
        dimensions(260, 36);
    }

    public String getValue() {
        return value.toString();
    }

    public void setValue(String text) {
        value.setLength(0);
        if (text != null) value.append(text, 0, Math.min(text.length(), maxLength));
        cursor = value.length();
        changed();
    }

    public void clear() {
        value.setLength(0);
        cursor = 0;
        changed();
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = focused ? 1f : (ctx.isHovering() ? 0.45f : 0f);
        focusProgress += (target - focusProgress) * 0.25f;
        int fill = blend(0xD012161C, 0xF01A2027, focusProgress);
        int outline = blend(0x506A747F, 0xFFE7EBEF, focusProgress);

        scope.drawRoundedRectangle(0, 0, width, height, 11, fill);
        scope.drawRoundedBorder(0, 0, width, height, 11, outline);

        int textX = 12;
        if (icon != null) {
            scope.drawTexture(icon, 11, 10, 0, 0, 16, 16,
                    focused ? Theme.FOREGROUND.value : Theme.PRIMARY_FG.value);
            textX = 36;
        }

        int availableWidth = Math.max(20, width - textX - 10);
        String shown;
        if (value.length() == 0) {
            renderStart = 0;
            shown = fitFromStart(placeholder, availableWidth);
        } else {
            renderStart = calculateRenderStart(availableWidth);
            shown = fitFromStart(value.substring(renderStart), availableWidth);
        }
        int color = value.length() == 0 ? Theme.withAlpha(125, Theme.PRIMARY_FG.value) : Theme.FOREGROUND.value;
        scope.drawText(0.52f, shown, textX, 12, Theme.FONT.value, color);

        if (focused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
            int safeCursor = Math.max(renderStart, Math.min(cursor, value.length()));
            String before = value.substring(renderStart, safeCursor);
            int cursorX = textX + (int) (Fonts.getWidth(before, Theme.FONT.value) * 0.52f) + 1;
            scope.drawRectangle(Math.min(width - 8, cursorX), 9, 1, 18, Theme.ACCENT.value);
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        boolean shortcut = (modifiers & (GLFWProvider.GLFW_MOD_CONTROL | GLFWProvider.GLFW_MOD_SUPER)) != 0;
        if (shortcut && keyCode == GLFWProvider.GLFW_KEY_V) {
            insertText(Providers.csClient.getClient().getClipboardText());
        } else if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            focused = false;
        } else if (keyCode == GLFWProvider.GLFW_KEY_ENTER || keyCode == GLFWProvider.GLFW_KEY_KP_ENTER) {
            if (onSubmit != null) onSubmit.run();
        } else if (keyCode == GLFWProvider.GLFW_KEY_BACKSPACE && cursor > 0) {
            value.deleteCharAt(cursor - 1);
            cursor--;
            changed();
        } else if (keyCode == GLFWProvider.GLFW_KEY_DELETE && cursor < value.length()) {
            value.deleteCharAt(cursor);
            changed();
        } else if (keyCode == GLFWProvider.GLFW_KEY_LEFT && cursor > 0) {
            cursor--;
        } else if (keyCode == GLFWProvider.GLFW_KEY_RIGHT && cursor < value.length()) {
            cursor++;
        } else if (keyCode == GLFWProvider.GLFW_KEY_HOME) {
            cursor = 0;
        } else if (keyCode == GLFWProvider.GLFW_KEY_END) {
            cursor = value.length();
        }
    }

    @Override
    public void charTyped(char typedChar) {
        if (value.length() >= maxLength || Character.isISOControl(typedChar)
                || !characterFilter.test(typedChar)) return;
        value.insert(cursor, typedChar);
        cursor++;
        changed();
    }

    @Override
    public boolean acceptsTextInput() {
        return true;
    }

    @Override
    public void click(int mouseX, int mouseY) {
        int textX = icon == null ? 12 : 36;
        int relative = Math.max(0, mouseX - textX);
        cursor = value.length();
        for (int i = renderStart; i <= value.length(); i++) {
            int w = (int) (Fonts.getWidth(value.substring(renderStart, i), Theme.FONT.value) * 0.52f);
            if (w >= relative) {
                cursor = i;
                break;
            }
        }
    }

    private int calculateRenderStart(int availableWidth) {
        int start = 0;
        int end = focused ? Math.min(cursor, value.length()) : value.length();
        while (start < end
                && Fonts.getWidth(value.substring(start, end), Theme.FONT.value) * 0.52f > availableWidth) {
            start++;
        }
        return start;
    }

    private String fitFromStart(String text, int availableWidth) {
        if (text == null || text.isEmpty()) return "";
        int end = text.length();
        while (end > 0 && Fonts.getWidth(text.substring(0, end), Theme.FONT.value) * 0.52f > availableWidth) {
            end--;
        }
        return text.substring(0, end);
    }

    private void insertText(String text) {
        if (text == null || text.isEmpty()) return;
        boolean inserted = false;
        for (int i = 0; i < text.length() && value.length() < maxLength; i++) {
            char c = text.charAt(i);
            if (Character.isISOControl(c) || !characterFilter.test(c)) continue;
            value.insert(cursor++, c);
            inserted = true;
        }
        if (inserted) changed();
    }

    private void changed() {
        if (onChange != null) onChange.accept(value.toString());
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
