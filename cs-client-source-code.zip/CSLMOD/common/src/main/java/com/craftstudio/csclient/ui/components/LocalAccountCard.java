package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.account.LocalAccountManager.LocalAccount;
import com.craftstudio.csclient.account.LocalSkinManager;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.Utils;
import com.craftstudio.csclient.ui.resources.Textures;

/** Local profile row with large switch and delete targets for touch launchers. */
public class LocalAccountCard extends Element {
    private final LocalAccount account;
    private final boolean active;
    private final Runnable onSwitch;
    private final Runnable onDelete;
    private float hover;

    public LocalAccountCard(LocalAccount account, boolean active, Runnable onSwitch, Runnable onDelete) {
        this.account = account;
        this.active = active;
        this.onSwitch = onSwitch;
        this.onDelete = onDelete;
        dimensions(650, 62);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.2f;
        int fill = blend(0xD014181E, 0xF01D242C, hover);
        int outline = active ? Theme.ACCENT.value : blend(0x365E6873, 0xAFCAD1D7, hover);
        scope.drawRoundedRectangle(0, 0, width, height, 7, fill);
        scope.drawRoundedBorder(0, 0, width, height, 7, outline);

        scope.drawRoundedRectangle(12, 11, 40, 40, 6,
                active ? Theme.withAlpha(220, Theme.ACCENT.value) : Theme.PRIMARY.value);
        scope.drawTexture(Textures.PROFILE, 23, 22, 0, 0, 18, 18,
                active ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);

        scope.drawText(0.60f, account.username(), 66, 15, Theme.FONT.value, Theme.FOREGROUND.value);
        boolean hasSkin = LocalSkinManager.hasSavedSkin(account.uuid());
        boolean hasCape = LocalSkinManager.hasSavedCape(account.uuid());
        String detail = active ? "CURRENT LOCAL SESSION"
                : hasSkin && hasCape ? "LOCAL PROFILE  •  CUSTOM SKIN + CAPE"
                : hasSkin ? "LOCAL PROFILE  •  CUSTOM SKIN"
                : hasCape ? "LOCAL PROFILE  •  CUSTOM CAPE"
                : "OFFLINE / LOCAL PROFILE";
        scope.drawText(0.34f, detail, 66, 38, Theme.FONT.value,
                active ? Theme.ACCENT.value : Theme.withAlpha(145, Theme.PRIMARY_FG.value));

        int deleteX = width - 46;
        int switchX = width - 164;
        boolean switchHover = ctx.isHovering(switchX, 13, 108, 36);
        boolean deleteHover = ctx.isHovering(deleteX, 13, 34, 36);

        scope.drawRoundedRectangle(switchX, 13, 108, 36, 6,
                active ? Theme.withAlpha(90, Theme.PRIMARY.value)
                        : switchHover ? Theme.ACCENT.value : Theme.PRIMARY.value);
        scope.drawTexture(Textures.SWITCH, switchX + 12, 23, 0, 0, 16, 16,
                switchHover && !active ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);
        scope.drawText(0.43f, active ? "ACTIVE" : "SWITCH", switchX + 36, 25, Theme.FONT.value,
                switchHover && !active ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);

        scope.drawRoundedRectangle(deleteX, 13, 34, 36, 6,
                deleteHover ? 0xFFD65959 : Theme.PRIMARY.value);
        scope.drawTexture(Textures.TRASH, deleteX + 9, 23, 0, 0, 16, 16,
                deleteHover ? 0xFFFFFFFF : Theme.PRIMARY_FG.value);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        int deleteX = width - 46;
        if (Utils.isHovering(mouseX - deleteX, mouseY - 13, 34, 36, 1f)) {
            if (onDelete != null) onDelete.run();
        } else if (!active) {
            // The explicit button and the full row both switch, matching modern
            // account managers and making touch interaction reliable.
            if (onSwitch != null) onSwitch.run();
        }
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
