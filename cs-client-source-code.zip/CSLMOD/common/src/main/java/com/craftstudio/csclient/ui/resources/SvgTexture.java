package com.craftstudio.csclient.ui.resources;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.kitfox.svg.SVGDiagram;
import com.kitfox.svg.SVGUniverse;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;

public class SvgTexture {

    // IdentifierRef adapters do not guarantee value equality across game versions.
    // Cache by stable resource string so rounded UI assets are rasterized exactly once.
    private static final Set<String> svgCache = new HashSet<>();
    private static final Map<Long, IdentifierRef> generatedShapeCache = new HashMap<>();

    /**
     * Returns a cached generated rounded fill/ring. SVG text and streams are built
     * only on the first use of a geometry instead of once per draw call/frame.
     */
    public static synchronized IdentifierRef getRoundedShape(int width, int height, int radius, boolean border) {
        if (width < 1 || height < 1) return null;
        radius = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
        long key = (border ? Long.MIN_VALUE : 0L)
                | ((long) (width & 0xFFFF) << 32)
                | ((long) (height & 0xFFFF) << 16)
                | (radius & 0xFFFFL);
        IdentifierRef cached = generatedShapeCache.get(key);
        if (cached != null) return cached;

        String kind = border ? "outline" : "rounded";
        IdentifierRef output = IdentifierRef.ofClient(
                "textures/gui/tmp_rect/" + kind + "_" + width + "_" + height + "_" + radius);
        String svg;
        if (border) {
            svg = String.format(
                    "<svg xmlns='http://www.w3.org/2000/svg' width='%d' height='%d'>"
                            + "<rect x='1' y='1' width='%d' height='%d' rx='%d' ry='%d' "
                            + "fill='none' stroke='white' stroke-width='2'/>"
                            + "</svg>",
                    width, height, width - 2, height - 2,
                    Math.max(1, radius - 1), Math.max(1, radius - 1));
        } else {
            svg = String.format(
                    "<svg xmlns='http://www.w3.org/2000/svg' width='%d' height='%d'>"
                            + "<rect width='%d' height='%d' rx='%d' ry='%d' fill='white'/>"
                            + "</svg>",
                    width, height, width, height, radius, radius);
        }
        IdentifierRef result = getSvg(new ByteArrayInputStream(svg.getBytes(StandardCharsets.UTF_8)),
                output, width * 2, height * 2);
        if (result != null) generatedShapeCache.put(key, result);
        return result;
    }

    private static BufferedImage renderSvg(InputStream svgStream, int width, int height) throws Exception {
        // Load SVG
        SVGUniverse universe = new SVGUniverse();
        java.net.URI uri = universe.loadSVG(svgStream, "tempSvg");
        SVGDiagram diagram = universe.getDiagram(uri);

        // Get intrinsic size of SVG
        float svgWidth = (float) diagram.getWidth();
        float svgHeight = (float) diagram.getHeight();

        // Compute scale factors
        float scaleX = width / svgWidth;
        float scaleY = height / svgHeight;

        // Create output image
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();

        // Enable anti-aliasing for smooth scaling
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

        // Apply scaling transform
        g.scale(scaleX, scaleY);

        // Render SVG
        diagram.render(g);

        g.dispose();
        return image;
    }

    public static synchronized IdentifierRef getSvg(InputStream stream, IdentifierRef output, int width, int height) {
        String cacheKey = output.toString();
        if (svgCache.contains(cacheKey)) {
            return output;
        }

        try {
            BufferedImage image = renderSvg(stream, width, height);
            Providers.csClient.registerBufferedImageTexture(output, image);
            svgCache.add(cacheKey);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return output;
    }

    public static IdentifierRef getSvg(IdentifierRef svgImage, int width, int height) {
        IdentifierRef output = IdentifierRef
                .of(svgImage.toString().replaceAll("\\.svg$", (width + "_" + height).toString() + ".png"));

        if (svgCache.contains(output.toString())) {
            return output;
        }

        try (InputStream svgStream = Providers.csClient.getClient().getResource(svgImage)) {
            return getSvg(svgStream, output, width, height);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}