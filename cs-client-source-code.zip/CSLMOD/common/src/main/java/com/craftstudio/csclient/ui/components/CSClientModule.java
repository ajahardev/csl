package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.Utils;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;
import com.craftstudio.csclient.ui.screens.ConfigEditor;

/** Restored responsive horizontal module card. */
public class CSClientModule extends Element {
    private final Mod mod;
    private float hover;
    private float enabledProgress;

    public CSClientModule(Mod mod) {
        this.mod = mod;
        dimensions(280, 88);
        enabledProgress = mod.isEnabled() ? 1f : 0f;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        boolean settingsHover = ctx.isHovering(width - 43, height - 37, 31, 27);
        boolean toggleHover = mod.isToggleable() && ctx.isHovering(width - 61, 12, 49, 27);
        float hoverTarget = ctx.isHovering() ? 1f : 0f;
        hover += (hoverTarget - hover) * 0.18f;
        float enabledTarget = mod.isEnabled() ? 1f : 0f;
        enabledProgress += (enabledTarget - enabledProgress) * 0.22f;

        int fill = blend(0xE012161C, 0xF01C232B, hover);
        int outline = blend(0x365F6974, Theme.withAlpha(205, Theme.ACCENT.value),
                Math.max(hover * 0.72f, enabledProgress));
        scope.drawRoundedRectangle(0, 0, width, height, 13, fill);
        scope.drawRoundedBorder(0, 0, width, height, 13, outline);

        int iconFill = blend(Theme.PRIMARY.value, Theme.ACCENT.value, enabledProgress);
        int iconColor = blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, enabledProgress);
        scope.drawRoundedRectangle(12, 14, 54, 54, 13, iconFill);
        scope.drawTexture(mod.getIconTexture(), 26, 28, 0, 0, 26, 26, iconColor);

        int copyX = 78;
        int copyWidth = Math.max(60, width - copyX - 74);
        String name = ellipsize(mod.getName(), copyWidth, 0.61f);
        String description = ellipsize(mod.getDescription(), width - copyX - 16, 0.36f);
        scope.drawText(0.61f, name, copyX, 15, Theme.FONT.value, Theme.FOREGROUND.value);
        scope.drawText(0.36f, description, copyX, 39, Theme.FONT.value,
                Theme.withAlpha(150, Theme.PRIMARY_FG.value));

        String category = mod.getTags().length == 0 ? "UTILITY" : mod.getTags()[0].toUpperCase();
        scope.drawRoundedRectangle(copyX, 59, Math.min(76, Fonts.getWidth(category, Theme.FONT.value) / 2 + 16),
                18, 7, Theme.withAlpha(95, Theme.ACCENT.value));
        scope.drawText(0.32f, category, copyX + 7, 65, Theme.FONT.value, Theme.PRIMARY_FG.value);

        int switchX = width - 61;
        int switchY = 12;
        if (mod.isToggleable()) {
            int switchFill = blend(0xFF252C34, Theme.ACCENT.value, enabledProgress);
            if (toggleHover) switchFill = blend(switchFill, 0xFFFFFFFF, 0.13f);
            scope.drawRoundedRectangle(switchX, switchY, 49, 27, 14, switchFill);
            int knobX = switchX + 4 + Math.round(enabledProgress * 22f);
            scope.drawRoundedRectangle(knobX, switchY + 4, 19, 19, 10,
                    blend(0xFF9199A2, Theme.ACCENT_FG.value, enabledProgress));
        } else {
            scope.drawRoundedRectangle(switchX, switchY, 49, 27, 9, Theme.withAlpha(150, Theme.ACCENT.value));
            scope.drawText(0.30f, "AUTO", switchX + 10, switchY + 10,
                    Theme.FONT.value, Theme.ACCENT_FG.value);
        }

        int settingsX = width - 43;
        int settingsY = height - 37;
        scope.drawRoundedRectangle(settingsX, settingsY, 31, 27, 9,
                settingsHover ? Theme.ACCENT.value : Theme.withAlpha(170, Theme.PRIMARY.value));
        scope.drawTexture(Textures.SLIDERS, settingsX + 8, settingsY + 6, 0, 0, 15, 15,
                settingsHover ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (Utils.isHovering(mouseX - (width - 43), mouseY - (height - 37), 31, 27, 1f)) {
            Providers.csClient.getClient().setScreen(new ConfigEditor(mod));
        } else if (mod.isToggleable()) {
            mod.setEnabled(!mod.isEnabled());
        } else {
            Providers.csClient.getClient().setScreen(new ConfigEditor(mod));
        }
    }

    private static String ellipsize(String text, int maxWidth, float scale) {
        if (text == null) return "";
        if (Fonts.getWidth(text, Theme.FONT.value) * scale <= maxWidth) return text;
        String suffix = "…";
        int end = text.length();
        while (end > 1 && Fonts.getWidth(text.substring(0, end) + suffix, Theme.FONT.value) * scale > maxWidth) {
            end--;
        }
        return text.substring(0, Math.max(1, end)) + suffix;
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
