package com.craftstudio.csclient.screenshot;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;

/** Lazy, bounded thumbnail decoding; no filesystem/image work runs during normal gameplay. */
public final class ScreenshotThumbnailCache {
    private static final int MAX_CACHE_ENTRIES = 128;
    private static final int MAX_DIMENSION = 16_384;
    private static final Map<String, State> CACHE = new LinkedHashMap<>(32, 0.75f, true);
    private static ExecutorService executor;

    public record Thumbnail(IdentifierRef texture, int width, int height, boolean failed) { }
    private record State(Thumbnail thumbnail, boolean loading) { }

    private ScreenshotThumbnailCache() { }

    public static Thumbnail request(ScreenshotRepository.Entry entry, int maxWidth, int maxHeight) {
        if (entry == null) return new Thumbnail(null, 0, 0, true);
        int width = Math.max(32, Math.min(1280, maxWidth));
        int height = Math.max(24, Math.min(720, maxHeight));
        String key = entry.path().toAbsolutePath().normalize() + "|" + entry.modifiedMillis()
                + "|" + entry.bytes() + "|" + width + "x" + height;
        return requestInternal(entry.path(), key, width, height);
    }

    public static Thumbnail request(Path path, int maxWidth, int maxHeight) {
        if (!ScreenshotRepository.isSafePng(path)) return new Thumbnail(null, 0, 0, true);
        int width = Math.max(32, Math.min(1280, maxWidth));
        int height = Math.max(24, Math.min(720, maxHeight));
        return requestInternal(path, key(path, width, height), width, height);
    }

    private static Thumbnail requestInternal(Path path, String key, int width, int height) {
        synchronized (CACHE) {
            State state = CACHE.get(key);
            if (state != null) return state.thumbnail();
            CACHE.put(key, new State(null, true));
            trim();
        }
        executor().execute(() -> decode(key, path, width, height));
        return null;
    }

    private static void decode(String key, Path path, int maxWidth, int maxHeight) {
        Thumbnail result;
        try {
            if (Files.size(path) > ScreenshotRepository.MAX_IMAGE_BYTES) throw new IOException("Screenshot too large");
            int[] dimensions = readDimensions(path);
            if (dimensions[0] < 1 || dimensions[1] < 1
                    || dimensions[0] > MAX_DIMENSION || dimensions[1] > MAX_DIMENSION) {
                throw new IOException("Unsafe screenshot dimensions");
            }
            BufferedImage source = ImageIO.read(path.toFile());
            if (source == null) throw new IOException("Unsupported PNG");
            double scale = Math.min(1.0, Math.min(maxWidth / (double) source.getWidth(),
                    maxHeight / (double) source.getHeight()));
            int targetWidth = Math.max(1, (int) Math.round(source.getWidth() * scale));
            int targetHeight = Math.max(1, (int) Math.round(source.getHeight() * scale));
            BufferedImage thumb = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
            Graphics2D graphics = thumb.createGraphics();
            try {
                graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                        RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                graphics.drawImage(source, 0, 0, targetWidth, targetHeight, null);
            } finally {
                graphics.dispose();
            }
            IdentifierRef id = IdentifierRef.ofClient("dynamic/screenshots/" + hash(key));
            Thumbnail success = new Thumbnail(id, targetWidth, targetHeight, false);
            Providers.csClient.getClient().executeOnThread(() -> {
                Providers.csClient.registerBufferedImageTexture(id, thumb);
                synchronized (CACHE) {
                    CACHE.put(key, new State(success, false));
                    trim();
                }
            });
            return;
        } catch (Exception error) {
            result = new Thumbnail(null, 0, 0, true);
        }
        synchronized (CACHE) {
            CACHE.put(key, new State(result, false));
            trim();
        }
    }

    private static int[] readDimensions(Path path) throws IOException {
        try (ImageInputStream input = ImageIO.createImageInputStream(path.toFile())) {
            if (input == null) throw new IOException("Unable to open screenshot");
            var readers = ImageIO.getImageReaders(input);
            if (!readers.hasNext()) throw new IOException("No PNG reader");
            ImageReader reader = readers.next();
            try {
                reader.setInput(input, true, true);
                return new int[] { reader.getWidth(0), reader.getHeight(0) };
            } finally {
                reader.dispose();
            }
        }
    }

    private static ExecutorService executor() {
        synchronized (CACHE) {
            if (executor == null || executor.isShutdown()) {
                executor = Executors.newSingleThreadExecutor(runnable -> {
                    Thread thread = new Thread(runnable, "CS-Screenshot-Thumbnails");
                    thread.setDaemon(true);
                    thread.setPriority(Thread.MIN_PRIORITY);
                    return thread;
                });
            }
            return executor;
        }
    }

    private static String key(Path path, int width, int height) {
        long modified = 0L;
        long size = 0L;
        try { modified = Files.getLastModifiedTime(path).toMillis(); size = Files.size(path); }
        catch (IOException ignored) { }
        return path.toAbsolutePath().normalize() + "|" + modified + "|" + size + "|" + width + "x" + height;
    }

    private static String hash(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder(24);
            for (int i = 0; i < 12; i++) result.append(String.format("%02x", bytes[i] & 255));
            return result.toString();
        } catch (Exception impossible) {
            return Integer.toHexString(value.hashCode());
        }
    }

    private static void trim() {
        while (CACHE.size() > MAX_CACHE_ENTRIES) {
            String oldest = CACHE.keySet().iterator().next();
            CACHE.remove(oldest);
        }
    }
}
