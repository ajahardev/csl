package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.NetworkFeature;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * AutoSprintMod automatically enables sprinting whenever the
 * player moves forward and no sprint-blocking condition is active.
 */
public class AutoSprintMod extends Mod {

    private static final BoolProperty enabled = Property.bool(false);

    public AutoSprintMod() {
        super(
                new ModSpec("Auto Sprint", "sprint")
                        .description("Makes the player always sprint")
                        .tags("Movement")
                        .version("v0.2.0")
                        .requires(Providers.feature::player, Providers.feature::network),
                enabled.named("Enabled"));
    }

    // ---------------------------------------------------------------
    // Mod contract
    // ---------------------------------------------------------------

    @Override
    public void tick() {
        PlayerFeature player = Providers.feature.player();
        NetworkFeature network = Providers.feature.network();

        if (!player.hasPlayer() || !network.hasNetwork()) {
            return;
        }

        if (player.isForwardPressed()
                && !player.isBackPressed()
                && !player.isSneaking()
                && !player.hasHorizontalCollision()
                && !player.isUsingItem()) {

            player.setSprinting(true);
        }
    }

    @Override
    public boolean isEnabled() {
        return enabled.value;
    }

    @Override
    public void onEnabled(boolean e) {
        enabled.value = e;
    }
}
