package com.craftstudio.csclient.common.feature;

import java.util.List;

import com.craftstudio.csclient.common.ref.game.EffectRef;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;

/**
 * PlayerFeature provides access to the state of the local player.
 *
 * All methods return safe defaults (false / 0 / empty) when no player
 * is present so that features do not need to null-check everywhere.
 */
public interface PlayerFeature {

    // ---------------------------------------------------------------
    // Presence
    // ---------------------------------------------------------------

    /** Returns true when a local player entity exists. */
    boolean hasPlayer();

    // ---------------------------------------------------------------
    // Position
    // ---------------------------------------------------------------

    int getX();

    int getY();

    int getZ();

    // ---------------------------------------------------------------
    // Movement / input
    // ---------------------------------------------------------------

    boolean isForwardPressed();

    boolean isBackPressed();

    boolean isLeftPressed();

    boolean isRightPressed();

    boolean isJumpPressed();

    boolean isAttackPressed();

    boolean isUsePressed();

    boolean isSneaking();

    /** Returns whether the local player is currently sprinting. */
    default boolean isSprinting() {
        return false;
    }

    /** Camera/body yaw in degrees, used by compass HUD modules. */
    default float getYaw() {
        return 0.0f;
    }

    boolean isUsingItem();

    boolean hasHorizontalCollision();

    boolean isOnGround();

    void setSprinting(boolean sprinting);

    // ---------------------------------------------------------------
    // Velocity
    // ---------------------------------------------------------------

    Velocity getVelocity();

    /** Immutable snapshot of the player's velocity components. */
    final class Velocity {
        public static final Velocity ZERO = new Velocity(0, 0, 0);

        public final double x;
        public final double y;
        public final double z;

        public Velocity(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    // ---------------------------------------------------------------
    // Stats
    // ---------------------------------------------------------------

    float getHealth();
    default float getMaxHealth() { return 20.0f; }
    default float getAbsorptionHealth() { return 0.0f; }

    /** Vanilla food and hidden saturation values. */
    default int getFoodLevel() { return 0; }
    default float getSaturationLevel() { return 0.0f; }

    /** Total count of the selected item across the player inventory. */
    default int getSelectedItemTotalCount() { return 0; }
    default int getTotemCount() { return 0; }
    default ItemStackRef getTotemStack() { return getDummyMainHand(); }
    default boolean isShieldDisabled() { return false; }

    /** Vanilla shield cooldown fraction: 1 at disable start, 0 when usable. */
    default float getShieldCooldownRemaining(float tickDelta) { return isShieldDisabled() ? 1.0f : 0.0f; }

    /** 0–1 vanilla attack recharge value. */
    default float getAttackCooldown() { return 1.0f; }

    default String getServerAddress() { return "SINGLEPLAYER"; }

    /** Platform-neutral sidebar data used by the movable scoreboard module. */
    final class ScoreboardLine {
        public final String text;
        public final int score;
        public ScoreboardLine(String text, int score) { this.text = text; this.score = score; }
    }

    default String getScoreboardTitle() { return "SCOREBOARD"; }
    default List<ScoreboardLine> getScoreboardLines() { return List.of(); }

    /** Platform-neutral boss event snapshot. */
    final class BossInfo {
        public final String name;
        public final float progress;
        public BossInfo(String name, float progress) { this.name = name; this.progress = progress; }
    }

    default List<BossInfo> getBossBars() { return List.of(); }

    /** Controls the modern vanilla debug hitbox renderer. */
    default void setHitboxesEnabled(boolean enabled) { }
    default boolean areHitboxesEnabled() { return false; }

    // ---------------------------------------------------------------
    // Effects / Potions
    // ---------------------------------------------------------------

    /**
     * Returns a list of the player’s currently active effects.
     * Safe default: empty list if no player is present.
     */
    List<? extends EffectRef> getActiveEffects();

    /**
     * Returns a list of dummy effects used in HUD editor / preview mode.
     * Safe default: empty list.
     */
    List<? extends EffectRef> getDummyEffects();

    // ---------------------------------------------------------------
    // Inventory / equipment
    // ---------------------------------------------------------------

    ItemStackRef getMainHand();

    default ItemStackRef getOffHand() { return getMainHand(); }

    /** Main inventory slots in vanilla order; empty slots are preserved. */
    default List<? extends ItemStackRef> getInventoryItems() { return List.of(); }

    ItemStackRef getHelmet();

    ItemStackRef getChestplate();

    ItemStackRef getLeggings();

    ItemStackRef getBoots();

    // ---------------------------------------------------------------
    // Dummy / preview data (used in HUD editor)
    // ---------------------------------------------------------------

    ItemStackRef getDummyMainHand();

    default ItemStackRef getDummyOffHand() { return getDummyMainHand(); }

    ItemStackRef getDummyHelmet();

    ItemStackRef getDummyChestplate();

    ItemStackRef getDummyLeggings();

    ItemStackRef getDummyBoots();
}
