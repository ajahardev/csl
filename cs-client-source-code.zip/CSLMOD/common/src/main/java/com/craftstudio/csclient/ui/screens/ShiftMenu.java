package com.craftstudio.csclient.ui.screens;

/** Right Shift opens the Feather-style draggable HUD layout overlay. */
public class ShiftMenu extends HudEditor {
    public ShiftMenu() {
        super(true);
    }
}
