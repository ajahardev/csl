package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.screenshot.ScreenshotRepository;
import com.craftstudio.csclient.screenshot.ScreenshotRepository.Entry;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.elements.FeatherStackButton;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

public final class ScreenshotDeleteConfirmScreen extends CSClientScreen {
    private final CSClientScreen galleryParent;
    private final Entry entry;

    public ScreenshotDeleteConfirmScreen(CSClientScreen galleryParent, Entry entry) {
        super("Delete Screenshot?");
        this.galleryParent = galleryParent == null ? new ScreenshotManagerScreen(new TitleMenu()) : galleryParent;
        this.entry = entry;
        backgroundBlur = 5;
    }

    @Override
    public void ui() {
        int panelWidth = Math.min(500, width - 30);
        int panelHeight = 260;
        int x = (width - panelWidth) / 2;
        int y = (height - panelHeight) / 2;
        draw(new Panel(0xF20E1419).dimensions(panelWidth, panelHeight).position(x, y));
        draw(new Text("DELETE SCREENSHOT?").scale(0.70f).position(x + 30, y + 25));
        draw(new Text("This removes the PNG from this profile permanently.")
                .scale(0.32f).position(x + 30, y + 66));
        String name = entry.name().length() > 48 ? entry.name().substring(0, 45) + "…" : entry.name();
        draw(new Text(name).color(Theme.ACCENT.value).scale(0.34f).position(x + 30, y + 94));
        draw(new FeatherStackButton(Textures.TRASH, "DELETE", false, true, this::delete)
                .dimensions(panelWidth - 60, 46).position(x + 30, y + 136));
        draw(new FeatherStackButton(Textures.BACK, "CANCEL", false, false, this::cancel)
                .dimensions(panelWidth - 60, 42).position(x + 30, y + 194));
    }

    private void delete() {
        ScreenshotRepository.delete(entry.path());
        Providers.csClient.getClient().setScreen(galleryParent);
    }
    private void cancel() {
        Providers.csClient.getClient().setScreen(new ScreenshotPreviewScreen(galleryParent, entry));
    }

    @Override public boolean shouldPause() { return true; }
    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) { cancel(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
