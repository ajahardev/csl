package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Lunar/Soar-inspired primary play action: simple, centered and lightweight. */
public class HomePrimaryButton extends Element {
    private final String text;
    private final Runnable onClick;
    private float hover;

    public HomePrimaryButton(String text, Runnable onClick) {
        this.text = text;
        this.onClick = onClick;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.20f;
        if (Math.abs(target - hover) < 0.002f) hover = target;

        int expand = hover > 0.08f ? Math.max(1, Math.round(hover * 2f)) : 0;
        int fill = blend(0x3010161D, 0xB029333D, hover);
        int outline = blend(0x929DA6B0, 0xFFFFFFFF, hover);
        int foreground = blend(0xFFE1E5E9, 0xFFFFFFFF, hover);
        int radius = 9 + expand;

        // Feather-style layered outline: soft outer rail plus crisp interactive ring.
        scope.drawRoundedBorder(-expand - 2, -expand - 2,
                width + expand * 2 + 4, height + expand * 2 + 4,
                radius + 2, withAlpha(35 + Math.round(65 * hover), Theme.ACCENT.value));
        scope.drawRoundedRectangle(-expand, -expand, width + expand * 2, height + expand * 2,
                radius, fill);
        scope.drawRoundedBorder(-expand, -expand, width + expand * 2, height + expand * 2,
                radius, outline);
        scope.drawRoundedRectangle(9, 10, 3, height - 20, 2,
                withAlpha(100 + Math.round(130 * hover), Theme.ACCENT.value));
        scope.drawText(0.62f, "›", width - 23 + Math.round(hover * 2f), height / 2 - 6,
                Theme.FONT.value, foreground);

        if (hover > 0.01f) {
            int rail = Math.max(2, Math.round((width - 34) * hover));
            scope.drawRoundedRectangle((width - rail) / 2, height - 3, rail, 2, 1,
                    withAlpha(Math.round(225 * hover), Theme.ACCENT.value));
        }

        scope.drawText(text, Fonts.centerX(width, text, Theme.FONT.value),
                Fonts.centerY(height) - (hover > 0.55f ? 1 : 0),
                Theme.FONT.value, foreground);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
