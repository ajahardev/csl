package com.craftstudio.csclient.ui.components.inputs;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Click, then press a key. Backspace clears the binding. */
public class KeybindingSelector extends Element {
    private final KeybindingProperty prop;

    public KeybindingSelector(KeybindingProperty prop) {
        this.prop = prop;
        this.width = 180;
        this.height = 24;
    }

    @Override
    public void render(RenderScope renderScope, ElementContext ctx) {
        boolean active = focused || ctx.isHovering();
        int bg = focused ? Theme.ACCENT.value : Theme.PRIMARY.value;
        int fg = focused ? Theme.ACCENT_FG.value : active ? Theme.FOREGROUND.value : Theme.PRIMARY_FG.value;
        renderScope.drawRoundedRectangle(0, 0, width, height, Theme.WIDGET_RADIUS.value, bg);

        String label;
        if (focused) {
            label = "PRESS A KEY • BACKSPACE CLEARS";
        } else if (prop.value == -1) {
            label = "NOT BOUND • CLICK TO SET";
        } else {
            String name = Providers.GLFW.getKeyName(prop.value);
            label = (name != null ? name.toUpperCase() : "KEY " + prop.value) + " • CLICK TO CHANGE";
        }

        float scale = 0.48f;
        int textWidth = (int) (Fonts.getWidth(label, Theme.FONT.value) * scale);
        renderScope.drawRoundedBorder(0, 0, width, height, Theme.WIDGET_RADIUS.value,
                Theme.withAlpha(active ? 150 : 60, Theme.ACCENT.value));
        renderScope.drawText(scale, label, Math.max(5, (width - textWidth) / 2), 11, Theme.FONT.value, fg);
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            focused = false;
            return;
        }
        prop.value = keyCode == GLFWProvider.GLFW_KEY_BACKSPACE ? -1 : keyCode;
        focused = false;
    }
}
