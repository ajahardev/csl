package com.craftstudio.csclient.ui;

import java.util.ArrayList;
import java.util.List;

public class ElementRenderer {
    public static void draw(List<Element> elements, Element element) {
        synchronized (elements) {
            elements.add(element);
        }
        if (element.animation != null) element.animation.init(element);
    }

    public static void render(List<Element> elements, long elapsed, RenderScope renderScope, int mouseX, int mouseY) {
        for (Element element : elements) {
            element.playAnimationFrame(elapsed);
            renderScope.getMatrixStack().push();
            renderScope.setOpacity(element.opacity);
            renderScope.getMatrixStack().translate(element.x, element.y);
            renderScope.getMatrixStack().scale(element.scale, element.scale);
            element.render(renderScope, new ElementContext(elapsed, mouseX, mouseY, element));
            renderScope.getMatrixStack().pop();
        }
    }

    public static void mouseClicked(List<Element> elements, double mouseX, double mouseY, int button) {
        if (button != 0) return;
        for (Element element : new ArrayList<>(elements)) {
            element.focused = false;
            float scale = safeScale(element);
            double adjustedX = mouseX - element.x;
            double adjustedY = mouseY - element.y;
            double localX = adjustedX / scale;
            double localY = adjustedY / scale;
            element.mouseClicked(localX, localY, button);
            if (element.opacity > 0 && Utils.isHovering((int) adjustedX, (int) adjustedY,
                    element.width, element.height, scale)) {
                element.focused = true;
                element.click((int) localX, (int) localY);
            }
        }
    }

    public static void mouseScrolled(List<Element> elements, double mouseX, double mouseY,
            double horizontalAmount, double verticalAmount) {
        for (Element element : new ArrayList<>(elements)) {
            float scale = safeScale(element);
            double adjustedX = mouseX - element.x;
            double adjustedY = mouseY - element.y;
            if (Utils.isHovering((int) adjustedX, (int) adjustedY, element.width, element.height, scale)) {
                element.scroll((int) (adjustedX / scale), (int) (adjustedY / scale),
                        horizontalAmount, verticalAmount);
            }
        }
    }

    public static void keyPressed(List<Element> elements, int keyCode, int scanCode, int modifiers) {
        for (Element element : new ArrayList<>(elements)) {
            if (element.focused && element.opacity > 0) {
                element.keyPressed(keyCode, scanCode, modifiers);
            }
        }
    }

    /** Routes Minecraft's native character/IME commit separately from key codes. */
    public static boolean charTyped(List<Element> elements, String text) {
        boolean consumed = false;
        for (Element element : new ArrayList<>(elements)) {
            if (element.focused && element.opacity > 0 && element.acceptsTextInput()) {
                element.charTyped(text);
                consumed = true;
            }
        }
        return consumed;
    }

    public static boolean hasFocusedTextInput(List<Element> elements) {
        for (Element element : new ArrayList<>(elements)) {
            if (element.focused && element.opacity > 0 && element.acceptsTextInput()) return true;
        }
        return false;
    }

    public static void mouseDragged(List<Element> elements, double mouseX, double mouseY, int button,
            double deltaX, double deltaY) {
        for (Element element : new ArrayList<>(elements)) {
            float scale = safeScale(element);
            element.mouseDragged((mouseX - element.x) / scale, (mouseY - element.y) / scale,
                    button, deltaX / scale, deltaY / scale);
        }
    }

    public static void mouseReleased(List<Element> elements, double mouseX, double mouseY, int button) {
        for (Element element : new ArrayList<>(elements)) {
            float scale = safeScale(element);
            element.mouseReleased((mouseX - element.x) / scale, (mouseY - element.y) / scale, button);
        }
    }

    private static float safeScale(Element element) {
        return element.scale == 0f ? 1f : element.scale;
    }
}
