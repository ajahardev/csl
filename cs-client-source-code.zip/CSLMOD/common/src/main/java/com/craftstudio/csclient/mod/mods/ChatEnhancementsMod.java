package com.craftstudio.csclient.mod.mods;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/** Local display-only chat QoL. Network packets and signed chat content are untouched. */
public final class ChatEnhancementsMod extends Mod {
    private static final long DUPLICATE_WINDOW_MS = 10_000L;
    private static final long COUNTER_VISIBLE_MS = 5_000L;
    private static final DateTimeFormatter TIMESTAMP = DateTimeFormatter.ofPattern("HH:mm");

    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty SHOW_TIMESTAMPS = Property.bool(true);
    private static final BoolProperty COMPACT_DUPLICATES = Property.bool(true);
    private static final BoolProperty HIGHLIGHT_MENTIONS = Property.bool(true);
    private static final BoolProperty HIDE_CHAT = Property.bool(false);
    private static final ColorProperty TIMESTAMP_COLOR = Property.color(0xFF8A949E);
    private static final ColorProperty MENTION_COLOR = Property.color(0xFFFFC857);
    private static final KeybindingProperty TOGGLE_VISIBILITY_KEY = Property.keybinding(-1);
    private static final KeybindingProperty COPY_LAST_KEY = Property.keybinding(-1);

    private static String previousRaw = "";
    private static String lastMessage = "";
    private static long previousAt;
    private static long counterUntil;
    private static int duplicateCount;

    public record IncomingDecision(boolean suppress, String timestamp, boolean mention) { }

    public ChatEnhancementsMod() {
        super(new ModSpec("Chat Improvements", "chat")
                        .description("Adds local timestamps, mention markers, duplicate compaction, copy-last and chat visibility controls")
                        .version("v1.0.0").tags("Utility", "Chat", "Mobile"),
                ENABLED.named("Enabled"),
                SHOW_TIMESTAMPS.named("Show Timestamps"),
                COMPACT_DUPLICATES.named("Compact Consecutive Duplicates"),
                HIGHLIGHT_MENTIONS.named("Highlight Mentions"),
                HIDE_CHAT.named("Hide Chat"),
                TIMESTAMP_COLOR.named("Timestamp Color"),
                MENTION_COLOR.named("Mention Color"),
                TOGGLE_VISIBILITY_KEY.named("Toggle Chat Visibility Key"),
                COPY_LAST_KEY.named("Copy Last Message Key"));
    }

    public static synchronized IncomingDecision processIncoming(String plainText) {
        String raw = sanitize(plainText);
        if (!isActive()) return new IncomingDecision(false, "", false);
        long now = System.currentTimeMillis();
        lastMessage = raw;
        if (COMPACT_DUPLICATES.value && !raw.isEmpty() && raw.equals(previousRaw)
                && now - previousAt <= DUPLICATE_WINDOW_MS) {
            duplicateCount = Math.max(2, duplicateCount + 1);
            previousAt = now;
            counterUntil = now + COUNTER_VISIBLE_MS;
            return new IncomingDecision(true, "", false);
        }
        previousRaw = raw;
        previousAt = now;
        duplicateCount = 1;
        counterUntil = 0L;
        String username = Providers.csClient == null ? "" : Providers.csClient.getClient().getUsername();
        boolean mention = HIGHLIGHT_MENTIONS.value && containsWord(raw, username);
        String timestamp = SHOW_TIMESTAMPS.value ? "[" + LocalTime.now().format(TIMESTAMP) + "] " : "";
        return new IncomingDecision(false, timestamp, mention);
    }

    public static boolean isActive() { return ENABLED.value; }
    public static boolean shouldHideChat() { return ENABLED.value && HIDE_CHAT.value; }
    public static int timestampColor() { return TIMESTAMP_COLOR.value & 0x00FFFFFF; }
    public static int mentionColor() { return MENTION_COLOR.value & 0x00FFFFFF; }

    public static void toggleChatVisibility() {
        if (!ENABLED.value) return;
        HIDE_CHAT.value = !HIDE_CHAT.value;
    }

    public static void copyLastMessage() {
        if (!ENABLED.value || lastMessage.isBlank() || Providers.csClient == null) return;
        Providers.csClient.getClient().setClipboardText(lastMessage);
    }

    @Override
    public void tick() {
        if (TOGGLE_VISIBILITY_KEY.wasKeyPressed()) toggleChatVisibility();
        if (COPY_LAST_KEY.wasKeyPressed()) copyLastMessage();
    }

    @Override
    public void render(RenderScope scope) {
        if (!ENABLED.value || shouldHideChat()) return;
        int count;
        long until;
        synchronized (ChatEnhancementsMod.class) {
            count = duplicateCount;
            until = counterUntil;
        }
        if (count < 2 || System.currentTimeMillis() > until) return;
        int y = Math.max(8, scope.getScaledWindowHeight() - 76);
        scope.drawRoundedRectangle(4, y, 92, 18, 5, 0xB8141A20);
        scope.drawRoundedBorder(4, y, 92, 18, 5, Theme.withAlpha(130, Theme.ACCENT.value));
        scope.drawText(0.42f, "REPEATED  ×" + count, 11, y + 6, Theme.FONT.value, Theme.FOREGROUND.value);
    }

    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }

    private static String sanitize(String value) {
        if (value == null) return "";
        String safe = value.replace('\n', ' ').replace('\r', ' ').trim();
        return safe.length() > 2048 ? safe.substring(0, 2048) : safe;
    }

    private static boolean containsWord(String text, String word) {
        if (text == null || word == null || word.isBlank()) return false;
        String haystack = text.toLowerCase(Locale.ROOT);
        String needle = word.toLowerCase(Locale.ROOT);
        int from = 0;
        while (true) {
            int index = haystack.indexOf(needle, from);
            if (index < 0) return false;
            boolean left = index == 0 || !Character.isLetterOrDigit(haystack.charAt(index - 1));
            int end = index + needle.length();
            boolean right = end == haystack.length() || !Character.isLetterOrDigit(haystack.charAt(end));
            if (left && right) return true;
            from = index + 1;
        }
    }
}
