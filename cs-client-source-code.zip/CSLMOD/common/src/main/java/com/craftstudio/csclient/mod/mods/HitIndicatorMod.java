package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/** Animated crosshair hit marker for targeted attacks. */
public class HitIndicatorMod extends Mod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final ColorProperty color = Property.color(0xFFFFFFFF);
    private static final IntProperty duration = Property.integer(320);
    private static final IntProperty size = Property.integer(7);
    private boolean lastAttack;
    private long lastHit;

    public HitIndicatorMod() {
        super(new ModSpec("Hit Indicator", "hitindicator")
                        .description("Animated hit marker around the crosshair")
                        .version("v1.0.0").tags("PvP", "Visuals")
                        .requires(Providers.feature::player, Providers.feature::entity, Providers.feature::render),
                enabled.named("Enabled"), color.named("Marker color"),
                duration.named("Animation duration (ms)"), size.named("Marker size"));
    }

    @Override
    public void tick() {
        PlayerFeature p = Providers.feature.player();
        boolean attack = p.isAttackPressed();
        if (attack && !lastAttack && Providers.feature.entity().isTargetingLivingEntity()) {
            lastHit = System.currentTimeMillis();
        }
        lastAttack = attack;
    }

    @Override
    public void render(RenderScope scope) {
        long age = System.currentTimeMillis() - lastHit;
        int life = Math.max(120, duration.value);
        if (age < 0 || age > life) return;
        float progress = age / (float) life;
        float eased = 1.0f - (1.0f - progress) * (1.0f - progress);
        int alpha = Math.max(0, Math.round((1.0f - progress) * 255));
        int c = (color.value & 0x00FFFFFF) | (alpha << 24);
        int centerX = scope.getScaledWindowWidth() / 2;
        int centerY = scope.getScaledWindowHeight() / 2;
        int base = Math.max(4, size.value) + Math.round(eased * 4);
        int arm = 4;

        // Four crisp animated corner markers.
        scope.drawRectangle(centerX - base - arm, centerY - base, arm, 1, c);
        scope.drawRectangle(centerX - base, centerY - base - arm, 1, arm, c);
        scope.drawRectangle(centerX + base, centerY - base, arm, 1, c);
        scope.drawRectangle(centerX + base, centerY - base - arm, 1, arm, c);
        scope.drawRectangle(centerX - base - arm, centerY + base, arm, 1, c);
        scope.drawRectangle(centerX - base, centerY + base, 1, arm, c);
        scope.drawRectangle(centerX + base, centerY + base, arm, 1, c);
        scope.drawRectangle(centerX + base, centerY + base, 1, arm, c);
    }

    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
