package com.craftstudio.csclient.mod.mods;

import java.util.ArrayList;
import java.util.List;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/** Compact 9-column inventory view using actual Minecraft item rendering. */
public class InventoryHudMod extends Mod implements HudMod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty SHOW_HOTBAR = Property.bool(true);
    private static final BoolProperty SHOW_EMPTY = Property.bool(true);
    private static final BoolProperty SHOW_COUNTS = Property.bool(true);
    private static final IntProperty SLOT_SPACING = Property.integer(1);
    private static final ModLayout LAYOUT = createLayout();

    public InventoryHudMod() {
        super(new ModSpec("Inventory HUD", "inventoryhud")
                        .description("Movable compact view of your real inventory and item counts")
                        .version("v1.0.0").tags("HUD", "Utility")
                        .requires(Providers.feature::player),
                ENABLED.named("Enabled"), SHOW_HOTBAR.named("Show Hotbar Row"),
                SHOW_EMPTY.named("Show Empty Slots"), SHOW_COUNTS.named("Show Item Counts"),
                SLOT_SPACING.named("Slot Spacing"), LAYOUT.prop());
    }

    private static ModLayout createLayout() {
        ModLayout layout = new ModLayout(172, 80);
        layout.bgColor.value = 0xBA0B0F13;
        layout.radius.value = 7;
        return layout;
    }

    @Override
    public void renderHud(RenderScope scope) {
        drawInventory(scope, Providers.feature.player().getInventoryItems());
    }

    @Override
    public void renderDummy(RenderScope scope) {
        List<ItemStackRef> dummy = new ArrayList<>();
        for (int i = 0; i < 36; i++) dummy.add(null);
        dummy.set(0, Providers.feature.player().getDummyMainHand());
        dummy.set(10, Providers.feature.player().getDummyHelmet());
        dummy.set(12, Providers.feature.player().getDummyChestplate());
        dummy.set(14, Providers.feature.player().getTotemStack());
        drawInventory(scope, dummy);
    }

    private void drawInventory(RenderScope scope, List<? extends ItemStackRef> source) {
        int spacing = Math.max(0, Math.min(5, SLOT_SPACING.value));
        int slot = 18;
        int step = slot + spacing;
        int rows = SHOW_HOTBAR.value ? 4 : 3;
        LAYOUT.width = 8 + 9 * slot + 8 * spacing;
        LAYOUT.height = 8 + rows * slot + (rows - 1) * spacing + (SHOW_HOTBAR.value ? 3 : 0);

        // Main inventory slots 9..35, matching the vanilla three-row order.
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                drawSlot(scope, itemAt(source, 9 + row * 9 + col), 4 + col * step, 4 + row * step);
            }
        }
        if (SHOW_HOTBAR.value) {
            int y = 4 + 3 * step + 3;
            scope.drawRectangle(4, y - 2, LAYOUT.width - 8, 1,
                    Theme.withAlpha(75, Theme.ACCENT.value));
            for (int col = 0; col < 9; col++) {
                drawSlot(scope, itemAt(source, col), 4 + col * step, y);
            }
        }
    }

    private void drawSlot(RenderScope scope, ItemStackRef stack, int x, int y) {
        boolean empty = stack == null || stack.isEmpty();
        if (SHOW_EMPTY.value || !empty) {
            scope.drawRectangle(x, y, 18, 18, empty ? 0x52151A20 : 0x8A1A2027);
            scope.drawBorder(x, y, 18, 18, empty ? 0x265E6872 : 0x559AA1AA);
        }
        if (empty) return;
        scope.drawItem(stack, x + 1, y + 1);
        if (SHOW_COUNTS.value && stack.getCount() > 1) {
            String count = stack.getCount() > 99 ? "99+" : String.valueOf(stack.getCount());
            scope.drawText(0.31f, count, x + (count.length() > 2 ? 7 : 11), y + 12,
                    LAYOUT.font.value, 0xFFFFFFFF);
        }
    }

    private static ItemStackRef itemAt(List<? extends ItemStackRef> source, int index) {
        return source != null && index >= 0 && index < source.size() ? source.get(index) : null;
    }

    @Override public ModLayout getDimensions() { return LAYOUT; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
