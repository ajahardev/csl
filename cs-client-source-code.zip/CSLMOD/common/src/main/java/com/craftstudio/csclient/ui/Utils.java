package com.craftstudio.csclient.ui;

import java.util.List;

public class Utils {
    public static boolean isHovering(int mouseX, int mouseY, int elementWidth, int elementHeight, float elementScale) {
        return mouseX >= 0 &&
                mouseX <= (elementWidth * elementScale) &&
                mouseY >= 0 &&
                mouseY <= (elementHeight * elementScale);
    }

    public static <T> T getOrNull(List<T> list, int index) {
        return (index >= 0 && index < list.size()) ? list.get(index) : null;
    }

    // public static void notify(NotificationKind kind, String title, String toast)
    // {
    // if (CSClient.client.currentScreen instanceof CSClientScreen) {
    // ((CSClientScreen) CSClient.client.currentScreen)
    // .draw(new Notification(CSClient.client.currentScreen.width,
    // CSClient.client.currentScreen.height, kind,
    // title, toast));
    // }
    // }
}
