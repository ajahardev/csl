package com.craftstudio.csclient.ui.anim;

import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.ui.Element;

public class FadeOut extends Animation {
    float targetOpacity;

    public FadeOut(int duration) {
        super(duration);
    }

    public FadeOut(AnimationConfig config) {
        super(config);
    }

    @Override
    public void tick(double progress, Element element) {
        element.opacity = targetOpacity - (float) progress;
    }

    @Override
    public void init(Element element) {
        targetOpacity = element.opacity;
        // element.opacity = 1.0f;
    }
}
