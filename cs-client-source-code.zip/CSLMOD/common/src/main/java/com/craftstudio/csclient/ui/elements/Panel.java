package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Non-interactive graphite surface used to group CS Client content. */
public class Panel extends Element {
    private final int color;

    public Panel() {
        this(0xEB12151A);
    }

    public Panel(int color) {
        this.color = color;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        scope.drawRoundedRectangle(0, 0, width, height, Theme.BG_RADIUS.value, color);
        scope.drawBorder(0, 0, width, height, Theme.withAlpha(80, Theme.ACCENT.value));
    }
}
