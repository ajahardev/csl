package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/**
 * SpeedometerMod displays the player's current movement speed as
 * a HUD element. Velocity data comes from {@link PlayerFeature}.
 */
public class SpeedometerMod extends Mod implements HudMod {

    private static final BoolProperty enabled = Property.bool(false);
    private static final SelectProperty axis = Property.select(1, "Absolute", "Horizontal", "Vertical");
    private static final SelectProperty unitText = Property.select(0, "None", "Blocks/s", "blocks/s", "b/s");
    private static final BoolProperty showLabel = Property.bool(true);
    private static final ModLayout layout = new ModLayout(40, 18);

    private double cachedSpeed = 0.0;
    private String cachedText;
    private long nextTextUpdate;
    private final com.craftstudio.csclient.mod.HudDirtyTracker dirtyTracker =
            new com.craftstudio.csclient.mod.HudDirtyTracker();

    public SpeedometerMod() {
        super(
                new ModSpec("Speedometer", "speed")
                        .description("Displays your current movement speed")
                        .version("v0.2.0")
                        .tags("Utility")
                        .requires(Providers.feature::player),
                enabled.named("Enabled"),
                axis.named("Speed type"),
                unitText.named("Unit text"),
                showLabel.named("Show speed label"),
                layout.prop());
    }

    // ---------------------------------------------------------------
    // HudMod
    // ---------------------------------------------------------------

    @Override
    public void renderHud(RenderScope scope) {
        int interval = PerformanceBoostMod.hudRefreshIntervalMs();
        long now = System.currentTimeMillis();
        if (cachedText == null || interval == 0 || now >= nextTextUpdate) {
            PlayerFeature player = Providers.feature.player();
            PlayerFeature.Velocity v = player.getVelocity();
            double effectiveY = player.isOnGround() ? 0.0 : v.y;
            cachedSpeed = switch (axis.value) {
                case 0 -> Math.sqrt(v.x * v.x + effectiveY * effectiveY + v.z * v.z);
                case 2 -> Math.abs(effectiveY);
                default -> Math.sqrt(v.x * v.x + v.z * v.z);
            };
            cachedText = formatSpeed(cachedSpeed * 20.0);
            nextTextUpdate = now + interval;
        }
        // Frame skip: cached speed text + colour + position unchanged.
        if (!dirtyTracker.dirty(cachedText, layout.fgColor.value, layout)) return;
        HudTextRenderer.draw(scope, layout, cachedText);
    }

    @Override
    public void renderDummy(RenderScope scope) {
        HudTextRenderer.draw(scope, layout, formatSpeed(2.71));
    }

    // ---------------------------------------------------------------
    // Rendering
    // ---------------------------------------------------------------

    private String formatSpeed(double bps) {
        String text = FastNumberFormatter.fixed(bps, 2);

        text += switch (unitText.value) {
            case 1 -> " BLOCKS/S";
            case 2 -> " blocks/s";
            case 3 -> " B/S";
            default -> "";
        };

        if (showLabel.value) {
            text = "SPEED  " + text;
        }

        return text;
    }

    // ---------------------------------------------------------------
    // Mod contract
    // ---------------------------------------------------------------

    @Override
    public ModLayout getDimensions() {
        return layout;
    }

    @Override
    public boolean isEnabled() {
        return enabled.value;
    }

    @Override
    public void onEnabled(boolean e) {
        enabled.value = e;
    }
}
