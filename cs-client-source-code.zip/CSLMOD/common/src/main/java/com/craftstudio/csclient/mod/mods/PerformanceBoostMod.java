package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.config.property.StringProperty;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.performance.PerformanceEngine;

/**
 * CS-owned performance engine controller. Profiles control only CS algorithms;
 * Minecraft and external renderer settings are never read or changed.
 */
public class PerformanceBoostMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(true);
    private static final SelectProperty PROFILE = Property.select(1, "Low", "Balanced", "High Performance");
    private static final BoolProperty ADAPTIVE = Property.bool(true);
    private static final IntProperty TARGET_FPS = Property.integer(120);
    private static final BoolProperty OPTIMIZE_CS_HUD = Property.bool(true);
    private static final KeybindingProperty BENCHMARK_KEY = Property.keybinding(-1);
    private static final IntProperty BENCHMARK_SECONDS = Property.integer(120);
    private static final StringProperty BENCHMARK_LABEL = Property.string("survival");
    private static final BoolProperty OCCLUSION_CULLING = Property.bool(true);
    private static final BoolProperty CULL_PLAYERS = Property.bool(true);
    private static final IntProperty CULL_DISTANCE = Property.integer(64);

    public PerformanceBoostMod() {
        super(new ModSpec("Performance Engine", "performanceboost")
                        .description("Measures frametimes and optimizes only CS-owned HUD/render work")
                        .version("v3.0.0").tags("Performance", "Utility"),
                ENABLED.named("Enabled"),
                PROFILE.named("Internal Optimization Profile"),
                ADAPTIVE.named("Adaptive Internal Profile"),
                TARGET_FPS.named("Adaptive Smoothness Goal (30-360)"),
                OPTIMIZE_CS_HUD.named("Optimize CS HUD Updates"),
                BENCHMARK_KEY.named("Start/Stop Benchmark Key"),
                BENCHMARK_SECONDS.named("Benchmark Duration Seconds"),
                BENCHMARK_LABEL.named("Benchmark Scenario Label"),
                OCCLUSION_CULLING.named("Entity Occlusion Culling"),
                CULL_PLAYERS.named("Cull Players Behind Blocks"),
                CULL_DISTANCE.named("Occlusion Probe Range (16-96)"));
    }

    public static boolean isActive() { return ENABLED.value; }
    public static int profileLevel() { return PerformanceEngine.effectiveProfile(); }

    public static int hudRefreshIntervalMs() {
        if (!ENABLED.value || !OPTIMIZE_CS_HUD.value) return 0;
        return PerformanceEngine.hudRefreshIntervalMs();
    }

    public static int minimapSampleIntervalMs() {
        if (!ENABLED.value) return 350;
        return PerformanceEngine.minimapSampleIntervalMs();
    }

    /** Occlusion culling is active only while the performance engine itself is on. */
    public static boolean occlusionCulling() {
        return ENABLED.value && OCCLUSION_CULLING.value;
    }

    public static boolean cullPlayers() { return CULL_PLAYERS.value; }

    public static int cullDistance() { return Math.max(16, Math.min(96, CULL_DISTANCE.value)); }

    @Override
    public void tick() {
        if (BENCHMARK_KEY.wasKeyPressed()) PerformanceEngine.toggleBenchmark(BENCHMARK_LABEL.value);
        PerformanceEngine.tick(ENABLED.value, ADAPTIVE.value, PROFILE.value,
                TARGET_FPS.value, BENCHMARK_SECONDS.value);
    }

    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
