package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Compact outlined utility action used only by the Home bottom dock. */
public class HomeDockButton extends Element {
    private final IdentifierRef icon;
    private final String text;
    private final Runnable onClick;
    private float hover;

    public HomeDockButton(IdentifierRef icon, String text, Runnable onClick) {
        this.icon = icon;
        this.text = text;
        this.onClick = onClick;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.21f;
        if (Math.abs(target - hover) < 0.002f) hover = target;

        int expand = hover > 0.12f ? 1 : 0;
        int fill = blend(0x2810161C, 0x9A2A333C, hover);
        int outline = blend(0x78959EA8, 0xFFF2F5F7, hover);
        int foreground = blend(0xFFD4D9DE, 0xFFFFFFFF, hover);
        int radius = 10;

        scope.drawRoundedBorder(-expand - 1, -expand - 1,
                width + expand * 2 + 2, height + expand * 2 + 2,
                radius + expand + 1, withAlpha(30 + Math.round(55 * hover), Theme.ACCENT.value));
        scope.drawRoundedRectangle(-expand, -expand, width + expand * 2, height + expand * 2,
                radius + expand, fill);
        scope.drawRoundedBorder(-expand, -expand, width + expand * 2, height + expand * 2,
                radius + expand, outline);

        int iconSize = 14 + (hover > 0.6f ? 1 : 0);
        int iconX = 12 + Math.round(hover * 2f);
        int iconY = (height - iconSize) / 2;
        scope.drawTexture(icon, iconX, iconY, 0, 0, iconSize, iconSize, foreground);

        int textX = 34 + Math.round(hover * 2f);
        scope.drawText(0.52f, text, textX, height / 2 - 5,
                Theme.FONT.value, foreground);

        if (hover > 0.02f) {
            int dot = hover > 0.55f ? 3 : 2;
            scope.drawRoundedRectangle(width - 13, (height - dot) / 2, dot, dot, dot,
                    withAlpha(Math.round(220 * hover), Theme.ACCENT.value));
        }
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
