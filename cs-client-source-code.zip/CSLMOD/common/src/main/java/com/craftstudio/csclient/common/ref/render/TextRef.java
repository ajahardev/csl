package com.craftstudio.csclient.common.ref.render;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;

public interface TextRef {
    public TextRef withFont(IdentifierRef font);

    public int getWidth();

    public static TextRef literal(String text) {
        return Providers.refConstructor.text(text);
    }
}
