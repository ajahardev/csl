package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * Keeps the vanilla first-person fire warning visible, but lower on screen.
 * The offset is deliberately smaller than the previous value: it must never
 * push both vanilla fire quads completely beyond the visible frame.
 */
public class LowFireMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(false);

    public LowFireMod() {
        super(new ModSpec("Low Fire", "lowfire")
                        .description("Lowers first-person fire while keeping the flame warning visible")
                        .version("v2.1.0").tags("Visuals", "PvP"),
                ENABLED.named("Enabled"));
    }

    public static boolean isActive() { return ENABLED.value; }
    /** Applied in addition to vanilla's -0.30 Y placement; retains a visible lower flame strip. */
    public static float verticalOffset() { return -0.25f; }
    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
