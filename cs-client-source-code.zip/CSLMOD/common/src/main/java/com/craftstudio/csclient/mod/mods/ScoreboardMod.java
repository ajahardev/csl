package com.craftstudio.csclient.mod.mods;

import java.util.List;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModRuntimeGuard;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/**
 * Position/scale adapter for Minecraft's real server sidebar.
 *
 * <p>Gameplay rendering is intentionally left to Minecraft. Version adapters
 * wrap the native scoreboard method in a supported GUI matrix transform, so
 * server-supplied text, number formats, team colours, ordering, background and
 * live updates remain byte-for-byte Minecraft behavior.</p>
 */
public final class ScoreboardMod extends Mod implements HudMod {
    private static final ModLayout layout = new ModLayout(128, 94);
    private static final BoolProperty MOVED = Property.bool(false);
    private static volatile long nativeSidebarSeenAtNanos;
    private static volatile int vanillaX;
    private static volatile int vanillaY;

    public ScoreboardMod() {
        super(new ModSpec("Scoreboard", "scoreboard")
                        .description("Moves the original live server scoreboard from its vanilla position")
                        .version("v1.0.0").tags("HUD", "Server"),
                layout.nativeHudProp(MOVED));
        // Minecraft renders its own exact background; CS must not add another or resize it.
        layout.renderBackground = false;
        layout.scale.value = 1.0f;
    }

    /** Called by the native scoreboard mixin once exact vanilla bounds are known. */
    public static void updateNativeBounds(int width, int height, int defaultX, int defaultY) {
        if (width > 0) layout.width = width;
        if (height > 0) layout.height = height;
        vanillaX = defaultX;
        vanillaY = defaultY;
        if (!MOVED.value) {
            layout.x.value = defaultX;
            layout.y.value = defaultY;
            layout.scale.value = 1.0f;
        }
        nativeSidebarSeenAtNanos = System.nanoTime();
    }

    public static int targetX() { return layout.x.value; }
    public static int targetY() { return layout.y.value; }
    public static float targetScale() { return 1.0f; }

    /** Fail open: a quarantined adapter leaves Minecraft's scoreboard completely untouched. */
    public static boolean shouldMoveVanilla() {
        return MOVED.value && !ModRuntimeGuard.isQuarantined("Scoreboard");
    }

    /** Compatibility name retained for smoke tests; this adapter never replaces vanilla content. */
    public static boolean shouldReplaceVanilla() { return true; }

    private static boolean nativeSidebarIsOnThisFrame() {
        long age = System.nanoTime() - nativeSidebarSeenAtNanos;
        return age >= 0L && age < 1_000_000_000L;
    }

    /** Normal HUD rendering is done only by Minecraft's native scoreboard method. */
    @Override public boolean shouldRenderHud() { return false; }
    @Override public void renderHud(RenderScope scope) { }

    /** Live editor uses the real native scoreboard behind the editor; otherwise show a movable preview. */
    @Override public void renderEditor(RenderScope scope) {
        if (!nativeSidebarIsOnThisFrame()) renderDummy(scope);
    }

    @Override public void renderDummy(RenderScope scope) {
        drawPreview(scope, "SERVER SCOREBOARD", List.of(
                new PlayerFeature.ScoreboardLine("Player  CS_User", 0),
                new PlayerFeature.ScoreboardLine("Rank  MVP+", 0),
                new PlayerFeature.ScoreboardLine("Coins  12,480", 0),
                new PlayerFeature.ScoreboardLine("play.server.net", 0)));
    }

    /** Editor-only stand-in. It is never used to replace real server data in gameplay. */
    private static void drawPreview(RenderScope scope, String title, List<PlayerFeature.ScoreboardLine> lines) {
        int width = Math.max(112, (int) (Fonts.getWidth(title, 2) * 0.54f) + 16);
        for (PlayerFeature.ScoreboardLine line : lines) {
            width = Math.max(width, (int) (Fonts.getWidth(line.text, 2) * 0.43f) + 16);
        }
        layout.width = width;
        layout.height = 23 + Math.max(1, lines.size()) * 12;
        scope.drawText(0.54f, title, 8, 6, 2, 0xFFF0F2F4);
        scope.drawRectangle(8, 19, layout.width - 16, 1, 0x709AA1AA);
        for (int i = 0; i < lines.size(); i++) {
            scope.drawText(0.43f, lines.get(i).text, 8, 25 + i * 12, 2, 0xFFF0F2F4);
        }
    }

    @Override public boolean canScale() { return false; }
    @Override public boolean usesNativeDefaultPosition() { return true; }
    @Override public boolean isUsingNativeDefaultPosition() { return !MOVED.value; }
    @Override public void onLayoutChanged() { MOVED.value = true; }
    @Override public void onLayoutReset() {
        MOVED.value = false;
        layout.x.value = vanillaX;
        layout.y.value = vanillaY;
        layout.scale.value = 1.0f;
    }
    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return true; }
    @Override public boolean isToggleable() { return false; }
    @Override public void onEnabled(boolean ignored) { }
}
