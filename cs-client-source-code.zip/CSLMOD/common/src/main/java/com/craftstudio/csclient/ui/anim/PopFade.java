package com.craftstudio.csclient.ui.anim;

import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.ui.Element;

/** Center-preserving scale/fade entrance for compact overlay surfaces. */
public class PopFade extends Animation {
    private final float startFactor;
    private int targetX;
    private int targetY;
    private float targetScale;
    private float targetOpacity;

    public PopFade(AnimationConfig config) {
        this(config, 0.86f);
    }

    public PopFade(AnimationConfig config, float startFactor) {
        super(config);
        this.startFactor = Math.max(0.65f, Math.min(0.98f, startFactor));
        this.curve = Curve::easeOutCubic;
    }

    @Override
    public void init(Element element) {
        targetX = element.x;
        targetY = element.y;
        targetScale = element.scale;
        targetOpacity = element.opacity;
        apply(element, 0.0);
    }

    @Override
    public void tick(double progress, Element element) {
        apply(element, Math.max(0.0, Math.min(1.0, progress)));
    }

    private void apply(Element element, double progress) {
        float factor = startFactor + (1f - startFactor) * (float) progress;
        float currentScale = targetScale * factor;
        element.scale = currentScale;
        element.x = targetX + Math.round(element.width * (targetScale - currentScale) / 2f);
        element.y = targetY + Math.round(element.height * (targetScale - currentScale) / 2f);
        element.opacity = Math.max(0.10f, targetOpacity * (float) progress);
    }
}
