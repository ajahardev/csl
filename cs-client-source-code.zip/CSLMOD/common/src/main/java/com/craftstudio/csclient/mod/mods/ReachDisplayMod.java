package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.ModSpec;

/** Displays distance for the latest targeted attack, matching Lunar/Feather behavior. */
public class ReachDisplayMod extends TextHudMod {
    private static final BoolProperty hideZero = Property.bool(false);
    private static final IntProperty resetMs = Property.integer(1800);
    private boolean lastAttack;
    private double lastReach;
    private long lastHitAt;

    public ReachDisplayMod() {
        super(new ModSpec("Reach Display", "reachdisplay")
                        .description("Shows the distance of your latest targeted hit")
                        .version("v1.0.0").tags("PvP", "HUD")
                        .requires(Providers.feature::player, Providers.feature::entity),
                82, hideZero.named("Hide zero"), resetMs.named("Reset delay (ms)"));
    }

    @Override
    public void tick() {
        PlayerFeature player = Providers.feature.player();
        boolean attacking = player.isAttackPressed();
        if (attacking && !lastAttack && Providers.feature.entity().isTargetingLivingEntity()) {
            lastReach = Providers.feature.entity().getTargetDistance();
            lastHitAt = System.currentTimeMillis();
        }
        if (System.currentTimeMillis() - lastHitAt > Math.max(300, resetMs.value)) lastReach = 0;
        lastAttack = attacking;
    }

    @Override protected String getText() {
        if (hideZero.value && lastReach <= 0) return "REACH —";
        return "REACH  " + FastNumberFormatter.fixed(lastReach, 2);
    }

    @Override protected String getDummyText() { return "REACH  2.84"; }
}
