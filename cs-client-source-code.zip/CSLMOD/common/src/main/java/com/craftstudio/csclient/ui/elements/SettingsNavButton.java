package com.craftstudio.csclient.ui.elements;

import java.util.function.BooleanSupplier;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Sidebar navigation row for client settings sections. */
public class SettingsNavButton extends Element {
    private final IdentifierRef icon;
    private final String label;
    private final BooleanSupplier selected;
    private final Runnable onClick;
    private float progress;

    public SettingsNavButton(IdentifierRef icon, String label, BooleanSupplier selected, Runnable onClick) {
        this.icon = icon;
        this.label = label;
        this.selected = selected;
        this.onClick = onClick;
        dimensions(210, 46);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = selected.getAsBoolean() ? 1f : (ctx.isHovering() ? 0.45f : 0f);
        progress += (target - progress) * 0.23f;
        scope.drawRoundedRectangle(0, 0, width, height, 12,
                blend(0xA312171D, Theme.ACCENT.value, progress));
        if (progress > 0.04f) {
            scope.drawRoundedRectangle(0, 9, 3, height - 18, 2,
                    blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, progress));
        }
        int fg = blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, progress);
        scope.drawTexture(icon, 14, 13, 0, 0, 20, 20, fg);
        scope.drawText(0.50f, label, 46, 17, Theme.FONT.value, fg);
        scope.drawText(0.56f, "›", width - 22, 16, Theme.FONT.value, fg);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
