package com.craftstudio.csclient.performance;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.mods.PerformanceBoostMod;

/**
 * Client-side entity occlusion culling (the technique Feather/Lunar-class
 * clients and the EntityCulling mod use): an entity whose line of sight from
 * the camera is blocked by opaque blocks is skipped entirely — render state
 * creation and GPU submission included. Simulation is untouched, so mobs,
 * farms and PvP behaviour are unaffected; only the draw is removed.
 *
 * Safety model:
 * <ul>
 *   <li>Close entities (beyond a safety margin from the camera) are never culled.</li>
 *   <li>Probes stop short of the target so entities hugging terrain still render.</li>
 *   <li>Each entity is re-probed at most every 100 ms, and only when it moved.</li>
 *   <li>A per-frame probe budget prevents a first-join spike.</li>
 *   <li>Any error disables culling permanently for the run (fail-open: render).</li>
 * </ul>
 *
 * Called from the render thread only; no locking is needed.
 */
public final class EntityOcclusionCulling {
    private static final long CHECK_INTERVAL_NS = 100_000_000L;
    private static final int MAX_CACHED = 512;
    private static final double MIN_DISTANCE = 4.0;
    private static final double RELOCATE_INVALIDATE = 0.75;
    private static final int CHECKS_PER_FRAME = 48;

    private static final Map<UUID, Check> CACHE = new HashMap<>(256);

    private static long lastFrameId = -1L;
    private static int checksThisFrame;
    private static volatile boolean disabled;

    private EntityOcclusionCulling() { }

    /** Permanently disables culling for this run after an unexpected error. */
    public static void disableSafely(Throwable error) {
        if (!disabled) {
            disabled = true;
            if (Providers.csClient != null) {
                Providers.csClient.logError("Entity occlusion culling disabled after an error", error);
            }
        }
        CACHE.clear();
    }

    public static boolean isDisabled() { return disabled; }

    /**
     * @return true when the entity's render pass may be skipped this frame
     */
    public static boolean shouldSkip(UUID uuid, double ex, double ey, double ez,
            double camX, double camY, double camZ, boolean playerEntity, boolean ownPlayer) {
        if (disabled || uuid == null || ownPlayer) return false;
        if (!PerformanceBoostMod.occlusionCulling()) return false;
        if (playerEntity && !PerformanceBoostMod.cullPlayers()) return false;

        double dx = ex - camX, dy = ey - camY, dz = ez - camZ;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (distance < MIN_DISTANCE) return false;
        if (distance > PerformanceBoostMod.cullDistance()) return false;

        long now = System.nanoTime();
        Check check = CACHE.get(uuid);
        if (check != null && now - check.lastNs < CHECK_INTERVAL_NS) {
            double mx = ex - check.lastX, my = ey - check.lastY, mz = ez - check.lastZ;
            if (mx * mx + my * my + mz * mz < RELOCATE_INVALIDATE * RELOCATE_INVALIDATE) {
                return check.occluded;
            }
        }

        long frame = PerformanceEngine.frameId();
        if (frame != lastFrameId) {
            lastFrameId = frame;
            checksThisFrame = 0;
        }
        if (checksThisFrame >= CHECKS_PER_FRAME) {
            // Budget spent: trust the last known state (fail open when unknown).
            return check != null && check.occluded;
        }
        checksThisFrame++;

        boolean occluded;
        try {
            occluded = !Providers.feature.world().isLineOfSightClear(camX, camY, camZ, ex, ey, ez);
        } catch (Throwable failure) {
            disableSafely(failure);
            return false;
        }

        if (CACHE.size() > MAX_CACHED) CACHE.clear();
        if (check == null) check = new Check();
        check.lastNs = now;
        check.lastX = ex;
        check.lastY = ey;
        check.lastZ = ez;
        check.occluded = occluded;
        CACHE.put(uuid, check);
        return occluded;
    }

    public static void clear() { CACHE.clear(); }

    private static final class Check {
        long lastNs;
        double lastX, lastY, lastZ;
        boolean occluded;
    }
}
