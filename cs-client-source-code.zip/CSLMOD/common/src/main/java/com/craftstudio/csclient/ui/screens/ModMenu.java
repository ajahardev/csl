package com.craftstudio.csclient.ui.screens;

import java.util.Locale;

import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.components.CSClientModule;
import com.craftstudio.csclient.ui.elements.AnimationStagger;
import com.craftstudio.csclient.ui.elements.FilterChip;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.Scroll;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.elements.TextFieldElement;
import com.craftstudio.csclient.ui.resources.Textures;

/** responsive module browser. */
public class ModMenu extends CSClientScreen {
    private static final String[] FILTERS = { "ALL", "HUD", "PVP", "WORLD", "UTILITY" };
    private String query = "";
    private String filter = "ALL";
    private Scroll moduleScroll;
    private int contentWidth;

    public ModMenu() {
        super("CS Client V1 Modules");
    }

    @Override
    public void ui() {
        backgroundBlur = 5;
        int panelWidth = Math.min(1040, width - 36);
        int panelX = (width - panelWidth) / 2;
        boolean compact = panelWidth < 900;

        draw(new IconButton(Textures.BACK, provider::close).position(panelX + 2, 20));
        draw(new Text("CS MODULES").scale(0.92f).position(panelX + 56, 22));
        draw(new Text(ModManager.MODS.size() + " FEATURES  •  AUTO HUDS STAY ACTIVE  •  SLIDERS OPEN SETTINGS")
                .scale(0.34f).position(panelX + 57, 51));

        int searchWidth = compact ? panelWidth - 4 : 300;
        int searchX = compact ? panelX + 2 : panelX + panelWidth - searchWidth;
        int searchY = 72;
        TextFieldElement search = new TextFieldElement("Search modules and settings", 40,
                c -> Character.isLetterOrDigit(c) || Character.isWhitespace(c) || c == '-' || c == '_',
                value -> {
                    query = value;
                    rebuildModules();
                }, null, Textures.SEARCH);
        search.dimensions(searchWidth, 38).position(searchX, searchY);
        draw(search);

        int chipY = compact ? 120 : 76;
        int chipX = panelX + 2;
        for (String name : FILTERS) {
            FilterChip chip = new FilterChip(name, () -> filter.equals(name), () -> {
                filter = name;
                rebuildModules();
            });
            chip.position(chipX, chipY);
            draw(chip);
            chipX += chip.width + 8;
        }

        int scrollY = compact ? 164 : 120;
        int scrollHeight = Math.max(210, height - scrollY - 20);
        contentWidth = panelWidth;
        moduleScroll = new Scroll(12);
        moduleScroll.dimensions(panelWidth, scrollHeight).position(panelX, scrollY);
        draw(moduleScroll);
        rebuildModules();

        draw(new Text("SEARCH  •  FILTER  •  ENABLE  •  CONFIGURE")
                .scale(0.31f).position(panelX + panelWidth - 230, height - 14));
    }

    private void rebuildModules() {
        if (moduleScroll == null) return;
        moduleScroll.clearChildren();

        int gap = 12;
        int inner = contentWidth - 24;
        int columns = inner >= 900 ? 3 : inner >= 590 ? 2 : 1;
        int cardWidth = (inner - gap * (columns - 1)) / columns;
        int row = 0;
        int col = 0;
        AnimationStagger stagger = new AnimationStagger(AnimationConfig.modMenu);

        for (Mod mod : ModManager.MODS) {
            if (!matches(mod)) continue;
            CSClientModule card = new CSClientModule(mod);
            card.dimensions(cardWidth, 88)
                    .position((cardWidth + gap) * col, (88 + gap) * row)
                    .animation(new SlideFade(AnimationConfig.modMenu, -10));
            stagger.draw(card);
            col++;
            if (col >= columns) {
                col = 0;
                row++;
            }
        }

        if (col > 0) row++;
        if (row == 0) {
            moduleScroll.draw(new Text("NO MODULES MATCH THIS SEARCH")
                    .scale(0.52f).position(24, 28));
        } else {
            moduleScroll.draw(stagger.dimensions(inner, row * (88 + gap)));
        }
    }

    private boolean matches(Mod mod) {
        String needle = query.trim().toLowerCase(Locale.ROOT);
        boolean textMatch = needle.isEmpty()
                || mod.getName().toLowerCase(Locale.ROOT).contains(needle)
                || mod.getDescription().toLowerCase(Locale.ROOT).contains(needle);
        if (!textMatch) {
            for (String tag : mod.getTags()) {
                if (tag.toLowerCase(Locale.ROOT).contains(needle)) {
                    textMatch = true;
                    break;
                }
            }
        }
        if (!textMatch || filter.equals("ALL")) return textMatch;

        for (String raw : mod.getTags()) {
            String tag = raw.toUpperCase(Locale.ROOT);
            if (filter.equals("HUD") && tag.equals("HUD")) return true;
            if (filter.equals("PVP") && tag.equals("PVP")) return true;
            if (filter.equals("WORLD") && (tag.equals("WORLD") || tag.equals("NAVIGATION")
                    || tag.equals("CAMERA") || tag.equals("MOVEMENT") || tag.equals("VISUALS"))) return true;
            if (filter.equals("UTILITY") && (tag.equals("UTILITY") || tag.equals("PERFORMANCE")
                    || tag.equals("NETWORK") || tag.equals("SERVER") || tag.equals("MINIGAMES"))) return true;
        }
        return false;
    }
}
