package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.screenshot.ScreenshotRepository;
import com.craftstudio.csclient.screenshot.ScreenshotThumbnailCache;
import com.craftstudio.csclient.screenshot.ScreenshotThumbnailCache.Thumbnail;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

public final class ScreenshotPreviewImage extends Element {
    private final ScreenshotRepository.Entry entry;

    public ScreenshotPreviewImage(ScreenshotRepository.Entry entry) {
        this.entry = entry;
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        scope.drawRoundedRectangle(0, 0, width, height, 8, 0xF0080D12);
        scope.drawRoundedBorder(0, 0, width, height, 8, 0x806E7883);
        Thumbnail thumbnail = ScreenshotThumbnailCache.request(entry, width - 12, height - 12);
        if (thumbnail == null) {
            scope.drawText(0.42f, "LOADING SCREENSHOT…", 16, height / 2, Theme.FONT.value, 0xFF8E99A4);
            return;
        }
        if (thumbnail.failed() || thumbnail.texture() == null) {
            scope.drawText(0.42f, "SCREENSHOT PREVIEW UNAVAILABLE", 16, height / 2,
                    Theme.FONT.value, 0xFFFF8B94);
            return;
        }
        float scale = Math.min((width - 12) / (float) thumbnail.width(),
                (height - 12) / (float) thumbnail.height());
        int drawWidth = Math.max(1, Math.round(thumbnail.width() * scale));
        int drawHeight = Math.max(1, Math.round(thumbnail.height() * scale));
        scope.drawTexture(thumbnail.texture(), (width - drawWidth) / 2, (height - drawHeight) / 2,
                0, 0, drawWidth, drawHeight);
    }
}
