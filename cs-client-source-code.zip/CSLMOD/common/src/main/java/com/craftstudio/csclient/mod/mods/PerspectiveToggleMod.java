package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

public class PerspectiveToggleMod extends Mod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final KeybindingProperty perspectiveKey = Property.keybinding(GLFWProvider.GLFW_KEY_V);

    public PerspectiveToggleMod() {
        super(new ModSpec("Perspective Toggle", "perspective").description("Switches instantly between first and third person")
                        .version("v1.0.0").tags("Camera", "Utility").requires(Providers.feature::render),
                enabled.named("Enabled"), perspectiveKey.named("Perspective Key"));
    }

    @Override public void tick() {
        if (perspectiveKey.wasKeyPressed()) {
            if (Providers.feature.render().isFirstPerson()) Providers.feature.render().setThirdPersonBack();
            else Providers.feature.render().setFirstPerson();
        }
    }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean value) { enabled.value = value; }
}
