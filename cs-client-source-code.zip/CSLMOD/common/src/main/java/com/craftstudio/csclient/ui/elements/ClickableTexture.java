package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

public class ClickableTexture extends Element {
    IdentifierRef sprite;
    private Runnable onClick;

    public ClickableTexture(IdentifierRef sprite, Runnable onClick) {
        this.sprite = sprite;
        this.onClick = onClick;
    }

    @Override
    public void render(RenderScope renderScope, ElementContext ctx) {
        renderScope.drawTexture(sprite, 0, 0, 0, 0, width, height,
                ctx.isHovering() ? Theme.ACCENT.value : Theme.PRIMARY.value);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) {
            onClick.run();
        }
    }
}
