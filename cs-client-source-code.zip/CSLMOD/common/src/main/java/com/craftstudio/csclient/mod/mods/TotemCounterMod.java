package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.mod.tracking.TotemTracker;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Inventory + observed pop counter inspired by competitive client behavior. */
public class TotemCounterMod extends Mod implements HudMod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final BoolProperty SHOW_ICON = Property.bool(true);
    private static final BoolProperty SHOW_INVENTORY = Property.bool(true);
    private static final BoolProperty SHOW_POP_COUNT = Property.bool(true);
    private static final BoolProperty SHOW_NAMETAG_POPS = Property.bool(true);
    private static final ColorProperty POP_COLOR = Property.color(0xFFFFC857);
    private static final ColorProperty LOW_COLOR = Property.color(0xFFFF6B6B);
    private static final IntProperty LOW_THRESHOLD = Property.integer(1);
    private static final ModLayout LAYOUT = createLayout();

    private int lastInventory = -1;
    private long pulseUntil;
    private boolean hadPlayer;

    public TotemCounterMod() {
        super(new ModSpec("Totem Counter", "totemcounter")
                        .description("Inventory count plus your and your opponent's observed totem pops")
                        .version("v2.0.0").tags("PvP", "HUD"),
                ENABLED.named("Enabled"),
                SHOW_ICON.named("Show Totem Icon"),
                SHOW_INVENTORY.named("Show Inventory Count"),
                SHOW_POP_COUNT.named("Show Pop Count"),
                SHOW_NAMETAG_POPS.named("Show Pops Above Players"),
                POP_COLOR.named("Pop Accent Color"),
                LOW_COLOR.named("Low Totem Warning Color"),
                LOW_THRESHOLD.named("Low Totem Threshold"),
                LAYOUT.prop());
    }

    private static ModLayout createLayout() {
        ModLayout layout = new ModLayout(142, 30);
        layout.bgColor.value = 0xE014181E;
        layout.fgColor.value = 0xFFF0F2F4;
        layout.radius.value = 8;
        layout.font.value = 2;
        return layout;
    }

    @Override
    public void tick() {
        boolean hasPlayer = Providers.feature.player() != null && Providers.feature.player().hasPlayer();
        if (!hasPlayer && hadPlayer) {
            TotemTracker.reset();
            lastInventory = -1;
        }
        hadPlayer = hasPlayer;
        if (!hasPlayer) return;

        int count = Providers.feature.player().getTotemCount();
        if (lastInventory >= 0 && count < lastInventory) pulseUntil = System.currentTimeMillis() + 520L;
        if (TotemTracker.getLatestPopTime() + 520L > System.currentTimeMillis()) {
            pulseUntil = Math.max(pulseUntil, TotemTracker.getLatestPopTime() + 520L);
        }
        lastInventory = count;
    }

    @Override
    public void renderHud(RenderScope scope) {
        draw(scope, Providers.feature.player().getTotemCount(),
                TotemTracker.getLocalPops(), TotemTracker.getLatestOpponentName(),
                TotemTracker.getLatestOpponentPops());
    }

    @Override
    public void renderDummy(RenderScope scope) {
        draw(scope, 3, 1, "RIVAL", 2);
    }

    private void draw(RenderScope scope, int inventory, int ownPops, String opponent, int opponentPops) {
        StringBuilder label = new StringBuilder();
        if (SHOW_INVENTORY.value) label.append(inventory).append(" LEFT");
        if (SHOW_POP_COUNT.value) {
            if (!label.isEmpty()) label.append("  •  ");
            label.append("YOU ").append(ownPops);
            if (opponentPops > 0) {
                String shortName = opponent == null ? "RIVAL" : opponent.toUpperCase();
                if (shortName.length() > 9) shortName = shortName.substring(0, 8) + "…";
                label.append("  ").append(shortName).append(' ').append(opponentPops);
            }
        }
        if (label.isEmpty()) label.append("TOTEMS");

        float textScale = 0.48f;
        int iconSpace = SHOW_ICON.value ? 25 : 0;
        int textWidth = Math.round(Fonts.getWidth(label.toString(), LAYOUT.font.value) * textScale);
        LAYOUT.width = Math.max(72, 18 + iconSpace + textWidth);
        LAYOUT.height = 30;

        boolean pulsing = System.currentTimeMillis() < pulseUntil;
        // The shared style renderer owns the shell; pop feedback is only a temporary outline.
        if (pulsing) {
            scope.drawRoundedBorder(0, 0, LAYOUT.width, LAYOUT.height,
                    LAYOUT.effectiveRadius(), Theme.withAlpha(220, POP_COLOR.value));
        }

        int x = 9;
        if (SHOW_ICON.value) {
            scope.drawItem(Providers.feature.player().getTotemStack(), x, 7);
            x += 25;
        }
        int fg = inventory <= Math.max(0, LOW_THRESHOLD.value) && SHOW_INVENTORY.value
                ? LOW_COLOR.value : LAYOUT.fgColor.value;
        if (pulsing) fg = POP_COLOR.value;
        scope.drawText(textScale, label.toString(), x, 11, LAYOUT.font.value, fg);
    }

    @Override
    public ModLayout getDimensions() {
        return LAYOUT;
    }

    @Override
    public boolean isEnabled() {
        return ENABLED.value;
    }

    @Override
    public void onEnabled(boolean enabled) {
        ENABLED.value = enabled;
        if (!enabled) TotemTracker.reset();
    }

    public static boolean shouldShowNametagPops() {
        return ENABLED.value && SHOW_NAMETAG_POPS.value;
    }

    public static int getPopColor() {
        return POP_COLOR.value;
    }
}
