package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.Fade;
import com.craftstudio.csclient.ui.anim.PopFade;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.elements.HomeIconTile;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.QuickActionTile;
import com.craftstudio.csclient.ui.elements.QuickPopupSurface;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

/** Six-color compact preset chooser opened from Right Shift or HUD Editor. */
public class HudPresetPopup extends CSClientScreen {
    private static final int PANEL_WIDTH = 382;
    private static final int PANEL_HEIGHT = 308;
    private final CSClientScreen parent;
    private final String status;
    private int panelX;
    private int panelY;
    private int panelWidth;

    public HudPresetPopup(CSClientScreen parent) {
        this(parent, "CHOOSE A HUD LAYOUT");
    }

    private HudPresetPopup(CSClientScreen parent, String status) {
        super("CS Client V1 HUD Presets");
        this.parent = parent == null ? new ShiftMenu() : parent;
        this.status = status;
        backgroundBlur = 1;
        backgroundOpacity = 0.34f;
    }

    @Override
    public void ui() {
        panelWidth = Math.min(PANEL_WIDTH, width - 28);
        panelX = (width - panelWidth) / 2;
        panelY = Math.max(12, (height - PANEL_HEIGHT) / 2);
        int x = panelX;
        int top = panelY;
        int pad = 14;
        int gap = 8;
        int cardWidth = (panelWidth - pad * 2 - gap) / 2;

        draw(new QuickPopupSurface(Theme.ACCENT.value).dimensions(panelWidth, PANEL_HEIGHT)
                .position(x, top).animation(pop(0)));
        draw(new HomeIconTile(Textures.BACK, this::goBack).dimensions(34, 34)
                .position(x + 22, top + 15).animation(pop(35)));
        draw(new Text("HUD PRESETS").scale(0.58f).position(x + 66, top + 16)
                .animation(slide(-7, 45)));
        draw(new Text(status).scale(0.27f).position(x + 67, top + 40)
                .animation(fade(60)));
        draw(new HomeMenuButton(Textures.UNDO, "UNDO", false, this::undo)
                .dimensions(92, 34).position(x + panelWidth - 106, top + 15)
                .animation(slide(7, 60)));

        int rowY = top + 66;
        addPreset(x + pad, rowY, cardWidth, HudPresetManager.Preset.PVP,
                Textures.PRESET_PVP, "PVP", "COMBAT HUD", 0xFFF07178, 85);
        addPreset(x + pad + cardWidth + gap, rowY, cardWidth, HudPresetManager.Preset.BEDWARS,
                Textures.PRESET_BEDWARS, "BEDWARS", "RUSH + ITEMS", 0xFFFF77B7, 100);
        rowY += 62;
        addPreset(x + pad, rowY, cardWidth, HudPresetManager.Preset.SURVIVAL,
                Textures.PRESET_SURVIVAL, "SURVIVAL", "WORLD INFO", 0xFF5EE58A, 120);
        addPreset(x + pad + cardWidth + gap, rowY, cardWidth, HudPresetManager.Preset.STREAM,
                Textures.PRESET_STREAM, "STREAM", "EDGE SAFE", 0xFFB78CFF, 135);
        rowY += 62;
        addPreset(x + pad, rowY, cardWidth, HudPresetManager.Preset.PERFORMANCE,
                Textures.PRESET_PERFORMANCE, "PERFORMANCE", "FPS + NETWORK", 0xFF58D6E8, 155);
        addPreset(x + pad + cardWidth + gap, rowY, cardWidth, HudPresetManager.Preset.MINIMAL,
                Textures.PRESET_MINIMAL, "MINIMAL", "FPS + PING", 0xFFF0C86A, 170);

        draw(new HomeMenuButton(Textures.HUD_ICON, "OPEN FULL HUD EDITOR", false,
                () -> Providers.csClient.getClient().setScreen(new HudEditor()))
                .dimensions(panelWidth - pad * 2, 34).position(x + pad, top + 258)
                .animation(slide(7, 195)));
    }

    private void addPreset(int x, int y, int width, HudPresetManager.Preset preset,
            com.craftstudio.csclient.common.ref.asset.IdentifierRef icon, String name, String hint,
            int color, int delay) {
        draw(new QuickActionTile(icon, name, hint, color, () -> apply(preset, name))
                .dimensions(width, 54).position(x, y).animation(slide(-6, delay)));
    }

    private void apply(HudPresetManager.Preset preset, String label) {
        HudPresetManager.apply(preset, width, height);
        Providers.csClient.getClient().setScreen(new HudPresetPopup(parent,
                label + " APPLIED  •  UNDO READY"));
    }

    private void undo() {
        boolean restored = HudPresetManager.restoreLast();
        Providers.csClient.getClient().setScreen(new HudPresetPopup(parent,
                restored ? "PREVIOUS HUD RESTORED" : "NOTHING TO UNDO"));
    }

    private void goBack() {
        Providers.csClient.getClient().setScreen(parent);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double logicalX = mouseX / uiScale;
        double logicalY = mouseY / uiScale;
        if (logicalX < panelX || logicalX > panelX + panelWidth
                || logicalY < panelY || logicalY > panelY + PANEL_HEIGHT) {
            goBack();
            return true;
        }
        super.mouseClicked(mouseX, mouseY, button);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            goBack();
            return true;
        }
        if (keyCode == GLFWProvider.GLFW_KEY_RIGHT_SHIFT) {
            provider.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private static PopFade pop(int delay) {
        PopFade value = new PopFade(AnimationConfig.shiftMenu);
        value.delay = delay;
        return value;
    }

    private static SlideFade slide(int offset, int delay) {
        SlideFade value = new SlideFade(AnimationConfig.shiftMenu, offset);
        value.delay = delay;
        return value;
    }

    private static Fade fade(int delay) {
        Fade value = new Fade(AnimationConfig.shiftMenu);
        value.delay = delay;
        return value;
    }
}
