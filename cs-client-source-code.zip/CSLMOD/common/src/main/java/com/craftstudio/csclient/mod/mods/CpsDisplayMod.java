package com.craftstudio.csclient.mod.mods;

import java.util.ArrayDeque;
import java.util.Deque;
import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.ModSpec;

public class CpsDisplayMod extends TextHudMod {
    private static final BoolProperty showRightClick = Property.bool(true);
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean lastLeft;
    private boolean lastRight;

    public CpsDisplayMod() {
        super(new ModSpec("CPS Display", "cps").description("Shows left and right clicks per second")
                        .version("v1.0.0").tags("PvP", "HUD").requires(Providers.feature::player),
                82, showRightClick.named("Show Right CPS"));
    }

    @Override
    public void tick() {
        PlayerFeature player = Providers.feature.player();
        long now = System.currentTimeMillis();
        boolean left = player.isAttackPressed();
        boolean right = player.isUsePressed();
        if (left && !lastLeft) leftClicks.addLast(now);
        if (right && !lastRight) rightClicks.addLast(now);
        lastLeft = left;
        lastRight = right;
        trim(leftClicks, now);
        trim(rightClicks, now);
    }

    private static void trim(Deque<Long> clicks, long now) {
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000L) clicks.removeFirst();
    }

    @Override protected String getText() {
        return showRightClick.value ? leftClicks.size() + " | " + rightClicks.size() + " CPS" : leftClicks.size() + " CPS";
    }
    @Override protected String getDummyText() { return showRightClick.value ? "8 | 5 CPS" : "8 CPS"; }
}
