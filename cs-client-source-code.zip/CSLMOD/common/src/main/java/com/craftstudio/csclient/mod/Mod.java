package com.craftstudio.csclient.mod;

import java.util.function.Supplier;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.ConfigManager;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.NamedProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;

public abstract class Mod {
    /** Fast-path quarantine flag set by {@link ModRuntimeGuard} (render/tick hot paths). */
    public volatile boolean quarantined;
    private final ModSpec spec;
    private final ConfigManager configManager;
    private final KeybindingProperty moduleToggleKey = Property.keybinding(-1);

    public Mod(ModSpec spec, NamedProperty... props) {
        this.spec = spec;
        configManager = new ConfigManager(spec.name);
        for (NamedProperty prop : props) {
            configManager.property(prop.name, prop.prop);
        }

        // Automatic HUD adapters such as Scoreboard/Boss Bar have no on/off state.
        if (isToggleable()) configManager.property("Module Toggle Key", moduleToggleKey);
    }

    /** Called for every module, including disabled modules. */
    public final void handleGlobalKeybind() {
        if (isToggleable() && moduleToggleKey.wasKeyPressed()) setEnabled(!isEnabled());
    }

    public void render(RenderScope scope) {
    }

    public void tick() {
    }

    public abstract boolean isEnabled();

    public final void setEnabled(boolean e) {
        onEnabled(isToggleable() ? e : true);
        ModManager.updateEnabledModules();
    }

    /** Automatic adapters stay active and expose settings/layout only. */
    public boolean isToggleable() { return true; }

    public abstract void onEnabled(boolean e);

    public final String getName() {
        return spec.name;
    }

    public IdentifierRef getIconTexture() {
        return Textures.getModIcon(spec.namespace);
    }

    public ConfigManager getConfig() {
        return configManager;
    }

    public String getDescription() {
        return spec.description;
    }

    public String[] getTags() {
        return spec.tags;
    }

    public String getVersion() {
        return spec.version;
    }

    public boolean isSupported() {
        for (Supplier<?> supplier : spec.requiresFeature) {
            if (supplier.get() == null) {
                return false;
            }
        }

        return true;
    }
}
