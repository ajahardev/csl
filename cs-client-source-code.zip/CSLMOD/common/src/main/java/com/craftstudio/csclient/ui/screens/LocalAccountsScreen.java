package com.craftstudio.csclient.ui.screens;

import java.nio.file.Path;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import com.craftstudio.csclient.account.LocalAccountManager;
import com.craftstudio.csclient.account.LocalAccountManager.LocalAccount;
import com.craftstudio.csclient.account.LocalSkinManager;
import com.craftstudio.csclient.account.LocalSkinManager.CapeRecord;
import com.craftstudio.csclient.account.LocalSkinManager.SkinRecord;
import com.craftstudio.csclient.account.LocalSkinManager.SkinResult;
import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.Fade;
import com.craftstudio.csclient.ui.anim.PopFade;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.components.AppearanceProfileCard;
import com.craftstudio.csclient.ui.components.LocalAccountCard;
import com.craftstudio.csclient.ui.components.ModuleSettingRow;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.ActiveSkinHead;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.IdentityTabButton;
import com.craftstudio.csclient.ui.elements.ImageTexture;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.Scroll;
import com.craftstudio.csclient.ui.elements.SkinModelSelector;
import com.craftstudio.csclient.ui.elements.SkinStatusBadge;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.elements.TextFieldElement;
import com.craftstudio.csclient.ui.resources.Textures;

/** Credential-free local identity center with local-only skin and cape management. */
public class LocalAccountsScreen extends CSClientScreen {
    public enum Tab { ACCOUNTS, SKIN }

    private final Tab tab;
    private final CSClientScreen parent;
    private volatile String status = "Ready.";
    private volatile boolean operationRunning;
    private volatile boolean statusSuccess = true;
    private String selectedModel;

    private TextFieldElement usernameField;
    private TextFieldElement skinPlayerField;
    private TextFieldElement skinUrlField;
    private Scroll accountScroll;
    private int listWidth;

    // Logical bounds consumed by the version-specific native PlayerSkinWidget.
    private int previewX;
    private int previewY;
    private int previewWidth;
    private int previewHeight;

    public LocalAccountsScreen() {
        this(Tab.ACCOUNTS, new TitleMenu());
    }

    public LocalAccountsScreen(Tab tab, CSClientScreen parent) {
        super("Local Identity Center");
        this.tab = tab == null ? Tab.ACCOUNTS : tab;
        this.parent = parent == null ? new TitleMenu() : parent;
    }

    @Override
    public void ui() {
        backgroundBlur = 6;
        int panelWidth = Math.min(1040, width - 32);
        int panelX = (width - panelWidth) / 2;
        boolean compact = panelWidth < 820;
        boolean stackedHeader = panelWidth < 760;

        draw(new IconButton(Textures.BACK, this::goBack).position(panelX, 20));
        draw(new Text("LOCAL IDENTITY").scale(0.88f).position(panelX + 56, 22));
        draw(new Text("ACCOUNT SWITCHER  •  LOCAL SKIN + CAPE  •  NO PASSWORDS OR TOKENS")
                .scale(0.32f).position(panelX + 57, 51));

        int tabWidth = stackedHeader ? (panelWidth - 8) / 2 : 164;
        int tabY = stackedHeader ? 74 : 20;
        int tabX = stackedHeader ? panelX : panelX + panelWidth - tabWidth * 2 - 8;
        draw(new IdentityTabButton(Textures.ACCOUNTS, "ACCOUNTS",
                () -> tab == Tab.ACCOUNTS, () -> false,
                () -> switchTab(Tab.ACCOUNTS)).dimensions(tabWidth, 40).position(tabX, tabY));
        draw(new IdentityTabButton(Textures.CAPE, "SKIN + CAPE",
                () -> tab == Tab.SKIN, () -> !LocalSkinManager.isActiveAppearanceProfile(),
                () -> switchTab(Tab.SKIN)).dimensions(tabWidth, 40).position(tabX + tabWidth + 8, tabY));

        int contentY = stackedHeader ? 126 : 78;
        int contentHeight = Math.max(250, height - contentY - 18);
        if (tab == Tab.SKIN) drawSkinTab(panelX, contentY, panelWidth, contentHeight, compact);
        else drawAccountsTab(panelX, contentY, panelWidth, contentHeight, compact);
    }

    private void drawAccountsTab(int x, int y, int width, int height, boolean compact) {
        if (compact) {
            int identityHeight = 96;
            drawCurrentIdentity(x, y, width, identityHeight, true);
            drawAccountListPane(x, y + identityHeight + 10, width, height - identityHeight - 10);
            return;
        }
        int identityWidth = 286;
        drawCurrentIdentity(x, y, identityWidth, height, false);
        drawAccountListPane(x + identityWidth + 10, y, width - identityWidth - 10, height);
    }

    private void drawCurrentIdentity(int x, int y, int width, int height, boolean compact) {
        draw(new Panel(0xE710151B).dimensions(width, height).position(x, y));
        String current = Providers.csClient.getClient().getUsername();
        if (current == null || current.isBlank()) current = "PLAYER";
        boolean local = LocalSkinManager.isActiveLocalAccount();
        boolean launcherOffline = LocalSkinManager.isActiveLauncherOfflineProfile();
        boolean eligible = LocalSkinManager.isActiveAppearanceProfile();

        int iconSize = compact ? 48 : 58;
        draw(new Panel(eligible ? Theme.withAlpha(205, Theme.ACCENT.value) : 0xE31C232B)
                .dimensions(iconSize, iconSize).position(x + 16, y + 16));
        int faceSize = compact ? 38 : 46;
        draw(new ActiveSkinHead().dimensions(faceSize, faceSize)
                .position(x + 16 + (iconSize - faceSize) / 2,
                        y + 16 + (iconSize - faceSize) / 2));
        draw(new Text("ACTIVE IDENTITY").scale(0.30f).position(x + iconSize + 30, y + 18));
        draw(new Text(current.toUpperCase()).scale(compact ? 0.58f : 0.64f)
                .position(x + iconSize + 30, y + 37));
        draw(new Text(local ? "CS LOCAL / OFFLINE"
                : launcherOffline ? "LAUNCHER OFFLINE PROFILE"
                        : eligible ? "LAUNCHER PROFILE" : "PROFILE UNAVAILABLE")
                .scale(0.29f).position(x + iconSize + 30, y + 61));

        if (compact) {
            draw(new HomeMenuButton(eligible ? Textures.CAPE : Textures.LOCK,
                    eligible ? "MANAGE SKIN + CAPE" : "SKIN + CAPE LOCKED", false,
                    () -> switchTab(Tab.SKIN)).dimensions(190, 34)
                    .position(x + width - 204, y + 31));
            return;
        }

        draw(new Text(local
                ? "This profile stores only its username, offline UUID, and optional local skin/cape."
                : launcherOffline
                        ? "Launcher offline profile: local appearance stays in its own CS profile folder."
                        : eligible
                                ? "Launcher profile detected: local appearance is available without credentials."
                                : "A valid launcher or CS local profile is required for local appearance.")
                .scale(0.29f).position(x + 16, y + 94));
        draw(new Text("SECURITY").scale(0.29f).position(x + 16, y + 140));
        draw(new Text("NO PASSWORDS").scale(0.34f).position(x + 16, y + 160));
        draw(new Text("NO MICROSOFT TOKENS").scale(0.34f).position(x + 16, y + 179));
        draw(new Text("NO LAUNCHER COOKIES").scale(0.34f).position(x + 16, y + 198));
        draw(new HomeMenuButton(eligible ? Textures.CAPE : Textures.LOCK,
                eligible ? "MANAGE SKIN + CAPE" : "SKIN + CAPE LOCKED", false,
                () -> switchTab(Tab.SKIN)).dimensions(width - 32, 38)
                .position(x + 16, y + height - 54));
    }

    private void drawAccountListPane(int x, int y, int width, int height) {
        draw(new Panel(0xE710151B).dimensions(width, height).position(x, y));
        draw(new Text("LOCAL ACCOUNTS").scale(0.60f).position(x + 14, y + 14));
        draw(new Text(LocalAccountManager.getAccounts().size() + " SAVED  •  CREDENTIAL-FREE")
                .scale(0.28f).position(x + 15, y + 41));

        int fieldY = y + 62;
        usernameField = new TextFieldElement("New local username", 16,
                c -> Character.isLetterOrDigit(c) || c == '_', value -> {
                    status = "3–16 letters, numbers, or underscores.";
                    statusSuccess = true;
                }, this::addAccount, Textures.PROFILE);
        usernameField.dimensions(width - 72, 40).position(x + 12, fieldY);
        draw(usernameField);
        draw(new IconButton(Textures.PLUS, this::addAccount)
                .dimensions(48, 40).position(x + width - 56, fieldY));

        draw(new SkinStatusBadge(() -> status, () -> false, () -> statusSuccess)
                .dimensions(width - 24, 32).position(x + 12, fieldY + 48));

        int scrollY = fieldY + 90;
        listWidth = width - 24;
        accountScroll = new Scroll(10);
        accountScroll.dimensions(width - 16, Math.max(130, height - (scrollY - y) - 8))
                .position(x + 8, scrollY);
        draw(accountScroll);
        rebuildAccounts();
    }

    private void drawSkinTab(int x, int y, int width, int height, boolean compact) {
        selectedModel = selectedModel == null ? LocalSkinManager.getActiveModel() : selectedModel;
        boolean eligible = LocalSkinManager.isActiveAppearanceProfile();
        if (compact) {
            int previewPanelHeight = Math.min(180, Math.max(150, height / 3));
            drawSkinPreviewPanel(x, y, width, previewPanelHeight, true, eligible);
            drawSkinControls(x, y + previewPanelHeight + 10, width,
                    height - previewPanelHeight - 10, eligible);
            return;
        }
        int previewPanelWidth = 318;
        drawSkinPreviewPanel(x, y, previewPanelWidth, height, false, eligible);
        drawSkinControls(x + previewPanelWidth + 10, y,
                width - previewPanelWidth - 10, height, eligible);
    }

    private void drawSkinPreviewPanel(int x, int y, int width, int height,
            boolean compact, boolean eligible) {
        boolean local = LocalSkinManager.isActiveLocalAccount();
        boolean offline = LocalSkinManager.isActiveLauncherOfflineProfile();
        String profileLabel = local ? "CS LOCAL PROFILE"
                : offline ? "LAUNCHER OFFLINE PROFILE"
                        : eligible ? "LAUNCHER PROFILE" : "PROFILE UNAVAILABLE";
        draw(new Panel(0xE710151B).dimensions(width, height).position(x, y).animation(pop(0)));
        draw(new Text("APPEARANCE STUDIO").scale(0.52f).position(x + 14, y + 14)
                .animation(slide(-7, 24)));
        draw(new Text("LIVE 3D PREVIEW  •  DRAG TO ROTATE  •  CLIENT-SIDE ONLY")
                .scale(0.26f).position(x + 15, y + 39).animation(fade(42)));

        if (compact) {
            previewX = x + 16;
            previewY = y + 58;
            previewWidth = Math.min(210, width / 3);
            previewHeight = height - 70;
            draw(new Panel(0xCF090D11).dimensions(previewWidth, previewHeight)
                    .position(previewX, previewY).animation(pop(45)));
            int infoX = previewX + previewWidth + 16;
            draw(new Text(profileLabel).scale(0.35f).position(infoX, y + 62)
                    .animation(slide(-6, 65)));
            draw(new Text(eligible ? "Local skin and cape are available for this profile."
                    : "A valid launcher or CS local profile is required.")
                    .scale(0.28f).position(infoX, y + 85).animation(fade(82)));
            if (eligible) {
                draw(new SkinModelSelector(() -> selectedModel, this::changeModel)
                        .dimensions(Math.min(250, width - (infoX - x) - 16), 38)
                        .position(infoX, y + height - 54).animation(slide(7, 100)));
            }
            return;
        }

        previewX = x + 20;
        previewY = y + 60;
        previewWidth = width - 40;
        previewHeight = Math.min(258, Math.max(172, height - 282));
        draw(new Panel(0xCF090D11).dimensions(previewWidth, previewHeight)
                .position(previewX, previewY).animation(pop(48)));

        int modelY = previewY + previewHeight + 14;
        draw(new Text("BODY MODEL").scale(0.27f).position(x + 20, modelY).animation(fade(70)));
        draw(new SkinModelSelector(() -> selectedModel, this::changeModel)
                .dimensions(width - 40, 38).position(x + 20, modelY + 16)
                .animation(slide(7, 82)));

        int cardY = modelY + 64;
        int cardHeight = Math.max(126, height - (cardY - y) - 16);
        draw(new AppearanceProfileCard(
                () -> Providers.csClient.getClient().getUsername(),
                LocalSkinManager::isActiveLocalAccount,
                LocalSkinManager::isActiveLauncherOfflineProfile,
                LocalSkinManager::getActiveRecord,
                LocalSkinManager::getActiveCapeRecord,
                LocalSkinManager::getActiveProfileStorageLabel)
                .dimensions(width - 40, cardHeight).position(x + 20, cardY).animation(pop(104)));
    }

    private void drawSkinControls(int x, int y, int width, int height, boolean eligible) {
        boolean local = LocalSkinManager.isActiveLocalAccount();
        boolean offline = LocalSkinManager.isActiveLauncherOfflineProfile();
        draw(new Panel(0xE710151B).dimensions(width, height).position(x, y).animation(pop(18)));
        draw(new Text("APPEARANCE SOURCES").scale(0.62f).position(x + 14, y + 14)
                .animation(slide(-8, 28)));
        draw(new Text("PROFILE-LOCAL  •  SECURE IMPORT  •  SKIN + CAPE")
                .scale(0.28f).position(x + 15, y + 42).animation(fade(45)));

        String state = local ? "CS LOCAL PROFILE"
                : offline ? "LAUNCHER OFFLINE PROFILE"
                        : eligible ? "LAUNCHER PROFILE • LOCAL APPEARANCE READY" : "PROFILE UNAVAILABLE";
        int stateColor = eligible ? Theme.ACCENT.value : 0xFFE07581;
        draw(new Panel(Theme.withAlpha(eligible ? 170 : 130, stateColor)).dimensions(width - 28, 24)
                .position(x + 14, y + 61).animation(slide(7, 55)));
        draw(new Text(state).scale(0.27f).position(x + 24, y + 69).animation(fade(68)));

        if (!eligible) {
            int centerX = x + width / 2;
            draw(new Panel(0xD0181D23).dimensions(Math.min(460, width - 48), 202)
                    .position(centerX - Math.min(460, width - 48) / 2, y + 106).animation(pop(80)));
            draw(new ImageTexture(Textures.LOCK).dimensions(34, 34).position(centerX - 17, y + 126)
                    .animation(pop(100)));
            draw(new Text("PROFILE UNAVAILABLE").scale(0.56f).position(centerX - 94, y + 172)
                    .animation(slide(-6, 115)));
            draw(new Text("CS never reads or stores launcher credentials.")
                    .scale(0.32f).position(centerX - 145, y + 204).animation(fade(132)));
            draw(new Text("Use any valid launcher profile or create a CS local profile.")
                    .scale(0.32f).position(centerX - 170, y + 224).animation(fade(148)));
            draw(new HomeMenuButton(Textures.ACCOUNTS, "GO TO ACCOUNTS", false,
                    () -> switchTab(Tab.ACCOUNTS)).dimensions(210, 38)
                    .position(centerX - 105, y + 252).animation(slide(7, 165)));
            return;
        }

        int scrollY = y + 96;
        int scrollHeight = Math.max(150, height - 146);
        Scroll controls = new Scroll(10);
        controls.dimensions(width - 16, scrollHeight).position(x + 8, scrollY);
        draw(controls);
        int rowWidth = width - 36;
        int actionWidth = 108;
        int fieldWidth = Math.min(380, Math.max(170, rowWidth - 350));
        int controlX = Math.max(178, rowWidth - fieldWidth - actionWidth - 20);
        fieldWidth = Math.max(130, rowWidth - controlX - actionWidth - 20);

        int rowY = 0;
        skinPlayerField = addSkinSourceRow(controls, rowWidth, rowY, Textures.PROFILE,
                "PLAYER USERNAME", "Copies public Mojang skin and the player's active official cape.",
                "Minecraft username", 16,
                c -> Character.isLetterOrDigit(c) || c == '_', controlX, fieldWidth,
                () -> runSkinOperation("Fetching Mojang skin and official cape…",
                        LocalSkinManager.applyFromUsername(skinPlayerField.getValue())), 92);
        rowY += 66;
        skinUrlField = addSkinSourceRow(controls, rowWidth, rowY, Textures.LINK,
                "DIRECT SKIN URL", "Public HTTP(S) only; private/local addresses remain blocked.",
                "https://example.com/skin.png", 768,
                c -> !Character.isISOControl(c), controlX, fieldWidth,
                () -> runSkinOperation("Downloading and validating the skin PNG…",
                        LocalSkinManager.applyFromUrl(skinUrlField.getValue(), selectedModel)), 108);
        rowY += 66;

        int pickerX = Math.max(178, rowWidth - 194);
        controls.draw(new ModuleSettingRow("SELECT SKIN PNG",
                "Device file chooser • exactly 64×64 • validated before save.",
                Textures.IMAGE, rowWidth - pickerX + 10).dimensions(rowWidth, 58).position(0, rowY)
                .animation(slide(-6, 124)));
        controls.draw(new HomeMenuButton(Textures.FOLDER, "CHOOSE SKIN PNG", false, this::openSkinPicker)
                .dimensions(184, 36).position(pickerX, rowY + 11).animation(slide(7, 132)));
        rowY += 66;

        controls.draw(new ModuleSettingRow("SELECT CAPE PNG",
                "Client cape + matching elytra • exactly 64×32.",
                Textures.CAPE, rowWidth - pickerX + 10).dimensions(rowWidth, 58).position(0, rowY)
                .animation(slide(-6, 140)));
        controls.draw(new HomeMenuButton(Textures.FOLDER, "CHOOSE CAPE PNG", false, this::openCapePicker)
                .dimensions(184, 36).position(pickerX, rowY + 11).animation(slide(7, 148)));
        rowY += 72;

        int resetGap = 7;
        int resetWidth = Math.max(104, (rowWidth - resetGap * 2) / 3);
        controls.draw(new HomeMenuButton(Textures.RESET, "RESET SKIN", false,
                () -> runSkinOperation("Restoring the session skin…", LocalSkinManager.resetActiveSkin()))
                .dimensions(resetWidth, 38).position(0, rowY).animation(slide(-5, 164)));
        controls.draw(new HomeMenuButton(Textures.RESET, "RESET CAPE", false,
                () -> runSkinOperation("Restoring the session cape…", LocalSkinManager.resetActiveCape()))
                .dimensions(resetWidth, 38).position(resetWidth + resetGap, rowY).animation(fade(172)));
        controls.draw(new HomeMenuButton(Textures.RESET, "RESET ALL", false,
                () -> runSkinOperation("Restoring the complete session appearance…",
                        LocalSkinManager.resetActiveAppearance()))
                .dimensions(resetWidth, 38).position((resetWidth + resetGap) * 2, rowY)
                .animation(slide(5, 180)));
        rowY += 48;
        controls.draw(new Text("Client-only: other players still see the server/Mojang appearance.")
                .scale(0.29f).position(4, rowY).animation(fade(194)));
        controls.draw(new Text("Saved in CS " + LocalSkinManager.getActiveProfileStorageLabel())
                .scale(0.25f).position(4, rowY + 17).animation(fade(204)));
        controls.draw(new Panel(0x0012161C).dimensions(1, rowY + 42).position(0, 0));

        draw(new SkinStatusBadge(() -> status, () -> operationRunning, () -> statusSuccess)
                .dimensions(width - 24, 34).position(x + 12, y + height - 42).animation(pop(80)));
    }

    private TextFieldElement addSkinSourceRow(Scroll controls, int rowWidth, int rowY,
            com.craftstudio.csclient.common.ref.asset.IdentifierRef icon, String title, String hint,
            String placeholder, int maxLength, java.util.function.Predicate<Character> filter,
            int controlX, int fieldWidth, Runnable action, int delay) {
        int actionWidth = 108;
        controls.draw(new ModuleSettingRow(title, hint, icon,
                rowWidth - controlX + 10).dimensions(rowWidth, 58).position(0, rowY)
                .animation(slide(-6, delay)));
        TextFieldElement field = new TextFieldElement(placeholder, maxLength, filter,
                value -> { }, action, null);
        field.dimensions(fieldWidth, 36).position(controlX, rowY + 11);
        field.animation(slide(6, delay + 8));
        controls.draw(field);
        controls.draw(new HomeMenuButton(null, "APPLY", false, action)
                .dimensions(actionWidth, 36).position(controlX + fieldWidth + 8, rowY + 11)
                .animation(slide(7, delay + 14)));
        return field;
    }

    private void openSkinPicker() {
        statusSuccess = true;
        status = "Opening the device PNG chooser…";
        boolean opened = Providers.csClient.getClient().openNativePngPicker("Choose 64×64 Skin PNG", path -> {
            if (path == null) {
                statusSuccess = false;
                status = "No skin PNG was selected or the platform chooser is unavailable.";
                return;
            }
            importSelectedSkin(path);
        });
        if (!opened) {
            statusSuccess = false;
            status = "The native device file chooser is unavailable in this launcher build.";
        }
    }

    private void openCapePicker() {
        statusSuccess = true;
        status = "Opening the device PNG chooser…";
        boolean opened = Providers.csClient.getClient().openNativePngPicker("Choose 64×32 Cape PNG", path -> {
            if (path == null) {
                statusSuccess = false;
                status = "No cape PNG was selected or the platform chooser is unavailable.";
                return;
            }
            importSelectedCape(path);
        });
        if (!opened) {
            statusSuccess = false;
            status = "The native device file chooser is unavailable in this launcher build.";
        }
    }

    private void importSelectedSkin(Path path) {
        runSkinOperation("Reading and validating the selected 64×64 skin…",
                LocalSkinManager.applyFromFile(path, selectedModel));
    }

    private void importSelectedCape(Path path) {
        runSkinOperation("Reading and validating the selected 64×32 cape…",
                LocalSkinManager.applyCapeFromFile(path));
    }

    private void addAccount() {
        if (usernameField == null) return;
        String username = usernameField.getValue();
        String error = LocalAccountManager.add(username);
        statusSuccess = error == null;
        status = error == null ? "Added local profile " + username.trim() + "." : error;
        if (error == null) usernameField.clear();
        rebuildAccounts();
    }

    private void rebuildAccounts() {
        if (accountScroll == null) return;
        accountScroll.clearChildren();
        List<LocalAccount> accounts = LocalAccountManager.getAccounts();
        UUID currentUuid = Providers.csClient.getClient().getUuid();
        int rowWidth = listWidth - 20;
        if (accounts.isEmpty()) {
            accountScroll.draw(new Text("NO LOCAL PROFILES YET").scale(0.50f).position(18, 24));
            accountScroll.draw(new Text("Create one above. No password, cookie, or access token is requested.")
                    .scale(0.34f).position(18, 50));
            return;
        }
        int rowY = 0;
        for (LocalAccount account : accounts) {
            boolean active = account.uuid().equals(currentUuid);
            LocalAccountCard card = new LocalAccountCard(account, active,
                    () -> switchAccount(account), () -> deleteAccount(account));
            card.dimensions(rowWidth, 62).position(0, rowY)
                    .animation(new SlideFade(AnimationConfig.accountMenu, -8));
            accountScroll.draw(card);
            rowY += 70;
        }
        accountScroll.draw(new Panel(0x0012161C).dimensions(1, Math.max(1, rowY)).position(0, 0));
    }

    private void switchAccount(LocalAccount account) {
        boolean switched = Providers.csClient.getClient().switchLocalAccount(account.username(), account.uuid());
        if (switched) {
            LocalAccountManager.markUsed(account.uuid());
            LocalSkinManager.activateForCurrentAccount();
            Providers.csClient.getClient().setScreen(parent);
        } else {
            statusSuccess = false;
            status = "Return to the title screen before switching local profiles.";
            rebuildAccounts();
        }
    }

    private void deleteAccount(LocalAccount account) {
        if (account.uuid().equals(Providers.csClient.getClient().getUuid())) {
            statusSuccess = false;
            status = "Switch profiles before deleting the active local identity.";
            return;
        }
        LocalSkinManager.remove(account.uuid());
        LocalAccountManager.remove(account.uuid());
        statusSuccess = true;
        status = "Removed " + account.username() + " and its optional local skin/cape.";
        rebuildAccounts();
    }

    private void changeModel(String model) {
        selectedModel = LocalSkinManager.SLIM.equalsIgnoreCase(model)
                ? LocalSkinManager.SLIM : LocalSkinManager.CLASSIC;
        SkinRecord record = LocalSkinManager.getActiveRecord();
        if (record == null) {
            statusSuccess = true;
            status = "Selected " + selectedModel + " for the next URL/file skin.";
            return;
        }
        runSkinOperation("Updating the 3D model…", LocalSkinManager.setActiveModel(selectedModel));
    }

    private void runSkinOperation(String loading, CompletableFuture<SkinResult> future) {
        if (operationRunning) return;
        operationRunning = true;
        statusSuccess = true;
        status = loading;
        future.thenAccept(result -> Providers.csClient.getClient().executeOnThread(() -> {
            operationRunning = false;
            statusSuccess = result.success();
            status = result.message();
            if (result.success()) selectedModel = LocalSkinManager.getActiveModel();
        }));
    }

    private static PopFade pop(int delay) {
        PopFade value = new PopFade(AnimationConfig.accountMenu);
        value.delay = delay;
        return value;
    }

    private static SlideFade slide(int offset, int delay) {
        SlideFade value = new SlideFade(AnimationConfig.accountMenu, offset);
        value.delay = delay;
        return value;
    }

    private static Fade fade(int delay) {
        Fade value = new Fade(AnimationConfig.accountMenu);
        value.delay = delay;
        return value;
    }

    private void switchTab(Tab target) {
        Providers.csClient.getClient().setScreen(new LocalAccountsScreen(target, parent));
    }

    private void goBack() {
        Providers.csClient.getClient().setScreen(parent);
    }

    public boolean showsNativeSkinPreview() {
        return tab == Tab.SKIN && previewWidth > 0 && previewHeight > 0;
    }

    public int getSkinPreviewX() { return previewX; }
    public int getSkinPreviewY() { return previewY; }
    public int getSkinPreviewWidth() { return previewWidth; }
    public int getSkinPreviewHeight() { return previewHeight; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            goBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
