package com.craftstudio.csclient.ui.components.inputs;

import com.craftstudio.csclient.config.property.StringProperty;

public class StringInput extends Input {
    private final StringProperty prop;

    public StringInput(StringProperty prop) {
        this.prop = prop;
        this.width = 210;
        this.height = 30;
        this.text = prop.value;
        this.cursorPosition = text.length();
    }

    @Override
    public void charTyped(char chr) {
        if (Character.isISOControl(chr) || text.length() >= 80) return;
        text = text.substring(0, cursorPosition) + chr + text.substring(cursorPosition);
        cursorPosition++;
        prop.value = text;
        // Persist immediately: saved values (e.g. server IP) must survive
        // relaunches even when the game is closed without a clean exit.
        com.craftstudio.csclient.config.ConfigManager.save();
    }

    @Override
    public void backspace() {
        prop.value = text;
        com.craftstudio.csclient.config.ConfigManager.save();
    }

    @Override
    public void checkReset() {
        if (prop.isReset) {
            text = prop.value;
            cursorPosition = text.length();
            prop.isReset = false;
        }
    }
}
