package com.craftstudio.csclient.mod;

import java.util.ArrayList;
import java.util.List;

import com.craftstudio.csclient.mod.mods.*;
import com.craftstudio.csclient.account.LocalSkinManager;

public class ModManager {
    /** Pre-resolved array removes iterator/type/layout lookup work from every rendered frame. */
    public record RenderEntry(Mod mod, HudMod hud, ModLayout layout) { }
    public static volatile List<Mod> ENABLED_MODS = List.of();
    public static volatile RenderEntry[] RENDER_ENTRIES = new RenderEntry[0];
    public static final List<Mod> MODS = new ArrayList<>(List.of(
            new ArmorDisplayMod(), new DayCounterMod(), new KeystrokesMod(), new StatusEffectsMod(),
            new AutoSprintMod(), new FpsMod(), new PerformanceBoostMod(), new NametagsMod(), new ClientBrandingMod(), new TpsMod(),
            new ClockMod(), new FreelookMod(), new NoFogMod(), new ZoomMod(),
            new CoordinatesMod(), new FullbrightMod(), new PingMod(),
            new CrosshairMod(), new HealthDisplayMod(), new SpeedometerMod(),

            // CS Client competitive and utility expansion.
            new CpsDisplayMod(), new ComboCounterMod(), new ShieldStatusesMod(),
            new DirectionDisplayMod(), new MemoryUsageMod(), new MovementStatusMod(),
            new DistanceTrackerMod(), new TargetIndicatorMod(), new ConnectionStatusMod(),
            new ChunkPositionMod(), new StopwatchMod(),
            new PerspectiveToggleMod(),

            // Feather/Lunar-inspired displays and overlays.
            new SaturationDisplayMod(), new ScoreboardMod(), new HitIndicatorMod(),
            new HitboxMod(), new ReachDisplayMod(), new ItemCounterMod(),
            new ItemInfoMod(), new BlockOverlayMod(), new BlockBreakAnimationMod(), new BossBarMod(),
            new AttackCooldownMod(), new TntTimerMod(),
            new ServerAddressMod(), new TotemCounterMod(),

            // Feather-style visibility, inventory and world-information expansion.
            new LowFireMod(), new LowShieldMod(), new ClearFluidsMod(), new RemoveShakeMod(), new AutoGGMod(), new ShulkerPreviewMod(),
            new ChatEnhancementsMod(), new ScreenshotManagerMod(),
            new BlockInfoMod(), new MinimapMod(), new InventoryHudMod()));

    public static void init() {
        MODS.removeIf(mod -> !mod.isSupported());
        updateEnabledModules();
    }

    public static synchronized void updateEnabledModules() {
        List<Mod> enabled = new ArrayList<>();
        for (Mod mod : MODS) {
            if (mod.isEnabled()) enabled.add(mod);
        }

        // Place only new/unpositioned widgets. Existing user positions reserve
        // space, so enabling modules one-by-one never stacks everything at 0,0.
        List<int[]> occupied = new ArrayList<>();
        for (Mod mod : enabled) {
            if (mod instanceof HudMod hud) {
                ModLayout l = hud.getDimensions();
                if (l.x.value != 0 || l.y.value != 0) {
                    occupied.add(rect(l));
                }
            }
        }

        for (Mod mod : enabled) {
            if (!(mod instanceof HudMod hud) || hud.usesNativeDefaultPosition()) continue;
            ModLayout l = hud.getDimensions();
            if (l.x.value != 0 || l.y.value != 0) continue;
            if (Math.abs(l.scale.value - 1.0f) < 0.001f) l.scale.value = 0.75f;

            int w = Math.max(24, Math.round(l.width * l.scale.value)) + 7;
            int h = Math.max(14, Math.round(l.height * l.scale.value)) + 7;
            int foundX = 8;
            int foundY = 40;
            boolean found = false;
            for (int y = 40; y <= 220 - h && !found; y += 8) {
                for (int x = 8; x <= 420 - w; x += 8) {
                    int[] candidate = {x, y, w, h};
                    if (occupied.stream().noneMatch(other -> overlaps(candidate, other))) {
                        foundX = x;
                        foundY = y;
                        found = true;
                        break;
                    }
                }
            }
            l.x.value = foundX;
            l.y.value = foundY;
            occupied.add(new int[] {foundX, foundY, w, h});
        }
        // Immutable snapshot: render/tick loops can iterate without allocating a
        // defensive ArrayList every frame.
        ENABLED_MODS = List.copyOf(enabled);
        RenderEntry[] entries = new RenderEntry[enabled.size()];
        for (int i = 0; i < enabled.size(); i++) {
            Mod mod = enabled.get(i);
            HudMod hud = mod instanceof HudMod value ? value : null;
            entries[i] = new RenderEntry(mod, hud, hud == null ? null : hud.getDimensions());
        }
        RENDER_ENTRIES = entries;
    }

    private static int[] rect(ModLayout l) {
        return new int[] {
                l.x.value, l.y.value,
                Math.max(24, Math.round(l.width * l.scale.value)) + 7,
                Math.max(14, Math.round(l.height * l.scale.value)) + 7
        };
    }

    private static boolean overlaps(int[] a, int[] b) {
        return a[0] < b[0] + b[2] && a[0] + a[2] > b[0]
                && a[1] < b[1] + b[3] && a[1] + a[3] > b[1];
    }

    /** Processes global module keybinds and then ticks enabled modules. */
    public static void tick() {
        LocalSkinManager.tickExternalSync();
        for (Mod mod : MODS) {
            if (ModRuntimeGuard.isQuarantined(mod)) continue;
            try {
                mod.handleGlobalKeybind();
            } catch (LinkageError | RuntimeException failure) {
                ModRuntimeGuard.quarantine(mod, "keybind", failure);
            }
        }

        // Volatile immutable snapshot: keybind updates replace the list atomically.
        List<Mod> enabled = ENABLED_MODS;
        for (Mod mod : enabled) {
            if (ModRuntimeGuard.isQuarantined(mod)) continue;
            try {
                mod.tick();
            } catch (LinkageError | RuntimeException failure) {
                ModRuntimeGuard.quarantine(mod, "tick", failure);
            }
        }
    }
}
