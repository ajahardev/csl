package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.Fade;
import com.craftstudio.csclient.ui.anim.PopFade;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.ImageTexture;
import com.craftstudio.csclient.ui.elements.QuickPopupSurface;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

/** Local placeholder for a fixed Home server slot; it never performs a network action. */
public final class ServerComingSoonScreen extends CSClientScreen {
    private final CSClientScreen parent;
    private final FeaturedServers.Slot slot;

    public ServerComingSoonScreen(CSClientScreen parent, FeaturedServers.Slot slot) {
        super("CS Client V1 — Server Coming Soon");
        this.parent = parent == null ? new TitleMenu() : parent;
        this.slot = slot;
        backgroundBlur = 1;
        backgroundOpacity = 0.34f;
    }

    @Override
    public void ui() {
        int panelWidth = Math.min(354, width - 30);
        int panelHeight = 218;
        int x = (width - panelWidth) / 2;
        int y = Math.max(14, (height - panelHeight) / 2);
        int accent = Theme.ACCENT.value;

        draw(new QuickPopupSurface(accent).dimensions(panelWidth, panelHeight).position(x, y)
                .animation(pop(0)));
        draw(new ImageTexture(Textures.SERVER_SLOT).dimensions(39, 39).position(x + 28, y + 24)
                .animation(pop(32)));
        draw(new Text("CS SERVERS").scale(0.70f).position(x + 82, y + 25)
                .animation(slide(-7, 42)));
        draw(new Text("COMING SOON").color(accent).scale(0.31f).position(x + 83, y + 53)
                .animation(fade(58)));

        draw(new Text(slot.name()).scale(0.40f).position(x + 28, y + 91)
                .animation(slide(-5, 76)));
        draw(new Text("This fixed server slot is being prepared.").scale(0.29f)
                .position(x + 28, y + 116).animation(fade(92)));
        draw(new Text("NO CONNECTION  •  NO PING  •  NO REMOTE LIST").color(accent).scale(0.25f)
                .position(x + 28, y + 139).animation(fade(106)));

        draw(new HomeMenuButton(Textures.BACK, "BACK TO HOME", false, this::goBack)
                .dimensions(panelWidth - 56, 38).position(x + 28, y + 166)
                .animation(slide(8, 120)));
    }

    private void goBack() {
        Providers.csClient.getClient().setScreen(parent);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            goBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private static PopFade pop(int delay) {
        PopFade value = new PopFade(AnimationConfig.mainMenu);
        value.delay = delay;
        return value;
    }

    private static SlideFade slide(int offset, int delay) {
        SlideFade value = new SlideFade(AnimationConfig.mainMenu, offset);
        value.delay = delay;
        return value;
    }

    private static Fade fade(int delay) {
        Fade value = new Fade(AnimationConfig.mainMenu);
        value.delay = delay;
        return value;
    }
}
