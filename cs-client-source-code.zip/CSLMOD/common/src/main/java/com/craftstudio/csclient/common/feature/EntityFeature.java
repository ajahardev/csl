package com.craftstudio.csclient.common.feature;

/**
 * EntityFeature provides queries about entities in the current world.
 *
 * Designed to be thin so that feature logic is not polluted with
 * engine-specific entity types.
 */
public interface EntityFeature {

    // ---------------------------------------------------------------
    // Crosshair / targeting
    // ---------------------------------------------------------------

    /** Returns true when the player's crosshair is aimed at a living entity. */
    boolean isTargetingLivingEntity();

    /** Distance from the local player's eyes/body to the targeted living entity. */
    default double getTargetDistance() {
        return 0.0;
    }

    // ---------------------------------------------------------------
    // Nametag entity state
    // ---------------------------------------------------------------

    /**
     * Represents the minimal observable state of an entity needed for
     * nametag rendering. Implementations are created per-entity each
     * frame; they are intentionally not cached.
     */
    public static interface EntityState {

        /** The entity's display name, or {@code null} if it has none. */
        String getCustomName();

        float getHealth();

        float getMaxHealth();

        EntityType getEntityType();
    }

    public static enum EntityType {
        PLAYER,
        HOSTILE,
        PASSIVE,
        OTHER
    }
}
