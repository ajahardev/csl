package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.mod.ModSpec;

/** Current server address / singleplayer indicator. */
public class ServerAddressMod extends TextHudMod {
    public ServerAddressMod() {
        super(new ModSpec("Server Address", "serveraddress")
                .description("Shows the current server address")
                .version("v1.0.0").tags("Server", "HUD")
                .requires(Providers.feature::player), 132);
    }
    @Override protected String getText() { return "SERVER  " + Providers.feature.player().getServerAddress(); }
    @Override protected String getDummyText() { return "SERVER  play.example.net"; }
}
