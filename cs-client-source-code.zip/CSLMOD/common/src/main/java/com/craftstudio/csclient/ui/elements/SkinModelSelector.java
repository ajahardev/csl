package com.craftstudio.csclient.ui.elements;

import java.util.function.Consumer;
import java.util.function.Supplier;

import com.craftstudio.csclient.account.LocalSkinManager;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Classic/Slim segmented selector with two touch-sized halves. */
public class SkinModelSelector extends Element {
    private final Supplier<String> value;
    private final Consumer<String> onChange;
    private float classicProgress;
    private float slimProgress;

    public SkinModelSelector(Supplier<String> value, Consumer<String> onChange) {
        this.value = value;
        this.onChange = onChange;
        dimensions(236, 38);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        boolean slim = LocalSkinManager.SLIM.equalsIgnoreCase(value.get());
        classicProgress += ((slim ? 0f : 1f) - classicProgress) * 0.24f;
        slimProgress += ((slim ? 1f : 0f) - slimProgress) * 0.24f;
        int half = width / 2;
        scope.drawRoundedRectangle(0, 0, width, height, 6, 0xE3171C22);
        scope.drawRoundedRectangle(3, 3, half - 5, height - 6, 5,
                blend(0x00171C22, Theme.ACCENT.value, classicProgress));
        scope.drawRoundedRectangle(half + 2, 3, half - 5, height - 6, 5,
                blend(0x00171C22, Theme.ACCENT.value, slimProgress));
        scope.drawRoundedBorder(0, 0, width, height, 6, Theme.withAlpha(110, Theme.ACCENT.value));
        scope.drawText(0.43f, "CLASSIC", 24, 15, Theme.FONT.value,
                blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, classicProgress));
        scope.drawText(0.43f, "SLIM", half + 39, 15, Theme.FONT.value,
                blend(Theme.PRIMARY_FG.value, Theme.ACCENT_FG.value, slimProgress));
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onChange != null) onChange.accept(mouseX < width / 2
                ? LocalSkinManager.CLASSIC : LocalSkinManager.SLIM);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
