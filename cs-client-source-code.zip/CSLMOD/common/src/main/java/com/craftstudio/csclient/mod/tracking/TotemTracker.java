package com.craftstudio.csclient.mod.tracking;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Tracks observable totem-pop entity events for the current play session. */
public final class TotemTracker {
    private static final Map<UUID, Integer> POPS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_POP_NANOS = new ConcurrentHashMap<>();
    private static final long DUPLICATE_WINDOW_NANOS = 500_000_000L;
    private static volatile UUID localPlayer;
    private static volatile UUID latestOpponent;
    private static volatile String latestOpponentName = "OPPONENT";
    private static volatile long latestPopTime;

    private TotemTracker() {
    }

    public static void recordPop(UUID uuid, String name, boolean local) {
        if (uuid == null) return;
        long nowNanos = System.nanoTime();
        Long previous = LAST_POP_NANOS.put(uuid, nowNanos);
        // Some protocol/mod stacks surface the same status event twice. A real
        // second totem use cannot occur inside this short vanilla-safe window.
        if (previous != null && nowNanos - previous < DUPLICATE_WINDOW_NANOS) return;
        POPS.merge(uuid, 1, Integer::sum);
        if (local) {
            localPlayer = uuid;
        } else {
            latestOpponent = uuid;
            latestOpponentName = name == null || name.isBlank() ? "OPPONENT" : name;
        }
        latestPopTime = System.currentTimeMillis();
    }

    public static int getPops(UUID uuid) {
        return uuid == null ? 0 : POPS.getOrDefault(uuid, 0);
    }

    public static int getLocalPops() {
        return getPops(localPlayer);
    }

    public static int getLatestOpponentPops() {
        return getPops(latestOpponent);
    }

    public static String getLatestOpponentName() {
        return latestOpponentName;
    }

    public static long getLatestPopTime() {
        return latestPopTime;
    }

    public static void resetPlayer(UUID uuid) {
        if (uuid == null) return;
        POPS.remove(uuid);
        LAST_POP_NANOS.remove(uuid);
        if (uuid.equals(latestOpponent)) {
            latestOpponent = null;
            latestOpponentName = "OPPONENT";
        }
        if (uuid.equals(localPlayer)) localPlayer = null;
    }

    public static void reset() {
        POPS.clear();
        LAST_POP_NANOS.clear();
        localPlayer = null;
        latestOpponent = null;
        latestOpponentName = "OPPONENT";
        latestPopTime = 0L;
    }
}
