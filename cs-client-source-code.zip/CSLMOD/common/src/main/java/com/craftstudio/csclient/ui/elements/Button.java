package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/**
 * Rounded glass button with a complete animated outline.
 *
 * The animation only changes a few cached rounded surfaces; it does not create
 * per-pixel geometry and therefore stays inexpensive on the title and pause
 * screens.
 */
public class Button extends Element {
    private final String text;
    private final Runnable onClick;
    private final int phase;
    private float hoverProgress;

    public Button(String text, Runnable onClick) {
        this.text = text;
        this.onClick = onClick;
        this.phase = Math.abs(text.hashCode() % 900);
        this.dimensions(Fonts.getWidth(text, Theme.FONT.value) + 50, 38);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1.0f : 0.0f;
        hoverProgress += (target - hoverProgress) * 0.19f;
        if (Math.abs(target - hoverProgress) < 0.002f) hoverProgress = target;

        float breathe = (float) ((Math.sin((System.currentTimeMillis() + phase) / 760.0) + 1.0) * 0.5);
        int expand = hoverProgress > 0.08f ? Math.max(1, Math.round(hoverProgress * 2f)) : 0;
        int radius = Math.max(10, Theme.WIDGET_RADIUS.value + 4);

        int idleOutline = withAlpha(96 + Math.round(24 * breathe), Theme.ACCENT.value);
        int outline = blend(idleOutline, 0xFFE8EDF2, hoverProgress);
        int base = blend(0x2411161C, 0x882A313A, hoverProgress);
        int foreground = blend(0xFFE1E5EA, 0xFFFFFFFF, hoverProgress);

        // True rounded ring: outline never paints over the glass interior.
        scope.drawRoundedRectangle(-expand, -expand, width + expand * 2, height + expand * 2,
                radius + expand, base);
        scope.drawRoundedBorder(-expand, -expand, width + expand * 2, height + expand * 2,
                radius + expand, outline);

        // Animated accent rail grows from the center while hovering.
        if (hoverProgress > 0.01f) {
            int railWidth = Math.max(2, Math.round((width - 28) * hoverProgress));
            int railX = (width - railWidth) / 2;
            scope.drawRoundedRectangle(railX, height - 4, railWidth, 2, 1,
                    withAlpha(Math.round(225 * hoverProgress), Theme.ACCENT.value));
        }

        // Small leading status point gives every action its own motion cue.
        int dotAlpha = 105 + Math.round(120 * hoverProgress);
        int dotSize = hoverProgress > 0.55f ? 4 : 3;
        scope.drawRoundedRectangle(13, (height - dotSize) / 2, dotSize, dotSize, dotSize,
                withAlpha(dotAlpha, Theme.ACCENT.value));

        int lift = hoverProgress > 0.5f ? -1 : 0;
        scope.drawText(text, Fonts.centerX(width, text, Theme.FONT.value),
                Fonts.centerY(height) + lift, Theme.FONT.value, foreground);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int withAlpha(int alpha, int color) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0, Math.min(1, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
