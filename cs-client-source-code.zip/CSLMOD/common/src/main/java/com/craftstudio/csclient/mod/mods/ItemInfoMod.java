package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.ItemStackRef;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Compact Feather-style held-item name, enchant and durability display. */
public class ItemInfoMod extends Mod implements HudMod {
    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty showDurability = Property.bool(true);
    private static final BoolProperty showEnchanted = Property.bool(true);
    private static final ModLayout layout = new ModLayout(126, 27);

    public ItemInfoMod() {
        super(new ModSpec("Item Info", "iteminfo")
                        .description("Shows held item name, enchant state and durability")
                        .version("v1.0.0").tags("HUD", "Utility")
                        .requires(Providers.feature::player),
                enabled.named("Enabled"),
                showDurability.named("Show durability"),
                showEnchanted.named("Show enchanted"),
                layout.prop());
    }

    @Override public boolean shouldRenderHud() { return !Providers.feature.player().getMainHand().isEmpty(); }
    @Override public void renderHud(RenderScope scope) { draw(scope, Providers.feature.player().getMainHand()); }
    @Override public void renderDummy(RenderScope scope) { draw(scope, Providers.feature.player().getDummyMainHand()); }

    private void draw(RenderScope scope, ItemStackRef stack) {
        if (!stack.isEmpty()) scope.drawItem(stack, 5, 5);
        String name = stack.isEmpty() ? "EMPTY HAND" : stack.getItemName();
        if (showEnchanted.value && stack.isEnchanted()) name = "✦ " + name;
        String detail = "";
        if (showDurability.value && stack.getMaxDamage() > 0) {
            detail = (stack.getMaxDamage() - stack.getDamage()) + " / " + stack.getMaxDamage();
        } else if (!stack.isEmpty()) {
            detail = "COUNT  " + stack.getCount();
        }
        scope.drawText(0.48f, name, 27, 4, layout.font.value, layout.fgColor.value);
        scope.drawText(0.36f, detail, 27, 16, layout.font.value, 0xFF9EA5AD);
        layout.width = Math.max(112, 34 + (int) (Fonts.getWidth(name, layout.font.value) * 0.48f));
        layout.height = 27;
    }

    @Override public ModLayout getDimensions() { return layout; }
    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
