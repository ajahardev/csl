package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/** Badlion-inspired custom crosshair with target highlighting and attack animation. */
public class CrosshairMod extends Mod {
    public static final BoolProperty enabled = Property.bool(false);
    private static final SelectProperty style = Property.select(1, "Dot", "Cross", "Brackets", "T-Shape");
    private static final IntProperty length = Property.integer(5);
    private static final IntProperty gap = Property.integer(3);
    private static final IntProperty thickness = Property.integer(1);
    private static final ColorProperty normalColor = Property.color(0xFFFFFFFF);
    private static final ColorProperty targetColor = Property.color(0xFF70E58B);
    private static final BoolProperty targetHighlight = Property.bool(true);
    private static final BoolProperty dynamicAttack = Property.bool(true);
    private float animation;
    private float velocity;

    public CrosshairMod() {
        super(new ModSpec("Custom Crosshair", "crosshair")
                        .description("Preset crosshairs, colors, target highlight and attack animation")
                        .tags("Visuals", "PvP").version("v1.0.0")
                        .requires(Providers.feature::player, Providers.feature::render, Providers.feature::entity),
                enabled.named("Enabled"), style.named("Crosshair style"),
                length.named("Line length"), gap.named("Center gap"), thickness.named("Thickness"),
                normalColor.named("Normal color"), targetColor.named("Target color"),
                targetHighlight.named("Highlight attackable target"),
                dynamicAttack.named("Dynamic attack animation"));
    }

    public static boolean shouldReplaceVanilla() { return enabled.value; }

    @Override
    public void tick() {
        float target = dynamicAttack.value && Providers.feature.player().isAttackPressed() ? 1.0f : 0.0f;
        velocity += (target - animation) * 0.38f;
        velocity *= 0.62f;
        animation += velocity;
        animation = Math.max(0, Math.min(1.1f, animation));
    }

    @Override
    public void render(RenderScope scope) {
        int cx = scope.getScaledWindowWidth() / 2;
        int cy = scope.getScaledWindowHeight() / 2;
        int line = Math.max(2, Math.min(16, length.value));
        int thick = Math.max(1, Math.min(5, thickness.value));
        int space = Math.max(0, Math.min(12, gap.value)) + Math.round(animation * 3);
        boolean hittable = Providers.feature.entity().isTargetingLivingEntity()
                && Providers.feature.entity().getTargetDistance() <= 3.25;
        int color = targetHighlight.value && hittable ? targetColor.value : normalColor.value;

        switch (style.value) {
            case 0 -> scope.drawRectangle(cx - thick / 2, cy - thick / 2,
                    Math.max(2, thick + 1), Math.max(2, thick + 1), color);
            case 2 -> drawBrackets(scope, cx, cy, line, space, thick, color);
            case 3 -> {
                scope.drawRectangle(cx - thick / 2, cy + space, thick, line, color);
                scope.drawRectangle(cx - space - line, cy - thick / 2, line, thick, color);
                scope.drawRectangle(cx + space, cy - thick / 2, line, thick, color);
            }
            default -> drawCross(scope, cx, cy, line, space, thick, color);
        }
    }

    private static void drawCross(RenderScope s, int x, int y, int len, int gap, int thick, int color) {
        s.drawRectangle(x - thick / 2, y - gap - len, thick, len, color);
        s.drawRectangle(x - thick / 2, y + gap, thick, len, color);
        s.drawRectangle(x - gap - len, y - thick / 2, len, thick, color);
        s.drawRectangle(x + gap, y - thick / 2, len, thick, color);
    }

    private static void drawBrackets(RenderScope s, int x, int y, int len, int gap, int thick, int color) {
        int r = gap + len;
        s.drawRectangle(x - r, y - r, len, thick, color);
        s.drawRectangle(x - r, y - r, thick, len, color);
        s.drawRectangle(x + gap, y - r, len, thick, color);
        s.drawRectangle(x + r - thick, y - r, thick, len, color);
        s.drawRectangle(x - r, y + r - thick, len, thick, color);
        s.drawRectangle(x - r, y + gap, thick, len, color);
        s.drawRectangle(x + gap, y + r - thick, len, thick, color);
        s.drawRectangle(x + r - thick, y + gap, thick, len, color);
    }

    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
