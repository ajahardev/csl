package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.SkinHeadRenderer;

/** Clickable title-screen profile chip that opens the local account manager. */
public class ProfileButton extends Element {
    private final String username;
    private final Runnable onClick;
    private float hover;

    public ProfileButton(String username, Runnable onClick) {
        this.username = username;
        this.onClick = onClick;
        dimensions(190, 50);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.22f;
        int fill = blend(0x6511161C, 0xDE202831, hover);
        int outline = blend(0x406E7882, 0xE5EDF1F4, hover);
        int foreground = blend(Theme.PRIMARY_FG.value, Theme.FOREGROUND.value, hover);

        scope.drawRoundedRectangle(0, 0, width, height, 12, fill);
        scope.drawRoundedBorder(0, 0, width, height, 12, outline);
        scope.drawRoundedRectangle(9, 8, 34, 34, 7, Theme.withAlpha(195, Theme.PRIMARY.value));
        SkinHeadRenderer.draw(scope, 11, 10, 30, foreground);
        scope.drawText(0.34f, "ACTIVE PROFILE", 52, 10, Theme.FONT.value,
                Theme.withAlpha(145, Theme.PRIMARY_FG.value));
        scope.drawText(0.56f, username.toUpperCase(), 52, 25, Theme.FONT.value, foreground);
        scope.drawText(0.54f, ">", width - 19 + Math.round(hover * 2), 21, Theme.FONT.value, foreground);
    }

    @Override
    public void click(int mouseX, int mouseY) {
        if (onClick != null) onClick.run();
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
