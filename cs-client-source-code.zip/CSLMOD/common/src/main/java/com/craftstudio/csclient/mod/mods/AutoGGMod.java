package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.StringProperty;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/** Safe local Auto GG configuration. Game-end detection lives in AutoGGTracker. */
public class AutoGGMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(false);
    private static final StringProperty MESSAGE = Property.string("gg");
    private static final IntProperty DELAY_SECONDS = Property.integer(2);
    private static final BoolProperty HYPIXEL_ONLY = Property.bool(true);

    public AutoGGMod() {
        super(new ModSpec("Auto GG", "autogg")
                        .description("Sends one delayed GG after a verified game-end message")
                        .version("v1.0.0").tags("Chat", "Utility", "Hypixel"),
                ENABLED.named("Enabled"),
                MESSAGE.named("Message"),
                DELAY_SECONDS.named("Delay Seconds (1-5)"),
                HYPIXEL_ONLY.named("Supported Networks Only"));
    }

    public static boolean isActive() { return ENABLED.value; }
    public static boolean isHypixelOnly() { return HYPIXEL_ONLY.value; }
    public static int delaySeconds() { return Math.max(1, Math.min(5, DELAY_SECONDS.value)); }

    /** Commands, line breaks, empty text and oversized chat are never emitted. */
    public static String safeMessage() {
        String value = MESSAGE.value == null ? "" : MESSAGE.value
                .replace('\r', ' ').replace('\n', ' ').trim().replaceAll("\\s+", " ");
        if (value.isEmpty() || value.startsWith("/") || value.length() > 64) return "gg";
        return value;
    }

    @Override
    public void tick() {
        AutoGGTracker.tick();
    }

    @Override public boolean isEnabled() { return ENABLED.value; }

    @Override
    public void onEnabled(boolean enabled) {
        ENABLED.value = enabled;
        if (!enabled) AutoGGTracker.cancelPending();
    }
}
