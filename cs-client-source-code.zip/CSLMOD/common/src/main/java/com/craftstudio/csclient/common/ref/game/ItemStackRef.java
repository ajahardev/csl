package com.craftstudio.csclient.common.ref.game;

public interface ItemStackRef {
    boolean isEmpty();
    int getMaxDamage();

    /**
     * Current durability damage. Version adapters override this when Minecraft
     * uses a differently named method; zero is a safe compatibility fallback.
     */
    default int getDamage() { return 0; }

    default int getCount() { return 0; }
    default String getItemName() { return "Item"; }
    default boolean isEnchanted() { return false; }
}
