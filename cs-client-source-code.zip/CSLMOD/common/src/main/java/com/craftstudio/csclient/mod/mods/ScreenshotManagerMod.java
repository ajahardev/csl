package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.KeybindingProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.screens.PauseMenu;
import com.craftstudio.csclient.ui.screens.ScreenshotManagerScreen;
import com.craftstudio.csclient.ui.screens.TitleMenu;

/** Opens a local-only gallery for the active launch profile's screenshots directory. */
public final class ScreenshotManagerMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(true);
    private static final KeybindingProperty OPEN_KEY = Property.keybinding(-1);

    public ScreenshotManagerMod() {
        super(new ModSpec("Screenshot Manager", "screenshotmanager")
                        .description("Views and manages PNG screenshots stored in this Minecraft profile")
                        .version("v1.0.0").tags("Utility", "Screenshots", "Mobile"),
                ENABLED.named("Enabled"), OPEN_KEY.named("Open Screenshot Manager Key"));
    }

    @Override
    public void tick() {
        if (!OPEN_KEY.wasKeyPressed()) return;
        CSClientScreen parent = Providers.feature != null && Providers.feature.player().hasPlayer()
                ? new PauseMenu() : new TitleMenu();
        Providers.csClient.getClient().setScreen(new ScreenshotManagerScreen(parent));
    }

    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
