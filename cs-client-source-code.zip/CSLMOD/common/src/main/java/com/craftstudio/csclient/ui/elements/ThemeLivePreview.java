package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Textures;

/** Small real-token composition showing how the active palette propagates. */
public class ThemeLivePreview extends Element {
    public ThemeLivePreview() {
        dimensions(880, 112);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        scope.drawRoundedRectangle(0, 0, width, height, 7, Theme.withAlpha(235, Theme.BACKGROUND.value));
        scope.drawRoundedBorder(0, 0, width, height, 7, Theme.withAlpha(125, Theme.ACCENT.value));

        scope.drawTexture(Config.getLogo(), 18, 18, 0, 0, 34, 34, Theme.FOREGROUND.value);
        scope.drawText(0.58f, "CS CLIENT V1", 64, 18, Theme.FONT.value, Theme.FOREGROUND.value);
        scope.drawText(0.30f, "LIVE GLOBAL THEME", 64, 43, Theme.FONT.value, Theme.PRIMARY_FG.value);

        int buttonX = Math.max(184, width / 2 - 124);
        int buttonY = 19;
        int buttonW = Math.min(250, Math.max(150, width / 3));
        scope.drawRoundedRectangle(buttonX, buttonY, buttonW, 38, 6, Theme.PRIMARY.value);
        scope.drawRoundedBorder(buttonX, buttonY, buttonW, 38, 6, Theme.withAlpha(145, Theme.ACCENT.value));
        scope.drawTexture(Textures.GRID, buttonX + 14, buttonY + 11, 0, 0, 16, 16, Theme.PRIMARY_FG.value);
        scope.drawText(0.46f, "CS MODULES", buttonX + 42, buttonY + 14,
                Theme.FONT.value, Theme.FOREGROUND.value);

        int toggleX = width - 104;
        scope.drawText(0.31f, "ENABLED", toggleX - 2, 10, Theme.FONT.value, Theme.PRIMARY_FG.value);
        scope.drawRoundedRectangle(toggleX, 30, 72, 30, 6, Theme.ACCENT.value);
        scope.drawRoundedRectangle(toggleX + 45, 34, 22, 22, 5, Theme.ACCENT_FG.value);

        int barX = 18;
        int barY = height - 25;
        int barW = width - 36;
        scope.drawRoundedRectangle(barX, barY, barW, 7, 3, Theme.PRIMARY.value);
        scope.drawRoundedRectangle(barX, barY, Math.max(18, Math.round(barW * 0.68f)), 7, 3, Theme.ACCENT.value);
        scope.drawRectangle(barX + Math.max(18, Math.round(barW * 0.68f)) - 2, barY - 2, 4, 11,
                Theme.FOREGROUND.value);
    }
}
