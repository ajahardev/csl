package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;
import com.craftstudio.csclient.ui.resources.Textures;

/** Offline Store teaser button; it opens only CS's local Coming Soon popup. */
public class HomeStoreButton extends Element {
    private final Runnable action;
    private float hover;

    public HomeStoreButton(Runnable action) {
        this.action = action;
        dimensions(92, 40);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.23f;
        int color = Theme.ACCENT.value;
        int fill = blend(0xB011171C, withAlpha(215, color), hover * 0.72f);
        scope.drawRoundedRectangle(0, hover > 0.55f ? -1 : 0, width, height, 6, fill);
        scope.drawRoundedBorder(0, hover > 0.55f ? -1 : 0, width, height, 6,
                withAlpha(150 + Math.round(95 * hover), color));
        scope.drawTexture(Textures.STORE, 11, 11, 0, 0, 18, 18, hover > 0.4f ? 0xFFFFFFFF : color);
        String text = "STORE";
        int tw = Math.round(Fonts.getWidth(text, Theme.FONT.value) * 0.40f);
        scope.drawText(0.40f, text, 39 + Math.max(0, (width - 43 - tw) / 2), 15,
                Theme.FONT.value, 0xFFFFFFFF);
    }

    @Override public void click(int mouseX, int mouseY) { if (action != null) action.run(); }

    private static int withAlpha(int alpha, int color) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
