package com.craftstudio.csclient.ui.resources;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;

/** Central resource identifiers. Feature/module icons intentionally retain their existing SVGs. */
public final class Textures {
    private Textures() {
    }

    public static final IdentifierRef CROSSHAIR_RANGE = IdentifierRef
            .ofClient("textures/gui/hud/crosshair_range.png");
    public static final IdentifierRef HEART = IdentifierRef.ofClient("textures/gui/hud/heart.svg");

    public static final IdentifierRef HUD_ICON = IdentifierRef.ofClient("textures/gui/components/hud.png");
    public static final IdentifierRef CLOSE = IdentifierRef.ofClient("textures/gui/components/close.png");
    public static final IdentifierRef MODS_TAB = IdentifierRef.ofClient("textures/gui/components/mods_tab.png");
    public static final IdentifierRef SETTINGS = IdentifierRef.ofClient("textures/gui/components/settings.png");
    public static final IdentifierRef RESET = IdentifierRef.ofClient("textures/gui/components/reset.png");
    public static final IdentifierRef LEFT = IdentifierRef.ofClient("textures/gui/components/left.png");
    public static final IdentifierRef RIGHT = IdentifierRef.ofClient("textures/gui/components/right.png");
    public static final IdentifierRef CIRCLE_X = IdentifierRef.ofClient("textures/gui/components/circle_x.png");
    public static final IdentifierRef INFO = IdentifierRef.ofClient("textures/gui/components/info.png");
    public static final IdentifierRef CHECK = IdentifierRef.ofClient("textures/gui/components/check.png");

    // New vector navigation system. SVGs are rasterized once and cached by SvgTexture.
    public static final IdentifierRef PROFILE = IdentifierRef.ofClient("textures/gui/components/profile.svg");
    public static final IdentifierRef ACCOUNTS = IdentifierRef.ofClient("textures/gui/components/accounts.svg");
    public static final IdentifierRef SKIN = IdentifierRef.ofClient("textures/gui/components/skin.svg");
    public static final IdentifierRef LINK = IdentifierRef.ofClient("textures/gui/components/link.svg");
    public static final IdentifierRef FILE = IdentifierRef.ofClient("textures/gui/components/file.svg");
    public static final IdentifierRef LOCK = IdentifierRef.ofClient("textures/gui/components/lock.svg");
    public static final IdentifierRef SINGLEPLAYER = IdentifierRef.ofClient("textures/gui/components/singleplayer.svg");
    public static final IdentifierRef MULTIPLAYER = IdentifierRef.ofClient("textures/gui/components/multiplayer.svg");
    public static final IdentifierRef BACK = IdentifierRef.ofClient("textures/gui/components/back.svg");
    public static final IdentifierRef SEARCH = IdentifierRef.ofClient("textures/gui/components/search.svg");
    public static final IdentifierRef PLUS = IdentifierRef.ofClient("textures/gui/components/plus.svg");
    public static final IdentifierRef TRASH = IdentifierRef.ofClient("textures/gui/components/trash.svg");
    public static final IdentifierRef SWITCH = IdentifierRef.ofClient("textures/gui/components/switch.svg");
    public static final IdentifierRef SLIDERS = IdentifierRef.ofClient("textures/gui/components/sliders.svg");
    public static final IdentifierRef GRID = IdentifierRef.ofClient("textures/gui/components/grid.svg");
    public static final IdentifierRef PALETTE = IdentifierRef.ofClient("textures/gui/components/palette.svg");
    public static final IdentifierRef KEY = IdentifierRef.ofClient("textures/gui/components/key.svg");
    public static final IdentifierRef HASH = IdentifierRef.ofClient("textures/gui/components/hash.svg");
    public static final IdentifierRef CHOICE = IdentifierRef.ofClient("textures/gui/components/choice.svg");
    public static final IdentifierRef SPARK = IdentifierRef.ofClient("textures/gui/components/spark.svg");
    public static final IdentifierRef TOGGLE = IdentifierRef.ofClient("textures/gui/components/toggle.svg");
    public static final IdentifierRef STORE = IdentifierRef.ofClient("textures/gui/components/store.svg");
    public static final IdentifierRef CAPE = IdentifierRef.ofClient("textures/gui/components/cape.svg");
    public static final IdentifierRef FOLDER = IdentifierRef.ofClient("textures/gui/components/folder.svg");
    public static final IdentifierRef IMAGE = IdentifierRef.ofClient("textures/gui/components/image.svg");
    public static final IdentifierRef UNDO = IdentifierRef.ofClient("textures/gui/components/undo.svg");
    public static final IdentifierRef RESUME = IdentifierRef.ofClient("textures/gui/components/resume.svg");
    public static final IdentifierRef FRIENDS = IdentifierRef.ofClient("textures/gui/components/friends.svg");
    public static final IdentifierRef HOST_WORLD = IdentifierRef.ofClient("textures/gui/components/host_world.svg");
    /** Official unmodified white Discord wordmark, used only for the CS invite card. */
    public static final IdentifierRef DISCORD_OFFICIAL = IdentifierRef
            .ofClient("textures/gui/components/discord_official.svg");
    /** Official unmodified full-color YouTube logo, used only for the CS channel card. */
    public static final IdentifierRef YOUTUBE_OFFICIAL = IdentifierRef
            .ofClient("textures/gui/components/youtube_official.png");

    /** Packaged PlantMC logo for the fixed PlantMC Home and pinned multiplayer entry. */
    public static final IdentifierRef PLANTMC_SERVER = IdentifierRef
            .ofClient("textures/gui/servers/plantmc_slot.png");
    public static final IdentifierRef PLANTMC_BANNER = IdentifierRef
            .ofClient("textures/gui/servers/plantmc_banner.png");
    public static final IdentifierRef INDIA_FLAG = IdentifierRef
            .ofClient("textures/gui/servers/india_flag.png");
    /** Original neutral icon used by local Coming Soon server slots. */
    public static final IdentifierRef SERVER_SLOT = IdentifierRef
            .ofClient("textures/gui/servers/server_slot.svg");

    public static final IdentifierRef PRESET_PVP = IdentifierRef.ofClient("textures/gui/presets/pvp.svg");
    public static final IdentifierRef PRESET_BEDWARS = IdentifierRef.ofClient("textures/gui/presets/bedwars.svg");
    public static final IdentifierRef PRESET_SURVIVAL = IdentifierRef.ofClient("textures/gui/presets/survival.svg");
    public static final IdentifierRef PRESET_STREAM = IdentifierRef.ofClient("textures/gui/presets/stream.svg");
    public static final IdentifierRef PRESET_PERFORMANCE = IdentifierRef.ofClient("textures/gui/presets/performance.svg");
    public static final IdentifierRef PRESET_MINIMAL = IdentifierRef.ofClient("textures/gui/presets/minimal.svg");

    // Static color-picker gradients: composited in the GPU, never regenerated while dragging.
    public static final IdentifierRef PICKER_SV_WHITE = IdentifierRef.ofClient("textures/gui/color_picker/sv_white.png");
    public static final IdentifierRef PICKER_SV_BLACK = IdentifierRef.ofClient("textures/gui/color_picker/sv_black.png");
    public static final IdentifierRef PICKER_HUE = IdentifierRef.ofClient("textures/gui/color_picker/hue.png");
    public static final IdentifierRef PICKER_ALPHA = IdentifierRef.ofClient("textures/gui/color_picker/alpha.png");
    public static final IdentifierRef PICKER_CHECKER = IdentifierRef.ofClient("textures/gui/color_picker/checker.png");

    public static final IdentifierRef LOGO = IdentifierRef.ofClient("textures/logo/logo.png");
    public static final IdentifierRef REALISTIC_LOGO = IdentifierRef.ofClient("textures/logo/realistic.png");
    public static final IdentifierRef LOGO_TEXT = IdentifierRef.ofClient("textures/logo/text.png");
    public static final IdentifierRef LOGO_TEXT_BIG = IdentifierRef.ofClient("textures/logo/text_big.png");
    public static final IdentifierRef SPLASH = IdentifierRef.ofClient("textures/gui/splash.png");

    public static IdentifierRef getModIcon(String modId) {
        return IdentifierRef.ofClient("textures/gui/mod/" + modId + ".svg");
    }
}
