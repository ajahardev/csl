package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/**
 * World-space player health indicator.
 *
 * This is intentionally not a HudMod: platform render adapters place its
 * bitmap heart glyphs above player nametags in the 3D world.
 */
public class HealthDisplayMod extends Mod {
    public static final char EMPTY_HEART = '\uE000';
    public static final char FULL_HEART = '\uE001';
    public static final char HALF_HEART = '\uE002';
    public static final char ABSORPTION_HEART = '\uE003';

    private static final BoolProperty enabled = Property.bool(false);
    private static final BoolProperty useVanillaHeartTextures = Property.bool(true);
    private static final BoolProperty showOwn = Property.bool(false);
    /** When enabled, every nearby non-player MobEntity uses the same heart row style. */
    private static final BoolProperty showMobs = Property.bool(false);
    private static final BoolProperty showAbsorption = Property.bool(true);
    private static final BoolProperty hideAtFullHealth = Property.bool(false);
    private static final IntProperty maxDistance = Property.integer(32);
    private static final ColorProperty heartColor = Property.color(0xFFF05A67);
    private static final ColorProperty lowHeartColor = Property.color(0xFFFF4054);
    private static final ColorProperty emptyHeartColor = Property.color(0xFF4A3035);
    private static final ColorProperty absorptionColor = Property.color(0xFFFFD45C);

    public HealthDisplayMod() {
        super(new ModSpec("Health Indicator", "health")
                        .description("Full, half and absorption hearts above players and optional mobs")
                        .version("v2.1.0").tags("World", "PvP", "Utility"),
                enabled.named("Enabled"),
                useVanillaHeartTextures.named("Use Exact Minecraft Heart Textures"),
                showOwn.named("Show above own player"),
                showMobs.named("Show all mob health"),
                showAbsorption.named("Show absorption hearts"),
                hideAtFullHealth.named("Hide entities at full health"),
                maxDistance.named("Maximum render distance"),
                heartColor.named("Heart color"),
                lowHeartColor.named("Low health color"),
                emptyHeartColor.named("Empty heart color"),
                absorptionColor.named("Absorption heart color"));
    }

    public static boolean shouldShow(boolean ownPlayer, boolean invisible,
            double squaredDistance, float health, float maxHealth) {
        if (!enabled.value || invisible || health <= 0f || maxHealth <= 0f) return false;
        if (ownPlayer && !showOwn.value) return false;
        int distance = Math.max(4, maxDistance.value);
        if (squaredDistance > distance * (double) distance) return false;
        return !hideAtFullHealth.value || health < maxHealth;
    }

    /** Same distance/visibility contract as player health, but opt-in for all non-player mobs. */
    public static boolean shouldShowMob(boolean invisible, double squaredDistance,
            float health, float maxHealth) {
        if (!enabled.value || !showMobs.value || invisible || health <= 0f || maxHealth <= 0f) return false;
        int distance = Math.max(4, maxDistance.value);
        if (squaredDistance > distance * (double) distance) return false;
        return !hideAtFullHealth.value || health < maxHealth;
    }

    public static HeartRow createHeartRow(float health, float maxHealth, float absorption) {
        float safeMax = Math.max(2f, maxHealth);
        int containers = Math.max(1, (int) Math.ceil(safeMax / 2f));
        float shownHealth = Math.max(0f, Math.min(health, safeMax));

        // Keep very high custom-health servers readable in one compact row.
        if (containers > 20) {
            shownHealth = (shownHealth / safeMax) * 40f;
            containers = 20;
        }

        int full = Math.min(containers, (int) Math.floor(shownHealth / 2f));
        int half = full < containers && shownHealth - full * 2f > 0.01f ? 1 : 0;
        int empty = Math.max(0, containers - full - half);
        int gold = showAbsorption.value
                ? Math.min(10, Math.max(0, (int) Math.ceil(absorption / 2f)))
                : 0;
        int liveColor = shownHealth / Math.max(2f, containers * 2f) <= 0.25f
                ? lowHeartColor.value : heartColor.value;
        int emptyColor = emptyHeartColor.value;
        int goldColor = absorptionColor.value;
        // Vanilla sprites already contain their exact red/gold/container colors;
        // white preserves those pixels instead of multiplying them by a tint.
        if (useVanillaHeartTextures.value) {
            liveColor = 0xFFFFFFFF;
            emptyColor = 0xFFFFFFFF;
            goldColor = 0xFFFFFFFF;
        }
        return new HeartRow(full, half, empty, gold, liveColor, emptyColor, goldColor);
    }

    public record HeartRow(int full, int half, int empty, int absorption,
            int fullColor, int emptyColor, int absorptionColor) {
        public String fullGlyphs() { return String.valueOf(FULL_HEART).repeat(full); }
        public String halfGlyphs() { return String.valueOf(HALF_HEART).repeat(half); }
        public String emptyGlyphs() { return String.valueOf(EMPTY_HEART).repeat(empty); }
        public String absorptionGlyphs() { return String.valueOf(ABSORPTION_HEART).repeat(absorption); }
    }

    @Override public boolean isEnabled() { return enabled.value; }
    @Override public void onEnabled(boolean e) { enabled.value = e; }
}
