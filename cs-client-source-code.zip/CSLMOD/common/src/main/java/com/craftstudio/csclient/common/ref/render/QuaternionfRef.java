package com.craftstudio.csclient.common.ref.render;

public interface QuaternionfRef {
}
