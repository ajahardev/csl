package com.craftstudio.csclient.ui;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** Base screen with adaptive, GUI-scale-independent coordinates. */
public abstract class CSClientScreen {
    public interface ScreenProvider {
        void close();
        int getWidth();
        int getHeight();
        float getUiScale();
    }

    public int width;
    public int height;
    public String title;
    public List<Element> elements = new ArrayList<>();
    public float backgroundOpacity = 1.0f;
    public Instant start = null;
    public int backgroundBlur = 10;
    protected float uiScale = 1.0f;
    public ScreenProvider provider;

    public CSClientScreen(String title) {
        this.title = title;
    }

    public void init() {
        elements.clear();
        uiScale = provider.getUiScale();
        width = provider.getWidth();
        height = provider.getHeight();
        ui();
    }

    public abstract void ui();

    public void draw(Element element) {
        ElementRenderer.draw(elements, element);
    }

    public void render(RenderScope renderScope, int mouseX, int mouseY, float delta, long elapsed) {
        renderScope.getMatrixStack().push();
        renderScope.getMatrixStack().scale(uiScale, uiScale);
        int virtualMouseX = Math.round(mouseX / uiScale);
        int virtualMouseY = Math.round(mouseY / uiScale);
        ElementRenderer.render(elements, elapsed, renderScope, virtualMouseX, virtualMouseY);
        renderScope.getMatrixStack().pop();
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        ElementRenderer.mouseClicked(elements, mouseX / uiScale, mouseY / uiScale, button);
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        ElementRenderer.mouseDragged(elements, mouseX / uiScale, mouseY / uiScale, button,
                deltaX / uiScale, deltaY / uiScale);
        return false;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        ElementRenderer.mouseReleased(elements, mouseX / uiScale, mouseY / uiScale, button);
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        ElementRenderer.mouseScrolled(elements, mouseX / uiScale, mouseY / uiScale,
                horizontalAmount, verticalAmount);
        return false;
    }

    public void resize(int width, int height) {
        init();
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        ElementRenderer.keyPressed(elements, keyCode, scanCode, modifiers);
        return false;
    }

    /** Receives committed text from Minecraft's native CharInput/CharacterEvent path. */
    public boolean charTyped(String text, int modifiers) {
        return ElementRenderer.charTyped(elements, text);
    }

    public boolean hasFocusedTextInput() {
        return ElementRenderer.hasFocusedTextInput(elements);
    }

    public boolean shouldPause() {
        return true;
    }

    public void onClose() {
    }

    /**
     * Targets a 960x540 design surface, grows to native 1:1, and keeps touch
     * targets readable on GUI scale 3/4 and Android launchers.
     */
    public static float calculateUiScale(int viewportWidth, int viewportHeight) {
        float fit = Math.min(viewportWidth / 960f, viewportHeight / 540f);
        return Math.max(0.62f, Math.min(1.0f, fit));
    }
}
