package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/** Narrow Feather-structure pause action using only CS's configured theme accent. */
public class FeatherStackButton extends Element {
    private final IdentifierRef icon;
    private final String label;
    private final boolean primary;
    private final boolean danger;
    private final Runnable action;
    private float hover;

    public FeatherStackButton(IdentifierRef icon, String label, boolean primary, boolean danger, Runnable action) {
        this.icon = icon;
        this.label = label;
        this.primary = primary;
        this.danger = danger;
        this.action = action;
        dimensions(300, 42);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        boolean disabled = action == null;
        float target = !disabled && ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.24f;
        int lift = hover > 0.6f ? -1 : 0;
        int fill;
        int outline;
        int foreground;
        if (disabled) {
            fill = 0xB8101419;
            outline = 0x4A56616B;
            foreground = 0xFF6F7983;
        } else if (danger) {
            fill = blend(0xD21B1217, 0xEB632A35, hover);
            outline = blend(0x927A3B47, 0xFFFF9AA5, hover);
            foreground = blend(0xFFF0929C, 0xFFFFFFFF, hover);
        } else if (primary) {
            fill = blend(Theme.withAlpha(205, Theme.ACCENT.value), Theme.ACCENT.value, hover);
            outline = blend(Theme.withAlpha(170, Theme.ACCENT.value), 0xFFFFFFFF, hover);
            foreground = Theme.ACCENT_FG.value;
        } else {
            fill = blend(0xE111171C, 0xF1263038, hover);
            outline = blend(0x786D797B, Theme.withAlpha(235, Theme.ACCENT.value), hover);
            foreground = blend(0xFFDCE2E0, 0xFFFFFFFF, hover);
        }

        scope.drawRoundedRectangle(0, lift, width, height, 6, fill);
        scope.drawRoundedBorder(0, lift, width, height, 6, outline);
        int textWidth = Math.round(Fonts.getWidth(label, Theme.FONT.value) * 0.48f);
        int groupWidth = textWidth + (icon == null ? 0 : 25);
        int groupX = (width - groupWidth) / 2 + Math.round(hover * 2f);
        if (icon != null) {
            scope.drawTexture(icon, groupX, 13 + lift, 0, 0, 16, 16, foreground);
            groupX += 25;
        }
        scope.drawText(0.48f, label, groupX, 15 + lift, Theme.FONT.value, foreground);
        if (!disabled && hover > 0.02f) {
            scope.drawRectangle(12, height - 2 + lift, Math.round((width - 24) * hover), 1,
                    danger ? 0xFFFF8F9D : Theme.withAlpha(225, Theme.ACCENT.value));
        }
    }

    @Override public void click(int mouseX, int mouseY) { if (action != null) action.run(); }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
