package com.craftstudio.csclient.common.provider;

public class Providers {
    public static RefConstructorProvider refConstructor;
    public static CSClientProvider csClient;
    public static GLFWProvider GLFW;
    public static FeatureProvider feature;
}
