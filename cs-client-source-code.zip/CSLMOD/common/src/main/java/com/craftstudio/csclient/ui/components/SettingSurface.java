package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;

/** Rich settings row with type icon, hierarchy and contextual helper copy. */
public class SettingSurface extends Element {
    private final String name;
    private final String hint;
    private final IdentifierRef icon;
    private float hover;

    public SettingSurface(String name, String hint, IdentifierRef icon) {
        this.name = name;
        this.hint = hint;
        this.icon = icon;
        dimensions(560, 64);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.19f;
        int fill = blend(0xD814191F, 0xF01D252E, hover);
        int outline = blend(0x275E6872, 0x929CA7B1, hover);
        scope.drawRoundedRectangle(0, 0, width, height, 13, fill);
        scope.drawRoundedBorder(0, 0, width, height, 13, outline);
        scope.drawRoundedRectangle(12, 12, 40, 40, 11,
                blend(0xD01D232A, Theme.withAlpha(185, Theme.ACCENT.value), hover * 0.55f));
        scope.drawTexture(icon, 23, 23, 0, 0, 18, 18,
                hover > 0.55f ? Theme.FOREGROUND.value : Theme.PRIMARY_FG.value);
        scope.drawText(0.53f, name, 64, 17, Theme.FONT.value, Theme.FOREGROUND.value);
        scope.drawText(0.32f, hint, 64, 40, Theme.FONT.value,
                Theme.withAlpha(145, Theme.PRIMARY_FG.value));
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
