package com.craftstudio.csclient.ui.screens;

import java.util.List;

import com.craftstudio.csclient.common.provider.GLFWProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef.LoadedModInfo;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.components.ModuleSettingRow;
import com.craftstudio.csclient.ui.elements.IconButton;
import com.craftstudio.csclient.ui.elements.Panel;
import com.craftstudio.csclient.ui.elements.Scroll;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

/** Credential-free Fabric mod viewer used when optional Mod Menu is absent. */
public final class InstalledModsScreen extends CSClientScreen {
    private final CSClientScreen parent;

    public InstalledModsScreen(CSClientScreen parent) {
        super("Installed Fabric Mods");
        this.parent = parent == null ? new TitleMenu() : parent;
        backgroundBlur = 5;
    }

    @Override
    public void ui() {
        List<LoadedModInfo> mods = Providers.csClient.getClient().getLoadedMods();
        int panelWidth = Math.min(820, width - 30);
        int panelHeight = Math.min(500, height - 28);
        int x = (width - panelWidth) / 2;
        int y = (height - panelHeight) / 2;
        draw(new Panel(0xF00E1419).dimensions(panelWidth, panelHeight).position(x, y));
        draw(new IconButton(Textures.BACK, this::goBack).dimensions(38, 38).position(x + 12, y + 12));
        draw(new Text("INSTALLED MODS").scale(0.70f).position(x + 62, y + 12));
        draw(new Text(mods.size() + " FABRIC MODS  •  READ-ONLY VIEW")
                .color(Theme.ACCENT.value).scale(0.28f).position(x + 63, y + 40));

        Scroll list = new Scroll(7);
        list.dimensions(panelWidth - 20, panelHeight - 76).position(x + 10, y + 66);
        draw(list);
        int rowWidth = panelWidth - 40;
        int rowY = 0;
        for (LoadedModInfo mod : mods) {
            String name = mod.name() == null || mod.name().isBlank() ? mod.id() : mod.name();
            String version = mod.version() == null || mod.version().isBlank() ? "" : "  •  " + mod.version();
            list.draw(new ModuleSettingRow(name + version, mod.id(), Textures.MODS_TAB, 24)
                    .dimensions(rowWidth, 52).position(0, rowY));
            rowY += 58;
        }
        if (mods.isEmpty()) {
            list.draw(new Text("NO FABRIC MOD METADATA AVAILABLE").scale(0.45f).position(16, 22));
            rowY = 70;
        }
        list.draw(new Panel(0x0012161C).dimensions(1, Math.max(1, rowY)).position(0, 0));
    }

    private void goBack() { Providers.csClient.getClient().setScreen(parent); }

    @Override public boolean shouldPause() { return true; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFWProvider.GLFW_KEY_ESCAPE) {
            goBack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
