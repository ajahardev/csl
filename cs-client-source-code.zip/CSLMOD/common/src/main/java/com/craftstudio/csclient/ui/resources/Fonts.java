package com.craftstudio.csclient.ui.resources;

import java.util.LinkedHashMap;
import java.util.Map;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.render.TextRef;

/** Bounded cache for immutable styled text; width remains renderer-derived. */
public final class Fonts {
    private static final int MAX_TEXT_CACHE = 4_096;
    private static final Map<TextKey, TextRef> TEXT_CACHE = new LinkedHashMap<>(512, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<TextKey, TextRef> eldest) {
            return size() > MAX_TEXT_CACHE;
        }
    };

    /**
     * Measured-width cache. HUD labels ("FPS", "PING", units, ...) are
     * measured several times per frame per widget; caching the result removes
     * repeated key construction, lock traffic and renderer measurement from
     * the hot path.
     */
    private static final int MAX_WIDTH_CACHE = 4_096;
    private static final Map<WidthKey, Integer> WIDTH_CACHE = new LinkedHashMap<>(512, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<WidthKey, Integer> eldest) {
            return size() > MAX_WIDTH_CACHE;
        }
    };

    public static final IdentifierRef INTER = IdentifierRef.ofClient("inter");
    public static final IdentifierRef INTER_BOLD = IdentifierRef.ofClient("inter_bold");
    public static final IdentifierRef DEFAULT = IdentifierRef.ofVanilla("default");

    private Fonts() { }

    public static IdentifierRef getFont(int font) {
        return switch (font) {
            case 0 -> DEFAULT;
            case 1 -> INTER;
            default -> INTER_BOLD;
        };
    }

    public static TextRef setFont(String text, IdentifierRef font) {
        String safe = text == null ? "" : text;
        TextKey key = new TextKey(safe, font == null ? "minecraft:default" : font.toString());
        synchronized (TEXT_CACHE) {
            TextRef cached = TEXT_CACHE.get(key);
            if (cached != null) return cached;
            TextRef created = TextRef.literal(safe).withFont(font == null ? DEFAULT : font);
            TEXT_CACHE.put(key, created);
            return created;
        }
    }

    public static TextRef setFont(String text, int font) {
        return setFont(text, getFont(font));
    }

    /** No regex/split allocation for the normal one-line HUD path. */
    public static int getWidth(String text, int font) {
        if (text == null || text.isEmpty()) return 0;
        int max = 0;
        int start = 0;
        while (true) {
            int newline = text.indexOf('\n', start);
            String line;
            if (start == 0 && newline < 0) line = text;
            else line = text.substring(start, newline < 0 ? text.length() : newline);
            max = Math.max(max, cachedWidth(line, font));
            if (newline < 0) break;
            start = newline + 1;
        }
        return font == 0 ? max * 2 : max;
    }

    private static int cachedWidth(String line, int font) {
        if (line.isEmpty()) return 0;
        WidthKey key = new WidthKey(line, font);
        synchronized (WIDTH_CACHE) {
            Integer cached = WIDTH_CACHE.get(key);
            if (cached != null) return cached;
        }
        int width = setFont(line, font).getWidth();
        synchronized (WIDTH_CACHE) {
            WIDTH_CACHE.put(key, width);
        }
        return width;
    }

    public static void clearCaches() {
        synchronized (TEXT_CACHE) { TEXT_CACHE.clear(); }
        synchronized (WIDTH_CACHE) { WIDTH_CACHE.clear(); }
    }

    public static int getHeight() { return 18; }
    public static int centerX(int width, String text, int font) { return (width - getWidth(text, font)) / 2; }
    public static int centerY(int height) { return (height - 18) / 2; }

    private record TextKey(String text, String font) { }
    private record WidthKey(String line, int font) { }
}
