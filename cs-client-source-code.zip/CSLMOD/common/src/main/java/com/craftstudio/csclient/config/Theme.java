package com.craftstudio.csclient.config;

import com.craftstudio.csclient.config.property.ColorProperty;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;

/** CS Client's charcoal, graphite and silver visual system. */
public class Theme {
    // Near-black application canvas.
    public static final ColorProperty BACKGROUND = Property.color(0xFF0B0D10);

    // High-contrast primary copy.
    public static final ColorProperty FOREGROUND = Property.color(0xFFF0F2F4);

    // Graphite cards, buttons and controls.
    public static final ColorProperty PRIMARY = Property.color(0xFF181B20);

    // Secondary copy and icon color.
    public static final ColorProperty PRIMARY_FG = Property.color(0xFFD4D8DD);

    // Brushed-silver selected, enabled and hovered state.
    public static final ColorProperty ACCENT = Property.color(0xFF9AA1AA);

    // Dark copy/icons placed on silver controls.
    public static final ColorProperty ACCENT_FG = Property.color(0xFF0B0D10);

    // Muted steel scrollbar.
    public static final ColorProperty SCROLL = Property.color(0xFF707780);

    // Compact, modern corner radii.
    public static final IntProperty BG_RADIUS = Property.integer(10);
    public static final IntProperty WIDGET_RADIUS = Property.integer(8);

    public static final SelectProperty FONT = Property.font(2);

    public static void init(ConfigManager parent) {
        ConfigManager config = new ConfigManager(parent, "CS Client • Dark Grey UI");
        config.property("Background", BACKGROUND);
        config.property("Foreground", FOREGROUND);
        config.property("Primary", PRIMARY);
        config.property("Primary Foreground", PRIMARY_FG);
        config.property("Accent", ACCENT);
        config.property("Accent Foreground", ACCENT_FG);
        config.property("Scrollbar Color", SCROLL);

        config.property("Background Radius", BG_RADIUS);
        config.property("Widget Radius", WIDGET_RADIUS);
        config.property("Font", FONT);
    }

    /** primary by default, accent when hovered/active. */
    public static int getBg(boolean hover) {
        return hover ? ACCENT.value : PRIMARY.value;
    }

    /** primary foreground by default, accent foreground when hovered/active. */
    public static int getFg(boolean hover) {
        return hover ? ACCENT_FG.value : PRIMARY_FG.value;
    }

    /** Multiplies the existing alpha by a 0–255 alpha value. */
    public static int withAlpha(int alpha, int color) {
        alpha = Math.max(0, Math.min(255, alpha));
        int originalAlpha = (color >>> 24) & 0xFF;
        int merged = (originalAlpha * alpha) / 255;
        return (color & 0x00FFFFFF) | (merged << 24);
    }

    /** Multiplies the existing alpha by a 0.0–1.0 alpha value. */
    public static int withAlpha(float alpha, int color) {
        alpha = Math.max(0f, Math.min(1f, alpha));
        int originalAlpha = (color >>> 24) & 0xFF;
        int merged = (int) (originalAlpha * alpha);
        return (color & 0x00FFFFFF) | (merged << 24);
    }
}
