package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.common.feature.PlayerFeature;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.ModSpec;

public class ComboCounterMod extends TextHudMod {
    private static final IntProperty resetDelay = Property.integer(1800);
    private boolean lastAttack;
    private int combo;
    private long lastHit;

    public ComboCounterMod() {
        super(new ModSpec("Combo Counter", "combo").description("Counts consecutive attacks while targeting an entity")
                        .version("v1.0.0").tags("PvP", "HUD")
                        .requires(Providers.feature::player, Providers.feature::entity),
                76, resetDelay.named("Reset Delay (ms)"));
    }

    @Override
    public void tick() {
        PlayerFeature player = Providers.feature.player();
        boolean attack = player.isAttackPressed();
        long now = System.currentTimeMillis();
        if (attack && !lastAttack) {
            if (Providers.feature.entity().isTargetingLivingEntity()) {
                combo++;
                lastHit = now;
            } else {
                combo = 0;
            }
        }
        if (combo > 0 && now - lastHit > Math.max(250, resetDelay.value)) combo = 0;
        lastAttack = attack;
    }

    @Override protected String getText() { return combo + " COMBO"; }
    @Override protected String getDummyText() { return "6 COMBO"; }
}
