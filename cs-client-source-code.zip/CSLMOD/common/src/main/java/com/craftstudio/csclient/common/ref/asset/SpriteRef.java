package com.craftstudio.csclient.common.ref.asset;

public interface SpriteRef {
}
