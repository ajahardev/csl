package com.craftstudio.csclient.ui.screens;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.replay.ReplayModBridge;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef.MinecraftScreen;
import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.mod.ModManager;
import com.craftstudio.csclient.server.FeaturedServers;
import com.craftstudio.csclient.util.ExternalLinks;
import com.craftstudio.csclient.ui.CSClientScreen;
import com.craftstudio.csclient.ui.anim.Fade;
import com.craftstudio.csclient.ui.anim.SlideFade;
import com.craftstudio.csclient.ui.elements.HomeDiscordCard;
import com.craftstudio.csclient.ui.elements.HomeIconTile;
import com.craftstudio.csclient.ui.elements.HomeMenuButton;
import com.craftstudio.csclient.ui.elements.HomeServerIcon;
import com.craftstudio.csclient.ui.elements.HomeStoreButton;
import com.craftstudio.csclient.ui.elements.HomeYouTubeCard;
import com.craftstudio.csclient.ui.elements.ImageTexture;
import com.craftstudio.csclient.ui.elements.ProfileButton;
import com.craftstudio.csclient.ui.elements.Text;
import com.craftstudio.csclient.ui.resources.Textures;

/**
 * CS Client V1 Home. The left featured-server rail is an original local UI:
 * it borrows only the compact icon-line hierarchy observed in Feather, not
 * Feather branding, assets, layout coordinates, service, or server API.
 */
public class TitleMenu extends CSClientScreen {
    public TitleMenu() { super("CS Client V1 Home"); }

    @Override
    public void ui() {
        backgroundBlur = 0;
        boolean compact = width < 900;
        boolean shortView = height < 520;
        boolean hasModMenu = Providers.csClient.getClient().isModLoaded("modmenu");
        boolean friends = Providers.csClient.getClient().supportsNativeFriends();
        String externalModCount = hasModMenu ? Providers.csClient.getClient().getExternalModCount()
                : Integer.toString(Providers.csClient.getClient().getLoadedMods().size());
        if (externalModCount.isBlank()) externalModCount = "?";
        String username = Providers.csClient.getClient().getUsername();
        if (username == null || username.isBlank()) username = "PLAYER";

        drawBrandCorner();
        drawUtilityRail(username, compact, hasModMenu, friends);
        drawFeaturedServers(compact, shortView);
        drawCenteredIdentity(shortView);
        drawActionStack(shortView, hasModMenu, externalModCount);
        drawBottomDock(compact);
        drawCommunityCards(compact);
        drawFooter(hasModMenu, externalModCount);
    }

    private void drawBrandCorner() {
        draw(new ImageTexture(Config.getLogo()).dimensions(34, 34).position(18, 17)
                .animation(new Fade(AnimationConfig.logo)));
        draw(new Text("CS CLIENT V1").scale(0.61f).position(62, 19)
                .animation(new SlideFade(AnimationConfig.mainMenu, -8)));
        draw(new Text("HOME  •  RELEASE").scale(0.27f).position(63, 42)
                .animation(new Fade(AnimationConfig.mainMenu)));
    }

    /**
     * Feather's Home reference uses a narrow left logo rail rather than text
     * cards. CS keeps that icon-only hierarchy in an original implementation:
     * no heading, label, address, fake ping, or card surface at rest.
     */
    private void drawFeaturedServers(boolean compact, boolean shortView) {
        int hitbox = compact || height < 440 ? 38 : 44;
        int gap = compact || height < 440 ? 9 : 13;
        int totalHeight = FeaturedServers.slots().size() * hitbox
                + (FeaturedServers.slots().size() - 1) * gap;
        int x = compact ? 10 : 15;
        int y = Math.max(shortView ? 68 : 92, (height - totalHeight) / 2);

        // A subtle rail groups the icon line without becoming a server card.
        int railX = x + hitbox / 2;
        draw(new com.craftstudio.csclient.ui.elements.Panel(0x223C4854)
                .dimensions(1, totalHeight - 6).position(railX, y + 3)
                .animation(new Fade(AnimationConfig.mainMenu)));

        int index = 0;
        for (FeaturedServers.Slot slot : FeaturedServers.slots()) {
            Fade entry = new Fade(AnimationConfig.mainMenu);
            entry.delay = 38 + index * 30;
            draw(new HomeServerIcon(slot, () -> selectFeaturedServer(slot))
                    .dimensions(hitbox, hitbox).position(x, y).animation(entry));
            y += hitbox + gap;
            index++;
        }
    }

    private void selectFeaturedServer(FeaturedServers.Slot slot) {
        if (slot.joinable()) {
            // Target adapters can connect only to the exact FeaturedServers address.
            Providers.csClient.getClient().joinFeaturedServer();
            return;
        }
        Providers.csClient.getClient().setScreen(new ServerComingSoonScreen(new TitleMenu(), slot));
    }

    private void drawUtilityRail(String username, boolean compact, boolean hasModMenu, boolean friends) {
        int y = 16;
        int quitX = width - 56;
        if (compact) {
            int storeWidth = 92;
            int friendSpace = friends ? 48 : 0;
            int profileWidth = Math.max(96, Math.min(158, width - 300 - friendSpace));
            int storeX = quitX - storeWidth - 8;
            int friendX = storeX - friendSpace;
            int profileX = (friends ? friendX : storeX) - profileWidth - 8;
            draw(new ProfileButton(username,
                    () -> Providers.csClient.getClient().setScreen(new LocalAccountsScreen()))
                    .dimensions(profileWidth, 40).position(profileX, y)
                    .animation(new SlideFade(AnimationConfig.mainMenu, 8)));
            if (friends) {
                drawTile(friendX, y, Textures.FRIENDS,
                        () -> Providers.csClient.getClient().openNativeFriends(new TitleMenu()));
            }
            draw(new HomeStoreButton(() -> Providers.csClient.getClient()
                    .setScreen(new ComingSoonScreen(new TitleMenu())))
                    .dimensions(storeWidth, 40).position(storeX, y)
                    .animation(new SlideFade(AnimationConfig.mainMenu, 10)));
            draw(new HomeIconTile(Textures.CLOSE, () -> Providers.csClient.getClient().scheduleStop())
                    .dimensions(40, 40).position(quitX, y)
                    .animation(new SlideFade(AnimationConfig.mainMenu, 12)));
            return;
        }

        int tile = 40;
        int gap = 7;
        int utilityTiles = 5 + (friends ? 1 : 0);
        int profileWidth = 184;
        int storeWidth = 92;
        int total = profileWidth + gap + utilityTiles * (tile + gap) + storeWidth + gap + tile;
        int x = width - total - 18;
        draw(new ProfileButton(username,
                () -> Providers.csClient.getClient().setScreen(new LocalAccountsScreen()))
                .dimensions(profileWidth, 40).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, 7)));
        x += profileWidth + gap;
        if (friends) {
            drawTile(x, y, Textures.FRIENDS,
                    () -> Providers.csClient.getClient().openNativeFriends(new TitleMenu()));
            x += tile + gap;
        }
        drawTile(x, y, Textures.GRID, () -> Providers.csClient.getClient().setScreen(new ModMenu()));
        x += tile + gap;
        drawTile(x, y, Textures.HUD_ICON, () -> Providers.csClient.getClient().setScreen(new HudEditor()));
        x += tile + gap;
        drawTile(x, y, Textures.SLIDERS,
                () -> Providers.csClient.getClient().setScreen(new ConfigEditor(Config.config)));
        x += tile + gap;
        drawTile(x, y, Textures.PALETTE,
                () -> Providers.csClient.getClient().setScreen(new ThemeStudio()));
        x += tile + gap;
        drawTile(x, y, Textures.MODS_TAB, this::openModsScreen);
        x += tile + gap;
        draw(new HomeStoreButton(() -> Providers.csClient.getClient()
                .setScreen(new ComingSoonScreen(new TitleMenu())))
                .dimensions(storeWidth, 40).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, 10)));
        x += storeWidth + gap;
        drawTile(x, y, Textures.CLOSE, () -> Providers.csClient.getClient().scheduleStop());
    }

    private void drawTile(int x, int y, com.craftstudio.csclient.common.ref.asset.IdentifierRef icon, Runnable action) {
        draw(new HomeIconTile(icon, action).dimensions(40, 40).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, 10)));
    }

    private void drawCenteredIdentity(boolean shortView) {
        int centerX = width / 2;
        int logoSize = shortView ? 55 : 68;
        int y = shortView ? 77 : 91;
        int lockupWidth = logoSize + 18 + (shortView ? 142 : 170);
        int logoX = centerX - lockupWidth / 2;
        draw(new ImageTexture(Config.getLogo()).dimensions(logoSize, logoSize).position(logoX, y)
                .animation(new SlideFade(AnimationConfig.logo, -18)));
        draw(new Text("CS CLIENT V1").scale(shortView ? 0.88f : 1.03f)
                .position(logoX + logoSize + 18, y + (shortView ? 10 : 12))
                .animation(new SlideFade(AnimationConfig.mainMenu, -12)));
        draw(new Text("COMPETITIVE FABRIC").scale(0.30f)
                .position(logoX + logoSize + 19, y + (shortView ? 39 : 46))
                .animation(new Fade(AnimationConfig.mainMenu)));
    }

    private void drawActionStack(boolean shortView, boolean hasModMenu, String externalModCount) {
        int centerX = width / 2;
        int buttonWidth = Math.min(350, width - 100);
        int buttonHeight = shortView ? 38 : 42;
        int gap = shortView ? 8 : 9;
        int x = centerX - buttonWidth / 2;
        int y = shortView ? 153 : 183;

        draw(new HomeMenuButton(Textures.SINGLEPLAYER, "SINGLEPLAYER", true,
                () -> Providers.csClient.getClient().setScreen(MinecraftScreen.SelectWorld))
                .dimensions(buttonWidth, buttonHeight).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, -14)));
        y += buttonHeight + gap;
        draw(new HomeMenuButton(Textures.PROFILE, "MULTIPLAYER", true,
                () -> Providers.csClient.getClient().setScreen(MinecraftScreen.Multiplayer))
                .dimensions(buttonWidth, buttonHeight).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, -10)));
        y += buttonHeight + gap;
        draw(new HomeMenuButton(Textures.GRID, "CS MODULES", false,
                () -> Providers.csClient.getClient().setScreen(new ModMenu()))
                .dimensions(buttonWidth, buttonHeight).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, -6)));
        y += buttonHeight + gap;
        draw(new HomeMenuButton(Textures.HUD_ICON, "EDIT HUD", false,
                () -> Providers.csClient.getClient().setScreen(new HudEditor()))
                .dimensions(buttonWidth, buttonHeight).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, -2)));
        y += buttonHeight + gap;
        draw(new HomeMenuButton(Textures.MODS_TAB,
                (hasModMenu ? "MOD MENU" : "INSTALLED MODS") + "  •  " + externalModCount,
                false, this::openModsScreen)
                .dimensions(buttonWidth, buttonHeight).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, 2)));
        y += buttonHeight + gap;
        // Replay Mod's default menu, opened exactly as Replay Mod provides it.
        if (ReplayModBridge.isLoaded()) {
            draw(new HomeMenuButton(Textures.IMAGE, "REPLAY MOD", false,
                    () -> ReplayModBridge.open(Providers.csClient.getClient()))
                    .dimensions(buttonWidth, buttonHeight).position(x, y)
                    .animation(new SlideFade(AnimationConfig.mainMenu, 4)));
            y += buttonHeight + gap;
        }
        y += 1;
        draw(new HomeMenuButton(Textures.CLOSE, "QUIT GAME", false,
                () -> Providers.csClient.getClient().scheduleStop())
                .dimensions(180, shortView ? 28 : 31).position(centerX - 90, y)
                .animation(new Fade(AnimationConfig.mainMenu)));
    }

    private void drawBottomDock(boolean compact) {
        int tile = compact ? 38 : 40;
        int gap = 8;
        int count = 5;
        int total = count * tile + (count - 1) * gap;
        int x = (width - total) / 2;
        int y = height - (compact ? 57 : 61);
        draw(new HomeIconTile(Textures.SLIDERS,
                () -> Providers.csClient.getClient().setScreen(new ConfigEditor(Config.config)))
                .dimensions(tile, tile).position(x, y));
        x += tile + gap;
        draw(new HomeIconTile(Textures.PALETTE,
                () -> Providers.csClient.getClient().setScreen(new ThemeStudio()))
                .dimensions(tile, tile).position(x, y));
        x += tile + gap;
        draw(new HomeIconTile(Textures.SETTINGS,
                () -> Providers.csClient.getClient().setScreen(MinecraftScreen.Options))
                .dimensions(tile, tile).position(x, y));
        x += tile + gap;
        draw(new HomeIconTile(Textures.MODS_TAB, this::openModsScreen)
                .dimensions(tile, tile).position(x, y));
        x += tile + gap;
        draw(new HomeIconTile(Textures.IMAGE,
                () -> Providers.csClient.getClient().setScreen(new ScreenshotManagerScreen(new TitleMenu())))
                .dimensions(tile, tile).position(x, y));
    }

    /** Two compact lower-right community cards; each opens an animated confirmation first. */
    private void drawCommunityCards(boolean compact) {
        int cardWidth = compact ? 174 : 220;
        int cardHeight = compact ? 54 : 66;
        int gap = compact ? 7 : 9;
        int x = width - cardWidth - 18;
        int y = Math.max(86, height - cardHeight * 2 - gap - (compact ? 78 : 86));

        draw(new HomeYouTubeCard(() -> openExternal(ExternalLinks.Destination.YOUTUBE))
                .dimensions(cardWidth, cardHeight).position(x, y)
                .animation(new SlideFade(AnimationConfig.mainMenu, 8)));
        draw(new HomeDiscordCard(() -> openExternal(ExternalLinks.Destination.DISCORD))
                .dimensions(cardWidth, cardHeight).position(x, y + cardHeight + gap)
                .animation(new SlideFade(AnimationConfig.mainMenu, 11)));
    }

    private void openModsScreen() {
        if (Providers.csClient.getClient().isModLoaded("modmenu")) {
            Providers.csClient.getClient().openExternalModMenu();
        } else {
            Providers.csClient.getClient().setScreen(new InstalledModsScreen(new TitleMenu()));
        }
    }

    private void openExternal(ExternalLinks.Destination destination) {
        Providers.csClient.getClient().setScreen(new ExternalLinkConfirmScreen(new TitleMenu(), destination));
    }

    private void drawFooter(boolean hasModMenu, String externalModCount) {
        String left = "CS CLIENT V1  •  " + ModManager.MODS.size() + " MODULES";
        String right = hasModMenu
                ? "MOD MENU  •  " + externalModCount + " LOADED"
                : "INSTALLED MODS  •  " + externalModCount + " LOADED";
        draw(new Text(left).scale(0.27f).position(16, height - 15));
        draw(new Text(right).scale(0.27f)
                .position(Math.max(16, width - right.length() * 7 - 16), height - 15));
    }
}
