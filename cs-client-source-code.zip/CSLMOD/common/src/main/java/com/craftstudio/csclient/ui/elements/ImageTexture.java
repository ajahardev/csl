package com.craftstudio.csclient.ui.elements;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.common.ref.game.MinecraftClientRef;
import com.craftstudio.csclient.common.ref.render.WindowRef;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.SvgTexture;

public class ImageTexture extends Element {
    IdentifierRef sprite;

    public ImageTexture(IdentifierRef sprite) {
        this.sprite = sprite;
    }

    @Override
    public void render(RenderScope renderScope, ElementContext ctx) {
        if (sprite.toString().endsWith(".svg")) {
            MinecraftClientRef client = Providers.csClient.getClient();
            WindowRef window = client.getWindow();

            int windowWidth = Math.max(1, window.getWidth());
            int windowHeight = Math.max(1, window.getHeight());
            int framebufferWidth = Math.max(1, window.getFramebufferWidth());
            int framebufferHeight = Math.max(1, window.getFramebufferHeight());
            int renderWidth = Math.max(1, Math.round(width * (framebufferWidth / (float) windowWidth)));
            int renderHeight = Math.max(1, Math.round(height * (framebufferHeight / (float) windowHeight)));

            IdentifierRef pngId = SvgTexture.getSvg(sprite, renderWidth * 2, renderHeight * 2);

            this.sprite = pngId;
            if (pngId == null) {
                System.err.println("Failed to render SVG: " + sprite);
                return;
            }
        }

        renderScope.drawTexture(this.sprite, 0, 0, 0, 0, width, height);
    }
}
