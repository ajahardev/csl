package com.craftstudio.csclient.ui.elements;

import java.util.ArrayList;
import java.util.List;

import com.craftstudio.csclient.config.AnimationConfig;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.ElementRenderer;
import com.craftstudio.csclient.ui.RenderScope;

public class AnimationStagger extends Element {
    protected List<Element> children = new ArrayList<>();
    public int delay;

    public AnimationStagger(int delay) {
        this.delay = delay;
    }

    public AnimationStagger(AnimationConfig config) {
        this.delay = config.stagger.value;
    }

    public void draw(Element element) {
        if (!Config.stagger.value) {
            element.animation = null;
        }

        if (element.animation != null) {
            element.animation.delay = delay * children.size();
        }

        ElementRenderer.draw(children, element);

        this.height = Math.max(this.height, element.y + element.height);
        this.width = Math.max(this.width, element.x + element.width);
    }

    @Override
    public void render(RenderScope renderScope, ElementContext ctx) {
        ElementRenderer.render(children, ctx.elapsed, renderScope,
                ctx.mouseX,
                ctx.mouseY);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        ElementRenderer.mouseClicked(children, mouseX, mouseY, button);
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        ElementRenderer.keyPressed(children, keyCode, scanCode, modifiers);
    }

    @Override
    public void charTyped(String text) {
        ElementRenderer.charTyped(children, text);
    }

    @Override
    public boolean acceptsTextInput() {
        return ElementRenderer.hasFocusedTextInput(children);
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        ElementRenderer.mouseDragged(children, mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        ElementRenderer.mouseReleased(children, mouseX, mouseY, button);
    }
}
