package com.craftstudio.csclient.config;

import com.craftstudio.csclient.config.property.IntProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.config.property.SelectProperty;

public class AnimationConfig {
    public static ConfigManager config;

    public static final AnimationConfig logo = new AnimationConfig(700, 0);
    public static final AnimationConfig mainMenu = new AnimationConfig(700, 120);
    public static final AnimationConfig modMenu = new AnimationConfig(560, 24);
    public static final AnimationConfig shiftMenu = new AnimationConfig(520, 70);
    public static final AnimationConfig accountMenu = new AnimationConfig(520, 45);
    public static final AnimationConfig pauseMenu = new AnimationConfig(520, 55);

    public static void init(ConfigManager parent) {
        config = new ConfigManager(parent, "Animations");
        logo.init("Logo");
        mainMenu.init("Main Menu");
        modMenu.init("Module Browser");
        shiftMenu.init("Quick Menu");
        accountMenu.init("Account Menu");
        pauseMenu.init("Pause Menu");
    }

    public final IntProperty duration;
    public final IntProperty stagger;
    public final SelectProperty curve;

    public AnimationConfig(int duration, int stagger) {
        this.duration = Property.integer(duration);
        this.stagger = Property.integer(stagger);
        this.curve = Property.select(1, "Ease In Out Cubic", "Ease Out Cubic", "Ease In Out Back");
    }

    public void init(String name) {
        config.property(name + " Duration", duration);
        config.property(name + " Stagger", stagger);
        config.property(name + " Curve", curve);
    }
}
