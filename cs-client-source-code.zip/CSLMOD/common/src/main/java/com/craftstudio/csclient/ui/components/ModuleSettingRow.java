package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.resources.Fonts;

/**
 * Dense Feather/Lunar-derived module option row. The control itself is layered
 * by ConfigEditor on the right; this surface only owns hierarchy and feedback.
 */
public class ModuleSettingRow extends Element {
    private final String name;
    private final String hint;
    private final IdentifierRef icon;
    private final int reservedControlWidth;
    private float hover;

    public ModuleSettingRow(String name, String hint, IdentifierRef icon, int reservedControlWidth) {
        this.name = name;
        this.hint = hint;
        this.icon = icon;
        this.reservedControlWidth = Math.max(54, reservedControlWidth);
        dimensions(620, 56);
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        float target = ctx.isHovering() ? 1f : 0f;
        hover += (target - hover) * 0.24f;
        int fill = blend(0xB814191F, 0xEB1D252D, hover);
        int outline = blend(0x385E6872, Theme.withAlpha(185, Theme.ACCENT.value), hover);

        scope.drawRoundedRectangle(0, 0, width, height, 6, fill);
        scope.drawRoundedBorder(0, 0, width, height, 6, outline);

        int railHeight = 18 + Math.round(22 * hover);
        scope.drawRoundedRectangle(0, (height - railHeight) / 2, 2, railHeight, 1,
                Theme.withAlpha(145 + Math.round(95 * hover), Theme.ACCENT.value));

        scope.drawRoundedRectangle(11, 13, 30, 30, 5,
                blend(0xDA20262D, Theme.withAlpha(185, Theme.ACCENT.value), hover * 0.48f));
        scope.drawTexture(icon, 18, 20, 0, 0, 16, 16,
                hover > 0.52f ? Theme.FOREGROUND.value : Theme.PRIMARY_FG.value);

        int copyX = 52;
        int maxCopyWidth = Math.max(72, width - copyX - reservedControlWidth - 18);
        String visibleName = ellipsize(name, maxCopyWidth, 0.49f);
        String visibleHint = ellipsize(hint, maxCopyWidth, 0.29f);
        scope.drawText(0.49f, visibleName, copyX, 12, Theme.FONT.value, Theme.FOREGROUND.value);
        scope.drawText(0.29f, visibleHint, copyX, 34, Theme.FONT.value,
                Theme.withAlpha(150, Theme.PRIMARY_FG.value));
    }

    private static String ellipsize(String text, int maxWidth, float scale) {
        if (text == null) return "";
        if (Fonts.getWidth(text, Theme.FONT.value) * scale <= maxWidth) return text;
        int end = text.length();
        while (end > 1 && Fonts.getWidth(text.substring(0, end) + "…", Theme.FONT.value) * scale > maxWidth) {
            end--;
        }
        return text.substring(0, Math.max(1, end)) + "…";
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = Math.round(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = Math.round(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = Math.round(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
