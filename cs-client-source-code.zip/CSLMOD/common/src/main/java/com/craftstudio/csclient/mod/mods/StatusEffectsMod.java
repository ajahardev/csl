package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.util.FastNumberFormatter;
import java.util.List;

import com.craftstudio.csclient.common.provider.FeatureProvider;
import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.SpriteRef;
import com.craftstudio.csclient.common.ref.game.EffectRef;
import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.HudMod;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModLayout;
import com.craftstudio.csclient.mod.ModSpec;
import com.craftstudio.csclient.ui.RenderScope;

/**
 * StatusEffectsMod displays the player's active potion effects as
 * a HUD overlay.
 *
 * The effect list is supplied by the platform through an interface
 * returned by a future {@code PlayerFeature#getActiveEffects()} call.
 * Until that is wired up, the existing {@link StatusEffectsInterface}
 * bridge is used, accessed via {@link FeatureProvider}.
 */
public class StatusEffectsMod extends Mod implements HudMod {

    public static final BoolProperty enabled = Property.bool(false);
    private static final ModLayout layout = new ModLayout(60, 0);

    public StatusEffectsMod() {
        super(
                new ModSpec("Status Effects", "effect")
                        .description("Displays active status effects")
                        .version("v0.2.0")
                        .tags("Utility")
                        .requires(Providers.feature::player),
                enabled.named("Enabled"),
                layout.prop());
    }

    // ---------------------------------------------------------------
    // HudMod
    // ---------------------------------------------------------------

    @Override
    public void renderHud(RenderScope scope) {
        renderEffects(scope, Providers.feature.player().getActiveEffects());
    }

    @Override
    public void renderDummy(RenderScope scope) {
        renderEffects(scope, Providers.feature.player().getDummyEffects());
    }

    // ---------------------------------------------------------------
    // Rendering
    // ---------------------------------------------------------------

    private void renderEffects(RenderScope scope, List<? extends EffectRef> effects) {
        int row = 0;

        for (EffectRef effect : effects) {
            if (!effect.shouldShowIcon())
                continue;

            SpriteRef sprite = effect.getIcon();
            int y = 4 + (20 * row);
            if (sprite == null) {
                scope.drawTexture(effect.getIconId(), 5, y, 0, 0, 16, 16);
            } else {
                scope.drawSpriteStretched(sprite, 5, y, 16, 16);
            }
            scope.drawText(0.48f, durationString(effect),
                    25, y + 4,
                    layout.font.value, layout.fgColor.value);
            row++;
        }

        layout.width = 74;
        layout.height = Math.max(18, 6 + (20 * row));
    }

    private static String durationString(EffectRef effect) {
        if (effect.isInfinite())
            return effect.getInfiniteText();

        int totalSeconds = effect.getDurationSeconds();
        if (totalSeconds >= 3600) {
            return (totalSeconds / 3600) + "h";
        } else if (totalSeconds >= 60) {
            return (totalSeconds / 60) + ":" + FastNumberFormatter.twoDigits(totalSeconds % 60);
        } else {
            return totalSeconds + "s";
        }
    }

    // ---------------------------------------------------------------
    // Mod contract
    // ---------------------------------------------------------------

    @Override
    public ModLayout getDimensions() {
        return layout;
    }

    @Override
    public boolean isEnabled() {
        return enabled.value;
    }

    @Override
    public void onEnabled(boolean e) {
        enabled.value = e;
    }
}
