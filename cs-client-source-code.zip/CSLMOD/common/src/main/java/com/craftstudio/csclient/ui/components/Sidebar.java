package com.craftstudio.csclient.ui.components;

import com.craftstudio.csclient.common.provider.Providers;
import com.craftstudio.csclient.common.ref.asset.IdentifierRef;
import com.craftstudio.csclient.config.Config;
import com.craftstudio.csclient.config.Theme;
import com.craftstudio.csclient.ui.Element;
import com.craftstudio.csclient.ui.ElementContext;
import com.craftstudio.csclient.ui.RenderScope;
import com.craftstudio.csclient.ui.Utils;
import com.craftstudio.csclient.ui.resources.Textures;
import com.craftstudio.csclient.ui.screens.ConfigEditor;
import com.craftstudio.csclient.ui.screens.ModMenu;

/** Legacy compact navigation retained for secondary screens; cosmetics were removed. */
public class Sidebar extends Element {
    private record SidebarComponent(IdentifierRef sprite, Runnable onClick, boolean end) {
    }

    private final Runnable onClose;
    private final SidebarComponent[] components;
    private final int active;

    public Sidebar(int active, Runnable onClose) {
        this.width = 36;
        this.height = 350;
        this.active = active;
        this.onClose = onClose;
        this.components = new SidebarComponent[] {
                new SidebarComponent(Textures.GRID,
                        () -> Providers.csClient.getClient().setScreen(new ModMenu()), false),
                new SidebarComponent(Textures.SLIDERS,
                        () -> Providers.csClient.getClient().setScreen(new ConfigEditor(Config.config)), false),
                new SidebarComponent(Textures.CLOSE, this.onClose, true)
        };
    }

    @Override
    public void render(RenderScope scope, ElementContext ctx) {
        scope.drawRoundedRectangle(0, 0, width, height, 12, 0xE312161C);
        scope.drawRoundedBorder(0, 0, width, height, 12, Theme.withAlpha(70, Theme.ACCENT.value));
        for (int i = 0, top = 0, bottom = 0; i < components.length; i++) {
            SidebarComponent component = components[i];
            int y = component.end ? height - 42 - bottom++ * 40 : 8 + top++ * 40;
            boolean selected = i == active || ctx.isHovering(4, y, 28, 32);
            scope.drawRoundedRectangle(4, y, 28, 32, 9,
                    selected ? Theme.withAlpha(220, Theme.ACCENT.value) : 0x0012161C);
            scope.drawTexture(component.sprite, 10, y + 8, 0, 0, 16, 16,
                    selected ? Theme.ACCENT_FG.value : Theme.PRIMARY_FG.value);
        }
    }

    @Override
    public void click(int mouseX, int mouseY) {
        for (int i = 0, top = 0, bottom = 0; i < components.length; i++) {
            SidebarComponent component = components[i];
            int y = component.end ? height - 42 - bottom++ * 40 : 8 + top++ * 40;
            if (Utils.isHovering(mouseX - 4, mouseY - y, 28, 32, 1f)) {
                component.onClick.run();
                return;
            }
        }
    }
}
