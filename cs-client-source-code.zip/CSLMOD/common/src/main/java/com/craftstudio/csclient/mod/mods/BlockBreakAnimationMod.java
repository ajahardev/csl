package com.craftstudio.csclient.mod.mods;

import com.craftstudio.csclient.config.property.BoolProperty;
import com.craftstudio.csclient.config.property.Property;
import com.craftstudio.csclient.mod.Mod;
import com.craftstudio.csclient.mod.ModSpec;

/** Selects CS destruction stages when enabled and active vanilla stages when disabled. */
public class BlockBreakAnimationMod extends Mod {
    private static final BoolProperty ENABLED = Property.bool(true);

    public BlockBreakAnimationMod() {
        super(new ModSpec("Block Break Animation", "block_break_animation")
                        .description("Uses CS block cracks; disable to restore Minecraft's active vanilla/resource-pack stages")
                        .version("v1.0.0").tags("Visuals", "World"),
                ENABLED.named("Enabled"));
    }

    public static boolean useCsStages() {
        return ENABLED.value;
    }

    @Override public boolean isEnabled() { return ENABLED.value; }
    @Override public void onEnabled(boolean enabled) { ENABLED.value = enabled; }
}
