# CS Client V1 common module

## Shared Home systems

- `FeaturedServers` owns five fixed local server slots.
- Only the exact PlantMC address is approved for the target-specific native connect flow.
- `HomeServerIcon` renders the original icon-only Home rail with a logo line and status dot only; four placeholders stay local and route to `ServerComingSoonScreen`.
- The supplied PlantMC logo is packaged under CS assets and never downloaded at runtime.

## Target adapters

- Each Minecraft target implements `MinecraftClientRef#joinFeaturedServer()` with that target’s native connection screen/API.
- The common layer never provides an arbitrary server address or a remote server-list API.
- Community browser links retain exact allowlisting and explicit confirmation.
