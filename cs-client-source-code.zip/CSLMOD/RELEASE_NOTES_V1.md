# CS Client V1 — Home server rail and stable naming

## Product version

- Product label: **CS Client V1**
- Public product/artifact label: **V1**
- Fabric metadata version: **1.0.0+MinecraftVersion** (valid extended semantic version)
- Version policy: **V1 is frozen until the project owner explicitly requests a change.**
- Active pre-release labels removed from product metadata, Home, Pause, Settings, Loading, release artifact naming, and current documentation.

## Home server rail

A left-edge icon-only Home server rail now contains exactly five fixed local slots. Its default state shows only compact logos and status dots; it does not show names, IPs, cards, or a server heading:

| Slot | Behavior |
|---|---|
| PlantMC — `play.plantmc.fun:25627` | Explicit click starts Minecraft’s native connection flow. |
| CS BedWars | Local Coming Soon popup only. |
| CS Practice | Local Coming Soon popup only. |
| CS SkyBlock | Local Coming Soon popup only. |
| CS Survival | Local Coming Soon popup only. |

The top icon uses the packaged PlantMC logo. The remaining icon slots use an original neutral server icon. Hover alone adds a small CS halo; no full card expands. PlantMC is also installed as the protected first entry in Minecraft's saved multiplayer list; its packaged icon, address and position cannot be edited, deleted or reordered.

## Identity cleanup

Legacy client name/link references were removed from runtime/UI/metadata/current release material. Required licensing provenance remains as a generic legal notice without product identity or external legacy link.

## Compatibility fixes

- Kept the public **V1** label while changing Fabric metadata to valid semantic versions such as `1.0.0+26.2`.
- Added version-specific 26.2 text-shader compatibility sources for `minecraft:core/text` so `minecraft:pipeline/gui_text` can compile when the launcher/runtime omits those sources.
- Removed the duplicate render-time mouse-coordinate multiplier. Hover animations and click hitboxes now use the same responsive GUI coordinate space.
- Expanded launcher-offline detection for canonical/version-3 UUIDs and common placeholder-token formats.
- Local skin/cape tools now work for every valid launcher profile, so unusual offline launchers are no longer mislabeled and locked out.
- Fixed the asynchronous appearance commit guard so both launcher profiles and CS local profiles can save/apply appearance files.
- Removed the custom in-game filesystem browser and routed skin/cape selection through the native PNG chooser API.
- Added modern Minecraft Services username lookup with Mojang fallback, active skin-head UI, and an atomic launcher↔client appearance sync contract.
- Replaced the destructive loading-overlay `@Overwrite` with a low-priority, non-destructive HEAD injection. Vanilla method constants remain available to RRLS mixins.
- When the `rrls` mod is installed, CS Client yields loading-overlay rendering to RRLS instead of cancelling its animation lifecycle.
- Added concrete 26.1/26.2 `WindowRef` framebuffer bridges from Minecraft's `getScreenWidth()`/`getScreenHeight()` methods.
- Added safe default framebuffer dimensions in `WindowRef` to prevent `AbstractMethodError` with launcher- or renderer-modified Window classes.
- Added concrete 26.1/26.2 `ItemStackRef.getDamage()` bridges to Minecraft's `getDamageValue()` API, plus a safe interface fallback.
- Added 26.1/26.2 status-effect bridges for `showIcon()` and `isInfiniteDuration()` to prevent the same interface-mapping failure in Status Effects.
- Hardened SVG raster sizing against zero dimensions and integer-scaling errors.
- Removed the remaining legacy `/2` pointer correction from HUD Editor rendering so editor hover and input coordinates match.
- Added per-module render/tick fault isolation: an unexpected runtime/linkage failure quarantines only that module instead of crashing Minecraft.
- Added scaled HUD collision handling: dragging slides along neighboring widgets, blocked moves stay at the previous safe position, and resizing cannot enter another module.
- Existing/preset HUD positions are separated when the editor opens, and keyboard/reset interactions follow the same collision rules.
- Replaced the settings-based Performance Boost with a CS-owned Performance Engine. Every graphics preset/distance/particles/clouds/entity-distance setter and shutdown restoration path was removed.
- Added Low, Balanced, and High Performance internal profiles plus optional frametime-driven adaptation with 20-second hysteresis.
- Added a pre-resolved render-entry array and single-line HUD measurement fast path to remove repeated per-frame iterator/type/layout and substring work without changing game settings.
- Zoom now has per-frame smooth transitions, hold/toggle behavior and wheel-up/wheel-down magnification control while preserving normal hotbar scrolling outside zoom.
- Minecraft 26.2 exposes native Friends from CS Home/Escape.
- The custom Escape menu exposes a labelled vanilla **Open to LAN** action in integrated worlds on all three targets, using 1.21.11 Open to LAN, 26.1 Share to LAN, and 26.2 Multiplayer Options screens respectively. It stays separate from CS Worlds relay hosting and is disabled on remote servers or during a CS Worlds transition/session.
- MODS remains available without optional Mod Menu through a read-only Fabric metadata viewer.
- Added Chat Improvements with timestamps, mention markers, Copy Last, Hide/Show Chat, keybinds, and consecutive system-message compaction while preserving signed player-message reporting history.
- Added a local Screenshot Manager for the active profile with paged thumbnails, preview, copy-path, and delete confirmation; it includes no upload/webhook/social service.
- Added independently implemented Shield Statuses using Minecraft's native cooldown percentage, red/orange/green states, optional interpolation, item-icon outlines, and a second translucent first-person model pass that does not replace resource-pack shield textures.
- Shield Status behavior was researched from Walksy's MIT project with attribution; no upstream assets, source copy, WalksyLib, grayscale texture replacement, or custom texture dependency is bundled.
- Added CS Worlds Host/Join logic backed by MIT-licensed e4mc 6.2.1; no CS-operated backend/VPS is required.
- Fixed Krypton/e4mc login-cipher redirect conflicts with a reproducible classic-relay profile: `e4mc.mixins.json` is replaced and only disabled Dialtone/login/DNS mixin classes are removed, retaining `ServerConnectionListenerMixin`.
- Fixed normal singleplayer disconnects by forcing bundled e4mc host/Dialtone hosting OFF at client startup and enabling it only after an explicit Host World click.
- Host World calls each target's vanilla IntegratedServer LAN publish API. e4mc intercepts that listener, negotiates the relay, and provides the `.e4mc.link` domain.
- If vanilla Open to LAN was used before Host World, CS reuses the already-created in-memory listener only after the explicit Host click. This avoids the silent no-session path on 1.21.11/26.1, where Minecraft cannot safely unpublish and recreate that listener.
- CS captures e4mc's exact `Domain assigned:` logger event, uses its chat component only as hidden-domain fallback, suppresses only the assignment chat line, and displays the domain in CS UI with Copy/Stop controls.
- Join World accepts a short label or full e4mc domain, appends `.e4mc.link` when required, validates the final address, and passes it to Minecraft's native Direct Connect flow.
- Dedicated-server safety disables the client-bundled e4mc host/Dialtone flags before a dedicated TCP listener starts, preserving CS's optional branding-relay server use without exposing the server through e4mc.
- Added allocation-free per-frame timing, p95/p99/p99.9, 1%/0.1% low calculations, local CSV/JSON benchmark export, heap/GC/CPU reporting, immutable enabled-module snapshots, bounded styled-text caching, and non-regex text line scanning.
- Scoreboard and Boss Bar now use tick-window snapshots instead of rebuilding stream/list data multiple times in one rendered frame.
- Added a Gradle safety gate that fails if forbidden Minecraft/Sodium graphics-setting mutation code returns.
- Scoreboard and Boss Bar are now automatic HUD adapters with no Enabled property, on/off switch, or module toggle key.
- They stay dormant without server data and automatically appear when a server supplies a scoreboard/boss event.
- Right Shift → HUD Layout always exposes movable Scoreboard/Boss Bar previews; live server data is used when present.
- HUD backgrounds default OFF, X/Y controls are hidden from module settings, settings previews match gameplay, and all four public HUD styles now have distinct rendering behavior.
- FPS/Ping/TPS displays use clean semantic quality colours; Keystrokes/WASD remains unchanged.
- Scoreboard moves Minecraft's original native sidebar renderer, preserving server title, ordering, hidden-entry rules, team formatting, number formats, live updates, and vanilla background exactly.
- Boss Bar now moves Minecraft's exact native renderer instead of rebuilding bars, preserving server names, colours, divisions/notches, progress animation, ordering and visibility.
- Scoreboard and Boss Bar start at their exact vanilla positions; HUD Layout movement is persisted only after an explicit drag, and Reset restores vanilla placement.
- Fixed 26.1/26.2 Shulker Preview's non-cancellable TAIL injection; valid previews now render from a cancellable HEAD injection, support empty shulkers, and stay inside screen edges.
- Health Indicator now references Minecraft's exact container/full/half/absorption heart sprites at runtime; the old hand-drawn private atlas was removed.
- Auto GG now recognizes guarded result markers across supported networks while 26.1/26.2 player chat cannot trigger it.
- Clear Water/Lava and No Fog paths were re-audited against each target's fog APIs and retain independent environment toggles.
- MIT-compatible behavior/source portions from Shulker Preview, Clear Water, AutoGG, and NoFog are now formally adapted with copyright notices and full MIT texts packaged under `LICENSES/`.
- HealthIndicators remains research-only because it is LGPL-3.0; no LGPL code/assets are bundled, and CS keeps an independent vanilla-heart implementation.
- Added protocol-versioned CS player branding using `csclient:brand_hello` and `csclient:brand_presence` custom payloads.
- The same JAR acts as an optional Fabric server relay; clients send no payload unless the server explicitly advertises support.
- UUID capability cache is event-updated/immutable and resets on disconnect; remote UNKNOWN/non-CS players never receive a guessed badge.
- Added official 32×32 transparent CS nametag asset, cached Small/Normal/Large glyphs, 48-block limit, vanilla nametag visibility/occlusion behavior, and independently configurable self logo.
- Added a canonical PlantMC server-list entry at index zero with protected UI controls, the transparent 64×64 user-supplied icon, responsive 1009×202 row banner, and India flag.
- Normal vanilla server-list operations remain untouched for every non-PlantMC address; arbitrary `play.*` servers can be added, edited, reordered and deleted normally.

## Build/package verification

- Fresh per-target production builds passed for Minecraft **1.21.11**, **26.1**, and **26.2**.
- ZIP integrity and `SHA256SUMS.txt` verification passed for all three JARs.
- Packaged JAR Markdown check: **0 `.md`/`.MD` entries**; notices and third-party licence index are packaged as `.txt`.
- Archive entries: **587** (1.21.11), **585** (26.1), **590** (26.2).
- Declared CS mixins: **49 per target**; missing packaged mixin classes: **0**.
- Common module smoke test: **57/57 modules passed** tick, overlay, live HUD, dummy HUD, and editor render paths.
- HUD collision smoke test: **drag overlap rejection and resize overlap rejection passed**.
- Performance settings safety gate: **no graphics preset/distance/particles/clouds/entity-distance/Sodium config mutation path exists**.
- Performance metrics smoke test: **render-frame sampling, FPS/frametime percentiles, 1%/0.1% lows, and CSV/JSON benchmark export passed**.
- Immutable enabled-module snapshot and Sodium/settings ownership smoke checks passed.
- All three targets compile with vanilla world create/play behavior preserved; every declared mixin class is packaged, and no mixin application error appeared before renderer startup in client smoke runs.
- Scoreboard/Boss fail-open, Shulker configuration, Auto GG detection, Clear Water/Lava, No Fog, and exact vanilla-heart resource checks passed.
- PlantMC address, first-slot definition, protected server-list mixin packaging, and 64×64 RGBA icon checks passed.
- Minecraft 1.21.11, 26.1, and 26.2 client smokes each reached CS initialization; they stopped only because the sandbox has no supported GLFW/X11 `DISPLAY`, with no CS/mixin application error beforehand.
- CS Worlds domain extraction, client-start classic-relay gate, single-mixin e4mc profile, and dedicated-server no-relay safety checks passed.
- Real Krypton **0.3.1 + Minecraft 26.2** compatibility startup loaded both mods and CS successfully with **0 redirect conflicts**; e4mc prepared exactly one listener mixin and all host/Dialtone flags remained false.
- Registered modules: **57**, all unique.
- All JARs contain the packaged PlantMC logo, neutral server-slot icon, icon-only Home rail class, server Coming Soon screen, and exact fixed-server adapter.
- Product-owned packaged content scan found no legacy client identity or pre-release label.
- The Home rail still has no remote list/ping/discovery logic. CS Worlds network traffic is owned by nested e4mc and starts only after vanilla LAN publish; payment/catalog code is absent.

```text
77d990536ab380c7f6fc8a6f2c14315bc044ac9ae49b2f6ce492cb52a636e05a  cs-client-V1+1.21.11.jar
594dc05277b4f38a586beb3fcc10a62a16696d0fa3e7d974c21b6f83f3ae6eeb  cs-client-V1+26.1.jar
16b956da97f43ad4fb8a4b473e2312c39e3cfb94d2450b938eaa6bd865f53ff6  cs-client-V1+26.2.jar
```

## Runtime-test boundary

Build/package validation is not a live Android/Pojav, OpenGL, Vulkan, or two-network e4mc result. Before public release, physically test e4mc Host/Join/domain expiry with online and offline profiles, Chat buttons/hiding, Screenshot Manager, Shield Status with resource packs/Low Shield, Home/Pause layouts, PlantMC joining, and retained gameplay modules on every target you distribute.
