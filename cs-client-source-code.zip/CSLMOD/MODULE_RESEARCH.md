# Module research and implementation notes

## Source-use policy

The referenced repositories were downloaded and reviewed. Compatible MIT-licensed behavior/source portions from Shulker Preview, Clear Water, AutoGG, and NoFog are adapted with copyright notices and full MIT texts in `LICENSES/`. HealthIndicators is LGPL-3.0, so its source/assets are not merged into the proprietary client; CS keeps an independent implementation that references Minecraft's built-in heart textures.

## Shulker Preview

Reference: https://github.com/kgriff0n/shulker-preview — MIT

Observed behavior: identify real shulker items, read the container data component, show a 9×3 inventory, preserve item decorations, and keep the preview inside the screen.

CS implementation changes:

- Fixed the 26.1/26.2 tooltip injection to be cancellable.
- Moved custom preview extraction to `HEAD`, so the vanilla tooltip is suppressed only when a valid CS shulker grid is actually rendered.
- Empty shulkers now show an empty 9×3 grid instead of returning without a preview.
- Added horizontal and vertical screen-edge clamping.

## Health Indicators

Reference: https://github.com/AdyTech99/HealthIndicators — LGPL-3.0

No LGPL source or texture assets were incorporated. Research confirmed that exact vanilla heart sprites are preferable to a hand-drawn private-use font atlas.

CS implementation changes:

- The CS bitmap-font provider now references Minecraft's own runtime heart sprite resources directly: container, full, half, and absorbing full.
- The old custom 30×10 heart atlas was removed.
- A dedicated absorption glyph was added.
- Exact vanilla textures render untinted by default; optional CS color tinting remains available when exact-texture mode is disabled.

## Clear Water / Lava

Reference: https://github.com/ExpensiveKoala/Clear-Water — MIT

Research confirmed that water and lava need separate environment checks and fog settings. CS retains its independent 26.2 `FogData` implementation and separate water/lava toggles. It clears the fog contribution after vanilla selects the active fluid and separately suppresses the matching first-person overlay.

## Auto GG

Reference: https://github.com/ModLabsCC/AutoGG — MIT

Research confirmed that reliable detection uses network-specific result markers rather than only broad words such as “winner”. CS keeps its own delayed, duplicate-guarded implementation.

CS implementation changes:

- Added supported result markers for Hypixel, BedwarsPractice, PvP Land, Minemen, and Mineplex-style result screens.
- Restricted 26.1/26.2 detection to server system messages, preventing player chat from triggering Auto GG.
- Kept message sanitization, delayed sending, duplicate suppression, and explicit supported-network filtering.

## No Fog

Reference: https://github.com/Virtuoel/NoFog — MIT

Research confirmed the standard approach of moving fog start/end out of view range. Minecraft 26.2 additionally exposes fog color alpha; CS uses that API to set the fog contribution to zero while retaining finite, safe plane values.

## Scoreboard and Boss Bar

These were verified against Minecraft 1.21.11, 26.1, and 26.2 target bytecode rather than copied from another mod.

- Scoreboard objective selection now matches vanilla: team-color sidebar first, normal sidebar fallback.
- Hidden scoreboard entries are filtered and team-formatted names are used.
- Scoreboard and Boss Bar replacements are fail-open: vanilla rendering remains active if CS has no readable data or a module is quarantined.
- Scoreboard text automatically falls back to a high-contrast foreground if saved colors would produce black-on-black output.
