# CS Client V1 — Minecraft 26.2 port

| Item | Value |
|---|---|
| Minecraft | exact `26.2` |
| Java | 25 |
| Fabric Loader | `0.19.3` |
| Fabric API | `0.157.0+26.2` |
| Fabric Loom | `1.17.19` |

## V1 target additions

- Home navigation remains on `Minecraft.gui` / `Gui` ownership.
- `joinFeaturedServer()` creates a fixed native `ServerData` connection only for `play.plantmc.fun:25627` after an explicit click.
- The common Home layer supplies no editable address, discovery, background ping, server-list request, or automatic connection.
- The left server rail, packaged PlantMC logo, and local Coming Soon server screen are target-neutral common UI.

Minecraft 26.2 can use an experimental Vulkan backend. CS Client V1 uses vanilla Gui/Hud/renderer submission APIs and has no direct OpenGL rendering call. This is static compatibility work, not a device-runtime guarantee.
