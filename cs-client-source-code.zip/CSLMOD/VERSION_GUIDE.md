# CS Client V1 version guide

Active targets:

- `versions/1.21.11` — Java 21, Yarn/intermediary runtime
- `versions/26.1` — Java 25, Mojang names
- `versions/26.2` — Java 25, Mojang names, Fabric Loader 0.19.3, Fabric API `0.157.0+26.2`

Public release label: **V1**. Product label: **CS Client V1**. Fabric metadata uses the compatible semantic base version **1.0.0** plus the Minecraft target.

> Version freeze: keep the public client/artifact label at **V1** until the project owner explicitly requests a change.

## Required real-game release checks

A build/JAR check does not replace a Minecraft/Pojav runtime test.

1. Test Home at normal and GUI Scale 3/4: left server rail must not overlap core actions.
2. Click **PlantMC** once: only `play.plantmc.fun:25627` may reach Minecraft’s native connection screen.
3. Click all four other server slots: each must show local Coming Soon; no connection/ping/network action.
4. Test title panorama, RShift → HUD Layout → CS Settings → Modules, Escape/Pause, and Appearance Studio.
5. Test Low Shield, Low Fire, Clear Water/Lava, Block Break, Block Overlay, Health Indicator, and Hitbox filtering.
6. Test YouTube/Discord: initial click shows confirmation; Cancel/Escape opens nothing; only confirm opens the exact link.
7. Test any target/backend you publish, including Pojav and 26.2’s experimental Vulkan backend when relevant.

If anything fails, save the exact screen/settings screenshot and `.minecraft/logs/latest.log`, plus launcher, renderer/backend, Fabric API, and mod list.
