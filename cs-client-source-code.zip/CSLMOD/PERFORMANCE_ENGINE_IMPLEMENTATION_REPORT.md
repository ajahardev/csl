# CS Performance Engine — implementation status

## Implemented now

### Strict settings ownership

- Removed every Performance Engine graphics-preset mutation path.
- Removed render/simulation/entity distance changes.
- Removed particles/clouds/shadows/AO/VSync/FPS-limit changes.
- Removed settings capture and shutdown restoration.
- Performance Engine does not access Sodium configuration.
- Added a Gradle safety task that fails when forbidden setters/tokens return.

### Actual frame metrics

- Allocation-free fixed primitive frame ring buffer, sampled from the actual HUD render-frame path.
- Average FPS and average frametime.
- p95, p99 and p99.9 frametime.
- 1% and 0.1% low FPS equivalents.
- Worst frametime.
- Heap, benchmark GC count/pause, and process CPU load when available.
- Detected renderer/performance mod IDs in local benchmark metadata.

### Local benchmark export

- Configurable benchmark key, duration, and scenario label.
- Local CSV per-frame samples.
- Local JSON summary.
- No upload/network path.
- Files saved under `.minecraft/cs-client-benchmarks/`.

### Internal profiles

- Low, Balanced, and High Performance.
- Profiles control only CS HUD/minimap refresh behavior.
- Optional adaptive selection from measured p95/p99 frametimes.
- Multi-window hysteresis and 20-second cooldown prevent oscillation.

### Allocation/work reduction

- Immutable enabled-module snapshot, replaced only on module-state changes.
- Removed defensive enabled-list allocation from every frame/tick.
- Removed top-level CS screen element copy from every render.
- Bounded immutable styled-text cache.
- Removed regex line splitting from common text width and target text render paths.
- Added short refresh-window snapshots for Scoreboard and Boss Bar data.
- Removed capturing module-guard lambdas from the gameplay render/tick paths.

## Verification

- `:common:performanceSettingsSafetyCheck` passed.
- `:common:moduleSmokeTest` passed: 54/54 modules.
- Metrics percentile/export smoke test passed.
- Immutable snapshot test passed.
- All three production targets built successfully.
- JAR integrity and semantic metadata checks passed.

## Intentionally deferred

The following were not added without real benchmark evidence:

- Sodium/chunk renderer patches
- Vanilla entity or block-entity culling
- Entity AI/tick throttling
- Particle reduction
- Chunk threading/worldgen rewrites
- Raw OpenGL code
- Asynchronous world access

The next phase should run the benchmark matrix from `PERFORMANCE_ENGINE_RESEARCH_REPORT.md`. Conservative culling may then be added only for CS-owned overlays if the data proves a benefit.
