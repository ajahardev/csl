# CS Client V1 — Performance Engine

The Performance Engine optimizes only work owned by CS Client. It does not read, change, save, or restore Minecraft, Sodium, renderer, render-distance, simulation-distance, particles, clouds, entity-distance, or other visual settings.

## Internal profiles

- **Low** — frequent CS updates, maximum compatibility.
- **Balanced** — moderate CS HUD/minimap refresh reduction.
- **High Performance** — strongest safe CS-owned refresh reduction.

Adaptive mode evaluates real p95/p99 render frametimes every five seconds. A profile can change only after multiple consistent windows and a 20-second cooldown, preventing oscillation. Profiles affect only CS refresh/cache behavior.

## Implemented optimization work

- Immutable enabled-module snapshot, replaced only when module state changes.
- No defensive enabled-module list allocation in every rendered frame/client tick.
- Bounded cache of immutable styled CS text.
- No regex `String.split` in the normal HUD text width/render path.
- Scoreboard and Boss Bar source snapshots are shared across repeated calls in one refresh window.
- Existing CS HUD/minimap value refresh controls remain profile-driven.

## Frame metrics

The engine records from the actual HUD render-frame path into fixed primitive arrays. Per-frame measurement performs no object allocation.

Metrics:

- Average FPS
- Average frametime
- p95, p99 and p99.9 frametime
- 1% low and 0.1% low FPS equivalents
- Worst frametime
- Heap used
- GC count and pause time during a benchmark
- Process CPU load when the JVM exposes it
- Effective internal profile
- Detected performance/render mods

## Benchmark export

Configure **Start/Stop Benchmark Key**, duration, and scenario label in the Performance Engine module.

- First key press starts a benchmark.
- A second key press stops and exports immediately.
- It also exports automatically when the configured duration is reached.
- Maximum retained session size is 131,072 frames; reaching it triggers export.

Files are saved locally in:

```text
.minecraft/cs-client-benchmarks/
```

Each session creates:

- CSV with one frametime sample per frame.
- JSON summary with FPS/lows/frametime/heap/GC/CPU/profile/environment data.

No benchmark data is uploaded.

## Safety enforcement

Gradle task:

```bash
./gradlew :common:performanceSettingsSafetyCheck
```

The build fails if forbidden graphics-preset, view/simulation-distance, entity-distance, Sodium config, or shutdown-restoration code is reintroduced into the Performance Engine paths.

The module smoke test also verifies metrics, CSV/JSON export, immutable module snapshots, and settings ownership:

```bash
./gradlew :common:moduleSmokeTest
```
