# CS Client V1 feature set

## Home server rail

- Original narrow left-edge icon rail inspired by the logo-line hierarchy of a modern client Home screen, without copying another client’s branding/assets/layout.
- Five icon-only local slots arranged in a narrow vertical line, with small hover halo, status dot, and compact mobile-aware sizing. No server names, IPs, cards, headings, or player-count text appear at rest.
- Top **PlantMC** icon uses the packaged PlantMC logo and exact address `play.plantmc.fun:25627`.
- PlantMC is the only joinable icon; it uses the native Minecraft connect screen after an explicit click.
- CS BedWars, CS Practice, CS SkyBlock, and CS Survival use a neutral local server icon and show a local Coming Soon screen.
- No remote Home discovery, auto-connect, arbitrary address field, or server API.

## Pinned multiplayer entry

- PlantMC is inserted at index 0 of Minecraft's real saved server list using `play.plantmc.fun:25627`.
- The supplied transparent 64×64 PlantMC icon is used on Home and stored in `servers.dat`, protected from server-ping favicon replacement.
- Only the PlantMC row receives the supplied responsive 1009×202 banner, center-cropped without stretching and darkened slightly for vanilla text readability.
- A locally packaged India flag is drawn immediately before the PlantMC server name; other server rows remain vanilla.
- Duplicate PlantMC entries are removed; the retired fixed slot is removed without touching user-owned servers.
- Edit/Delete and row-move controls are disabled only while the exact canonical PlantMC entry is selected.
- All normal Minecraft add/edit/delete/reorder methods remain untouched for every other address, including arbitrary `play.*` domains.
- Every load/save reasserts PlantMC's canonical name, address, icon and first position; other saved servers keep their relative order.

## Retained Home safety

- YouTube and Discord cards still require animated second confirmation before browser hand-off.
- URLs remain exact HTTPS allowlisted values.
- No Discord/YouTube API, auto-join, WebSocket, background request, or credential handling.

## Zoom and native 26.2 actions

- Zoom supports hold or toggle mode, per-frame smooth zoom-in/out, and mouse-wheel magnification from 1.25× to 50×.
- While zooming, wheel-up zooms further in and wheel-down zooms back out; the hotbar is not changed. Outside active zoom, vanilla scrolling is untouched.
- Minecraft 26.2 shows its native Friends overlay from the custom Home top-right corner and Escape menu.
- In an integrated singleplayer world, the custom Escape menu has a clearly labelled **Open to LAN** action on every target. It opens each version's real vanilla screen: Open to LAN on 1.21.11, Share to LAN on 26.1, and Multiplayer Options on 26.2.
- Vanilla local LAN stays purely local; no internet relay or world-hosting system is bundled. The LAN action is unavailable on remote multiplayer servers.
- A MODS button is always present. With Mod Menu installed it opens Mod Menu; otherwise CS opens a read-only Fabric metadata list.

## Chat, screenshots, and Shield Statuses

- **Chat Improvements** is a local display-only module with optional timestamps, mention markers, consecutive system-message compaction, a visible repeat counter, Copy Last, and Hide/Show Chat.
- Signed player messages are never removed from Minecraft's reportable chat history; the module does not alter outgoing/network chat packets.
- Chat screen includes touch-friendly **Copy Last** and **Hide/Show Chat** buttons when the module is enabled, plus configurable keybinds.
- **Screenshot Manager** lists PNG screenshots from only the active launch profile's `screenshots` directory, with bounded lazy thumbnails, pagination, preview, copy-path, and explicit delete confirmation.
- Screenshot Manager has no upload, webhook, social-sharing, or background gameplay scan; image decoding starts only while the gallery is used.
- **Shield Statuses** reads Minecraft's exact native shield cooldown fraction: disabled is red, ready-soon is orange, and enabled is green.
- Optional interpolation performs a per-frame red→orange→green transition using vanilla tick progress.
- Shield item icons receive a thin status outline. First-person shields receive a second translucent model pass while the original/resource-pack texture and banner patterns remain untouched underneath.
- Shield Statuses integrates with Low Shield's matrix transform and adds no texture replacement, raw OpenGL, framebuffer, WalksyLib dependency, or upstream assets.

## Performance Engine

- Minecraft, Sodium, and external renderer settings are never read, changed, saved, or restored.
- Low, Balanced, and High Performance profiles control only CS-owned refresh/cache algorithms.
- Optional adaptive mode uses measured p95/p99 frametimes with hysteresis; it never lowers visual quality.
- Actual render-frame telemetry records average FPS, 1%/0.1% lows, p95/p99/p99.9 and worst frametime.
- A configurable benchmark key exports local CSV frame samples and a JSON summary with heap, GC, CPU-load, Java/architecture, profile, and detected performance mods.
- Enabled-module and styled-text caches are bounded/immutable to reduce per-frame allocation pressure.
- The render loop uses a pre-resolved immutable array of module/HUD/layout entries, avoiding repeated iterator, type and layout resolution work every frame.
- Single-line HUD width measurement has a no-substring fast path; no visual quality or Minecraft/Sodium setting is changed.
- Sodium, Embeddium, Rubidium, Canvas, VulkanMod, ImmediatelyFast, EntityCulling, MoreCulling, Lithium, FerriteCore, ModernFix, C2ME, and Noisium are detected for benchmark/capability reporting; their settings and internals are untouched.

## Automatic movable server HUD

- Scoreboard and Boss Bar no longer expose on/off controls or module toggle keys.
- They remain dormant when a server has no corresponding data.
- Scoreboard and Boss Bar both use Minecraft's original live native renderers; server text, colours, notch styles, progress, animation, ordering and visibility are not recreated.
- Both start at Minecraft's exact vanilla positions. Open Right Shift → HUD Layout and drag either element anywhere; Reset returns it to vanilla.
- Until the user moves an element no transform is applied. Adapter failure also leaves the original vanilla position/rendering untouched.

## CS Client player branding

- Optional Fabric server relay exchanges protocol-versioned `csclient:brand_hello` and `csclient:brand_presence` payloads.
- Clients send a hello only when the connected server explicitly advertises the channel; normal servers receive no unknown payload.
- UUID-keyed immutable capability cache uses UNKNOWN, CS_CLIENT, and NON_CS_CLIENT states and resets on disconnect/server change.
- Only bridge-confirmed CS players receive the badge; vanilla/unknown clients do not.
- Official packaged CS logo is rendered as a cached bitmap-font glyph in the existing nametag submission pipeline—no raw OpenGL, framebuffer, shader, filesystem, or network work per frame.
- Settings: Show CS Client Logo (ON), Show Logo Above Self (ON), and Small/Normal/Large scale.
- Badge follows vanilla nametag availability, does not render for invisible/no-nametag players, and stops beyond 48 blocks.
- The badge is best-effort branding, not cryptographic proof; a custom client can imitate the open payload protocol.

## HUD display and style system

- Every movable HUD display now starts with **Show Background OFF**; the old forced-ON config key is migrated away.
- Minecraft, Feather Compact, Lunar, and CS Graphite are four genuinely different render presets with distinct spacing, typography, shells, rails, corners, and metric layouts.
- Settings previews use the exact gameplay render path instead of forcing a fake background.
- FPS, Ping, and TPS use semantic green/amber/red states; Ping includes signal bars and FPS can show a compact history graph.
- X/Y coordinates are hidden from module settings. Position changes happen only in Right Shift → HUD Layout.
- The original server Scoreboard is move-only: no scale, font, colour, score, or content controls are exposed.
- Keystrokes/WASD rendering remains unchanged.

## Skin, profile head, and launcher bridge

- The in-game filesystem browser was removed. Skin/cape buttons use the platform-native PNG chooser path.
- Public username lookup uses the modern Minecraft Services endpoint with the official Mojang endpoint as fallback, then reads skin/cape textures from the session server.
- Launcher profiles and CS local profiles both pass the asynchronous appearance commit guard.
- Active profile surfaces render the current skin head and hat layer instead of a generic profile icon.
- Local appearance files use isolated UUID folders and a once-per-second atomic index sync contract for launcher↔client changes.
- The launcher bridge requests maximum supported display refresh without changing Minecraft VSync/FPS/Sodium settings.

## HUD collision safety

- Scaled HUD widgets cannot be dragged or resized into another widget.
- Diagonal dragging slides along collision edges when one axis remains free.
- Blocked movement keeps the previous safe position.
- Existing and preset positions are separated when the HUD editor opens.

## Retained systems

User panorama, direct mob health labels, visual-only Hitbox filters, Appearance Studio, Clear Fluids, Low Shield, Low Fire, Block Break, Block Overlay, RShift HUD Layout, Modules, and 57 unique modules remain.
