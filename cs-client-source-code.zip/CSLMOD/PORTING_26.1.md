# CS Client V1 — Minecraft 26.1 adapter

Minecraft **26.1** remains a supported Java 25 target.

- Mojang-name / unobfuscated Loom target.
- Screen/browser adapter retains explicit confirmation and exact allowlisting.
- `joinFeaturedServer()` opens the native connection path only for `play.plantmc.fun:25627` after a Home click.
- User panorama, direct mob-health labels, Clear Fluids, Hitbox filtering, Appearance Studio, Low Shield, Low Fire, and the Home server rail are packaged.

26.2 is a separate exact target at `versions/26.2`; do not install two target JARs together.
