# Installing CS Client V1

1. Remove older CS Client JARs for the same Minecraft version.
2. Install matching Fabric Loader and Fabric API.
3. Put **exactly one** matching V1 JAR in `mods`:
   - `cs-client-V1+1.21.11.jar` — Minecraft 1.21.11, Java 21
   - `cs-client-V1+26.1.jar` — Minecraft 26.1, Java 25
   - `cs-client-V1+26.2.jar` — Minecraft 26.2, Java 25, Fabric Loader 0.19.3+, Fabric API `0.157.0+26.2`
4. Never install multiple CS Client target JARs together.

## Home server rail

- **PlantMC** (`play.plantmc.fun:25627`) is the only explicit joinable Home slot.
- Clicking it opens Minecraft’s own connection screen and starts the connection only then.
- The four remaining fixed slots show a local **Coming Soon** popup.
- CS Client does not auto-connect, background-ping, fetch server data, or expose an arbitrary server-address input through the Home rail.

## Integrity

```bash
sha256sum -c releases/SHA256SUMS.txt
```
