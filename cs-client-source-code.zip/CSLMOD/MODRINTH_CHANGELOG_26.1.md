# ✦ CS Client V1 — Minecraft 26.1

> A customizable client-side Fabric experience with a responsive interface, useful HUD tools, visual controls, and performance options.

## ◆ Included Features

- **54 configurable modules** for HUD, PvP, visuals, movement, world information, and performance.
- **CS Client Branding** badge for server-relay-confirmed CS players; official cached logo, self OFF by default.
- Complete **HUD Layout Editor** with dragging, scaling, presets, and automatic widget placement.
- **Theme Studio** with colors, presets, live previews, and animation controls.
- Password-free local profiles with local **skin and cape** support.
- Skin import through PNG file, direct URL, or public Mojang username.
- **Low, Balanced, and High Performance** internal profiles with real frametime telemetry and no graphics-setting changes.
- Right Shift quick menu and configurable module keybinds.
- Responsive Home, Pause, Settings, Modules, and Appearance screens.

## ◆ Requirements

- **Minecraft:** 26.1
- **Fabric Loader:** 0.19.3+
- **Fabric API:** 0.145.1+26.1
- **Java:** 25
- **File:** `cs-client-V1+26.1.jar`

> Install only the JAR matching Minecraft 26.1. Separate CS Client V1 builds are available for Minecraft 1.21.11 and 26.2.

**CS Client V1 is proprietary and source-available, not open source.**
