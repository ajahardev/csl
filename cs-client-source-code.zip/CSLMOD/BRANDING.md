# CS Client V1 branding and UI language

## Product identity

- Product: **CS Client V1**
- Publisher: **Craft Studio**
- Runtime namespace: `com.craftstudio.csclient`

## Home server rail rule

- The Home screen owns a compact left-edge fixed server logo line.
- Use compact logos only at rest; a small status dot and hover-only halo provide interaction feedback without labels, cards, or IP text.
- The top PlantMC icon uses the user-supplied local logo only for the named fixed server slot.
- Other slots use an original neutral server icon and a local Coming Soon state.
- Do not imitate another client’s logo, exact geometry, remote list service, player-count presentation, or server API.

## Connection rule

- The only Home rail network action is an explicit click on PlantMC’s exact address: `play.plantmc.fun:25627`.
- No automatic connection, background ping, remote server discovery, editable arbitrary address, or hidden fallback host.
- All other rail clicks remain local and open Coming Soon only.

## External-link rule

- Community-card click always opens animated confirmation first.
- Exact HTTPS allowlist only; no arbitrary URL opening or external-service integration.
