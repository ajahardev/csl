# CS Client V1 — implementation research references

## Home server rail

The user explicitly requested a Home-screen left icon rail structurally similar to Feather’s server access, with one joinable fixed icon and local Coming Soon placeholders.

Research sources inspected before implementation:

- Feather News documents server access from a left sidebar and draggable server-list behavior: https://news.feathermc.com/
- Feather’s server-list background documentation confirms that its server presentation is a server-list feature with branded entry surfaces: https://docs.feathermc.com/server-api/meta/server-list-background/
- The supplied Feather Home imagery was visually inspected for hierarchy only: a compact icon line, one clear selected/featured state, status dots, and no need for copied geometry/assets.

Applied CS interpretation:

- original CS graphite left rail rather than a Feather copy;
- five icon-only local slots in a narrow vertical rail, small hover halo/status dots, no name/IP/card surface or fake player/ping values;
- one explicit top PlantMC action and four neutral local Coming Soon slots;
- no Feather code, texture, network service, API, proxy, remote server list, or branding copied.

## Fixed PlantMC connection

The user supplied the exact PlantMC Java address:

```text
name:    PlantMC
address: play.plantmc.fun:25627
```

No unverified third-party PlantMC logo was packaged. The Home icon is original local flame artwork and has no runtime download path.

Address research cross-checks found current public listings that identify `play.plantmc.fun:25627` as a PlantMC Java address. No listing/API is queried by CS Client at runtime. The address is hard-coded and target adapters reject any other Home address.

The implementation uses each Minecraft target’s native Connect/ServerInfo or Connect/ServerData flow only after the user clicks the top icon. The other icons cannot connect.

## V1 naming pass

The request was interpreted as a normal stable release naming change:

```text
product label: CS Client V1
public package label: V1 (Fabric metadata base version: 1.0.0)
```

This removes pre-release labels from the packaged metadata, Home, Pause, Settings, Loading, documentation, release artifact names, and current release checks. Java package IDs and the Fabric mod ID remain stable for compatibility.

## 26.2 renderer compatibility retained

Minecraft 26.2’s Gui/Hud and renderer migration was previously verified against its released Fabric toolchain. CS V1 retains native Gui/Hud/render submission APIs and has no direct OpenGL render call. Actual Minecraft/Pojav/OpenGL/Vulkan runtime testing remains a separate requirement.

## Icon-rail correction after direct Home reference review

A closer review of the supplied/reference Home image established that the intended left rail is not a stack of labeled server cards. It is a narrow **icon-only vertical line**:

- each entry is a compact server logo;
- a tiny availability/status dot sits at the lower-right;
- there is no `SERVERS` title, IP/address line, text badge, player count, or rectangular card surface at rest;
- click targets are the icons themselves.

CS Client V1 was corrected accordingly: the prior large labeled Home cards were removed. The top packaged PlantMC logo remains the explicit join icon; four compact neutral icons remain local Coming Soon slots under the already-confirmed connection rule.

## Module behavior references

The following public projects were reviewed for behavior and API research. CS Client keeps independent implementations; no third-party source or assets were secretly copied. See `MODULE_RESEARCH.md`.

- Shulker Preview — MIT — https://github.com/kgriff0n/shulker-preview
- HealthIndicators — LGPL-3.0 — https://github.com/AdyTech99/HealthIndicators
- Clear Water — MIT — https://github.com/ExpensiveKoala/Clear-Water
- AutoGG — MIT — https://github.com/ModLabsCC/AutoGG
- No Fog — MIT — https://github.com/Virtuoel/NoFog
